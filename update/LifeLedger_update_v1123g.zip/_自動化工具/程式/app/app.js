// LifeLedger 單一視窗：首頁、直接看月報／生活帳本／隨手記、設定、關於。跟 Python 溝通走 window.pywebview.api
(() => {
'use strict';
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let api = null, ST = {}, LANG = 'zh', busy = false, curTask = '', viewUrl = '', firstRun = false;
const THEMES = ['pastel', 'mint', 'ocean', 'latte', 'night'];
const CARDS = {
  report: ['📊', 'report', 'sub_report'], book: ['📒', 'book', 'sub_book'], ledger: ['📱', 'ledger', 'sub_ledger'], excel: ['📗', 'excel', 'sub_excel'],
  folder: ['📁', 'folder', 'sub_folder'], settings: ['⚙️', 'settings', 'sub_settings'], help: ['📖', 'help', 'sub_help'], update: ['🔄', 'update', 'sub_update'],
};
const COLORS = ['--t1', '--t2', '--t3', '--t4', '--t5', '--t6', '--t7', '--t8'];

function t(k, v = {}) {
  let s = (I18N[LANG] && I18N[LANG][k]) ?? I18N.zh[k] ?? k;
  for (const [a, b] of Object.entries(v)) s = s.split('{' + a + '}').join(b);
  return s;
}
function toast(msg, ms = 2600) { const el = $('#toast'); el.textContent = msg; el.classList.remove('hidden'); clearTimeout(toast.h); toast.h = setTimeout(() => el.classList.add('hidden'), ms); }
function confirmBox(msg) { return new Promise(res => modal(`<p style="line-height:1.7">${esc(msg)}</p><div class="btns"><button class="ghost" data-x="0">${t('cancel')}</button><button class="primary" data-x="1">${t('ok')}</button></div>`, el => {
  $$('[data-x]', el).forEach(b => b.onclick = () => { closeModal(); res(b.dataset.x === '1'); }); })); }
function modal(html, bind) { $('#mbox').innerHTML = html; $('#modal').classList.remove('hidden'); bind && bind($('#mbox')); }
function closeModal() { $('#modal').classList.add('hidden'); $('#mbox').innerHTML = ''; }

// ---------- 語言、配色 ----------
function applyLang() {
  document.documentElement.lang = LANG === 'en' ? 'en' : 'zh-Hant';
  $$('[data-t]').forEach(el => el.textContent = t(el.dataset.t));
  $('#themeSel').innerHTML = THEMES.map(k => `<option value="${k}">${t('th_' + k)}</option>`).join('');
  $('#themeSel').value = document.body.dataset.theme; $('#langSel').value = LANG;
}
function setTheme(k) { document.body.dataset.theme = k; api.set_ui('theme', k); }

// ---------- 首頁 ----------
function greeting() {
  const h = new Date().getHours();
  return h >= 5 && h < 11 ? t('g_morning') + ' ☀️' : h < 14 && h >= 11 ? t('g_noon') + ' 🍱' : h >= 14 && h < 18 ? t('g_afternoon') + ' ☕' : t('g_night') + ' 🌙';
}
function dateLine() {
  const d = new Date();
  if (LANG === 'en') return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  return t('date_fmt', { m: d.getMonth() + 1, d: d.getDate(), w: '日一二三四五六'[d.getDay()] });
}
function renderHome() {
  $('#greet').textContent = greeting();
  $('#verPill').textContent = 'v' + ST.version + (ST.latest ? '　✓' : '');
  $('#verSide').textContent = 'v' + ST.version;
  renderBanner();
  if (!busy) { $('#runLabel').textContent = t('run'); $('#runSub').textContent = ST.last_report ? t('run_sub_last', { t: ST.last_report }) : t('run_sub_none'); }
  $('#reorderBtn').textContent = $('#grid').classList.contains('edit') ? t('reorder_done') : '↕ ' + t('reorder');
  const order = (ST.order || []).filter(k => CARDS[k]).concat(Object.keys(CARDS).filter(k => !(ST.order || []).includes(k)));
  $('#grid').innerHTML = order.map((k, i) => { const [em, ti, sub] = CARDS[k];
    return `<div class="card" draggable="false" data-k="${k}" style="background:var(${COLORS[i % 8]})"><div class="em">${em}</div><b>${esc(t(ti))}</b><small>${esc(t(sub))}</small></div>`; }).join('');
  $$('#grid .card').forEach(c => c.onclick = () => { if (!$('#grid').classList.contains('edit')) action(c.dataset.k); });
  bindDrag();
  $('#tip').textContent = t('tip');
}
function renderBanner() {
  const b = $('#banner'); b.className = 'banner';
  if (ST.just_updated) {
    b.classList.add('box', 'done');
    b.innerHTML = `<span>${esc(t('just_updated', { v: ST.just_updated.to }))}${(ST.just_updated.notes || []).length ? '：' + esc(ST.just_updated.notes.join('、')) : ''}</span><button id="bBtn">${t('got_it')}</button>`;
    $('#bBtn').onclick = () => { api.dismiss_just_updated(); ST.just_updated = null; renderBanner(); };
  } else if (ST.remote && ST.remote.available) {
    b.classList.add('box', 'new');
    b.innerHTML = `<span>${esc(t('new_ver', { v: ST.remote.version }))}${ST.remote.notes.length ? '：' + esc(ST.remote.notes.join('、')) : ''}</span><button id="bBtn">${t('update_now')}</button>`;
    $('#bBtn').onclick = () => { b.innerHTML = `<span>${t('downloading')}</span>`; api.install_update(); };
  } else {
    b.innerHTML = `<span>${esc(dateLine())}　・　${esc(t('auto_note'))}</span>`;
  }
}
function action(k) {
  if (k === 'report' || k === 'book' || k === 'ledger') return go(k);
  if (k === 'settings') return go('settings');
  if (k === 'update') { toast(t('update') + '…'); return checkUpdate(true); }
  api.open(k).then(ok => { if (!ok) toast(t('view_missing')); });
}

// 拖曳調整卡片順序（按「調整順序」後才能拖）
function bindDrag() {
  const g = $('#grid'); if (!g.classList.contains('edit')) return;
  let drag = null;
  $$('.card', g).forEach(c => {
    c.draggable = true;
    c.ondragstart = e => { drag = c; c.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; };
    c.ondragend = () => { c.classList.remove('dragging'); drag = null; saveOrder(); };
    c.ondragover = e => { e.preventDefault(); if (!drag || drag === c) return;
      const r = c.getBoundingClientRect(); const after = (e.clientX - r.left) > r.width / 2;
      g.insertBefore(drag, after ? c.nextSibling : c); };
  });
}
function saveOrder() {
  ST.order = $$('#grid .card').map(c => c.dataset.k); api.set_ui('order', ST.order);
  $$('#grid .card').forEach((c, i) => c.style.background = `var(${COLORS[i % 8]})`);
}

// ---------- 更新月報、補抓、健檢（背景，進度顯示在首頁） ----------
async function runTask(kind, arg) {
  if (busy) return toast(t('busy'));
  if (await api.task_running() && !(await confirmBox(t('running_q')))) return;
  const r = await api.run_task(kind, arg ?? null);
  if (!r.ok) return toast(r.error === 'busy' ? t('busy') : 'error: ' + r.error);
  busy = true; curTask = t('task_' + kind); go('home');
  $('#runBtn').disabled = true; $('#runLabel').textContent = t('running', { t: curTask }); $('#runSub').textContent = t('run_sub_busy');
  $('#progress').classList.remove('hidden'); $('#progress .bar').classList.remove('hidden'); $('#log').textContent = ''; $('#status').textContent = t('status_prep'); $('#tip').classList.add('hidden');
}
function onLog(line) {
  const m = line.match(/^\s*===\s*(.+?)\s*===/);
  if (m) $('#status').textContent = t('status_now', { s: m[1].replace(/^[\d.a-z]+\s*/, '') });
  const L = $('#log'); L.textContent += line + '\n'; L.scrollTop = L.scrollHeight;
}
async function onDone(d) {
  busy = false; ST = Object.assign(ST, d.state); $('#runBtn').disabled = false; $('#progress .bar').classList.add('hidden');
  const name = curTask; renderHome();
  if (d.rc === 0) {
    $('#progress').classList.add('hidden'); $('#tip').classList.remove('hidden'); toast(t('done_ok', { t: name }));
    if (d.kind === 'report' && await confirmBox(t('open_report_q'))) go('report');
    if (d.kind === 'backfill') go('report');
  } else {
    $('#status').textContent = t('done_fail', { t: name }); $('#tip').classList.remove('hidden');
    modal(`<h3>⚠ ${esc(name)}</h3><p style="line-height:1.7">${esc(name + ' ' + t('fail_msg'))}</p><div class="btns"><button class="ghost" id="mLogs">${t('ab_logs')}</button><button class="ghost" id="mRep">${t('rp_button')}</button><button class="primary" id="mOk">${t('ok')}</button></div>`,
      el => { $('#mOk', el).onclick = closeModal; $('#mLogs', el).onclick = () => { api.open('logs'); closeModal(); }; $('#mRep', el).onclick = () => reportDialog(name + ' ' + t('fail_short')); });
  }
}

// ---------- 直接看月報／生活帳本／隨手記 ----------
function showView(k) {
  const title = t(k); $('#viewTitle').textContent = title;
  const f = $('#viewFrame'), miss = $('#viewMissing');
  if (k === 'ledger') viewUrl = ST.ledger_url;
  else viewUrl = ST.reports[k] ? ST.base + 'reports/' + encodeURIComponent(k === 'report' ? 'LifeLedger月報.html' : 'LifeLedger生活帳本.html') : '';
  if (!viewUrl) { f.classList.add('hidden'); miss.classList.remove('hidden'); miss.textContent = t('view_missing'); return; }
  miss.classList.add('hidden'); f.classList.remove('hidden');
  if (f.dataset.src !== viewUrl) { f.src = viewUrl; f.dataset.src = viewUrl; }
}

// ---------- 頁面切換 ----------
let curPage = 'home';
function go(p) {
  curPage = p;
  $$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.page === p));
  const sec = ['report', 'book', 'ledger'].includes(p) ? 'view' : p;
  $$('.page').forEach(s => s.classList.toggle('hidden', s.id !== 'page-' + sec));
  if (sec === 'view') showView(p);
  if (p === 'settings') openSettings();
  if (p === 'about') renderAbout();
  if (p === 'home') renderHome();
}

// ---------- 設定 ----------
const SPAGES = ['s_ledger', 's_bills', 's_mail', 's_report', 's_web', 's_adv', 's_ui'];
const BANKS = ['台新', '永豐', '玉山', '聯邦', '中信', '星展', '國泰', '富邦', '第一', '渣打', '凱基', '遠東', '兆豐', '華南', '合庫', '彰銀', '上海', '元大', '新光', '台企', 'LINE Bank', '將來', '樂天'];
const KINDS = { gmail: 'https://myaccount.google.com/apppasswords', yahoo: 'https://login.yahoo.com/myaccount/security', hinet: '', outlook: '', imap: '' };
let SV = null, sPage = 0, banks = [], mboxes = [];
async function openSettings(page) {
  SV = await api.get_settings();
  banks = SV.bills.banks.map(n => ({ name: n, password: '' }));
  mboxes = SV.mailboxes.map(m => Object.assign({}, m, { password: '' }));
  sPage = page ?? sPage; renderSettings();
}
function field(id, label, opt = {}) {
  const v = esc(id in F ? F[id] : (opt.value ?? '')); const type = (opt.secret && !(F['show_' + id])) ? 'password' : 'text';
  return `<div class="row"><label for="${id}">${esc(label)}</label><input id="${id}" type="${type}" value="${v}" ${opt.ph ? `placeholder="${esc(opt.ph)}"` : ''} autocomplete="off">
    ${opt.secret ? `<label class="chk"><input type="checkbox" data-show="${id}"> ${t('show')}</label>` : ''}${opt.isSet ? `<span class="ok">${t('is_set')}</span>` : ''}</div>`;
}
function link(text, url) { return `<span class="link" data-url="${esc(url)}">🔗 ${esc(text)}</span>`; }
function renderSettings() {
  $('#stabs').innerHTML = SPAGES.map((k, i) => `<button data-i="${i}" class="${i === sPage ? 'on' : ''}">${['👤', '💳', '📬', '💌', '🌐', '🧩', '🎨'][i]}　${esc(t(k))}</button>`).join('') + `<div class="privacy">${esc(t('privacy'))}</div>`;
  $$('#stabs button').forEach(b => b.onclick = () => { collect(); sPage = +b.dataset.i; renderSettings(); });
  const S = SV, B = $('#sbody');
  const pages = [
    () => `<h2>👤 ${t('s_ledger')}</h2><p class="intro">${esc(t('l_intro'))}</p><div class="box">${field('l_user', t('l_user'), { value: S.ledger.user })}
      ${field('l_pw', t('l_pw'), { secret: true, isSet: S.ledger.has_password })}<p class="note">${esc(t('blank_keep'))}</p></div>
      <p class="note">${esc(t('l_noacc'))}</p>${link(t('l_open'), ST.ledger_url)}
      <div class="box" style="margin-top:14px"><p class="note">${esc(t('l_server'))}</p>${field('l_url', t('l_server_url'), { value: S.ledger.url })}</div>`,
    () => `<h2>💳 ${t('s_bills')}</h2><p class="intro">${esc(t('b_intro'))}</p><div class="box">
      ${field('b_def', t('b_default'), { secret: true, isSet: S.bills.has_default })}<p class="note">${esc(t('b_default_note'))}</p>
      ${field('b_bd', t('b_bd'), { secret: true, isSet: S.bills.has_birthday })}<p class="note">${esc(t('b_bd_note'))}</p></div>
      <div class="box"><h3>${t('b_other')}</h3><p class="note">${esc(t('b_other_note'))}</p><div class="list" id="bankList"></div>
      <div class="row"><label>${t('b_bank')}</label><input id="b_name" list="bankNames" style="width:140px"><datalist id="bankNames">${BANKS.map(b => `<option value="${b}">`).join('')}</datalist>
      <input id="b_pw" type="password" placeholder="${esc(t('b_pw'))}" style="width:170px" autocomplete="off"><button class="ghost small" id="b_add">${t('b_add')}</button></div></div>`,
    () => `<h2>📬 ${t('s_mail')}</h2><p class="intro">${esc(t('m_intro'))}</p><p class="note">${esc(t('m_gas'))}</p>
      <div class="box"><div class="list" id="mbList"></div><div class="row"><button class="ghost small" id="mbAdd">${t('add')}</button><span class="grow"></span><button class="ghost small" id="mbTest">${t('m_test')}</button></div><pre class="out" id="mbOut"></pre></div>
      <div class="box">${field('my_name', t('m_myname'), { value: S.my_name })}<p class="note">${esc(t('m_myname_note'))}</p></div>`,
    () => `<h2>💌 ${t('s_report')}</h2><p class="intro">${esc(t('r_intro'))}</p><label class="chk"><input type="checkbox" id="r_on" ${fv('r_on', S.mail.enabled) ? 'checked' : ''}> ${t('r_on')}</label>
      <div class="box" style="margin-top:10px">${field('r_from', t('r_from'), { value: S.mail.from })}${field('r_pw', t('r_pw'), { secret: true, isSet: S.mail.has_app_password })}${field('r_to', t('r_to'), { value: S.mail.to })}
      <div class="row"><label>${t('r_day')}</label><input id="r_day" type="number" min="1" max="28" value="${esc(fv('r_day', S.mail.mail_day))}" style="width:80px"><span class="note">${esc(t('r_day_note'))}</span></div></div>
      <h3>${esc(t('r_how'))}</h3><p class="note">${esc(t('r_steps'))}</p>${link(t('r_link1'), 'https://myaccount.google.com/signinoptions/twosv')}<br>${link(t('r_link2'), 'https://myaccount.google.com/apppasswords')}
      <div class="row"><button class="ghost small" id="r_test">${t('r_test')}</button><span id="r_out"></span></div>`,
    () => `<h2>🌐 ${t('s_web')}</h2><p class="intro">${esc(t('w_intro'))}</p><p class="note">${esc(t('w_note'))}</p><label class="chk"><input type="checkbox" id="w_on" ${fv('w_on', S.web.enabled) ? 'checked' : ''}> ${t('w_on')}</label>
      <div class="box" style="margin-top:10px">${field('w_token', t('w_token'), { secret: true, isSet: S.web.has_token })}${field('w_pw', t('w_pw'), { secret: true, isSet: S.web.has_password })}${field('w_pw2', t('w_pw2'), { secret: true })}${field('w_repo', t('w_repo'), { value: S.web.repo })}</div>
      <h3>${esc(t('w_how'))}</h3><p class="note">${esc(t('w_steps'))}</p>${link(t('w_link'), 'https://github.com/settings/tokens/new')}
      <div class="row"><button class="ghost small" id="w_pub">${t('w_publish')}</button></div><pre class="out" id="w_out"></pre>`,
    () => { const y = new Date().getFullYear(), rs = S.adv.report_start;
      return `<h2>🧩 ${t('s_adv')}</h2>
      <div class="box"><h3>${t('a_back')}</h3><p class="note">${esc(t('a_back_note', { c: rs || t('a_auto') }))}</p><div class="row">${t('a_from')}
        <input id="a_y" type="number" min="2015" max="${y}" value="${rs ? rs.slice(0, 4) : y}" style="width:90px"> ${t('a_year')}
        <input id="a_m" type="number" min="1" max="12" value="${rs ? +rs.slice(5, 7) : 1}" style="width:70px"> ${t('a_month')}<button class="ghost small" id="a_go">${t('a_start')}</button></div></div>
      <div class="box"><h3>${t('a_dirs')}</h3><p class="note">${esc(t('a_dirs_note'))}</p><div class="list" id="dirList"></div><div class="row"><button class="ghost small" id="a_add">${t('a_add_dir')}</button></div></div>
      <div class="box"><h3>${t('a_family')}</h3>${field('a_spouse', t('a_spouse'), { value: S.adv.spouse_names.join('、') })}<p class="note">${esc(t('a_spouse_note'))}</p>
        ${field('a_salary', t('a_salary'), { value: S.adv.salary_payer })}<p class="note">${esc(t('a_salary_note'))}</p></div>
      <div class="box"><h3>${t('a_pin')}</h3><p class="note">${esc(t('a_pin_note'))}</p><div class="row"><label class="chk"><input type="checkbox" id="a_auto" ${S.autostart ? 'checked' : ''}> ${t('a_autostart')}</label>
        <span class="grow"></span><button class="ghost small" id="a_fix">${t('a_fix')}</button></div></div>
      <button class="ghost" id="a_health">${t('a_health')}</button>`; },
    () => `<h2>🎨 ${t('s_ui')}</h2><div class="box"><div class="row"><label>${t('ui_theme')}</label><select id="u_theme">${THEMES.map(k => `<option value="${k}" ${document.body.dataset.theme === k ? 'selected' : ''}>${t('th_' + k)}</option>`).join('')}</select></div>
      <div class="row"><label>${t('ui_lang')}</label><select id="u_lang"><option value="zh">繁體中文</option><option value="en">English</option></select></div><p class="note">${esc(t('ui_lang_note'))}</p></div>`,
  ];
  B.innerHTML = pages[sPage](); B.scrollTop = 0;
  $$('[data-url]', B).forEach(a => a.onclick = () => api.open_url(a.dataset.url));
  $$('[data-show]', B).forEach(c => c.onchange = () => { $('#' + c.dataset.show).type = c.checked ? 'text' : 'password'; });
  $('#sPrev').disabled = sPage === 0; $('#sNext').disabled = sPage === SPAGES.length - 1;
  if (sPage === 1) { renderBanks(); $('#b_add').onclick = addBank; }
  if (sPage === 2) { renderMb(); $('#mbAdd').onclick = () => mailDialog(null); $('#mbTest').onclick = testMail; }
  if (sPage === 3) $('#r_test').onclick = () => { const u = $('#r_from').value.trim(), p = $('#r_pw').value;
    if (!u || (!p && !SV.mail.has_app_password)) { $('#r_out').innerHTML = `<span class="err">${t('r_need')}</span>`; return; }
    $('#r_out').innerHTML = `<span class="muted">${t('m_testing')}</span>`; api.test_gmail(u, p); };
  if (sPage === 4) $('#w_pub').onclick = publishWeb;
  if (sPage === 5) { renderDirs(); $('#a_add').onclick = async () => { const d = await api.pick_folder(); if (d && !SV.adv.bills.includes(d)) { SV.adv.bills.push(d); renderDirs(); } };
    $('#a_go').onclick = backfill; $('#a_auto').onchange = e => api.set_autostart(e.target.checked);
    $('#a_fix').onclick = async () => toast(await api.fix_shortcuts() ? t('a_fixed') : 'error'); $('#a_health').onclick = () => runTask('health'); }
  if (sPage === 6) { $('#u_lang').value = LANG; $('#u_theme').onchange = e => { setTheme(e.target.value); applyLang(); };
    $('#u_lang').onchange = e => { collect(); LANG = e.target.value; api.set_ui('lang', LANG); applyLang(); renderSettings(); }; }
}
function renderBanks() {
  $('#bankList').innerHTML = banks.length ? banks.map((b, i) => `<div class="item"><b>${esc(b.name)}</b><span class="${b.password ? 'muted' : 'ok'}">${b.password ? t('b_new') : t('is_set')}</span><span class="grow"></span><button data-del="${i}">${t('del')}</button></div>`).join('')
    : `<div class="empty1">${t('b_none')}</div>`;
  $$('[data-del]', $('#bankList')).forEach(b => b.onclick = () => { banks.splice(+b.dataset.del, 1); renderBanks(); });
}
function addBank() {
  const n = $('#b_name').value.trim(), p = $('#b_pw').value.trim();
  if (!n || !p) return toast(t('b_bank') + ' / ' + t('b_pw'));
  const ex = banks.find(b => b.name === n); ex ? ex.password = p : banks.push({ name: n, password: p });
  $('#b_name').value = ''; $('#b_pw').value = ''; renderBanks();
}
function mbLabel(m) { return m.kind === 'outlook' ? 'Outlook' + (m.account ? '（' + m.account + '）' : '') : (m.user || m.name) + '　（' + t('k_' + m.kind) + (m.host ? '，' + m.host : '') + '）'; }
function renderMb() {
  $('#mbList').innerHTML = mboxes.length ? mboxes.map((m, i) => `<div class="item"><span>${esc(mbLabel(m))}</span><span class="grow"></span><button data-ed="${i}">${t('edit')}</button><button data-del="${i}">${t('del')}</button></div>`).join('')
    : `<div class="empty1">${t('m_none')}</div>`;
  $$('[data-ed]', $('#mbList')).forEach(b => b.onclick = () => mailDialog(+b.dataset.ed));
  $$('[data-del]', $('#mbList')).forEach(b => b.onclick = async () => { if (await confirmBox(t('del') + '：' + mbLabel(mboxes[+b.dataset.del]) + '？')) { mboxes.splice(+b.dataset.del, 1); renderMb(); } });
}
function mailDialog(i) {
  const m = i == null ? { kind: 'gmail', user: '', host: '', port: 993, account: '', has_password: false } : mboxes[i];
  modal(`<h3>📬 ${t('m_kind')}</h3><div class="kinds">${Object.keys(KINDS).map(k => `<label><input type="radio" name="mk" value="${k}" ${m.kind === k ? 'checked' : ''}> ${t('k_' + k)}</label>`).join('')}</div>
    <div class="hint" id="mkHint"></div><div id="mkLink" style="margin:6px 0"></div><div id="mkForm"></div>
    <div class="btns"><button class="ghost" id="mkCancel">${t('cancel')}</button><button class="primary" id="mkOk">${t('ok')}</button></div>`, el => {
    const form = () => { const k = $('input[name=mk]:checked', el).value;
      $('#mkHint', el).textContent = t('kt_' + k); $('#mkLink', el).innerHTML = KINDS[k] ? link(t('m_help'), KINDS[k]) : '';
      $$('[data-url]', el).forEach(a => a.onclick = () => api.open_url(a.dataset.url));
      $('#mkForm', el).innerHTML = k === 'outlook' ? field('mk_acc', t('m_only'), { value: m.account }) + `<p class="note">${esc(t('m_only_note'))}</p>`
        : field('mk_user', t('m_addr'), { value: m.user }) + field('mk_pw', k === 'gmail' || k === 'yahoo' ? t('m_apppw') : t('m_pw'), { secret: true, isSet: m.has_password })
          + (m.has_password ? `<p class="note">${esc(t('m_keep'))}</p>` : '') + (k === 'imap' ? field('mk_host', t('m_host'), { value: m.host }) + field('mk_port', t('m_port'), { value: m.port || 993 }) : '');
      $$('[data-show]', el).forEach(c => c.onchange = () => { $('#' + c.dataset.show).type = c.checked ? 'text' : 'password'; }); };
    $$('input[name=mk]', el).forEach(r => r.onchange = form); form();
    $('#mkCancel', el).onclick = closeModal;
    $('#mkOk', el).onclick = () => { const k = $('input[name=mk]:checked', el).value, v = id => ($('#' + id, el) || {}).value?.trim() ?? '';
      const nm = { id: m.id, kind: k, account: v('mk_acc'), user: v('mk_user'), password: ($('#mk_pw', el) || {}).value || '', host: v('mk_host'), port: +v('mk_port') || 993, has_password: m.has_password };
      if (k !== 'outlook') { if (!nm.user) return toast(t('m_addr')); if (!nm.password && !(m.has_password && m.kind === k)) return toast(t('err_mailpw')); if (k === 'imap' && !nm.host) return toast(t('err_mailhost')); }
      if (i == null) mboxes = mboxes.filter(x => !(x.kind === k && (x.user || x.account) === (nm.user || nm.account))).concat([nm]); else mboxes[i] = nm;
      closeModal(); renderMb(); };
  });
}
function renderDirs() {
  const L = SV.adv.bills; $('#dirList').innerHTML = L.length ? L.map((d, i) => `<div class="item"><span>${esc(d)}</span><span class="grow"></span><button data-del="${i}">${t('del')}</button></div>`).join('') : `<div class="empty1">${t('a_only_main')}</div>`;
  $$('[data-del]', $('#dirList')).forEach(b => b.onclick = () => { L.splice(+b.dataset.del, 1); renderDirs(); });
}
// 目前這一頁填的值記到 SV／暫存，換頁不會不見
const F = {};
function collect() { $$('#sbody input, #sbody select').forEach(el => { if (el.id) F[el.id] = el.type === 'checkbox' ? el.checked : el.value; }); }
function fv(id, d = '') { return id in F ? F[id] : d; }
function payload() {
  collect(); const S = SV;
  return {
    ledger: { user: fv('l_user', S.ledger.user), password: fv('l_pw'), url: fv('l_url', S.ledger.url) },
    bills: { default: fv('b_def'), birthday: fv('b_bd'), banks },
    mailboxes: mboxes, my_name: fv('my_name', S.my_name),
    mail: { enabled: fv('r_on', S.mail.enabled), from: fv('r_from', S.mail.from), to: fv('r_to', S.mail.to), app_password: fv('r_pw'), mail_day: +fv('r_day', S.mail.mail_day) },
    web: { enabled: fv('w_on', S.web.enabled), token: fv('w_token'), password: fv('w_pw'), repo: fv('w_repo', S.web.repo) },
    adv: { bills: S.adv.bills, spouse: fv('a_spouse', S.adv.spouse_names.join('、')), salary: fv('a_salary', S.adv.salary_payer) },
  };
}
async function saveSettings(quiet) {
  const p = payload();
  if (p.bills.birthday && !/^\d{8}$/.test(p.bills.birthday)) { sPage = 1; renderSettings(); toast(t('err_birthday')); return false; }
  if (p.web.password && (p.web.password.length < 8 || p.web.password !== fv('w_pw2'))) { sPage = 4; renderSettings(); toast(t('w_pwbad')); return false; }
  if (!quiet && p.mail.enabled && !(p.mail.from && (p.mail.app_password || SV.mail.has_app_password)) && !(await confirmBox(t('r_off_q')))) { sPage = 3; renderSettings(); return false; }
  const r = await api.save_settings(p);
  if (!r.ok) { toast(t('err_' + r.error)); return false; }
  for (const k of Object.keys(F)) if (/pw|_def$|_bd$|token/.test(k)) delete F[k];   // 存好就清掉打過的密碼
  SV = await api.get_settings(); banks = SV.bills.banks.map(n => ({ name: n, password: '' })); mboxes = SV.mailboxes.map(m => Object.assign({}, m, { password: '' }));
  if (!quiet) { $('#sMsg').textContent = t('saved'); setTimeout(() => $('#sMsg').textContent = '', 3000); renderSettings(); }
  ST = Object.assign(ST, await api.state());
  if (!quiet && firstRun) { firstRun = false; if (await confirmBox(t('first_done_q'))) runTask('report'); }
  return true;
}
async function testMail() { if (!(await saveSettings(true))) return; $('#mbOut').textContent = t('m_testing'); api.test_mailboxes(); }
async function publishWeb() { F.w_on = true; if (!(await saveSettings(true))) return; $('#w_out').textContent = t('m_testing'); api.publish_web(); }
async function backfill() {
  const ym = `${$('#a_y').value}-${String($('#a_m').value).padStart(2, '0')}`;
  if (!/^20\d\d-(0[1-9]|1[0-2])$/.test(ym)) return toast('YYYY-MM');
  if (!(await confirmBox(t('a_back_q', { ym })))) return;
  if (await saveSettings(true)) runTask('backfill', ym);
}

// ---------- 關於 ----------
function renderAbout() {
  const a = ST.author || {}, b = String(ST.build || '');
  const built = b.length >= 12 ? `${b.slice(0, 4)}-${b.slice(4, 6)}-${b.slice(6, 8)} ${b.slice(8, 10)}:${b.slice(10, 12)}` : '—';
  $('#aboutBody').innerHTML = `<img src="../icon.png" alt=""><h1>${t('app')}</h1><p>${esc(t('ab_desc'))}</p>
    <table><tr><td>${t('ab_version')}</td><td><b>v${esc(ST.version)}</b>${ST.latest ? '　✓' : ''}</td></tr><tr><td>${t('ab_build')}</td><td>${built}</td></tr>
    <tr><td>${t('ab_author')}</td><td>${esc(a.name)}</td></tr><tr><td>${t('ab_email')}</td><td><span class="link" data-url="mailto:${esc(a.email)}">${esc(a.email)}</span></td></tr>
    <tr><td>${t('ab_update_src')}</td><td style="font-size:12px">${esc(ST.update_url)}</td></tr></table>
    ${ST.source_pc ? `<p class="note">${esc(t('ab_source'))}</p>` : ''}
    <div class="row" style="justify-content:center"><button class="ghost" id="abCheck">${t('ab_check')}</button><button class="ghost" id="abLogs">${t('ab_logs')}</button><button class="primary" id="abRep">${t('rp_button')}</button></div>`;
  $$('[data-url]', $('#aboutBody')).forEach(x => x.onclick = () => api.open_url(x.dataset.url));
  $('#abCheck').onclick = () => { toast(t('update') + '…'); checkUpdate(true); }; $('#abLogs').onclick = () => api.open('logs'); $('#abRep').onclick = () => reportDialog('');
}

// ---------- 回報問題 ----------
function reportDialog(prefill) {
  modal(`<h3>${t('rp_title')}</h3><p class="note">${esc(t('rp_desc'))}</p><textarea id="rpNote" rows="5" style="width:100%" placeholder="${esc(t('rp_ph'))}">${esc(prefill)}</textarea>
    <div id="rpOut" class="note"></div><div class="btns"><button class="ghost" id="rpCancel">${t('cancel')}</button><button class="primary" id="rpSend">${t('rp_send')}</button></div>`, el => {
    $('#rpCancel', el).onclick = closeModal;
    $('#rpSend', el).onclick = () => { $('#rpSend', el).disabled = true; $('#rpOut', el).textContent = t('rp_sending'); api.send_report($('#rpNote', el).value); };
  });
}
function onReported(r) {
  const out = $('#rpOut'); if (!out) return;
  if (r.ok) { out.innerHTML = `<span class="ok">${esc(t('rp_ok', { id: (r.id || '').split('/').pop() }))}</span>`; $('#rpSend').classList.add('hidden'); $('#rpCancel').textContent = t('ok'); return; }
  const why = t('why_' + r.reason) !== 'why_' + r.reason ? t('why_' + r.reason) : r.reason;
  out.innerHTML = `<span class="err">${esc(t('rp_saved', { why }))}</span>` + (r.saved ? `<br><span class="link" id="rpShow">📁 ${esc(t('rp_show'))}</span>` : '');
  $('#rpSend').classList.add('hidden'); $('#rpCancel').textContent = t('ok');
  if (r.saved) $('#rpShow').onclick = () => api.open_saved(r.saved);
}

// ---------- Python 送來的事件 ----------
window.LL = { event(kind, d) {
  if (kind === 'log') onLog(d);
  else if (kind === 'done') onDone(d);
  else if (kind === 'reported') onReported(d);
  else if (kind === 'update') {
    if (!d.ok) { if (update.manual) toast(t('check_fail')); }
    else { ST.remote = d; ST.latest = !d.available; if (!d.available && update.manual) toast(t('latest', { v: ST.version })); }
    update.manual = false; if (curPage === 'home') renderHome(); if (curPage === 'about') renderAbout();
  } else if (kind === 'installed') {
    if (d.status === 'updated') confirmBox(t('updated_q')).then(y => y && api.restart()); else { ST.remote = null; renderBanner(); }
  } else if (kind === 'test') {
    if (d.what === 'mail' && $('#mbOut')) $('#mbOut').textContent = d.text;
    if (d.what === 'gmail' && $('#r_out')) { $('#r_out').innerHTML = d.ok ? `<span class="ok">${t('r_test_ok')}</span>` : `<span class="err">${esc(t('r_test_fail') + d.text)}</span>`; if (d.ok && $('#r_on')) $('#r_on').checked = true; }
    if (d.what === 'web' && $('#w_out')) $('#w_out').textContent = d.ok ? t('w_ok', { u: d.text }) : d.text;
  }
} };
const update = { manual: false };
function checkUpdate(manual) { update.manual = manual; api.check_update(); }

// ---------- 啟動 ----------
async function init() {
  api = window.pywebview.api;
  ST = await api.state(); LANG = ST.lang === 'en' ? 'en' : 'zh'; document.body.dataset.theme = THEMES.includes(ST.theme) ? ST.theme : 'pastel';
  applyLang();
  $$('#nav button').forEach(b => b.onclick = () => { if (curPage === 'settings') collect(); go(b.dataset.page); });
  $('#themeSel').onchange = e => setTheme(e.target.value);
  $('#langSel').onchange = e => { LANG = e.target.value; api.set_ui('lang', LANG); applyLang(); go(curPage); };
  $('#runBtn').onclick = () => runTask('report');
  $('#reorderBtn').onclick = () => { $('#grid').classList.toggle('edit'); if (!$('#grid').classList.contains('edit')) saveOrder(); renderHome(); if ($('#grid').classList.contains('edit')) toast(t('reorder_hint')); };
  $('#viewReload').onclick = () => { const f = $('#viewFrame'); f.dataset.src = ''; showView(curPage); };
  $('#viewBrowser').onclick = () => curPage === 'ledger' ? api.open_url(viewUrl) : api.open(curPage);   // 月報、生活帳本：用預設瀏覽器開本機檔案
  $('#sPrev').onclick = () => { collect(); sPage--; renderSettings(); };
  $('#sNext').onclick = () => { collect(); sPage++; renderSettings(); };
  $('#sSave').onclick = () => saveSettings(false);
  go('home');
  checkUpdate(false);
  if (ST.first_run) { firstRun = true; await confirmBox(t('welcome')); sPage = 0; go('settings'); }
}
window.addEventListener('pywebviewready', init);
})();
