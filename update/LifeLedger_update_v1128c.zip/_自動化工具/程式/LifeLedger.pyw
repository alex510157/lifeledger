# LifeLedger 生活總帳：單一視窗 app（Edge WebView2）
#   畫面在 程式\app\（HTML／CSS／JS），這個檔案負責：開視窗、讀寫設定、背景執行更新月報、自動更新、捷徑
#   沒有 WebView2／pywebview 的電腦：先自動安裝 pywebview；還是不行就改用舊版視窗（LifeLedger_classic.pyw）
import os, sys, json, re, threading, subprocess, datetime, secrets, webbrowser, mimetypes, functools, http.server, urllib.parse

PROG = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(PROG)
HOME = os.path.dirname(TOOLS)
os.chdir(PROG)
sys.path.insert(0, PROG)
import updater
from paths import setp

APPID = 'LifeLedger.App'
APP_URL = 'https://alex510157.github.io/lifeledger/app/'   # 隨手記網頁（大家共用）
AUTHOR = {'name': 'Alex', 'email': 'alex510157@gmail.com'}
exe = sys.executable
_c = os.path.join(os.path.dirname(exe), 'python.exe')
PY = _c if os.path.basename(exe).lower() == 'pythonw.exe' and os.path.exists(_c) else exe
NOWIN = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
ENV = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
try:   # 工作列：開著的視窗、釘選的捷徑都用同一個 ID
    import ctypes
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APPID)
except Exception:
    pass


# ---------- 主題：月報、生活帳本在 app 裡看時，換成跟 LifeLedger 一樣的配色 ----------
PALETTE = {   # bg, surface, surface2, ink, ink2, ink3, rule, hero, hero2, accent, bar, gold, info, dark
    'pastel': ('#FFF9F3', '#FFFFFF', '#FFF3EA', '#3D3A4B', '#5E5A6E', '#8A8597', '#F0E2D8', '#D9708F', '#8E8BD8', '#D45C7A', '#FF8FA3', '#E3A04A', '#FFF1E6', False),
    'mint': ('#F3FBF7', '#FFFFFF', '#EAF7F0', '#24423A', '#4A665D', '#6E8A81', '#D3EBDF', '#1F8F6A', '#3A8FC0', '#1F9A72', '#34B98A', '#D49B3A', '#E6F5EE', False),
    'ocean': ('#F3F7FF', '#FFFFFF', '#EAF1FD', '#22324A', '#4A5B76', '#6B7C96', '#D6E2F5', '#2C5FC4', '#2B9BD1', '#2F6AD8', '#4A86F0', '#D9A440', '#E6EEFB', False),
    'latte': ('#FBF6F0', '#FFFFFF', '#F5EDE3', '#4A3B30', '#6B5848', '#937F70', '#E8D9C8', '#8C5A35', '#B98457', '#A86B3E', '#C58A5C', '#C9963F', '#F4EADF', False),
    'night': ('#1E2030', '#262838', '#2C2F44', '#ECEAF5', '#C3C0D6', '#A6A3BA', '#3A3C52', '#3A3F80', '#6E4E9C', '#A79BFF', '#8C7CF0', '#E0BE7A', '#2A2C40', True),
}


def report_theme_css(key):
    bg, sf, sf2, ink, ink2, ink3, rule, hero, hero2, acc, bar, gold, info, dark = PALETTE.get(key) or PALETTE['pastel']
    v = (f'--bg:{bg};--surface:{sf};--surface-2:{sf2};--ink:{ink};--ink-2:{ink2};--ink-3:{ink3};--rule:{rule};--rule-2:{rule};--track:{sf2};'
         f'--hero:{hero};--hero-2:{hero2};--hero-ink:#FFFFFF;--hero-ink-2:rgba(255,255,255,.78);--accent:{acc};--bar:{bar};--heat:{acc};--gold:{gold};--info-bg:{info};')
    css = ':root:root,:root:root[data-theme]{' + v + ('color-scheme:dark;' if dark else 'color-scheme:light;') + '}'
    return ('<style id="ll-theme">' + css + '</style><script>document.documentElement.setAttribute("data-theme","' + ('dark' if dark else 'light') + '")</script>')


# ---------- 設定檔 ----------
def load_json(p, default):
    try:
        return json.load(open(p, encoding='utf8'))
    except Exception:
        return default


def settings_json():
    return load_json(setp('local_settings.json'), {})


def out_dir():
    return settings_json().get('out') or HOME


def ui_get():
    return load_json(setp('ui.json'), {})


def ui_set(k, v):
    u = ui_get(); u[k] = v
    json.dump(u, open(setp('ui.json'), 'w', encoding='utf8'), ensure_ascii=False)


def ledger_url():
    L = settings_json().get('ledger') or {}
    if L.get('app_url'):
        return L['app_url']
    u = (L.get('url') or '').rstrip('/')
    return APP_URL if (not u or 'alexledger.netlify.app' in u) else u


blank = lambda v: not v or '填' in str(v) or '產生' in str(v)


def mail_kind(b):
    u = str(b.get('user', ''))
    if b.get('type') == 'outlook':
        return 'outlook'
    return 'gmail' if 'gmail' in u else 'yahoo' if 'yahoo' in u else 'hinet' if 'hinet' in u else ('imap' if b.get('host') else 'gmail')


# ---------- 捷徑（開始功能表、桌面、開機自動打開），帶 App ID ----------
def shortcut_paths():
    from win32com.shell import shell, shellcon
    f = lambda c: shell.SHGetFolderPath(0, c, 0, 0)
    name = 'LifeLedger 生活總帳.lnk'
    return {'start': os.path.join(f(shellcon.CSIDL_PROGRAMS), 'LifeLedger 生活總帳', name),
            'desktop': os.path.join(f(shellcon.CSIDL_DESKTOPDIRECTORY), name),
            'startup': os.path.join(f(shellcon.CSIDL_STARTUP), name)}


def make_shortcut(path):
    import pythoncom
    from win32com.shell import shell
    from win32com.propsys import propsys, pscon
    exe_ = os.path.join(TOOLS, 'LifeLedger.exe')
    os.makedirs(os.path.dirname(path), exist_ok=True)
    lnk = pythoncom.CoCreateInstance(shell.CLSID_ShellLink, None, pythoncom.CLSCTX_INPROC_SERVER, shell.IID_IShellLink)
    ico = os.path.join(PROG, 'LifeLedger.ico')   # 用 .ico 的路徑：Windows 依路徑快取圖示，exe 換了圖但路徑一樣會一直顯示舊的
    lnk.SetPath(exe_); lnk.SetWorkingDirectory(TOOLS); lnk.SetIconLocation(ico if os.path.exists(ico) else exe_, 0); lnk.SetDescription('LifeLedger 生活總帳')
    ps = lnk.QueryInterface(propsys.IID_IPropertyStore)
    ps.SetValue(pscon.PKEY_AppUserModel_ID, propsys.PROPVARIANTType(APPID, pythoncom.VT_LPWSTR)); ps.Commit()
    lnk.QueryInterface(pythoncom.IID_IPersistFile).Save(path, 0)


def pinned_shortcuts():
    """工作列、開始功能表釘選的捷徑裡，指向這個 LifeLedger.exe 的那些"""
    out = []
    try:
        import pythoncom
        from win32com.shell import shell
        base = os.path.join(os.environ.get('APPDATA', ''), 'Microsoft', 'Internet Explorer', 'Quick Launch', 'User Pinned')
        exe_ = os.path.normcase(os.path.join(TOOLS, 'LifeLedger.exe'))
        for root, _, fs in os.walk(base):
            for f in fs:
                if not f.lower().endswith('.lnk'):
                    continue
                lp = os.path.join(root, f)
                try:
                    lnk = pythoncom.CoCreateInstance(shell.CLSID_ShellLink, None, pythoncom.CLSCTX_INPROC_SERVER, shell.IID_IShellLink)
                    lnk.QueryInterface(pythoncom.IID_IPersistFile).Load(lp, 0)
                    if os.path.normcase(lnk.GetPath(0)[0]) == exe_:
                        out.append(lp)
                except Exception:
                    pass
    except Exception:
        pass
    return out


def refresh_icons():
    """請 Windows 重新讀圖示（不用重開機）"""
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
        subprocess.Popen(['ie4uinit.exe', '-show'], creationflags=0x08000000)   # CREATE_NO_WINDOW
    except Exception:
        pass


def ensure_shortcuts():
    """開始功能表一定有 LifeLedger；已有的捷徑補上 App ID（新圖示也一起換上）。版本記在 ui.json，只做一次"""
    try:
        import pythoncom
        pythoncom.CoInitialize()
        if not os.path.exists(os.path.join(TOOLS, 'LifeLedger.exe')):
            return
        sp = shortcut_paths()
        if ui_get().get('shortcuts') == 3 and os.path.exists(sp['start']):
            return
        make_shortcut(sp['start'])
        for k in ('desktop', 'startup'):
            if os.path.exists(sp[k]):
                make_shortcut(sp[k])
        for lp in pinned_shortcuts():   # 釘選在工作列／開始的 LifeLedger 也換上新圖示
            make_shortcut(lp)
        ui_set('shortcuts', 3)
        refresh_icons()
    except Exception:
        pass


# ---------- 視窗控制（無外框視窗：按鈕、拉大小都在畫面上自己做） ----------
def find_hwnd():
    """這個程式自己的主視窗（看得見、標題是 LifeLedger 生活總帳）"""
    import win32gui, win32process
    found = []
    def cb(h, _):
        if win32gui.IsWindowVisible(h) and win32process.GetWindowThreadProcessId(h)[1] == os.getpid() and win32gui.GetWindowText(h) == 'LifeLedger 生活總帳':
            found.append(h)
    win32gui.EnumWindows(cb, None)
    return found[0] if found else 0


def set_icon(hwnd):
    """視窗左上角、工作列的圖示換成 LifeLedger 的（不然會是 Python 的）"""
    try:
        import ctypes
        ico = os.path.join(PROG, 'LifeLedger.ico'); u32 = ctypes.windll.user32
        for size, which in ((32, 1), (16, 0)):
            h = u32.LoadImageW(None, ico, 1, size, size, 0x10)
            if h:
                u32.SendMessageW(hwnd, 0x80, which, h)
        # 無外框視窗也要能從工作列縮小、還原
        GWL_STYLE, WS_MINIMIZEBOX, WS_MAXIMIZEBOX, WS_SYSMENU = -16, 0x20000, 0x10000, 0x80000
        st = u32.GetWindowLongW(hwnd, GWL_STYLE); u32.SetWindowLongW(hwnd, GWL_STYLE, st | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU)
    except Exception:
        pass


# ---------- 設定：給畫面看的（不含任何密碼）、存檔（跟原本設定精靈同樣格式） ----------
def settings_view():
    S = settings_json(); PW = load_json(setp('passwords.json'), {})
    L = S.get('ledger') or {}; M = S.get('mail') or {}; Wb = S.get('web') or {}
    try:
        autostart = os.path.exists(shortcut_paths()['startup'])
    except Exception:
        autostart = False
    return {
        'ledger': {'user': '' if blank(L.get('user')) else L.get('user', ''), 'url': L.get('url') or 'https://alexledger.netlify.app', 'has_password': not blank(L.get('password'))},
        'bills': {'has_default': bool(PW.get('default')), 'has_birthday': bool(PW.get('birthday')),
                  'banks': sorted(k for k, v in PW.items() if k not in ('default', 'birthday', '說明') and v)},
        'mailboxes': [{'id': i, 'kind': mail_kind(b), 'type': b.get('type'), 'name': b.get('name', ''), 'user': b.get('user', ''), 'host': b.get('host', ''),
                       'port': b.get('port', 993), 'account': b.get('account', ''), 'has_password': bool(b.get('password'))} for i, b in enumerate(S.get('mailboxes', []))],
        'my_name': S.get('my_name', ''),
        'mail': {'enabled': bool(M.get('enabled')), 'from': '' if blank(M.get('from')) else M.get('from', ''), 'to': M.get('to') or '',
                 'mail_day': M.get('mail_day', 12), 'has_app_password': not blank(M.get('app_password'))},
        'web': {'enabled': bool(Wb.get('enabled')), 'repo': Wb.get('repo') if Wb.get('repo') not in (None, '', 'cardflow') else 'lifeledger',
                'has_token': not blank(Wb.get('token')), 'has_password': not blank(Wb.get('password'))},
        'adv': {'bills': [b for b in S.get('bills', []) if b], 'spouse_names': S.get('spouse_names', []), 'salary_payer': S.get('salary_payer', ''),
                'report_start': S.get('report_start', '')},
        'autostart': autostart,
    }


def settings_save(d):
    """d 是畫面送來的設定（密碼欄空白＝不修改）。回傳 (成功, 錯誤代碼)"""
    S = settings_json(); PW = load_json(setp('passwords.json'), {})
    b = d.get('bills', {})
    bd = (b.get('birthday') or '').strip()
    if bd and not re.fullmatch(r'\d{8}', bd):
        return False, 'birthday'
    w = d.get('web', {})
    if w.get('password') and len(w['password']) < 8:
        return False, 'webpw'
    if (b.get('default') or '').strip():
        PW['default'] = b['default'].strip()
    if bd:
        PW['birthday'] = bd
    keep = {x['name']: (x.get('password') or '').strip() for x in b.get('banks', []) if x.get('name')}
    for k in [k for k in PW if k not in ('default', 'birthday', '說明')]:
        if k not in keep:
            PW.pop(k)
    for k, v in keep.items():
        if v:
            PW[k] = v
        elif k not in PW:
            return False, 'bankpw'
    PW.setdefault('說明', '各銀行帳單 PDF 的開啟密碼；default 是共用的，銀行名稱的那一行會優先使用')
    # 隨手記
    L = S.setdefault('ledger', {}); l = d.get('ledger', {})
    L['url'] = (l.get('url') or '').strip() or 'https://alexledger.netlify.app'
    if (l.get('user') or '').strip():
        L['user'] = l['user'].strip()
    if l.get('password'):
        L['password'] = l['password']
    # 信箱
    old = S.get('mailboxes', []); MB = []
    for m in d.get('mailboxes', []):
        k = m.get('kind')
        prev = old[m['id']] if isinstance(m.get('id'), int) and 0 <= m['id'] < len(old) else {}
        if k == 'outlook':
            acc = (m.get('account') or '').strip()
            MB.append({'type': 'outlook', 'name': 'Outlook' + (f'（{acc}）' if acc else ''), 'account': acc}); continue
        user = (m.get('user') or '').strip()
        if not user:
            continue
        if k == 'hinet' and '@' not in user:
            user += '@ms1.hinet.net'
        pw = m.get('password') or ''
        pw = (pw.replace(' ', '') if k in ('gmail', 'yahoo') else pw) or prev.get('password', '')
        if not pw:
            return False, 'mailpw'
        mb = {'type': 'imap', 'name': user, 'user': user, 'password': pw}
        if k == 'imap':
            if not (m.get('host') or '').strip():
                return False, 'mailhost'
            mb['host'] = m['host'].strip(); mb['port'] = int(m.get('port') or 993)
        MB = [x for x in MB if not (x.get('type') == mb['type'] and x.get('user') == mb['user'])] + [mb]
    S['mailboxes'] = MB
    if (d.get('my_name') or '').strip() or 'my_name' in S:
        S['my_name'] = (d.get('my_name') or '').strip()
    # 寄月報
    M = S.setdefault('mail', {}); mm = d.get('mail', {})
    M['from'] = (mm.get('from') or '').strip(); M['to'] = (mm.get('to') or '').strip() or M['from']
    if mm.get('app_password'):
        M['app_password'] = mm['app_password'].replace(' ', '')
    try:
        M['mail_day'] = max(1, min(28, int(mm.get('mail_day', 12))))
    except (TypeError, ValueError):
        M['mail_day'] = 12
    M['enabled'] = bool(mm.get('enabled')) and bool(M['from']) and not blank(M.get('app_password'))
    # 線上版
    W = S.setdefault('web', {})
    if (w.get('token') or '').strip():
        W['token'] = w['token'].strip()
    if w.get('password'):
        W['password'] = w['password']
    W['repo'] = (w.get('repo') or '').strip() or 'lifeledger'
    W['enabled'] = bool(w.get('enabled')) and not blank(W.get('token')) and len(str(W.get('password') or '')) >= 8
    # 進階
    a = d.get('adv', {})
    S['bills'] = [x for x in a.get('bills', []) if x]
    S['spouse_names'] = [x.strip() for x in re.split(r'[、,，;；\n]+', a.get('spouse') or '') if x.strip()]   # 英文名字中間有空白，不能用空白分開
    S['salary_payer'] = (a.get('salary') or '').strip()
    os.makedirs(os.path.dirname(setp('passwords.json')), exist_ok=True)
    json.dump(PW, open(setp('passwords.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=1)
    json.dump(S, open(setp('local_settings.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=1)
    return True, ''


# ---------- 給畫面呼叫的功能（pywebview js_api） ----------
class Api:
    def __init__(self):
        self._window = None; self.busy = False; self.base = ''; self._hwnd = 0; self._restore = None

    # ---- 視窗按鈕、拉大小 ----
    def _h(self):
        if not self._hwnd:
            self._hwnd = find_hwnd()
        return self._hwnd

    def win_min(self):
        if self._window: self._window.minimize()
        return True

    def win_close(self):
        if self._window: self._window.destroy()
        return True

    def win_bounds(self):
        import win32gui
        l, t, r, b = win32gui.GetWindowRect(self._h())
        return {'x': l, 'y': t, 'w': r - l, 'h': b - t, 'max': self._restore is not None}

    def win_set_bounds(self, x, y, w, h):
        import win32gui, win32con
        w, h = max(900, int(w)), max(640, int(h))
        win32gui.SetWindowPos(self._h(), 0, int(x), int(y), w, h, win32con.SWP_NOZORDER | win32con.SWP_NOACTIVATE)
        return True

    def win_max(self):
        """放大到螢幕的工作區（不蓋住工作列）；再按一次還原"""
        import win32gui, win32api, win32con
        h = self._h()
        if self._restore:
            x, y, w, hh = self._restore; self._restore = None
        else:
            l, t, r, b = win32gui.GetWindowRect(h); self._restore = (l, t, r - l, b - t)
            wl, wt, wr, wb = win32api.GetMonitorInfo(win32api.MonitorFromWindow(h, win32con.MONITOR_DEFAULTTONEAREST))['Work']
            x, y, w, hh = wl, wt, wr - wl, wb - wt
        win32gui.SetWindowPos(h, 0, x, y, w, hh, win32con.SWP_NOZORDER)
        return self._restore is not None

    def emit(self, kind, data=None):
        if self._window:
            try:
                self._window.evaluate_js(f'LL.event({json.dumps(kind)}, {json.dumps(data, ensure_ascii=False)})')
            except Exception:
                pass

    def state(self):
        lv = updater.local_version(); u = ui_get()
        rp = os.path.join(out_dir(), '月報', 'LifeLedger月報.html')
        S = settings_json(); L = S.get('ledger') or {}
        has_pw = any(v for k, v in load_json(setp('passwords.json'), {}).items() if k != '說明')
        ju = load_json(os.path.join(PROG, '.just_updated.json'), None)
        return {'version': lv['version'], 'build': lv['build'], 'theme': u.get('theme', 'pastel'), 'lang': u.get('lang', 'zh'), 'order': u.get('order'),
                'viewmode': u.get('viewmode', 'inapp'), 'tour': u.get('tour', 0), 'help_hidden': u.get('help_hidden', []),
                'legacy_folders': [os.path.relpath(a, out_dir()) for a, _ in self._plan()],
                'last_report': datetime.datetime.fromtimestamp(os.path.getmtime(rp)).strftime('%m/%d %H:%M') if os.path.exists(rp) else '',
                'first_run': not has_pw and blank(L.get('user')), 'just_updated': ju, 'author': AUTHOR, 'ledger_url': ledger_url(),
                'reports': {k: os.path.exists(os.path.join(out_dir(), '月報', f)) for k, f in (('report', 'LifeLedger月報.html'), ('book', 'LifeLedger生活帳本.html'))},
                'base': self.base, 'source_pc': os.path.exists(os.path.join(PROG, 'make_share.py')), 'update_url': updater.MANIFEST}

    def _plan(self):
        try:
            import layout
            return layout.plan(out_dir())
        except Exception:
            return []

    def migrate_now(self):
        """立刻把帳單整理到「帳單」資料夾（平常更新時也會自動做）"""
        if self.busy:
            return {'ok': False, 'error': 'busy'}
        try:
            import layout
            n = layout.migrate(out_dir(), log=lambda s: None)
            return {'ok': True, 'moved': n}
        except Exception as e:
            return {'ok': False, 'error': str(e)[:200]}

    def open_popup(self, kind, url):
        """另外開一個視窗看（設定成「另開視窗」時）"""
        if not (url.startswith(self.base) or re.match(r'^https://', url or '')):
            return False
        pyw = os.path.join(os.path.dirname(exe), 'pythonw.exe')
        subprocess.Popen([pyw if os.path.exists(pyw) else exe, os.path.join(PROG, 'viewer.pyw'), url, str(kind)[:20]], cwd=PROG)
        return True

    def set_ui(self, k, v):
        if k in ('theme', 'lang', 'order', 'viewmode', 'tour', 'help_hidden'):
            ui_set(k, v)
        return True

    def code_stamp(self):
        """程式檔最後修改時間（視窗開著時被自動更新換掉 → 前端提示重新開啟）"""
        fs = [os.path.join(PROG, f) for f in ('LifeLedger.pyw', 'viewer.pyw', 'version.json')]
        ad = os.path.join(PROG, 'app')
        if os.path.isdir(ad):
            fs += [os.path.join(ad, f) for f in os.listdir(ad)]
        return int(max((os.path.getmtime(f) for f in fs if os.path.isfile(f)), default=0))

    def restart_safe(self):
        """沒有在更新帳目時才重新開啟（不要中斷正在跑的更新）"""
        if self.busy:
            return False
        return self.restart()

    def dismiss_just_updated(self):
        try:
            os.remove(os.path.join(PROG, '.just_updated.json'))
        except OSError:
            pass
        return True

    def open(self, what):
        d = out_dir()
        p = {'excel': os.path.join(d, 'LifeLedger_生活總帳.xlsx'), 'folder': d, 'help': os.path.join(TOOLS, '使用說明.md'),
             'report': os.path.join(d, '月報', 'LifeLedger月報.html'), 'book': os.path.join(d, '月報', 'LifeLedger生活帳本.html'),
             'logs': os.path.join(TOOLS, '紀錄')}.get(what)
        if p and os.path.exists(p):
            os.startfile(p); return True
        return False

    def open_url(self, url):
        if re.match(r'^(https?|mailto):', url or ''):
            webbrowser.open(url); return True
        return False

    # 更新程式
    def check_update(self):
        def work():
            try:
                r = updater.remote_version(); lv = updater.local_version()
                self.emit('update', {'ok': True, 'available': r['build'] > lv['build'], 'version': r['version'], 'notes': r.get('notes') or []})
            except Exception as e:
                self.emit('update', {'ok': False, 'error': str(e)[:120]})
        threading.Thread(target=work, daemon=True).start(); return True

    def install_update(self):
        def work():
            st = updater.check(install=True, log=lambda s: self.emit('log', s))[0]
            self.emit('installed', {'status': st})
        threading.Thread(target=work, daemon=True).start(); return True

    def restart(self):
        subprocess.Popen([exe, os.path.abspath(__file__)], cwd=PROG)
        if self._window:
            self._window.destroy()
        return True

    # 背景工作：更新月報、補抓舊帳單、健檢
    def run_task(self, kind, arg=None):
        if self.busy:
            return {'ok': False, 'error': 'busy'}
        S = settings_json()
        if kind == 'report':
            steps = [['run_local.py', '--auto']]
        elif kind == 'backfill':
            ym = str(arg or '')
            if not re.fullmatch(r'20\d\d-(0[1-9]|1[0-2])', ym):
                return {'ok': False, 'error': 'ym'}
            S['report_start'] = ym; S['mail_since'] = ym + '-01'
            json.dump(S, open(setp('local_settings.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=1)
            steps = ([['mail_fetch.py', '--since', ym + '-01']] if S.get('mailboxes') else []) + [['run_local.py', '--auto', '--no-mail']]
        elif kind == 'health':
            steps = [['health_check.py']]
        else:
            return {'ok': False, 'error': 'kind'}
        self.busy = True

        def work():
            rc = 0
            try:
                for args in steps:
                    p = subprocess.Popen([PY] + args, cwd=PROG, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=ENV, creationflags=NOWIN,
                                         text=True, encoding='utf8', errors='replace')
                    for line in p.stdout:
                        if line.strip():
                            self.emit('log', line.rstrip())
                    rc = p.wait()
                    if rc:
                        break
            except Exception as e:
                self.emit('log', str(e)); rc = 1
            self.busy = False
            if kind == 'health' and rc == 0:
                self.open('logs')
            self.emit('done', {'kind': kind, 'rc': rc, 'state': self.state()})
        threading.Thread(target=work, daemon=True).start()
        return {'ok': True}

    def task_running(self):
        return self.busy or os.path.exists(os.path.join(PROG, '.running'))

    # 回報問題：紀錄打包、用管理者公鑰加密、上傳（沒辦法上傳就存成檔案）
    def send_report(self, note=''):
        def work():
            try:
                import bugreport
                r = bugreport.send(str(note or '')[:4000])
            except Exception as e:
                r = {'ok': False, 'reason': str(e)[:200]}
            self.emit('reported', r)
        threading.Thread(target=work, daemon=True).start(); return True

    def open_saved(self, p):
        logs = os.path.join(TOOLS, '紀錄')
        if p and os.path.normpath(p).startswith(os.path.normpath(logs)) and os.path.exists(p):
            subprocess.Popen(['explorer', '/select,', os.path.normpath(p)]); return True
        return False

    # 設定
    def get_settings(self):
        return settings_view()

    def save_settings(self, d):
        ok, err = settings_save(d)
        return {'ok': ok, 'error': err}

    def test_mailboxes(self):
        def work():
            since = (datetime.date.today() - datetime.timedelta(days=90)).isoformat()
            try:
                r = subprocess.run([PY, 'mail_fetch.py', '--test', '--since', since], cwd=PROG, capture_output=True, text=True, encoding='utf8',
                                   errors='replace', env=ENV, creationflags=NOWIN, timeout=300)
                self.emit('test', {'what': 'mail', 'ok': r.returncode == 0, 'text': (r.stdout + r.stderr).strip()[-1500:]})
            except Exception as e:
                self.emit('test', {'what': 'mail', 'ok': False, 'text': str(e)})
        threading.Thread(target=work, daemon=True).start(); return True

    def test_gmail(self, user, pw):
        M = settings_json().get('mail') or {}
        pw = (pw or '').replace(' ', '') or M.get('app_password', '')

        def work():
            try:
                import smtplib
                with smtplib.SMTP_SSL('smtp.gmail.com', 465, timeout=20) as s:
                    s.login(user, pw)
                self.emit('test', {'what': 'gmail', 'ok': True, 'text': ''})
            except Exception as e:
                self.emit('test', {'what': 'gmail', 'ok': False, 'text': str(e)[:160]})
        threading.Thread(target=work, daemon=True).start(); return True

    def publish_web(self):
        def work():
            try:
                r = subprocess.run([PY, 'publish_web.py', '--force'], cwd=PROG, capture_output=True, text=True, encoding='utf8', errors='replace',
                                   env=ENV, creationflags=NOWIN, timeout=600)
                url = open(os.path.join(PROG, 'web_url.txt'), encoding='utf8').read().strip() if r.returncode == 0 and os.path.exists(os.path.join(PROG, 'web_url.txt')) else ''
                if not url:
                    S = settings_json(); S.setdefault('web', {})['enabled'] = False
                    json.dump(S, open(setp('local_settings.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=1)
                self.emit('test', {'what': 'web', 'ok': bool(url), 'text': url or (r.stdout + r.stderr).strip()[-800:]})
            except Exception as e:
                self.emit('test', {'what': 'web', 'ok': False, 'text': str(e)})
        threading.Thread(target=work, daemon=True).start(); return True

    def pick_folder(self):
        import webview
        r = self._window.create_file_dialog(webview.FOLDER_DIALOG) if self._window else None
        return os.path.normpath(r[0]) if r else ''

    def set_autostart(self, on):
        try:
            p = shortcut_paths()['startup']
            if on:
                make_shortcut(p)
            elif os.path.exists(p):
                os.remove(p)
            return True
        except Exception:
            return False

    def fix_shortcuts(self):
        try:
            sp = shortcut_paths(); make_shortcut(sp['start']); make_shortcut(sp['desktop']); return True
        except Exception:
            return False


# ---------- 本機小伺服器：畫面（程式\app）、月報（帳本資料夾\月報）。網址有隨機 token，別的程式猜不到 ----------
TOKEN = secrets.token_urlsafe(16)


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        path = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        pre = f'/{TOKEN}/'
        if not path.startswith(pre):
            self.send_error(404); return
        rel = path[len(pre):]
        if rel.startswith('app/'):
            root, rel = os.path.join(PROG, 'app'), rel[4:]
        elif rel.startswith('reports/'):
            root, rel = os.path.join(out_dir(), '月報'), rel[8:]
        elif rel == 'icon.png':
            root, rel = PROG, 'LifeLedger.png'
        else:
            self.send_error(404); return
        f = os.path.normpath(os.path.join(root, rel))
        if not f.startswith(os.path.normpath(root) + os.sep) or not os.path.isfile(f):
            self.send_error(404); return
        data = open(f, 'rb').read()
        ct = mimetypes.guess_type(f)[0] or 'application/octet-stream'
        if root.endswith('月報') and f.lower().endswith('.html'):   # 換成跟 LifeLedger 一樣的配色
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            css = report_theme_css((q.get('theme') or [ui_get().get('theme', 'pastel')])[0]).encode('utf8')
            i = data.lower().rfind(b'</head>')
            data = data[:i] + css + data[i:] if i >= 0 else css + data
        if ct.startswith('text/') or ct in ('application/javascript', 'application/json'):
            ct += '; charset=utf-8'
        self.send_response(200); self.send_header('Content-Type', ct); self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)


def serve():
    srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return f'http://127.0.0.1:{srv.server_port}/{TOKEN}/'


def ensure_webview():
    """pywebview 沒裝：先試著自動安裝（小視窗提示），回傳裝好沒"""
    import importlib, importlib.util
    if importlib.util.find_spec('webview'):
        return True
    try:
        import tkinter as tk
        r = tk.Tk(); r.title('LifeLedger'); r.geometry('420x120'); r.resizable(False, False)
        tk.Label(r, text='第一次使用新版介面，正在安裝需要的元件…\n（約 1 分鐘，需要網路）', font=('Microsoft JhengHei UI', 11), pady=30).pack()
        res = {}

        def work():
            res['rc'] = subprocess.run([PY, '-m', 'pip', 'install', '--disable-pip-version-check', '-q', 'pywebview'], capture_output=True, creationflags=NOWIN).returncode
            r.after(0, r.destroy)
        threading.Thread(target=work, daemon=True).start(); r.mainloop()
    except Exception:
        pass
    importlib.invalidate_caches()
    return bool(importlib.util.find_spec('webview'))


def main():
    if not ensure_webview():
        import runpy
        runpy.run_path(os.path.join(PROG, 'LifeLedger_classic.pyw'), run_name='__main__'); return
    import webview
    api = Api(); base = serve(); api.base = base
    u = ui_get()
    bgc = (PALETTE.get(u.get('theme')) or PALETTE['pastel'])[0]
    win = webview.create_window('LifeLedger 生活總帳', base + 'app/index.html', js_api=api, width=u.get('w', 1180), height=u.get('h', 800),
                                min_size=(900, 640), background_color=bgc, text_select=False, frameless=True, easy_drag=False)
    api._window = win

    def on_shown():
        h = api._h()
        if h:
            set_icon(h)
    win.events.shown += on_shown

    def remember_size():
        try:
            if api._restore:   # 放大中關掉：記住放大前的大小
                ui_set('w', api._restore[2]); ui_set('h', api._restore[3])
            else:
                ui_set('w', max(900, int(win.width))); ui_set('h', max(640, int(win.height)))
        except Exception:
            pass
    win.events.closing += remember_size
    threading.Thread(target=ensure_shortcuts, daemon=True).start()
    store = os.path.join(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~'), 'LifeLedger', 'webview')
    os.makedirs(store, exist_ok=True)
    webview.start(private_mode=False, storage_path=store)


if __name__ == '__main__':
    main()
