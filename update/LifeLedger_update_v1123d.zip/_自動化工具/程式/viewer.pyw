# LifeLedger 內建檢視器：在 LifeLedger 自己的視窗裡看月報、生活帳本、隨手記（不用開瀏覽器）
#   pythonw viewer.pyw <網址或本機檔案> <視窗標題>
#   用 Windows 內建的 Edge WebView2 顯示；隨手記的登入狀態記在 %LOCALAPPDATA%\LifeLedger\webview（只在這台電腦）
import os, sys

try:   # 跟主視窗同一個工作列圖示
    import ctypes
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('LifeLedger.App')
except Exception:
    pass

import webview

target = sys.argv[1] if len(sys.argv) > 1 else 'https://alex510157.github.io/lifeledger/app/'
title = sys.argv[2] if len(sys.argv) > 2 else 'LifeLedger'
store = os.path.join(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~'), 'LifeLedger', 'webview')
os.makedirs(store, exist_ok=True)
webview.create_window(f'LifeLedger ・ {title}', target, width=1180, height=820, min_size=(640, 480), text_select=True)
webview.start(private_mode=False, storage_path=store)
