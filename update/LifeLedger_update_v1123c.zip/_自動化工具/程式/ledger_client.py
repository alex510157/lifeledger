# 隨手記雲端（alexledger.netlify.app 的 /api/ledger）的共用工具：登入金鑰、加密帳本、「立即更新」狀態
# 參數和隨手記網頁 app/sync.js 完全一樣（兩邊加密的東西要互相解得開）：
#   登入金鑰 lk  = PBKDF2-SHA256(密碼, "login:"+帳號小寫, 600000) → 32 bytes，base64：送到伺服器驗證，代替密碼原文
#   資料金鑰 DEK = 隨機 32 bytes（AES-256-GCM，iv 12 bytes），帳本 JSON（UTF-8）用它加密，AAD = "cf-ledger:v1:"+帳號小寫
#   wrap_pw／wrap_rec = PBKDF2-SHA256(密碼或救援碼, 隨機 16 bytes salt, iter) 推出的包裝金鑰，以 AES-GCM 加密 DEK，
#                       AAD = "cf-wrap:v1:pw:"／"cf-wrap:v1:rec:"+帳號小寫；救援碼先轉大寫、去掉 A-Z0-9 以外的字
#   wrap_admin  = 管理者 RSA-OAEP-256 公鑰加密的 DEK（私鑰只在管理者電腦上，見 admin_recover.py）
# 伺服器 API 見 cardflow-ledger 的 docs/encryption.md
import base64, hashlib, json, os, re, subprocess, sys, urllib.error, urllib.parse, urllib.request

LK_ITER = WRAP_ITER = 600000
ITER_MIN, ITER_MAX = 100000, 10000000


class LedgerError(Exception):
    """status：HTTP 狀態碼（連不上是 None）；code：伺服器或這裡給的代碼"""
    def __init__(self, msg, status=None, code=None):
        super().__init__(msg); self.status = status; self.code = code


def norm_user(u):
    return str(u if u is not None else '').strip().lower()


def norm_code(c):
    return re.sub(r'[^A-Z0-9]', '', str(c if c is not None else '').upper())


def b64e(b):
    return base64.b64encode(b).decode('ascii')


def b64d(s):
    if not isinstance(s, str) or not re.fullmatch(r'[A-Za-z0-9+/]*={0,2}', s):
        raise LedgerError('金鑰格式不對', code='bad_key')
    return base64.b64decode(s)


def _aesgcm():
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:   # 和 publish_netlify.py 一樣：沒有就自動安裝
        subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', 'cryptography'], check=True)
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    return AESGCM


def _pbkdf2(secret, salt, it):
    return hashlib.pbkdf2_hmac('sha256', secret.encode('utf8'), salt, it, 32)


def is_ledger(d):
    if not isinstance(d, dict) or not isinstance(d.get('records'), list) or not isinstance(d.get('cards'), list):
        return False
    return all(d.get(k) is None or isinstance(d.get(k), list) for k in ('incomes', 'trips', 'deposits', 'depBanks', 'paidMarks'))


def login_key(user, pw):
    return b64e(_pbkdf2(pw, ('login:' + norm_user(user)).encode('utf8'), LK_ITER))


def new_dek():
    return os.urandom(32)


def _wrap_aad(kind, user):
    return ('cf-wrap:v1:' + kind + ':' + norm_user(user)).encode('utf8')


def wrap_dek(dek, secret, user, kind):
    """kind：'pw'（用密碼包）或 'rec'（用救援碼包）"""
    salt, iv = os.urandom(16), os.urandom(12)
    kek = _pbkdf2(norm_code(secret) if kind == 'rec' else secret, salt, WRAP_ITER)
    ct = _aesgcm()(kek).encrypt(iv, dek, _wrap_aad(kind, user))
    return {'v': 1, 'salt': b64e(salt), 'iter': WRAP_ITER, 'iv': b64e(iv), 'ct': b64e(ct)}


def unwrap_dek(w, secret, user, kind):
    # iter 由伺服器傳來：限制範圍，避免被塞一個超大的數字讓電腦算不完
    if not isinstance(w, dict) or w.get('v') != 1 or not isinstance(w.get('iter'), int) or isinstance(w.get('iter'), bool) \
            or not ITER_MIN <= w['iter'] <= ITER_MAX:
        raise LedgerError('資料金鑰的格式不對，資料沒有被改動', code='bad_key')
    try:
        kek = _pbkdf2(norm_code(secret) if kind == 'rec' else secret, b64d(w.get('salt')), w['iter'])
        dek = _aesgcm()(kek).decrypt(b64d(w.get('iv')), b64d(w.get('ct')), _wrap_aad(kind, user))
    except LedgerError:
        raise
    except Exception:
        raise LedgerError('這個救援碼解不開資料金鑰' if kind == 'rec' else
                          '用這個密碼解不開資料金鑰：在手機上改過或重設過密碼的話，請用設定精靈【0b】填新密碼', code='key_mismatch')
    if len(dek) != 32:
        raise LedgerError('資料金鑰的格式不對，資料沒有被改動', code='bad_key')
    return dek


def _ledger_aad(user):
    return ('cf-ledger:v1:' + norm_user(user)).encode('utf8')


def enc_ledger(dek, data, user):
    if not is_ledger(data):
        raise LedgerError('這次的修改會讓帳本格式不完整，所以沒有送出', code='bad_draft')
    iv = os.urandom(12)
    ct = _aesgcm()(dek).encrypt(iv, json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf8'), _ledger_aad(user))
    return {'v': 1, 'iv': b64e(iv), 'ct': b64e(ct)}


def dec_ledger(dek, enc, user):
    if not isinstance(enc, dict) or enc.get('v') != 1:
        raise LedgerError('雲端帳本的加密格式不認得，沒有讀取', code='decrypt_failed')
    try:
        d = json.loads(_aesgcm()(dek).decrypt(b64d(enc.get('iv')), b64d(enc.get('ct')), _ledger_aad(user)).decode('utf8'))
    except Exception:
        raise LedgerError('雲端帳本解不開（資料金鑰不對或內容被改過），沒有讀取', code='decrypt_failed')
    if not is_ledger(d):
        raise LedgerError('雲端帳本解開後格式不對，沒有讀取', code='bad_response')
    return d


def rev_ok(v):
    """版本號（rev）合約：≥ 0 的整數（和隨手記 app/sync.js 同一套規則）"""
    return isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= 2 ** 53 - 1


class Client:
    """L = local_settings.json 的 "ledger"：{"url", "user", "password"}
    新版伺服器（有 ?action=pubkey）用登入金鑰；帳號還沒有登入金鑰時改用密碼，成功後自動補上（setlogin，密碼登入照常保留）。
    舊版伺服器只送密碼（舊伺服器不認得登入金鑰，會當成密碼錯誤、累計錯誤次數）。"""

    def __init__(self, L, ua='LifeLedger-local'):
        self.base = L['url'].rstrip('/'); self.user = L['user']; self.pw = L['password']; self.ua = ua
        self.v2 = None; self.lk = None; self.legacy = False; self.dek = None; self.dek_ok = False

    # ---- HTTP ----
    def _http(self, method, path, body=None, headers=None, timeout=30):
        h = {'User-Agent': self.ua, **(headers or {})}
        data = None
        if body is not None:
            data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode('utf8')
            h['content-type'] = 'application/json'
        req = urllib.request.Request(self.base + path, data=data, headers=h, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                st, raw = r.status, r.read()
        except urllib.error.HTTPError as e:
            st, raw = e.code, e.read()
        except Exception as e:
            raise LedgerError(f'連不上隨手記網站：{e}')
        try:
            j = json.loads(raw.decode('utf8') or 'null')
        except Exception:
            j = None
        return st, j

    def probe(self):
        if self.v2 is None:
            try:
                st, j = self._http('GET', '/api/ledger?action=pubkey')
                self.v2 = st == 200 and isinstance(j, dict) and 'pubkey' in j
            except LedgerError:
                return False   # 連不上：這次當作舊版（只送密碼），下次再問
            if self.v2:
                self.lk = login_key(self.user, self.pw)   # 60 萬次 PBKDF2，每次執行只算一次
        return self.v2

    def _auth(self, key, lk):
        h = {'x-cf-user': urllib.parse.quote(self.user), 'x-cf-key': urllib.parse.quote(key)}
        if lk: h['x-cf-kind'] = 'lk'
        return h

    def call(self, method, path, body=None, timeout=30):
        """帶登入資料的請求 → (status, json)；HTTP 錯誤不丟例外，連不上才丟 LedgerError"""
        self.probe()
        if self.v2 and self.lk and not self.legacy:
            st, j = self._http(method, path, body, self._auth(self.lk, True), timeout)
            if st != 401 or not (isinstance(j, dict) and j.get('code') == 'no_login_key'):
                return st, j
            self.legacy = True
        st, j = self._http(method, path, body, self._auth(self.pw, False), timeout)
        if 200 <= st < 300 and self.v2 and self.lk and self.legacy:
            try:
                s2, _ = self._http('POST', '/api/ledger?action=setlogin', {'loginKey': self.lk}, self._auth(self.pw, False))
                if s2 == 200: self.legacy = False
            except LedgerError:
                pass
        return st, j

    @property
    def login_method(self):
        return '登入金鑰' if self.v2 and self.lk and not self.legacy else '密碼'

    @staticmethod
    def _raise(st, j, what):
        msg = (j.get('error') if isinstance(j, dict) else None) or f'{what}失敗（{st}）'
        raise LedgerError(msg, status=st, code=j.get('code') if isinstance(j, dict) else None)

    # ---- 資料金鑰 ----
    def get_dek(self):
        if self.dek: return self.dek
        st, j = self.call('GET', '/api/ledger?action=keys')
        if st != 200: self._raise(st, j, '讀取資料金鑰')
        if not isinstance(j, dict) or not j.get('wrap_pw'):
            raise LedgerError('雲端帳本已經加密，但這個帳號沒有資料金鑰，沒有讀取', code='no_key')
        self.dek = unwrap_dek(j['wrap_pw'], self.pw, self.user, 'pw')
        return self.dek

    def _open(self, j):
        """伺服器回的 {rev, data} 或 {rev, enc} → (data, encrypted)；解不開就丟錯（不能拿來覆蓋任何資料）"""
        if isinstance(j, dict) and j.get('enc') is not None:
            try:
                d = dec_ledger(self.get_dek(), j['enc'], self.user); self.dek_ok = True
            except LedgerError:
                self.dek = None; self.dek_ok = False; raise
            return d, True
        return (j.get('data') if isinstance(j, dict) else None), False

    # ---- 帳本 ----
    def get_ledger(self):
        """→ (rev, data, encrypted)。data 是解開後的帳本（全新帳號 rev 0 時是 None）"""
        st, j = self.call('GET', '/api/ledger')
        if st != 200: self._raise(st, j, '讀取隨手記')
        if not isinstance(j, dict) or not rev_ok(j.get('rev')):
            raise LedgerError('雲端回應缺少有效的版本號', code='bad_response')
        d, enc = self._open(j)
        return j['rev'], d, enc

    def put_ledger(self, base, data, encrypted):
        """→ (status, json)；加密帳本只送密文。409 時 json 裡的 data 是解開後的最新帳本（解不開就沒有 data）"""
        if encrypted:
            if not self.dek_ok:
                raise LedgerError('還沒成功解開雲端的加密帳本，這次沒有寫入', code='key_unverified')
            body = {'base': base, 'enc': enc_ledger(self.dek, data, self.user)}
        else:
            if not is_ledger(data): raise LedgerError('帳本格式不完整，沒有寫入', code='bad_draft')
            body = {'base': base, 'data': data}
        st, j = self.call('PUT', '/api/ledger', body)
        if st == 409 and isinstance(j, dict) and j.get('enc') is not None:
            try:
                j['data'], _ = self._open(j)
            except LedgerError:
                j.pop('data', None)
        return st, j

    def mutate(self, fn, tries=3):
        """讀最新帳本 → fn(d) 改它 → 存回去；409 就重讀再改（最多 tries 次）。
        回應不完整（rev 無效、沒有帳本、格式不對）就不寫入；存檔成功的 rev 必須比 base 新，否則視為沒寫入"""
        for _ in range(tries):
            rev, d, enc = self.get_ledger()
            if d is None: raise LedgerError(f'雲端沒有帳本資料（rev {rev}），沒有寫入', code='bad_response')
            if not is_ledger(d): raise LedgerError('雲端帳本格式不對，沒有寫入', code='bad_response')
            fn(d)
            st, res = self.put_ledger(rev, d, enc)
            if st == 409: continue
            if st != 200: self._raise(st, res, '寫入隨手記')
            if not isinstance(res, dict) or not rev_ok(res.get('rev')) or res['rev'] <= rev:
                raise LedgerError('伺服器回應不完整，無法確認有沒有寫入', code='bad_response')
            return enc
        raise LedgerError('另一台裝置也在存檔，3 次都沒有寫入', code='conflict_retry')

    # ---- 「立即更新」狀態（新版伺服器：獨立存放，不在帳本裡） ----
    def get_refresh(self):
        if not self.probe(): return {}
        st, j = self.call('GET', '/api/ledger?page=refresh')
        return j if st == 200 and isinstance(j, dict) else {}

    def put_refresh(self, **kw):
        if not self.probe(): return False
        st, _ = self.call('PUT', '/api/ledger?page=refresh', kw)
        return st == 200
