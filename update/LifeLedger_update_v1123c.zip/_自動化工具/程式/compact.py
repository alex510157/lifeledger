import json, os, hashlib as _hh, datetime as _dtm
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from banks import web_safe as _bkws
R=_bkws(json.load(open('rows.json')))
import banks as _bkp
R+=_bkws(_bkp.prov_rows(R))   # 隨手記記了、帳單還沒到的：暫列
R.sort(key=lambda r:(r['date'],r['bank']))
import banks as _bk
banks=_bk.order(R)
import subcat as _scf
for _r in R: _r['category']=_scf.fine(_r)   # 報表用細分類：交通・停車、旅遊・住宿、網購・3C家電…
for _r in R:   # 年費、海外手續費分開（年費減免那筆也算年費，淨額就是真的收的年費）
    if _r['category']=='年費手續費': _r['category']='年費' if '年費' in _r['merchant']+(_r.get('desc') or '') else '海外手續費'
R=_scf.spread(R); R.sort(key=lambda r:(r['date'],r['bank']))   # 自己分攤的大筆：分到各月
cats=_scf.expand_cats(['旅遊住宿','網購','保險','稅費','餐飲','醫療','教育','交通停車加油','汽車保養','超市便利商店','生活繳費','百貨購物','運動休閒','年費','海外手續費','其他','回饋折抵'],{r['category'] for r in R}|{r['orig_fine'] for r in R if r.get('orig_fine')})
import xrows as _xr   # 現金（隨手記）、帳戶扣款（房貸、無卡分期、轉帳）：跟刷卡一起列在明細、分類（x=1，收支頁不重複算）
XR=_xr.build(json.load(open('income.json',encoding='utf8')) if os.path.exists('income.json') else {})
for _x in XR: _x.update(owner='我', country='', key='')
XR+=[dict(b,country='') for b in _xr.card_buys(R) if not b.get('prov')]   # 刷卡分期：買的那天列原始金額（0 元，不重複算）
banks=banks+['現金','帳戶']
cats+= sorted(({r['category'] for r in R}|{x['category'] for x in XR})-set(cats))
cards=[]
for r in R+XR:
    k=[banks.index(r['bank']),r['cardname']]
    if k not in cards: cards.append(k)
ctrys=sorted(set(r['country'] for r in R if r['country']))
D=[[r['date'],banks.index(r['bank']),r['merchant'],r['desc'] if r['desc']!=r['merchant'] else '',round(r['amount']),cats.index(r['category']),1 if r['foreign'] else 0,1 if r['installment'] else 0,cards.index([banks.index(r['bank']),r['cardname']]),(ctrys.index(r['country'])+1) if r['country'] else 0,
   0 if _bk.mine(r) else (1 if r.get('owner')=='家人' else 2), 1 if r.get('hint') else 0,
   ('r'+r['rid']) if r.get('prov') and r.get('rid') else (lambda x:'h'+x[:6]+'k'+x[6:12])(_hh.sha1(str(r.get('key','')).split('#')[0].encode('utf8')).hexdigest()), r.get('paid_ratio') or 0, 1 if r.get('prov') else 0, r.get('sub') or '', r.get('sub_items') or '', 1 if r.get('edited') else 0, r.get('orig_merchant') or '', (cats.index(r['orig_fine']) if r.get('orig_fine') in cats else None), r.get('spread') or 0] for r in R]   # [16] 電子發票上的品項   # [15] 子分類；[14] 隨手記暫列（帳單還沒到）； [10] 0=我 1=家人附卡 2=代付；[11] 可能代付；[12] 交易代號（雜湊）；[13] 部分代墊比例
D+=[[x['date'],banks.index(x['bank']),x['merchant'],x.get('desc') or '',round(x['amount']),cats.index(x['category']),0,0,cards.index([banks.index(x['bank']),x['cardname']]),0,0 if _bk.mine(x) else 1,0,
     'x'+_hh.sha1((x['date']+x['merchant']+str(x['amount'])+x['cardname']).encode('utf8')).hexdigest()[:11],0,0,'','',0,'',None,0,2 if x.get('buy') else 1] for x in XR]   # [21] 1=現金／帳戶扣款（不是刷卡）
D.sort(key=lambda r:(r[0],r[1]))
P=[[banks.index(b) if b in banks else -1,d,p,u] for b,d,p,u in json.load(open('points.json')) if p]
try:   # 帳單上看不到的點數（中信 LINE Pay 卡的 LINE POINTS）：用回饋試算的估計值補進來，標「估」
    _RC=json.load(open('rewards_check.json',encoding='utf8'))
    for _ym,_rs in (_RC.get('month_rows_all') or {}).items():
        for _x in _rs:
            if '帳單上看不到' in (_x.get('when') or '') and _x.get('est') and _x['bank'] in banks:
                P.append([banks.index(_x['bank']),_ym+'-28',round(_x['est']),'LINE POINTS（估）'])
except Exception as _e: print('點數估計略過：',_e)
P=[p for p in P if p[0]>=0]
INCD=[]
if os.path.exists('income.json'):
    _I=json.load(open('income.json',encoding='utf8'))
    INCD=[[x['date'],'in',x['payer']+' 薪資','隨手記' if x.get('src')=='隨手記' else '富邦帳戶入帳',x['amount']] for x in _I.get('salary',[])]+\
         [[x['date'],'in',x['source'],x.get('note') or '隨手記',x['amount']] for x in _I.get('other',[])]+\
         [[x['date'],'bank',x['label'],x['summary']+('・'+x['memo'] if x.get('memo') else ''),x['amount']] for x in _I.get('bank_out',[])]+\
         [[x['date'],'cash',x.get('note') or x['category'],'現金・'+x['category'],x['amount'],x.get('rid') or ''] for x in _I.get('cash',[])]
    INCD.sort()
DEPD=None
if os.path.exists('deposits.json'):
    _Dj=json.load(open('deposits.json',encoding='utf8'))
    if _Dj.get('latest'):
        _last={};_mm=[]
        for _m in sorted({s['month'] for s in _Dj['stmts']}):
            for s in _Dj['stmts']:
                if s['month']==_m and s.get('balance') is not None: _last[s['bank']]=s
            _mm.append([_m,round(sum(s['balance'] for s in _last.values())),round(sum(s.get('loan',0) for s in _last.values()))])
        DEPD={'latest':[[_bk.full(b),v['month'],round(v['balance']),round(v.get('loan',0))] for b,v in sorted(_Dj['latest'].items(),key=lambda x:-x[1]['balance'])],
              'm':_mm,'int':[[x['date'],_bk.full(x['bank']),x['amount']] for x in _Dj.get('interest',[])],
              # 每家有對帳單的銀行：[名稱, 最新對帳單月份, 餘額(None=讀不到), 餘額月份, 缺的月份, 是否按月寄, 是否網銀截圖手動]
              'st':[[_bk.full(x['bank']),x['last'],(round(x['balance']) if x['balance'] is not None else None),x.get('bal_month',''),x['missing'],1 if x['regular'] else 0,1 if x.get('manual') else 0] for x in _Dj.get('status',[])] or None}
_ls={}
for r in R:
    if r.get('stmt'): _ls[r['bank']]=max(_ls.get(r['bank'],''),r['stmt'])
_cov={}
for r in R:   # 每家銀行最新一期帳單涵蓋到哪天：之後的隨手記刷卡＝帳單還沒到
    if r.get('stmt') and r['stmt']==_ls.get(r['bank']): _cov[r['bank']]=max(_cov.get(r['bank'],''),r['txn_date'])
_IGF='invoice_gap.json'
_IGD=json.load(open(_IGF,encoding='utf8')) if os.path.exists(_IGF) else {}
_IG=[[x['no'],x['date'],x['seller'],x['total'],x['items'],x['cat'],1 if x['recent'] else 0,x.get('kind','cash'),x.get('vouch',0),x.get('fixed',0)] for x in _IGD.get('gaps',[])]
_IM=[[x['no'],x['date'],x['seller'],x['total'],x['items'],x['via'],x['card'],x['rdate'],x['ramount'],x.get('inst','')] for x in _IGD.get('matched',[])]   # 已對上的發票   # 發票有、帳上沒有（店名、品項；沒有個資）
# 卡片狀態：已停卡（local_settings card_status 可改）／最新帳單超過 75 天 = 近期沒刷
try:
    from paths import setp as _sp2; _LS=json.load(open(_sp2('local_settings.json'),encoding='utf8'))
except Exception: _LS={}
BSTAT={'富邦':'已停卡'}; BSTAT.update(_LS.get('card_status') or {})
_lastst={}
for r in R: _lastst[r['bank']]=max(_lastst.get(r['bank'],''),r.get('stmt') or '')
import datetime as _dt
for b,d in _lastst.items():
    if b not in BSTAT and d and (_dt.date.today()-_dt.date.fromisoformat(d)).days>75: BSTAT[b]='近期沒刷'
json.dump({'dep':DEPD,'inc':INCD,'tx':D,'cards':cards,'ctry':ctrys,'pts':P,'banks':banks,'bfull':[{'現金':'現金','帳戶':'帳戶扣款'}.get(b) or _bk.full(b) for b in banks],'bcol':[{'現金':'#8a8f98','帳戶':'#5d6f86'}.get(b) or _bk.color(i) for i,b in enumerate(banks)],'cats':cats,'cov':_cov,'bstat':BSTAT,'ig':_IG,'ip':[[p['date'],p['name'],p['category'],p['total'],p['n'],p['per'],p['paid'],p['left'],p['next'],p.get('payee',''),p.get('rid','')] for p in (_I.get('inst',[]) if os.path.exists('income.json') else [])+[dict(q,payee=(q['bank']+' 刷卡') if q.get('bank') else '') for q in _scf.SPREAD_PLANS]],'im':_IM,'gen':_dtm.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')},open('page_data.json','w'),ensure_ascii=False,separators=(',',':'))
CFG=json.load(open('config.json')); CY,CM=CFG['cur_year'],CFG['cur_month']
ms=[]; y,m=int(CFG['start'][:4]),int(CFG['start'][5:])
def _site():
    try:
        from paths import setp as _sp
        return ((json.load(open(_sp('local_settings.json'),encoding='utf8')).get('ledger') or {}).get('url') or '').rstrip('/')
    except Exception:
        return ''
try:   # 隨手記暫列（帳單還沒到）可能比最後一期帳單新：月份延到最新那一筆，生活帳本才看得到
    _LM=max([CFG['last_month']]+[r[0][:7] for r in json.load(open('page_data.json',encoding='utf8')).get('tx',[]) if isinstance(r,list) and r and isinstance(r[0],str)])
except Exception:
    _LM=CFG['last_month']
_LM=min(_LM,__import__('datetime').date.today().strftime('%Y-%m'))
while f'{y}-{m:02d}'<=_LM:
    ms.append(f'{y}-{m:02d}'); m+=1
    if m>12: y+=1; m=1
partial=[x for x in ms if x>f'{CY}-{CM:02d}']
nall=sum(1 for x in ms if x<=f'{CY}-{CM:02d}')
note=('、'.join(f"{x[:4]} 年 {int(x[5:])} 月" for x in partial)+' 仍有帳單未寄達，金額偏低。') if partial else '帳單已到齊。'
s=open('template4.html').read()
for k,v in {'__DATA__':open('page_data.json').read(),'__RECUR__':open('recur.json').read(),'__CY__':str(CY),'__CM__':str(CM),'__PY__':str(CY-1),
            '__LASTM__':_LM,'__LL_SITE__':_site(),'__START__':CFG['start'],'__NALL__':str(nall),'__PARTIAL__':json.dumps(partial),'__PARTIAL_NOTE__':note,
            '__SY__':CFG['start'][:4],'__BANKLIST__':'・'.join(b+(f'（{BSTAT[b]}）' if b in BSTAT else '') for b in banks),'__REPORT_URL__':(open('report_url.txt',encoding='utf8').read().strip() if os.path.exists('report_url.txt') else ''),'__STARTS__':CFG['start'].replace('-','/'),'__THROUGH__':CFG['data_through'],'__PLANS__':open('plans.json').read()}.items():
    s=s.replace(k,v)
open('刷卡帳本.html','w',encoding='utf8').write(s)
# 離線版（不用 Claude）：存到 <OUT>/月報/LifeLedger生活帳本.html，跟離線月報放一起
_out=os.environ.get('CARDFLOW_OUT')
if _out:
    os.makedirs(os.path.join(_out,'月報'),exist_ok=True)
    open(os.path.join(_out,'月報','LifeLedger生活帳本.html'),'w',encoding='utf8').write('<!doctype html>\n<html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>\n'+s+'\n</body></html>')
