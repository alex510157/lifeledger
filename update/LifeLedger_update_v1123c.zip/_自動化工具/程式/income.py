# 收支總覽的資料：
#  1. 薪資：富邦存款對帳單裡 設定檔 salary_payer 指定的公司 匯入的金額（只算這兩家公司的薪資，其他入帳不算）
#  2. 隨手記：LifeLedger 隨手記（alexledger.netlify.app）匯出的記錄
#     - 現金／其他 → 加進支出
#     - 刷卡的 → 跟信用卡帳單逐筆對照
# 輸出 income.json、ledger_recon.json
import os, re, sys, json, glob, unicodedata, subprocess, datetime, collections
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from paths import setp, HOME
from banks import mine
EMPLOYER = re.compile(json.load(open(setp('local_settings.json'), encoding='utf8')).get('salary_payer') or r'(?!)', re.I)   # 富邦存款對帳單上的薪資匯款人
nf = lambda s: unicodedata.normalize('NFKC', s)


# ---------- 1. 薪資 ----------
def salary_txts():
    """把 _收入/富邦存款 的 PDF 解密轉文字（已轉過的跳過）"""
    S = json.load(open(setp('local_settings.json'), encoding='utf8'))
    PW = json.load(open(setp('passwords.json'), encoding='utf8')) if os.path.exists(setp('passwords.json')) else {}
    os.makedirs('income_txt', exist_ok=True)
    roots = [p for p in dict.fromkeys(S.get('bills', []) + [S.get('out', ''), os.environ.get('CARDFLOW_OUT', ''), HOME]) if p and os.path.isdir(os.path.join(p, '_收入'))]
    for r in roots:
        for f in glob.glob(os.path.join(r, '_收入', '富邦存款', '*.[Pp][Dd][Ff]')):
            out = os.path.join('income_txt', os.path.splitext(os.path.basename(f))[0] + '.txt')
            if os.path.exists(out):
                continue
            import pikepdf
            for pw in [v for v in PW.values() if v] + ['']:
                try:
                    pikepdf.open(f, password=pw).save('income_tmp.pdf'); break
                except pikepdf.PasswordError:
                    pass
            else:
                print('無法開啟存款對帳單：', os.path.basename(f)); continue
            subprocess.run(['pdftotext', '-layout', 'income_tmp.pdf', out]); os.remove('income_tmp.pdf')
    return sorted(glob.glob(os.path.join('income_txt', '*.txt')))


def salaries(txts):
    seen = {}
    for f in txts:
        for l in open(f, encoding='utf8', errors='ignore'):
            l = nf(l)
            m = re.search(r'(\d{4}/\d{2}/\d{2})\s+(\S+)\s+(.*?)\s+([\d,]+\.\d\d)\s+([\d,]+\.\d\d)\s*$', l)
            if m and EMPLOYER.search(m.group(3)):
                d = m.group(1).replace('/', '-')
                who = m.group(3).split()[0][:16]
                seen[(d, m.group(4))] = dict(date=d, amount=float(m.group(4).replace(',', '')), payer=who, src=os.path.basename(f))
    return sorted(seen.values(), key=lambda x: x['date'])


# ---------- 1a. 各家銀行存款對帳單的薪資（不限富邦）：用「上一筆餘額＋金額＝這筆餘額」判斷是存入 ----------
_DATE = re.compile(r'^\s*((?:20\d\d|1\d\d)[/.-]\d{1,2}[/.-]\d{1,2})\b')
_NUM = re.compile(r'(?<![\d/])-?\d{1,3}(?:,\d{3})+(?:\.\d\d)?(?![\d/])|(?<![\d/,.])-?\d+\.\d\d(?![\d/])')
_SALKW = r'薪資|薪轉|薪津|SALARY|PAYROLL|撥薪'


def salaries_any(files):
    """deposits.py 轉好的各銀行存款對帳單（dep_txt）：摘要／備註有「薪資、薪轉…」或設定的薪資匯款人，而且是存入的"""
    out = {}
    for f in files:
        prev = None
        for l in open(f, encoding='utf8', errors='ignore'):
            l = nf(l); m = _DATE.match(l)
            nums = [float(x.replace(',', '')) for x in _NUM.findall(l)]
            if not m:
                if nums and re.search(r'上期餘額|前期餘額|承前|期初餘額|承轉', l): prev = nums[-1]
                continue
            if len(nums) < 2:
                continue
            bal, amt = nums[-1], nums[-2]
            y, mo, dd = re.split(r'[/.-]', m.group(1)); y = int(y) + (1911 if int(y) < 1000 else 0)
            d = f'{y:04d}-{int(mo):02d}-{int(dd):02d}'
            desc = re.sub(r'\s+', ' ', _NUM.sub(' ', l[m.end():])).strip()
            if prev is not None and abs(prev + amt - bal) < 0.6 and amt > 0 and (re.search(_SALKW, desc, re.I) or EMPLOYER.search(desc)):
                who = (EMPLOYER.search(desc).group(0) if EMPLOYER.search(desc) else '薪資')[:16]
                out[(d, amt)] = dict(date=d, amount=amt, payer=who, src=os.path.basename(f))
            prev = bal
    return list(out.values())


# ---------- 1b. 銀行帳戶的支出：房貸、固定轉帳（不經過信用卡的支出） ----------
DEFAULT_OUT = {'說明': '富邦存款對帳單裡要算進支出的項目（房貸、固定轉帳）：摘要／備註關鍵字／對方帳號末幾碼 → 名稱',
               'by_summary': {'放款繳款': '房貸'}, 'by_memo': {}, 'by_account': {}}


def out_rules():
    S = json.load(open(setp('local_settings.json'), encoding='utf8'))
    if 'bank_out' not in S:   # 第一次：加上預設規則，之後可以自己改
        S['bank_out'] = DEFAULT_OUT
        json.dump(S, open(setp('local_settings.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=1)
    return S['bank_out']


def bank_outflows(txts, rules):
    seen = {}
    for f in txts:
        for l in open(f, encoding='utf8', errors='ignore'):
            l = nf(l)
            m = re.search(r'(\d{4}/\d{2}/\d{2})\s+(\S+)\s+(?:(\S.*?)\s+)?([\d,]+\.\d\d)\s+(\S.*?)\s+([\d,]+\.\d\d)\s*$', l)
            if not m:
                continue
            summ, memo, amt = m.group(2), m.group(5).strip(), float(m.group(4).replace(',', ''))
            label = rules.get('by_summary', {}).get(summ)
            if not label:
                label = next((v for k, v in rules.get('by_memo', {}).items() if k in memo), None)
            if not label:
                acct = re.sub(r'\D', '', memo)
                label = next((v for k, v in rules.get('by_account', {}).items() if acct and acct.endswith(re.sub(r'\D', '', k))), None)
            if label:
                label = label.replace('固定轉帳', '固定轉帳')
                d = m.group(1).replace('/', '-')
                seen[(d, summ, amt, memo)] = dict(date=d, amount=amt, label=label, summary=summ, memo=memo[-4:])
    return sorted(seen.values(), key=lambda x: x['date'])


# ---------- 2. 隨手記 ----------
def ledger():
    p = setp('隨手記.json')
    if not os.path.exists(p):
        return [], {}
    d = json.load(open(p, encoding='utf8'))
    cards = {c[0]: (c[1], c[2]) for c in d['cards']}
    out = []
    for date, amt, cid, cat, note, *rest in d['rec']:
        rid = rest[1] if len(rest) > 1 else ''
        inst = int(rest[2] or 0) if len(rest) > 2 and str(rest[2] or '').isdigit() else 0
        inst_start = rest[3] if len(rest) > 3 and re.fullmatch(r'\d{4}-\d{2}', str(rest[3] or '')) else ''
        bank, name = cards.get(cid, ('其他', '未指定'))
        cash = bank == '其他' or '現金' in name
        unk = cid not in cards or name == '未指定'   # 記帳時沒選卡：先當現金，但會拿去跟所有銀行的帳單對，對上了就是刷卡（不重複算）
        l4 = re.search(r'(\d{4})\s*$', name.replace('-', ' ').replace('·', ' '))
        out.append(dict(date=date, amount=float(amt), bank=bank, card=name, last4=l4.group(1) if l4 else '',
                        category={'稅款': '稅費', '醫療教育': '醫療', '購車／汽機車': '汽機車・購車', '汽機車': '汽機車・購車', '汽車保養': '汽機車・保養維修'}.get(cat, cat), note=note, rid=rid, cash=cash, unk=unk, inst=inst, inst_start=inst_start, foreign=bool(re.search(r'韓國|國外|海外|日圓', name))))
    return out, cards


def match(L, R):
    """隨手記刷卡記錄 ↔ 帳單交易：同銀行（有末四碼就同卡）、金額相近、日期差 5 天內"""
    bills, _base = [], {}
    for r in R:   # 部分代墊拆成兩筆的，合回原本刷卡的總額再對（不然金額對不上）
        if r['kind'] not in ('spend',) or r['category'] == '回饋折抵':
            continue
        k = str(r.get('key', '')).split('#')[0]
        if '#' in str(r.get('key', '')) and k in _base:
            _base[k]['amount'] += r['amount']; continue
        c = dict(r, bill_key=k); bills.append(c); _base[k] = c
    used = set(); res = []
    last_stmt = collections.defaultdict(str); covered = collections.defaultdict(str)
    for r in R:
        last_stmt[r['bank']] = max(last_stmt[r['bank']], r['stmt'])
    for r in R:   # 最新一期帳單涵蓋到哪一天（最後一筆消費日）
        if r['stmt'] == last_stmt[r['bank']]:
            covered[r['bank']] = max(covered[r['bank']], r['txn_date'])
    for x in sorted([x for x in L if not x['cash'] or x.get('unk')], key=lambda x: (bool(x.get('unk')), -x['amount'])):
        unk = x.get('unk')
        tol = 1 if unk else max(2, x['amount'] * (0.06 if x['foreign'] else 0.03))   # 海外含匯差、手續費；沒選卡的要金額一樣
        best = None
        for i, r in enumerate(bills):
            if i in used or (r['bank'] != x['bank'] and not unk) or (unk and not mine(r)):
                continue
            if x['last4'] and r['card'] and r['card'] != x['last4']:
                continue
            dd = abs((datetime.date.fromisoformat(r['txn_date']) - datetime.date.fromisoformat(x['date'])).days)
            da = abs(r['amount'] - x['amount'])
            if dd <= (3 if unk else 5) and da <= tol:
                score = da / max(x['amount'], 1) + dd / 30
                if best is None or score < best[0]:
                    best = (score, i)
        late = False
        if not best and unk:
            continue   # 沒選卡、也對不到帳單 → 算現金
        if not best:   # 第二輪：補記的（記帳日比消費日晚，最多 3 週），金額要一樣
            for i, r in enumerate(bills):
                if i in used or r['bank'] != x['bank'] or abs(r['amount'] - x['amount']) > 1:
                    continue
                if x['last4'] and r['card'] and r['card'] != x['last4']:
                    continue
                dd = (datetime.date.fromisoformat(x['date']) - datetime.date.fromisoformat(r['txn_date'])).days
                if 0 <= dd <= 21 and (best is None or dd < best[0]):
                    best = (dd, i); late = True
        if best:
            used.add(best[1]); r = bills[best[1]]
            if unk:
                x['cash'] = False; x['bank'] = r['bank']; x['card'] = r['cardname']   # 其實是刷卡 → 不算現金
            res.append(dict(x, status='對上（補記）' if late else '對上', bill_merchant=r['merchant'], bill_amount=r['amount'], bill_date=r['txn_date'], bill_card=r['cardname'], bill_key=r['bill_key']))
        else:
            pending = covered.get(x['bank'], '') < x['date']   # 消費日在最新一期帳單之後 → 帳單還沒到
            res.append(dict(x, status='帳單還沒到' if pending else '帳單找不到'))
    start = min((x['date'] for x in L if not x.get('cash')), default='9999')   # 現金（含從發票補記的舊帳）不影響對照起點
    missing = [dict(date=r['txn_date'], bank=r['bank'], card=r['cardname'], merchant=r['merchant'], amount=r['amount'], category=r['category'])
               for i, r in enumerate(bills) if i not in used and r['txn_date'] >= start and mine(r) and r['amount'] > 0 and r['category'] != '年費手續費']
    return res, sorted(missing, key=lambda m: m['date'])


def carry(rec):
    """帳單到了、對上隨手記那筆：
    (1) 隨手記的分類＋備註帶到帳單那筆（設定/隨手記帶入.json，build_data.py 套用）
    (2) 暫列時勾的代墊／代刷 → 轉成帳單那筆的代墊（只轉一次；之後在帳單那筆改的以帳單為準）
    有變動就留 _rebuild.flag，run_local 會馬上重算一次，這次更新就看得到"""
    rows = {x['bill_key']: {'cat': x['category'], 'note': x.get('note', ''), 'rid': x.get('rid', ''), **({'inst': x['inst'], 'ist': x.get('inst_start') or ''} if (x.get('inst') or 0) > 1 else {})}
            for x in rec if str(x.get('status', '')).startswith('對上') and x.get('bill_key')}
    cf = setp('隨手記帶入.json')
    old = json.load(open(cf, encoding='utf8')) if os.path.exists(cf) else {}
    ch = False
    pf = setp('代付標記.json')
    P = json.load(open(pf, encoding='utf8')) if os.path.exists(pf) else {'ticked': []}
    prov, moved = P.get('prov', {}), set(P.get('prov_moved', []))
    tick, ratio = set(P.get('ticked', [])), dict(P.get('ratio', {}))
    n = 0
    for k, v in rows.items():
        m = prov.get(v['rid']) if v['rid'] else None
        if m and v['rid'] not in moved:
            r = float(m[0]); tick.discard(k); ratio.pop(k, None)
            if r >= 0.999: tick.add(k)
            elif r > 0.001: ratio[k] = round(r, 4)
            moved.add(v['rid']); n += 1
    if n:
        P.update(ticked=sorted(tick), ratio=ratio, prov_moved=sorted(moved))
        json.dump(P, open(pf, 'w', encoding='utf8'), ensure_ascii=False, indent=0); ch = True
        print(f'隨手記：暫列時勾的代墊 {n} 筆，帳單到了已轉到帳單那筆')
    if old.get('rows') != rows:
        json.dump({'rows': rows}, open(cf, 'w', encoding='utf8'), ensure_ascii=False, indent=0); ch = True
    if ch:
        open('_rebuild.flag', 'w').close()
    return len(rows)


# ---------- 分期（無卡分期、自己每月轉帳繳的） ----------
#   隨手記那筆勾「分期 N 期」，或系統自動認出（隨手記一大筆現金之後，存款帳戶每月轉出同樣金額 ≈ 總額÷N）：
#   那筆不當成當月一次花掉，改成每月一期算進「帳戶扣款」→ 不會跟每月轉帳重複算
INST_N = (3, 6, 10, 12, 15, 18, 24, 30, 36, 48, 60)
_OUT = re.compile(r'(\d{4}/\d{2}/\d{2})\s+(\S+)\s+(?:(\S.*?)\s+)?([\d,]+\.\d\d)\s+(\S.*?)\s+([\d,]+\.\d\d)\s*$')


def _out_lines(txts):
    seen = {}
    for f in txts:
        for l in open(f, encoding='utf8', errors='ignore'):
            m = _OUT.search(nf(l))
            if m:
                d = m.group(1).replace('/', '-'); a = float(m.group(4).replace(',', ''))
                seen[(d, m.group(2), a, m.group(5).strip())] = dict(date=d, summary=m.group(2), amount=a, memo=m.group(5).strip())
    return sorted(seen.values(), key=lambda x: x['date'])


def _addm(d, k):
    y, m = int(d[:4]), int(d[5:7]) - 1 + k
    y += m // 12; m = m % 12 + 1
    import calendar
    return f'{y:04d}-{m:02d}-{min(int(d[8:10]), calendar.monthrange(y, m)[1]):02d}'


def installments(L, txts):
    lines = _out_lines(txts)
    today = datetime.date.today().isoformat()
    plans, pays = [], []
    for x in L:
        if not x['cash'] or (not x.get('inst') and x['amount'] < 20000):
            continue
        explicit = bool(x.get('inst')); best = None
        for n in ([x['inst']] if x.get('inst') else INST_N):
            per = x['amount'] / n
            hit = [l for l in lines if x['date'] < l['date'] <= _addm(x['date'], n + 2) and abs(l['amount'] - per) <= max(2, per * 0.01)]
            by = collections.defaultdict(dict)
            for l in hit:
                by[l['memo']].setdefault(l['date'][:7], l)   # 同一個收款人、每月一筆
            for memo, mm in by.items():
                hs = sorted(mm.values(), key=lambda z: z['date'])
                if hs and hs[0]['date'] <= _addm(x['date'], 2) and (len(hs) >= 2 or x.get('inst')):
                    if not best or len(hs) > len(best[2]):
                        best = (n, memo, hs)
        if not best and not x.get('inst'):
            continue
        n, memo, hs = best or (x['inst'], '', [])
        per = round(x['amount'] / n)
        name = x['note'] or x['category']
        import subcat as _sc
        if x['category'] in ('其他', '餐飲') and re.search(_sc.SUB_RULES['汽車保養'][0][1], name):
            x['category'] = '汽機車・購車'
        lab = x['category'] if x['category'] not in ('其他', '餐飲') else '分期付款'
        memo = memo if not re.fullmatch(r'[\dX*]+', memo or '') else memo[-4:]   # 帳號只留末 4 碼
        # 每月一期：照實際轉帳日算支出（存款對帳單上那筆）；對帳單還沒到、或從別的帳戶付的月份，先照每月同一天估
        st = x.get('inst_start') or _addm(x['date'], 1)[:7]
        day = hs[0]['date'][8:] if hs else '01'
        bym = {h['date'][:7]: h for h in hs}
        key = x['rid'] or name; acc = 0.0; k = 0; nxt = ''
        for k in range(1, n + 1):
            d = _addm(f'{st}-{day}', k - 1)
            h = bym.get(d[:7])
            if h: d = h['date']
            if d > today:
                nxt = d; k -= 1; break
            amt = round(x['amount'] - acc, 2) if k == n and not h else float(h['amount'] if h else per)
            acc += amt
            pays.append(dict(date=d, amount=amt, label=lab, memo=memo, inst=key, tx=[h['date'], h['amount']] if h else None,
                             summary=f'{name}・分期 {k}/{n}' + ('' if h else ('（預估：對帳單還沒到）' if d[:7] >= (hs[-1]['date'][:7] if hs else '0') else '（存款對帳單沒找到這期轉帳，可能從別的帳戶付）'))))
        x['inst'] = n
        plans.append(dict(date=x['date'], name=name, category=x['category'], total=x['amount'], n=n, per=per, paid=k,
                          left=round(x['amount'] - acc), next=nxt, payee=memo, auto=0 if explicit else 1, rid=x['rid'],
                          start=st, end=_addm(st + '-01', n - 1)[:7]))
    return plans, pays


def activities(R):
    """活動回饋的入帳狀態：刷卡金在帳單上找「回饋折抵」金額相近的那筆"""
    p = setp('活動回饋.json')
    A = json.load(open(p, encoding='utf8')) if os.path.exists(p) else []
    rebs = [r for r in R if r['category'] == '回饋折抵' and r['amount'] < 0]
    used = set()
    for a in A:
        a['status'], a['paid_date'] = (a.get('manual') or ''), ''
        if a['status']:
            continue
        if a['kind'] in ('刷卡金', '帳單折抵', ''):
            for i, r in enumerate(rebs):
                if i in used or (a['bank'] and r['bank'] != a['bank']) or r['stmt'][:7] < a['month']:
                    continue
                if abs(-r['amount'] - a['amount']) <= max(1, a['amount'] * 0.02):
                    used.add(i); a['status'], a['paid_date'] = '已入帳', r['stmt']; break
        if not a['status']:
            ym = datetime.date.today().strftime('%Y-%m')
            late = (int(ym[:4]) * 12 + int(ym[5:])) - (int(a['month'][:4]) * 12 + int(a['month'][5:7])) if len(a['month']) >= 7 else 0
            a['status'] = ('等待入帳' if late <= 3 else '超過 3 個月還沒入帳') if a['kind'] in ('刷卡金', '帳單折抵', '') else '點數／現金，請自行確認'
    return A


if __name__ == '__main__':
    txts = sys.argv[1:] or salary_txts()
    sal = salaries(txts)
    _have = {(x['date'], x['amount']) for x in sal}   # 其他銀行存款對帳單裡的薪資（分享版也適用）；跟富邦那份重複的不算
    sal += [x for x in salaries_any(sorted(glob.glob(os.path.join('dep_txt', '*.txt')))) if (x['date'], x['amount']) not in _have]
    if os.environ.get('LL_DEBUG'): print('薪資', len(sal))
    R = json.load(open('rows.json', encoding='utf8'))
    L, _ = ledger()
    rec, missing = match(L, R) if L else ([], [])
    carry(rec)
    plans, ipays = installments(L, txts)
    cash = [x for x in L if x['cash'] and not x.get('inst')]
    if plans:
        print('分期：' + '；'.join(f"{p['name']} {p['total']:,.0f}（{p['n']} 期，已繳 {p['paid']} 期，剩 {p['left']:,}）" for p in plans))
    _lp = setp('隨手記.json')
    other = [dict(date=d_, amount=float(a_), source=src_, note=n_) for d_, a_, src_, n_ in (json.load(open(_lp, encoding='utf8')).get('inc', []) if os.path.exists(_lp) else [])]
    # 隨手記記的「薪資」：跟存款對帳單的 薪資同一筆（日期差 7 天內、金額差 1% 內）就不重複算；對不上的才算薪資（例如現金、別的帳戶）
    _keep = []
    for o in other:
        if o['source'].startswith('薪資'):
            dup = any(abs((datetime.date.fromisoformat(s['date']) - datetime.date.fromisoformat(o['date'])).days) <= 7 and abs(s['amount'] - o['amount']) <= max(1, o['amount'] * 0.01) for s in sal)
            if not dup:
                sal.append(dict(date=o['date'], amount=o['amount'], payer='隨手記' + (f"・{o['note']}" if o['note'] else ''), src='隨手記'))
            continue
        _keep.append(o)
    other = _keep; sal.sort(key=lambda x: x['date'])
    # 存款利息（deposits.py 從各銀行存款／綜合對帳單抓的）→ 其他收入；隨手記也記了同一筆就不重複
    _dp = 'deposits.json'
    _manual_int = [o for o in other if o['source'].startswith('利息')]   # 只跟隨手記記的比；每筆隨手記只抵掉一筆對帳單利息
    for x in (json.load(open(_dp, encoding='utf8')).get('interest', []) if os.path.exists(_dp) else []):
        _dup = next((o for o in _manual_int if o['date'][:7] == x['date'][:7] and abs(o['amount'] - x['amount']) <= 1), None)
        if _dup is not None:
            _manual_int.remove(_dup)
            continue
        other.append(dict(date=x['date'], amount=x['amount'], source='利息', note=f"{x['bank']}存款利息"))
    bout = bank_outflows(txts, out_rules())
    _mp = setp('銀行收支_手動.json')   # 沒有電子對帳單的帳戶（中信）手動整理的收支
    for e in (json.load(open(_mp, encoding='utf8')).get('entries', []) if os.path.exists(_mp) else []):
        if e.get('type') == 'in':
            other.append(dict(date=e['date'], amount=float(e['amount']), source=e['label'], note=f"{e.get('bank', '')}・{e.get('memo', '')}"))
        else:
            bout.append(dict(date=e['date'], amount=float(e['amount']), label=e['label'].replace('固定轉帳', '固定轉帳'), summary=e.get('bank', '') + '帳戶', memo=e.get('memo', '')))
    for b in bout:   # 房貸月底先扣（遇假日提前）：算到下個月那期，才不會一個月兩期、一個月零期
        if b.get('summary') == '放款繳款' and int(b['date'][8:]) >= 26:
            b['paid_on'] = b['date']; b['date'] = _addm(b['date'][:8] + '01', 1)
            b['summary'] = f'放款繳款（{int(b["paid_on"][5:7])}/{int(b["paid_on"][8:])} 先扣）'
    _ik = {tuple(p['tx']) for p in ipays if p.get('tx')}
    bout = [b for b in bout if (b['date'], b['amount']) not in _ik] + ipays   # 已經有轉帳規則的那幾筆，換成分期那筆（不重複）
    bout.sort(key=lambda x: x['date']); other.sort(key=lambda x: x['date'])
    json.dump(dict(salary=sal, cash=cash, other=other, bank_out=bout, inst=plans), open('income.json', 'w', encoding='utf8'), ensure_ascii=False, indent=0)
    json.dump(dict(records=rec, missing=missing, start=min((x['date'] for x in L if not x.get('cash')), default='')), open('ledger_recon.json', 'w', encoding='utf8'), ensure_ascii=False, indent=0)
    json.dump(activities(R), open('activity.json', 'w', encoding='utf8'), ensure_ascii=False, indent=0)
    c = collections.Counter(x['status'] for x in rec)
    print(f'薪資入帳 {len(sal)} 筆・房貸／轉帳 {len(bout)} 筆・現金 {len(cash)} 筆・隨手記對照：' + '、'.join(f'{k} {v}' for k, v in c.items()) + f'・帳單有隨手記沒記 {len(missing)} 筆')
