# 帳單金額核對：程式解析出的「本期新增」交易合計 vs 帳單上印的本期新增金額
import json, re, glob, os, collections
os.chdir(os.path.dirname(os.path.abspath(__file__)))
T = json.load(open('txns_raw.json', encoding='utf8'))
by = collections.defaultdict(float); pay = collections.defaultdict(float)
for t in T:
    if t['kind'] in ('spend', 'refund') or (t['kind'] == 'adjust' and '取消信用卡年費' in t['desc']):
        by[t['src']] += t['amount']   # 年費取消會算進帳單的本期新增；退還溢付款不算
    elif t['kind'] == 'payment':
        pay[t['src']] += t['amount']
num = lambda x: float(x.replace(',', ''))
pat = {'台新': r'\+本期新增款項\s+(-?[\d,]+)', '玉山': r'本期合計：\s+TWD\s+(-?[\d,]+)', '星展': r'新增消費小計\s+(-?[\d,]+)',
       '國泰': r'正卡本期消費\s+(-?[\d,]+)',
       '渣打': r'^\s*您本期消費金額合計\s+(-?[\d,]+)\s*$'}   # 渣打：每張卡一個合計（OCR 帳單已用 PDF 文字層校正，見 generic_parse.merge_pdf_layer）
JPY = 0.21


def stated_of(b, s, fn):
    if b == '永豐':
        # 新版（2026-05 起）：幣別表格「上期 / 已繳 / 本期新增款項 / …」，臺幣、日圓各一列
        rows = re.findall(r'^(臺幣|日圓)\s+(-?[\d,.]+)\s+(-?[\d,.]+)\s+(-?[\d,.]+)', s, re.M)
        if rows:
            return sum(num(r[3]) * (JPY if r[0] == '日圓' else 1) for r in rows)
        m = re.findall(r'本期金額合計（含退款/調整）\s+(-?[\d,]+)', s)
        return sum(map(num, m)) if m else None
    if b == '聯邦':
        m = re.findall(r'^\s*總計\s+(-?[\d,]+)', s, re.M)
        if not m: return None
        # 總計＝上期金額＋上期付款（沒有日期的列）＋本期新增，扣掉前兩者才是本期新增
        carry = re.findall(r'^\s*(?:上期金額|上期付款金額\S*|\S*謝謝\S*)\s+(-?[\d,]+)\s*$', s, re.M)
        return sum(map(num, m)) - sum(map(num, carry))
    if b == '第一':   # 帳務摘要「上期應繳 −已繳 ＋本期新增 ＋回饋及調整 ＝本期應繳」：現金回饋也逐筆列在明細裡，要一起算
        r = re.search(r'^\s*新臺幣\s+(-?[\d,]+)\s+(-?[\d,]+)\s+(-?[\d,]+)\s+(-?[\d,]+)\s+(-?[\d,]+)', s, re.M)
        if r:
            return num(r.group(3)) + num(r.group(4))
    if b not in pat:   # 通用解析的銀行：用帳單上印的本期新增（找不到就用應繳金額反推）
        import generic_parse
        return generic_parse.stated_total(generic_parse.norm(s), pay[fn])
    m = re.findall(pat[b], s, re.M)
    if m:
        return sum(map(num, m))
    if b == '星展':   # 只有繳款、沒有新增消費的帳單沒有「新增消費小計」：帳務摘要那列「上期 已繳 本期應繳 本期新增 最低」後面都是 0
        r5 = re.search(r'^\s*(-?[\d,]+)\s+(-?[\d,]+)\s+(-?[\d,]+)\s+(-?[\d,]+)\s+(-?[\d,]+)\s*$', s, re.M)
        if r5 and num(r5.group(3)) == 0 and num(r5.group(4)) == 0:
            return 0.0
    if b == '國泰':   # 零消費帳單：本期應繳 = 上期 + 繳款 + 本期新增
        due = re.findall(r'本期應繳總額\s+(-?[\d,]+)', s); prev = re.findall(r'上期帳單總額\s+(-?[\d,]+)', s)
        if due:
            return num(due[0]) - (num(prev[0]) if prev else 0) - pay[fn]
    return None


DUP = set(json.load(open('dup_stmts.json', encoding='utf8'))) if os.path.exists('dup_stmts.json') else set()   # parse.py 認出的重複帳單
bad = n = 0
for f in sorted(glob.glob('txt/*.txt')):
    fn = os.path.basename(f); b = fn.split('__')[0]
    if b == '中信' or fn in DUP: continue
    s = open(f, encoding='utf8').read()
    stated = stated_of(b, s, fn)
    got = by.get(fn, 0); n += 1
    tol = 1 if b != '永豐' or '日圓' not in s else max(2, 0.001 * abs(stated or 0))   # 日圓逐筆換算有尾差
    if stated is None or abs(stated - got) > tol:
        bad += 1; print(b, fn[-30:], 'stated', stated, 'parsed', round(got))
print('bad', bad, 'of', n)
