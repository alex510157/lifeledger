# LifeLedger 生活總帳：本機每月更新（不需要 Claude）
# 用法：雙擊「CardFlow每月更新.bat」，或在這個資料夾執行  python run_local.py
#   --auto      不停下來等中信商家名（缺的先標「（待判讀）」），適合排程
#   --no-mail   這次不寄信
#   --mail      手動更新也寄一次月報（平常手動按「立即更新月報」不寄，只有每日排程每月寄一次）
#   --daily     每日排程用：= --auto，不開視窗；只有在 mail_day 那天（且當月還沒寄過）才寄月報
import os, sys, json, glob, shutil, subprocess, datetime, re

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)
DAILY = '--daily' in sys.argv
AUTO, NOMAIL = ('--auto' in sys.argv or DAILY), '--no-mail' in sys.argv
from paths import setp, LOG
import atexit   # 正在更新的標記（網頁按「立即更新」時，避免跟排程同時跑兩份）
open(os.path.join(BASE, '.running'), 'w').write(str(os.getpid()))
atexit.register(lambda: os.path.exists(os.path.join(BASE, '.running')) and os.remove(os.path.join(BASE, '.running')))
S = json.load(open(setp('local_settings.json'), encoding='utf8'))
# 資料夾改名（CardFlow_卡片消費誌 → LifeLedger_生活總帳）前後都認得：兩個名字都找，存在的才用
_NEW, _OLD = 'LifeLedger_生活總帳', 'CardFlow_卡片消費誌'
_HOME = os.path.dirname(os.path.dirname(os.path.abspath(__file__)).rstrip('\\/'))   # 程式 → _自動化工具 → 帳本資料夾
_HOME = os.path.dirname(_HOME) if os.path.basename(_HOME) == '_自動化工具' else _HOME
if not S.get('out'):    # 沒指定：輸出到「_自動化工具」的上一層（安裝檔裝好的預設）
    S['out'] = _HOME
if not S.get('bills'):
    S['bills'] = [S['out']]
S['bills'] = list(dict.fromkeys(q for p in S.get('bills', []) for q in (p.replace(_OLD, _NEW), p.replace(_NEW, _OLD))))
if S.get('out') and not os.path.isdir(S['out']):
    S['out'] = next((q for q in (S['out'].replace(_OLD, _NEW), S['out'].replace(_NEW, _OLD)) if os.path.isdir(q)), S['out'])
OUT = S['out']
env = dict(os.environ, PYTHONUTF8='1', CARDFLOW_OUT=OUT)
for p in S.get('poppler_bin', []) + [r'C:\poppler\Library\bin', r'C:\Program Files\poppler\Library\bin']:
    if os.path.isdir(p):
        env['PATH'] = p + os.pathsep + env['PATH']; break
for p in [os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs', 'Tesseract-OCR'), r'C:\Program Files\Tesseract-OCR']:
    if os.path.isfile(os.path.join(p, 'tesseract.exe')):     # OCR（遠東等特殊字型帳單）
        env['PATH'] = p + os.pathsep + env['PATH']; break


def step(t): print(f'\n=== {t} ===', flush=True)


def py(script, *args, quiet=False):
    r = subprocess.run([sys.executable, script, *args], env=env, capture_output=True, text=True, encoding='utf8', errors='replace')
    if r.returncode:
        print(r.stdout[-2000:], r.stderr[-3000:]); sys.exit(f'✗ {script} 失敗，請把上面的錯誤訊息給 Claude 看')
    if not quiet and r.stdout.strip():
        print(r.stdout.strip()[-1500:])
    return r.stdout


if not shutil.which('pdftotext', path=env['PATH']):
    sys.exit('✗ 找不到 pdftotext（Poppler）。請照「本機執行教學.md」第 1 步安裝，或在「設定\\local_settings.json」的 poppler_bin 填它的 bin 資料夾。')

step('0. 清掉多餘附件（繳款單、繳款聯、簽章檔、繳款提醒）')
_junk = re.compile(r'PaymentSlip|繳款聯|smime|設定繳款提醒|\.p7s$|\.ics$', re.I)
_n = 0
for _src in [OUT] + list(S.get('bills', [])):
    for _d in (os.listdir(_src) if os.path.isdir(_src) else []):
        _p = os.path.join(_src, _d)
        if not os.path.isdir(_p) or _d.startswith(('_', '月報', 'Claude', 'CardFlow', 'LifeLedger')):
            continue
        for _f in os.listdir(_p):
            if _junk.search(_f):
                try:
                    os.remove(os.path.join(_p, _f)); _n += 1
                except OSError:
                    pass
print('刪除', _n, '個' if _n else '個（沒有）')
try:   # 自動整理：重複、用不到的檔案搬到「_待刪除」（不會真的刪）
    _t = subprocess.run([sys.executable, 'tidy.py'], env=env, capture_output=True, text=True, encoding='utf8', errors='replace', timeout=120)
    if _t.stdout.strip():
        print(_t.stdout.strip())
except Exception:
    pass

def _grab_invoices():
    """財政部平台下載的發票明細（載具發票明細下載 / 彙整通知附件）在「下載」資料夾 → 自動搬進 帳本\\_電子發票"""
    import shutil, hashlib, glob as _g
    dst = os.path.join(OUT, '_電子發票'); n = 0
    home = os.path.expanduser('~')
    srcs = [os.path.join(home, 'Downloads'), os.path.join(home, '下載')] + [os.path.join(os.environ[k], 'Downloads') for k in ('OneDrive', 'OneDriveConsumer') if os.environ.get(k)]
    for d in dict.fromkeys(srcs):
        for f in _g.glob(os.path.join(d, '*.csv')):
            try:
                if os.path.getsize(f) > 20_000_000:
                    continue
                raw = open(f, 'rb').read()
                head = next((raw[:300].decode(e, 'ignore') for e in ('utf-8-sig', 'cp950')), '')
                if not (head.lstrip().startswith('載具自訂名稱') or head.lstrip().startswith('表頭=M|')):
                    continue
                os.makedirs(dst, exist_ok=True)
                h = hashlib.md5(raw).hexdigest()[:8]
                if any(hashlib.md5(open(x, 'rb').read()).hexdigest()[:8] == h for x in _g.glob(os.path.join(dst, '*.csv'))):
                    os.remove(f); continue   # 一樣的檔已經有了
                shutil.move(f, os.path.join(dst, datetime.date.today().strftime('%Y-%m-%d') + '_平台下載_' + os.path.basename(f))); n += 1
            except Exception:
                pass
    if n:
        print(f'電子發票：從「下載」資料夾搬進 {n} 個發票明細檔')


try:
    _grab_invoices()
except Exception:
    pass

if S.get('mailboxes'):
    step('0a. 從信箱收新帳單（任何銀行；Gmail／Yahoo／HiNet／Outlook 電腦版，可以好幾個信箱）')
    try:
        _r = subprocess.run([sys.executable, 'mail_fetch.py'], env=env, capture_output=True, text=True, encoding='utf8', errors='replace', timeout=1800)
        print((_r.stdout.strip() or '（沒有輸出）')[-1500:])
        if _r.returncode:
            print('⚠ 收信程式出錯（不影響其他步驟）：', _r.stderr.strip()[-400:])
    except subprocess.TimeoutExpired:
        print('⚠ 收信超過 30 分鐘，先跳過（下次會接著收）')

step('1. 更新月份設定')
today = datetime.date.today()
def back(n):
    y, m = today.year, today.month - n
    while m <= 0: y -= 1; m += 12
    return y, m
cfg = json.load(open('config.json', encoding='utf8'))
ly, lm = back(1); cy, cm = back(2)          # 報告月份＝往前兩個月（玉山帳單較晚到）
_ds = sorted(os.path.basename(f)[:7] for _p in dict.fromkeys(list(S.get('bills', [])) + [OUT]) if os.path.isdir(_p)
             for f in glob.glob(os.path.join(_p, '*', '*.pdf')) if re.match(r'\d{4}-\d{2}-\d{2}_', os.path.basename(f)))
_want = S.get('report_start') or (_ds[0] if _ds else f'{today.year}-01')   # 報表從哪個月開始：設定的、或最早一份帳單
if not cfg.get('start') or (S.get('report_start') and cfg.get('start') != S['report_start']):   # 第一次，或「補抓舊帳單」改了起始月
    cfg['start'] = _want
    print('報表從', cfg['start'], '開始')
cfg.update(last_month=f'{ly}-{lm:02d}', cur_year=cy, cur_month=cm, data_through=today.strftime('%Y/%m/%d'))
json.dump(cfg, open('config.json', 'w', encoding='utf8'), ensure_ascii=False)
print(f'報告月份 {cy}/{cm:02d}，資料至 {cfg["data_through"]}')

step('2. 讀取 Excel 卡片清單裡你改過的卡名')
xlsx = os.path.join(OUT, 'LifeLedger_生活總帳.xlsx')
bak = os.path.join(OUT, '_備份'); os.makedirs(bak, exist_ok=True)
for _n in ('LifeLedger_生活帳本.xlsx', 'CardFlow_卡片消費誌.xlsx'):   # 改名前的舊檔：讀它的勾選（代付、歸屬、活動），再收進備份
    _old = os.path.join(OUT, _n)
    if not os.path.exists(_old):
        continue
    if not os.path.exists(xlsx):
        shutil.copy2(_old, xlsx)
    try:
        shutil.move(_old, os.path.join(bak, f'{_n[:-5]}_改名前_{today:%Y%m%d}.xlsx'))
    except OSError:
        print(f'⚠ 舊檔 {_n} 正被開著，關掉後可直接刪除（內容已帶到 LifeLedger_生活總帳.xlsx）')
for _f in ('CardFlow月報.html', 'CardFlow全期帳本.html', 'LifeLedger全景帳本.html'):   # 舊檔名的網頁，換成新名字
    _p = os.path.join(OUT, '月報', _f)
    if os.path.exists(_p):
        try: os.remove(_p)
        except OSError: pass
if os.path.exists(xlsx):
    shutil.copy2(xlsx, os.path.join(bak, f'LifeLedger_生活總帳_{today:%Y%m%d}.xlsx'))
    py('sync_cards.py', xlsx)

step('3. 解密新帳單')
srcs = [p for p in dict.fromkeys(S['bills'] + [OUT]) if os.path.isdir(p)]   # 每個帳單資料夾都掃（雲端硬碟同步的、自己下載的）
if not srcs:
    sys.exit('✗ 找不到帳單資料夾：' + '、'.join(S['bills']))
print('帳單來源：', '、'.join(srcs))
if not any(glob.glob(os.path.join(p, d, '*.[Pp][Dd][Ff]')) for p in srcs for d in os.listdir(p) if os.path.isdir(os.path.join(p, d)) and not d.startswith(('_', '月報'))):
    print('\n還沒有任何帳單 PDF，所以還做不出月報和生活帳本。兩種方法擇一：')
    if not S.get('mailboxes'):
        print('  A.（建議）雙擊「設定精靈.bat」→【0c】加入收帳單的信箱（Gmail 要用應用程式密碼）→ 再按「立即更新月報.bat」，會自動從 2025/01 補抓帳單')
    else:
        print('  A. 信箱已設定但沒收到帳單：看上面「收信」那幾行的訊息（登入失敗？找到 0 封？）。帳單可能寄到別的信箱，再到設定精靈【0c】加那個信箱')
    print('  B. 自己把信用卡帳單 PDF 放進帳本資料夾裡對應的銀行資料夾（例如「台新」「國泰」，沒有就新增一個用銀行名字命名的資料夾），再按「立即更新月報.bat」')
    sys.exit(0)
from banks import KNOWN, short
newb = sorted({short(d) for p in srcs for d in os.listdir(p) if os.path.isdir(os.path.join(p, d)) and short(d) not in KNOWN
               and not d.startswith(('_', '月報', 'Claude', 'CardFlow', 'LifeLedger')) and glob.glob(os.path.join(p, d, '*.pdf'))})
if newb:
    print('其他銀行（用通用解析，金額會跟帳單總額核對）：', '、'.join(newb))
py('decrypt_all.py', *srcs)

step('4. 中信商家名（帳單上的中文是圖片）')
py('ctbc_crop.py', quiet=True)
while True:
    out = py('ctbc_build.py', quiet=True)
    miss = re.search(r'missing names: \[(.*)\]', out)
    miss = [x.strip(" '") for x in miss.group(1).split(',') if x.strip()] if miss else []
    if not miss:
        print('中信商家名都齊了'); break
    print(f'有 {len(miss)} 筆中信消費還沒有商家名：', '、'.join(miss))
    print('做法：打開 ctbc_strips 資料夾裡對應帳單的圖片（檔名＝帳單期別），每一列左邊有列號，')
    print('      在 ctbc_names.txt 最後加一行「列號 商家名」，例如：11510-3 全家便利商店')
    if AUTO:
        print('（--auto 模式：先標成「（待判讀）」繼續）'); break
    if os.name == 'nt':
        os.startfile(os.path.join(BASE, 'ctbc_strips')); os.startfile(setp('ctbc_names.txt'))
    a = input('填好存檔後按 Enter 再檢查；輸入 s 先略過：').strip().lower()
    if a == 's': break

step('5. 重建資料、回饋核對、Excel、月報')
for s in ['fetch_ledger.py', 'parse.py', 'ctbc_build.py', 'build_data.py', 'deposits.py', 'income.py', 'points.py', 'recur.py', 'plans.py', 'compact.py', 'rewards_check.py', 'build_xlsx2.py']:
    print('·', s, flush=True); py(s, quiet=s not in ('rewards_check.py', 'fetch_ledger.py', 'deposits.py', 'income.py'))
    if s == 'income.py' and os.path.exists('_rebuild.flag'):   # 帳單對上隨手記：分類、備註、代墊帶過去了 → 馬上重算一次
        os.remove('_rebuild.flag')
        print('· 帶入隨手記的分類／代墊，重算一次', flush=True); py('build_data.py', quiet=True); py('income.py', quiet=True)
        if os.path.exists('_rebuild.flag'): os.remove('_rebuild.flag')
rec = py('recon.py', quiet=True)
_rl = rec.strip().splitlines()
print('帳單金額核對：', _rl[-1] if _rl else '—')
if len(_rl) > 1:
    print('⚠ 這幾份帳單解析出的金額跟帳單上印的不一樣，請把這段給 Claude 看：'); print('\n'.join(_rl[:-1][:10]))
subj = py('monthly_email.py', quiet=True).strip().splitlines()[-1]
print(subj)
new_cards = sorted({r['cardname'] for r in json.load(open('rows.json', encoding='utf8')) if '待確認' in r['cardname']})
if new_cards:
    print('⚠ 有卡名待確認：', '、'.join(new_cards), '（可在 Excel「卡片清單」改卡名，下次會保留）')

step('6. 存檔')
rep = os.path.join(OUT, '月報'); os.makedirs(rep, exist_ok=True)
ym = f'{cy}-{cm:02d}'
shutil.copy2('email.html', os.path.join(rep, f'月報信件_{ym}.html'))
print('Excel：', xlsx)
print('網頁月報（離線版）：', os.path.join(rep, 'LifeLedger月報.html'))

if S.get('web', {}).get('enabled'):
    step('6b. 上傳加密網頁到 GitHub')
    r = subprocess.run([sys.executable, 'publish_web.py'], env=env, capture_output=True, text=True, encoding='utf8', errors='replace')
    print((r.stdout + r.stderr).strip()[-800:] or '—')   # 上傳失敗不影響 Excel 和離線月報

if (S.get('ledger') or {}).get('url'):
    step('6c. 上傳加密的月報、生活帳本到隨手記網站')
    r = subprocess.run([sys.executable, 'publish_netlify.py'], env=env, capture_output=True, text=True, encoding='utf8', errors='replace')
    print((r.stdout + r.stderr).strip()[-600:] or '—')

send = S.get('mail', {}).get('enabled') and not NOMAIL and (DAILY or '--mail' in sys.argv)   # 手動按「立即更新月報」不寄信
if send and DAILY:                           # 每日排程：只在 mail_day 當天或之後、且這個月還沒寄過才寄
    sent = open('.last_mail', encoding='utf8').read().strip() if os.path.exists('.last_mail') else ''
    send = today.day >= S['mail'].get('mail_day', 12) and sent != today.strftime('%Y-%m')
if send:
    step('7. 寄月報')
    import smtplib
    from email.mime.text import MIMEText
    M = S['mail']
    msg = MIMEText(open('email.html', encoding='utf8').read(), 'html', 'utf-8')
    msg['Subject'] = open('email_subject.txt', encoding='utf8').read().strip()
    msg['From'] = M['from']; msg['To'] = M['to']
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as s:
        s.login(M['from'], M['app_password'].replace(' ', '')); s.send_message(msg)
    print('已寄到', M['to'])
    open('.last_mail', 'w', encoding='utf8').write(today.strftime('%Y-%m'))

# 白天也自動更新（隨手記剛記的、新到的帳單）：12:30、16:30、20:30 各跑一次。第一次跑到這裡會自動建立排程
if os.name == 'nt':
    try:
        _bat = os.path.join(BASE, 'lifeledger_daily.bat')
        _pyw = os.path.join(os.path.dirname(sys.executable), 'pythonw.exe'); _daily = os.path.join(BASE, 'daily.pyw')
        if os.path.exists(_pyw) and os.path.exists(_daily):   # 用 pythonw 執行：排程跑的時候不會跳出黑色視窗
            _key, _tr = _daily, f'"{_pyw}" "{_daily}"'
        else:
            _key, _tr = _bat, f'"{_bat}"'
        for _tn, _args in (('LifeLedger 白天更新', ['/SC', 'DAILY', '/ST', '12:30', '/RI', '240', '/DU', '09:00']),
                           ('LifeLedger Daily', ['/SC', 'DAILY', '/ST', '07:30'])):
            _q = subprocess.run(['schtasks', '/Query', '/TN', _tn, '/XML'], capture_output=True)
            _x = _q.stdout.decode('utf-16', 'ignore') if _q.stdout[:2] in (b'\xff\xfe', b'\xfe\xff') else _q.stdout.decode('utf8', 'ignore')
            if _q.returncode == 0 and _key.lower() in _x.lower():
                continue   # 排程已經指向這個資料夾
            if _q.returncode and _tn == 'LifeLedger Daily':
                continue   # 早上的排程由安裝程式建立；沒有就不自己加
            r_ = subprocess.run(['schtasks', '/Create', '/TN', _tn] + _args + ['/TR', _tr, '/F'], capture_output=True, text=True)
            if r_.returncode == 0 and _tn == 'LifeLedger Daily' and os.path.exists('schedule_fix.ps1'):   # 錯過時間開機補跑、用電池也跑
                subprocess.run(['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', 'schedule_fix.ps1'], capture_output=True)
            print(f'已設定自動更新排程「{_tn}」（指向目前的帳本資料夾）' if r_.returncode == 0 else f'⚠ 排程「{_tn}」建立失敗：' + (r_.stderr or r_.stdout).strip()[:120])
    except Exception as e_:
        print('⚠ 白天自動更新排程：', e_)
    try:   # 網頁上的「⟳ 立即更新」：每 10 分鐘看一次有沒有人按（用 pythonw 在背景跑，不跳視窗；沒人按就只讀一下）
        _pw = os.path.join(os.path.dirname(sys.executable), 'pythonw.exe')
        _pw = _pw if os.path.exists(_pw) else sys.executable
        _w = os.path.join(BASE, 'refresh_watch.py'); _tn = 'LifeLedger 立即更新偵測'
        _q = subprocess.run(['schtasks', '/Query', '/TN', _tn, '/XML'], capture_output=True)
        _x = _q.stdout.decode('utf-16', 'ignore') if _q.stdout[:2] in (b'\xff\xfe', b'\xfe\xff') else _q.stdout.decode('utf8', 'ignore')
        if not (_q.returncode == 0 and _w.lower() in _x.lower()) and os.path.exists(_w):
            r_ = subprocess.run(['schtasks', '/Create', '/TN', _tn, '/SC', 'MINUTE', '/MO', '10', '/TR', f'"{_pw}" "{_w}"', '/F'], capture_output=True, text=True)
            print(f'已設定「{_tn}」（網頁按立即更新，10 分鐘內電腦就會更新）' if r_.returncode == 0 else f'⚠ 排程「{_tn}」建立失敗：' + (r_.stderr or r_.stdout).strip()[:160])
    except Exception as e_:
        print('⚠ 立即更新偵測排程：', e_)

print('\n✓ 完成。打開網頁月報：', os.path.join(rep, 'LifeLedger月報.html'))
if os.name == 'nt' and not AUTO and not DAILY:
    os.startfile(os.path.join(rep, 'LifeLedger月報.html'))
