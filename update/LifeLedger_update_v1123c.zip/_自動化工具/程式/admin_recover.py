# LifeLedger 管理者救援工具（只有網站管理者需要；雙擊「管理者救援.bat」）
#   1) 產生管理者金鑰：第一次用。產生一對 RSA-OAEP 3072 金鑰
#        私鑰 → 設定\admin_recovery_key.pem（用你自己記得的密語加密；不上傳、不進分享版）
#        公鑰 → 設定\admin_recovery_pubkey.txt，並貼到 Netlify 的環境變數 ADMIN_RECOVERY_PUBKEY
#   2) 檢查：網站上的公鑰是不是這台電腦的這把
#   3) 幫家人救回資料：家人忘了密碼、也沒有救援碼時，用 ADMIN_KEY 取回「用管理者公鑰包的資料金鑰」(wrap_admin)，
#      在這台電腦用私鑰解開，再用一組暫時密碼重新包好、重設家人的密碼。伺服器自始至終看不到資料金鑰。
# 注意：有私鑰＋密語＋ADMIN_KEY 的人，技術上看得到每個人的帳。三樣都要自己保管好。
import getpass, hashlib, json, os, sys
BASE = os.path.dirname(os.path.abspath(__file__)); os.chdir(BASE)
from paths import setp
import ledger_client as LC

KEY_FILE, PUB_FILE = setp('admin_recovery_key.pem'), setp('admin_recovery_pubkey.txt')


def _crypto():
    LC._aesgcm()   # 沒有 cryptography 套件就自動安裝
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding, rsa
    return hashes, serialization, padding, rsa


def kid_of(pub_b64):
    """和伺服器的 pubkeyId 一樣：sha256(公鑰的 base64 字串) 前 16 碼"""
    return hashlib.sha256(pub_b64.encode('ascii')).hexdigest()[:16]


def genkey(passphrase, key_file=KEY_FILE, pub_file=PUB_FILE):
    """產生金鑰 → 回傳公鑰（SPKI DER 的 base64）"""
    if len(passphrase) < 10: raise LC.LedgerError('密語至少 10 個字')
    hashes, serialization, padding, rsa = _crypto()
    k = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    pem = k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                          serialization.BestAvailableEncryption(passphrase.encode('utf8')))
    pub = LC.b64e(k.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo))
    os.makedirs(os.path.dirname(key_file), exist_ok=True)
    open(key_file, 'wb').write(pem)
    open(pub_file, 'w', encoding='ascii').write(pub + '\n')
    return pub


def load_key(passphrase, key_file=KEY_FILE):
    hashes, serialization, padding, rsa = _crypto()
    try:
        k = serialization.load_pem_private_key(open(key_file, 'rb').read(), passphrase.encode('utf8'))
    except FileNotFoundError:
        raise LC.LedgerError(f'找不到私鑰 {key_file}（要先用「1) 產生管理者金鑰」）')
    except (ValueError, TypeError):
        raise LC.LedgerError('私鑰的密語不對')
    pub = LC.b64e(k.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo))
    return k, pub


def unwrap_admin(k, pub, w):
    """wrap_admin = {v:1, alg:"RSA-OAEP-256", kid, ct} → 資料金鑰"""
    hashes, serialization, padding, rsa = _crypto()
    if not isinstance(w, dict) or w.get('v') != 1 or w.get('alg') != 'RSA-OAEP-256':
        raise LC.LedgerError('管理者金鑰包的資料金鑰格式不對')
    if w.get('kid') != kid_of(pub):
        raise LC.LedgerError(f'這份資料金鑰是用另一把管理者金鑰包的（{w.get("kid")}），這台電腦的是 {kid_of(pub)}')
    try:
        dek = k.decrypt(LC.b64d(w.get('ct')), padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
    except Exception:
        raise LC.LedgerError('私鑰解不開這份資料金鑰')
    if len(dek) != 32: raise LC.LedgerError('資料金鑰的格式不對')
    return dek


def recover(base, user, admin, passphrase, temp_pw, key_file=KEY_FILE, log=print):
    """幫 user 重設成暫時密碼 temp_pw；帳本已加密時，用私鑰解開資料金鑰再用暫時密碼重新包好。回傳 'encrypted' 或 'plain'"""
    if len(temp_pw) < 6: raise LC.LedgerError('暫時密碼至少 6 個字')
    C = LC.Client({'url': base, 'user': user, 'password': temp_pw}, ua='LifeLedger-admin')
    st, j = C._http('POST', '/api/ledger?action=adminwrap', {'user': user, 'admin': admin})
    if st != 200: C._raise(st, j, '取回管理者資料金鑰')
    body = {'user': user, 'admin': admin, 'newPassword': temp_pw}
    if C.probe(): body['newLoginKey'] = LC.login_key(user, temp_pw)
    if j.get('encrypted'):
        if not j.get('wrap_admin'):
            raise LC.LedgerError('這個帳號的帳本已經加密，但沒有用管理者金鑰包的資料金鑰（可能是設定管理者金鑰之前加密的、而且還沒重新登入過），救不回來')
        k, pub = load_key(passphrase, key_file)
        dek = unwrap_admin(k, pub, j['wrap_admin'])
        body['wrap_pw'] = LC.wrap_dek(dek, temp_pw, user, 'pw')
        log('✓ 已在這台電腦解開資料金鑰，用暫時密碼重新包好')
    st, r = C._http('POST', '/api/ledger?action=reset', body)
    if st != 200: C._raise(st, r, '重設密碼')
    # 用暫時密碼登入，確認真的讀得到（加密的話也解得開）
    rev, d, enc = C.get_ledger()
    log(f'✓ 已重設：用暫時密碼登入成功，帳本 {len((d or {}).get("records", []))} 筆' + ('（加密帳本，解得開）' if enc else ''))
    return 'encrypted' if enc else 'plain'


def _ask_pw(prompt, min_len, twice=True):
    while True:
        a = getpass.getpass(prompt)
        if len(a) < min_len: print(f'  至少 {min_len} 個字'); continue
        if twice and getpass.getpass('  再輸入一次：') != a: print('  兩次不一樣'); continue
        return a


def main():
    S = json.load(open(setp('local_settings.json'), encoding='utf8')) if os.path.exists(setp('local_settings.json')) else {}
    site = ((S.get('ledger') or {}).get('url') or 'https://alexledger.netlify.app').rstrip('/')
    print('LifeLedger 管理者救援工具（網站：' + site + '）\n')
    print('  1) 產生管理者金鑰（第一次用）')
    print('  2) 檢查網站上的管理者公鑰')
    print('  3) 幫家人救回資料（忘了密碼、也沒有救援碼）')
    c = input('\n選哪一個？（1／2／3，其他鍵離開）').strip()
    try:
        if c == '1':
            if os.path.exists(KEY_FILE):
                print(f'\n⚠ 已經有管理者私鑰：{KEY_FILE}')
                print('  重新產生的話，之前用舊公鑰包的資料金鑰就救不回來（直到每個人重新登入、補包新的那份）。')
                if input('  確定要重新產生？輸入 YES 繼續：').strip() != 'YES': return
            print('\n密語：保護私鑰用，要自己記得（至少 10 個字，畫面不會顯示）。忘了密語，救援功能就失效。')
            pub = genkey(_ask_pw('  密語：', 10))
            print(f'\n✓ 私鑰：{KEY_FILE}（已用密語加密）')
            print(f'✓ 公鑰：{PUB_FILE}（公開也沒關係）　代號 {kid_of(pub)}')
            print('\n接下來：Netlify → 你的網站 → Site configuration → Environment variables → 新增')
            print('  名稱：ADMIN_RECOVERY_PUBKEY　　值：上面公鑰檔裡那一整行')
            print('  存好後到 Deploys 按「Trigger deploy」。之後每個人登入隨手記時，會自動多包一份資料金鑰給這把公鑰。')
        elif c == '2':
            C = LC.Client({'url': site, 'user': '-', 'password': '-'})
            st, j = C._http('GET', '/api/ledger?action=pubkey')
            local = open(PUB_FILE, encoding='ascii').read().strip() if os.path.exists(PUB_FILE) else None
            if st != 200: print(f'⚠ 網站是舊版，不支援管理者救援（{st}）'); return
            if not j.get('pubkey'): print('⚠ 網站還沒有設定 ADMIN_RECOVERY_PUBKEY'); return
            print(f'網站上的公鑰代號：{j.get("kid")}')
            print('✓ 和這台電腦的私鑰是同一把' if local and kid_of(local) == j.get('kid') else
                  '⚠ 和這台電腦的不一樣（或這台電腦沒有金鑰）：救援會失敗')
        elif c == '3':
            user = input('\n家人的隨手記帳號：').strip()
            admin = getpass.getpass('ADMIN_KEY（Netlify 環境變數裡的管理碼，畫面不會顯示）：').strip()
            temp = _ask_pw('給家人的暫時密碼（至少 6 個字）：', 6)
            pp = getpass.getpass('管理者私鑰的密語（帳本沒加密的話不會用到）：') if os.path.exists(KEY_FILE) else ''
            r = recover(site, user, admin, pp, temp)
            print('\n完成。請家人：用暫時密碼登入隨手記 → 設定 → 馬上改密碼、產生新的救援碼；電腦端（設定精靈【0b】）也要改成新密碼。')
    except LC.LedgerError as e:
        print('\n✗ ' + str(e))
    except KeyboardInterrupt:
        print('\n已取消')


if __name__ == '__main__':
    main()
    if os.name == 'nt' and sys.stdin.isatty():
        input('\n按 Enter 關閉')
