# LifeLedger：把月報與生活帳本「用密碼加密」後上傳到 GitHub Pages，得到一個固定網址（手機、電腦都能加書籤）
#   python publish_web.py          由 run_local.py 在每次更新後自動呼叫；內容沒變就不上傳
#   python publish_web.py --force  不管有沒有變都重新上傳
# 設定在 local_settings.json 的 "web"：enabled / token（GitHub 權杖）/ repo / password（看網頁用的密碼）
# 加密方式：PBKDF2-SHA256（60 萬次）推導金鑰 → AES-256-GCM。網頁上只有密文，輸入正確密碼才會在瀏覽器裡解開。
import os, sys, json, re, base64, hashlib, subprocess, urllib.request, urllib.error

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)
from paths import setp
S = json.load(open(setp('local_settings.json'), encoding='utf8'))
W = S.get('web', {})
from paths import HOME
OUT = os.environ.get('CARDFLOW_OUT') or S.get('out') or HOME
FORCE = '--force' in sys.argv
DRY = '--dry' in sys.argv   # 只在本機產生 web_preview 資料夾，不上傳（測試用）
ITER = 600_000


def log(*a): print(*a, flush=True)


if not W.get('enabled'):
    log('網頁上傳未啟用（local_settings.json 的 web.enabled = false），略過'); sys.exit(0)
for k in (('password',) if DRY else ('token', 'password')):
    if not W.get(k) or '填' in W.get(k, ''):
        sys.exit(f'✗ local_settings.json 的 web.{k} 還沒填')
if len(W['password']) < 8:
    sys.exit('✗ 網頁密碼至少要 8 個字（建議 12 個字以上，英數混合）')

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
except ImportError:
    log('第一次使用：安裝加密套件 cryptography …')
    subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', 'cryptography'], check=True)
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes

# ---------- 1. 準備要發布的兩頁 ----------
rd = lambda p: open(p, encoding='utf8').read()
url_report = rd('report_url.txt').strip() if os.path.exists('report_url.txt') else ''
url_ledger = rd('ledger_url.txt').strip() if os.path.exists('ledger_url.txt') else ''


def localize(h):
    """claude.ai 的連結改成 GitHub 版本自己的頁面，並且同一個分頁打開（才不用再輸入一次密碼）"""
    if url_ledger:
        h = h.replace(f'href="{url_ledger}" target="_blank" rel="noopener"', 'href="ledger.html"').replace(url_ledger, 'ledger.html')
    if url_report:
        h = h.replace(url_report, 'index.html')
    return h


def full_doc(frag, title):
    if frag.lstrip().lower().startswith('<!doctype'):
        return frag
    return ('<!doctype html>\n<html lang="zh-Hant"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
            f'<title>{title}</title></head><body>\n' + frag + '\n</body></html>')


pages = {}
rep = os.path.join(OUT, '月報', 'LifeLedger月報.html')
if not os.path.exists(rep):
    sys.exit('✗ 找不到離線月報：' + rep)
pages['index.html'] = ('LifeLedger 月報', localize(rd(rep)))
if os.path.exists('刷卡帳本.html'):
    pages['ledger.html'] = ('LifeLedger 生活帳本', localize(full_doc(rd('刷卡帳本.html'), 'LifeLedger 生活帳本')))

# ---------- 1b. 隨手記網頁也放一份在 GitHub（/app/）：沒有 Netlify 標籤，資料一樣存在隨手記網站 ----------
APP = {}
_appdir = os.path.join(BASE, '..', '隨手記網站', 'public')
_api = ((S.get('ledger') or {}).get('url') or '').rstrip('/')
def _cors_ok(api):
    """隨手記網站的伺服器是不是新版（允許從 GitHub 網址連過去）"""
    try:
        req = urllib.request.Request(api + '/api/ledger', method='OPTIONS', headers={'Origin': 'https://example.github.io', 'Access-Control-Request-Method': 'GET', 'User-Agent': 'LifeLedger'})
        with urllib.request.urlopen(req, timeout=20) as r:
            return bool(r.headers.get('access-control-allow-origin'))
    except Exception:
        return False


def _go(to, title):   # 轉址頁（保留 ?p=report 這類參數和 #）
    return ('<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="robots" content="noindex">'
            f'<title>{title}</title><script>location.replace("{to}"+location.search+location.hash)</script>'
            f'<meta http-equiv="refresh" content="0;url={to}"></head><body><a href="{to}">{title}</a></body></html>')


CORS_OK = False
if _api and os.path.isdir(_appdir):
    CORS_OK = _cors_ok(_api)
    if CORS_OK:
        for _f in ('index.html', 'view.html', 'catalog.json', 'sync.js'):   # sync.js：隨手記的同步防護（index.html 會載入它，少了它隨手記打不開）
            _p = os.path.join(_appdir, _f)
            if os.path.exists(_p):
                APP['app/' + _f] = rd(_p).replace('__LL_API__', _api)
    else:   # 伺服器還是舊版：GitHub 網址先直接轉到隨手記網站（資料、帳密都一樣），等伺服器更新後自動換成 GitHub 版
        APP['app/index.html'] = _go(_api + '/', 'LifeLedger 隨手記')
        APP['app/view.html'] = _go(_api + '/view.html', 'LifeLedger 月報')

# ---------- 2. 內容有沒有變（忽略每天都會變的「資料至」日期） ----------
strip_date = lambda h: re.sub(r'(資料至\s*)\d{4}/\d{2}/\d{2}', r'\1', h)
digest = hashlib.sha256((W['password'] + '\0' + '\0'.join(strip_date(h) for _, h in pages.values()) + '\0'.join(APP.values()) + (rd(os.path.join(BASE, '..', '隨手記網站', 'netlify', 'functions', 'ledger.mjs')) if os.path.exists(os.path.join(BASE, '..', '隨手記網站', 'netlify', 'functions', 'ledger.mjs')) else '')).encode()).hexdigest()
if not FORCE and not DRY and os.path.exists('.web_hash') and rd('.web_hash').strip() == digest:
    log('網頁內容沒有變化，不用上傳'); sys.exit(0)

# ---------- 3. 加密，包進解鎖頁 ----------
SHELL = rd('web_lock.html')


def seal(title, html):
    salt, iv = os.urandom(16), os.urandom(12)
    key = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=ITER).derive(W['password'].encode('utf8'))
    ct = AESGCM(key).encrypt(iv, __import__('gzip').compress(html.encode('utf8'), 9), None)   # 先壓縮：檔案小約 8 倍，手機打開快
    blob = json.dumps({'v': 1, 'gz': 1, 'iter': ITER, 'salt': base64.b64encode(salt).decode(), 'iv': base64.b64encode(iv).decode(),
                       'ct': base64.b64encode(ct).decode()})
    return SHELL.replace('__TITLE__', title).replace('__BLOB__', blob)


def redirect(to, title):
    return ('<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="robots" content="noindex">'
            f'<meta http-equiv="refresh" content="0;url={to}"><title>{title}</title>'
            f'<script>location.replace("{to}"+location.hash)</script></head><body><a href="{to}">{title}</a></body></html>')


if APP and not W.get('keep_encrypted'):
    # 統一成一組帳密：GitHub 上的月報／生活帳本改成直接開「隨手記帳號登入」的版本（內容在電腦上用隨手記密碼加密，存在隨手記網站）
    _vb = 'app/view.html' if CORS_OK else _api + '/view.html'
    files = {'index.html': redirect(_vb + '?p=report', 'LifeLedger 月報'), 'ledger.html': redirect(_vb + '?p=book', 'LifeLedger 生活帳本')}
else:
    files = {name: seal(t, h) for name, (t, h) in pages.items()}
files.update(APP)
files['.nojekyll'] = ''
files['robots.txt'] = 'User-agent: *\nDisallow: /\n'
if DRY:
    os.makedirs('web_preview', exist_ok=True)
    for name, content in files.items():
        open(os.path.join('web_preview', name), 'w', encoding='utf8').write(content)
    log('已產生 web_preview（未上傳）'); sys.exit(0)

# ---------- 4. 上傳到 GitHub ----------
API = 'https://api.github.com'
HDR = {'Authorization': 'Bearer ' + W['token'].strip(), 'Accept': 'application/vnd.github+json',
       'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'LifeLedger-publisher'}


def gh(method, path, body=None, ok404=False):
    req = urllib.request.Request(API + path, method=method, headers=HDR,
                                 data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            t = r.read()
            return json.loads(t) if t else {}
    except urllib.error.HTTPError as e:
        if ok404 and e.code == 404:
            return None
        msg = e.read().decode(errors='replace')[:300]
        if e.code == 401:
            sys.exit('✗ GitHub 權杖無效或過期，請重新產生並填到 local_settings.json 的 web.token')
        sys.exit(f'✗ GitHub {method} {path} 失敗（{e.code}）：{msg}')


user = gh('GET', '/user')['login']
repo = W.get('repo') or 'lifeledger'
full = f'{user}/{repo}'
if gh('GET', f'/repos/{full}', ok404=True) is None:
    log('第一次使用：建立 GitHub 儲存庫', full)
    gh('POST', '/user/repos', {'name': repo, 'private': False, 'auto_init': True,
                               'description': 'LifeLedger 月報（內容已加密）'})
for name, content in files.items():
    cur = gh('GET', f'/repos/{full}/contents/{name}', ok404=True)
    raw = content.encode('utf8')
    if cur and cur.get('sha') == hashlib.sha1(b'blob %d\0' % len(raw) + raw).hexdigest():
        continue   # 內容一樣，不用再上傳
    body = {'message': f'LifeLedger 更新 {name}', 'content': base64.b64encode(raw).decode()}
    if cur and cur.get('sha'):
        body['sha'] = cur['sha']
    gh('PUT', f'/repos/{full}/contents/{name}', body)
if gh('GET', f'/repos/{full}/pages', ok404=True) is None:
    log('第一次使用：開啟 GitHub Pages')
    gh('POST', f'/repos/{full}/pages', {'source': {'branch': 'main', 'path': '/'}})

# ---------- 5. 隨手記網站的伺服器程式也自動更新（不用再手動上傳 GitHub） ----------
#   需要這組 GitHub 權杖也能寫入隨手記網站的儲存庫（預設 cardflow-ledger，可在 web.site_repo 改）
_srepo = W.get('site_repo', 'cardflow-ledger')
_sdir = os.path.join(BASE, '..', '隨手記網站')
if _srepo and os.path.isdir(_sdir):
    _sfull = f'{user}/{_srepo}'
    _changed = []
    def _ghq(method, path, body=None):
        req = urllib.request.Request(API + path, method=method, headers=HDR, data=json.dumps(body).encode() if body is not None else None)
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                t = r.read(); return r.status, (json.loads(t) if t else {})
        except urllib.error.HTTPError as e:
            return e.code, {}
    st, _ = _ghq('GET', f'/repos/{_sfull}')
    if st != 200:
        log(f'（隨手記網站自動更新：這組 GitHub 權杖沒有 {_sfull} 的權限，略過。要全自動的話，到 GitHub 權杖設定把 {_srepo} 加進去，權限 Contents: Read and write）')
    else:
        # 只在有變的時候、而且全部合成「一次」提交（Netlify 每次部署都扣點數）
        st, info = _ghq('GET', f'/repos/{_sfull}')
        br = info.get('default_branch', 'main')
        st, ref = _ghq('GET', f'/repos/{_sfull}/git/ref/heads/{br}')
        head = (ref.get('object') or {}).get('sha')
        st, com = _ghq('GET', f'/repos/{_sfull}/git/commits/{head}') if head else (0, {})
        base_tree = (com.get('tree') or {}).get('sha')
        st, tree = _ghq('GET', f'/repos/{_sfull}/git/trees/{base_tree}?recursive=1') if base_tree else (0, {})
        have = {t['path']: t['sha'] for t in tree.get('tree', []) if t.get('type') == 'blob'}
        items = []
        for rel in ('public/index.html', 'public/view.html', 'public/sync.js', 'netlify/functions/ledger.mjs'):
            fp = os.path.join(_sdir, *rel.split('/'))
            if not os.path.exists(fp):
                continue
            raw = open(fp, 'rb').read()
            if have.get(rel) == hashlib.sha1(b'blob %d\0' % len(raw) + raw).hexdigest():
                continue
            st, blob = _ghq('POST', f'/repos/{_sfull}/git/blobs', {'content': base64.b64encode(raw).decode(), 'encoding': 'base64'})
            if blob.get('sha'):
                items.append({'path': rel, 'mode': '100644', 'type': 'blob', 'sha': blob['sha']}); _changed.append(rel)
        if items and base_tree:
            st, nt = _ghq('POST', f'/repos/{_sfull}/git/trees', {'base_tree': base_tree, 'tree': items})
            st, nc = _ghq('POST', f'/repos/{_sfull}/git/commits', {'message': 'LifeLedger 自動更新隨手記網站', 'tree': nt.get('sha'), 'parents': [head]})
            st, _ = _ghq('PATCH', f'/repos/{_sfull}/git/refs/heads/{br}', {'sha': nc.get('sha')})
            if st == 200:
                log('隨手記網站已自動更新：' + '、'.join(_changed) + '（Netlify 約 1 分鐘後生效）')
            else:
                log(f'⚠ 隨手記網站自動更新失敗（{st}）')

site = f'https://{user.lower()}.github.io/{repo}/'
open('web_url.txt', 'w', encoding='utf8').write(site)
open('.web_hash', 'w', encoding='utf8').write(digest)
log('已上傳加密網頁：', site, '（GitHub 約 1 分鐘後更新）')
if APP:
    log('隨手記（沒有 Netlify 標籤的版本）：', site + 'app/')
