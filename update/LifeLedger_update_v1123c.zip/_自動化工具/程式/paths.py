# 資料夾位置：程式在「程式」、使用者會改的檔案在「設定」、執行紀錄在「紀錄」
import os
PROG = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(PROG)
SET = os.path.join(ROOT, '設定')
LOG = os.path.join(ROOT, '紀錄')
HOME = os.path.dirname(ROOT)   # 帳本資料夾（_自動化工具 的上一層）：沒設定 out 時的預設輸出位置


def setp(*name):
    return os.path.join(SET, *name)
