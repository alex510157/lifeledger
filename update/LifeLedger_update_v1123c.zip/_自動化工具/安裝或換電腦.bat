@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem 安裝檔（LifeLedger_Setup.exe）在背景一步一步呼叫：安裝或換電腦.bat /tools python|pip|poppler|tess|sched
rem 不開視窗、輸出寫進 紀錄\安裝紀錄.txt，成功回傳 0
if /i not "%~1"=="/tools" goto interactive
if not exist "%~dp0紀錄" mkdir "%~dp0紀錄"
call :t_%~2 >> "%~dp0紀錄\安裝紀錄.txt" 2>&1
exit /b %errorlevel%
:interactive
echo LifeLedger 生活總帳：安裝工具 → 設定精靈 → 試跑一次，約 10-30 分鐘（換電腦時雙擊這一個就好），請勿關閉此視窗...
echo 若跳出「使用者帳戶控制」視窗，請按「是」。
if not exist "%~dp0紀錄" mkdir "%~dp0紀錄"
call :main > "%~dp0紀錄\安裝紀錄.txt" 2>&1
type "%~dp0紀錄\安裝紀錄.txt" | findstr /b /l /c:"[OK]" /c:"[FAIL]" /c:"[INFO]"
echo.
echo 安裝流程結束，詳細記錄在「紀錄\安裝紀錄.txt」
echo.
echo 接下來是設定精靈：帳單 PDF 密碼、手機隨手記、信箱收帳單、寄月報、線上版（都可以回答 N 跳過，之後雙擊「設定精靈.bat」再設定）
call :findpy
pushd "%~dp0程式"
set PYTHONUTF8=1
"%PYEXE%" setup_wizard.py
echo.
echo 用剛剛的設定試跑一次（第一次會從信箱補抓帳單，可能要 5-20 分鐘）...
"%PYEXE%" run_local.py --auto --no-mail > "%~dp0紀錄\試跑紀錄.txt" 2>&1 && echo [OK] 試跑成功，月報在「月報」資料夾 || echo [FAIL] 試跑沒成功，請把「紀錄\試跑紀錄.txt」給 Claude 看
findstr /c:"⚠" /c:"✗" /c:"無法解密" "%~dp0紀錄\試跑紀錄.txt"
popd
pause
exit /b

:findpy
set "PYEXE="
for %%V in (Python313 Python312 Python311) do if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\%%V\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\%%V\python.exe"
for %%V in (Python313 Python312 Python311) do if not defined PYEXE if exist "C:\Program Files\%%V\python.exe" set "PYEXE=C:\Program Files\%%V\python.exe"
if not defined PYEXE for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
if not defined PYEXE set "PYEXE=python"
exit /b

:main
echo [INFO] start %date% %time%
for %%S in (python pip poppler tess sched) do call :t_%%S
echo [INFO] end %date% %time%
echo [DONE]
exit /b

:t_python
call :findpy

rem ---------- 1. Python（先用 winget，沒有 winget 就直接從 python.org 下載安裝） ----------
if not "%PYEXE%"=="python" (
  echo [INFO] Python already installed: %PYEXE%
) else (
  where winget >nul 2>&1 && winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements --override "/quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0"
  call :findpy
)
if "%PYEXE%"=="python" (
  echo [INFO] winget 不能用，改從 python.org 下載 Python 3.12
  powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; $f=Join-Path $env:TEMP 'py312.exe'; Invoke-WebRequest 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe' -OutFile $f -UseBasicParsing; Start-Process $f -ArgumentList '/quiet','InstallAllUsers=0','PrependPath=1','Include_launcher=1','Include_test=0' -Wait"
  call :findpy
)
"%PYEXE%" --version && echo [OK] Python: %PYEXE% || echo [FAIL] Python 沒裝好：請到 https://www.python.org/downloads/ 手動安裝（勾 Add python.exe to PATH），再雙擊一次這個檔

"%PYEXE%" --version >nul 2>&1 || exit /b 1
exit /b 0

:t_pip
call :findpy
rem ---------- 2. pip packages ----------
"%PYEXE%" -m pip install --upgrade pip
"%PYEXE%" -m pip install pikepdf openpyxl pillow cryptography pywin32
"%PYEXE%" -c "import pikepdf, openpyxl, PIL, cryptography; print('[OK] packages pikepdf', pikepdf.__version__, 'openpyxl', openpyxl.__version__, 'pillow', PIL.__version__)" || echo [FAIL] pip packages

"%PYEXE%" -c "import pikepdf, openpyxl" >nul 2>&1 || exit /b 1
exit /b 0

:t_poppler
rem ---------- 3. Poppler -> C:\poppler ----------
if exist "C:\poppler\Library\bin\pdftotext.exe" (
  echo [INFO] Poppler already installed
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; $r=Invoke-RestMethod 'https://api.github.com/repos/oschwartz10612/poppler-windows/releases/latest' -Headers @{'User-Agent'='CardFlow-setup'}; $a=$r.assets | ?{ $_.name -like 'Release-*.zip' } | select -First 1; $z=Join-Path $env:TEMP $a.name; Invoke-WebRequest $a.browser_download_url -OutFile $z -UseBasicParsing; $t=Join-Path $env:TEMP 'poppler_x'; if(Test-Path $t){Remove-Item $t -Recurse -Force}; Expand-Archive $z $t; $inner=Get-ChildItem $t -Directory | select -First 1; if(Test-Path 'C:\poppler'){Remove-Item 'C:\poppler' -Recurse -Force}; Move-Item $inner.FullName 'C:\poppler'; Write-Output ('[INFO] Poppler ' + $a.name)"
)
if exist "C:\poppler\Library\bin\pdftotext.exe" (echo [OK] Poppler: C:\poppler\Library\bin\pdftotext.exe) else (echo [FAIL] Poppler)

if not exist "C:\poppler\Library\bin\pdftotext.exe" exit /b 1
exit /b 0

:t_tess
rem ---------- 4. Tesseract + 中文語言檔 ----------
set "TESS=%LOCALAPPDATA%\Programs\Tesseract-OCR"
if not exist "%TESS%\tesseract.exe" if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESS=C:\Program Files\Tesseract-OCR"
if exist "%TESS%\tesseract.exe" (
  echo [INFO] Tesseract already installed at %TESS%
) else (
  where winget >nul 2>&1 && winget install -e --id UB-Mannheim.TesseractOCR --silent --accept-package-agreements --accept-source-agreements --location "%LOCALAPPDATA%\Programs\Tesseract-OCR"
  if not exist "%TESS%\tesseract.exe" if not exist "C:\Program Files\Tesseract-OCR\tesseract.exe" powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; $r=Invoke-RestMethod 'https://api.github.com/repos/UB-Mannheim/tesseract/releases/latest' -Headers @{'User-Agent'='LifeLedger-setup'}; $a=$r.assets | ?{ $_.name -like '*w64-setup*.exe' } | select -First 1; $f=Join-Path $env:TEMP $a.name; Invoke-WebRequest $a.browser_download_url -OutFile $f -UseBasicParsing; Start-Process $f -ArgumentList '/S',('/D=' + $env:LOCALAPPDATA + '\Programs\Tesseract-OCR') -Wait; Write-Output ('[INFO] Tesseract ' + $a.name)"
  if not exist "%TESS%\tesseract.exe" if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESS=C:\Program Files\Tesseract-OCR"
)
if exist "%TESS%\tesseract.exe" (echo [OK] Tesseract: %TESS%) else (echo [FAIL] Tesseract not installed)
set "TD=%LOCALAPPDATA%\CardFlow\tessdata"
if not exist "%TD%" mkdir "%TD%"
if exist "%TESS%\tessdata\eng.traineddata" copy /y "%TESS%\tessdata\eng.traineddata" "%TD%\" >nul
if exist "%TESS%\tessdata\osd.traineddata" copy /y "%TESS%\tessdata\osd.traineddata" "%TD%\" >nul
for %%L in (eng osd chi_tra chi_tra_vert) do (
  if not exist "%TD%\%%L.traineddata" powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest 'https://github.com/tesseract-ocr/tessdata_best/raw/main/%%L.traineddata' -OutFile '%TD%\%%L.traineddata' -UseBasicParsing"
)
setx TESSDATA_PREFIX "%TD%"
set "TESSDATA_PREFIX=%TD%"
"%TESS%\tesseract.exe" --tessdata-dir "%TD%" --list-langs 2>&1 | findstr /x "chi_tra" >nul && echo [OK] Tesseract 繁體中文 chi_tra || echo [FAIL] chi_tra language

"%TESS%\tesseract.exe" --tessdata-dir "%TD%" --list-langs 2>&1 | findstr /x "chi_tra" >nul || exit /b 1
exit /b 0

:t_sched
call :findpy
rem ---------- 5. 每日 07:30 排程（錯過時開機補跑） ----------
schtasks /Delete /TN "CardFlow Daily" /F >nul 2>&1
rem 有 pythonw（沒有視窗的 Python）就用它跑 daily.pyw，排程執行時不會跳出黑色視窗
set "PYW="
for %%D in ("%PYEXE%") do if exist "%%~dpDpythonw.exe" set "PYW=%%~dpDpythonw.exe"
if defined PYW schtasks /Create /TN "LifeLedger Daily" /SC DAILY /ST 07:30 /TR "\"%PYW%\" \"%~dp0程式\daily.pyw\"" /F && echo [OK] 排程 LifeLedger Daily 每天 07:30（背景執行） || echo [FAIL] schtasks
if not defined PYW schtasks /Create /TN "LifeLedger Daily" /SC DAILY /ST 07:30 /TR "\"%~dp0程式\lifeledger_daily.bat\"" /F && echo [OK] 排程 LifeLedger Daily 每天 07:30 || echo [FAIL] schtasks
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0程式\schedule_fix.ps1"
schtasks /Query /TN "LifeLedger Daily" /V /FO LIST
schtasks /Query /TN "LifeLedger Daily" >nul 2>&1 || exit /b 1
exit /b 0
