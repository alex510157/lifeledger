# LifeLedger 生活總帳：桌面小視窗（不會跳出黑色命令視窗）
#   顯示版本與更新通知、立即更新月報、打開月報／生活帳本／隨手記／Excel／資料夾、帳單密碼與隨手記設定
import os, sys, json, re, time, datetime, threading, queue, subprocess, webbrowser
import tkinter as tk
from tkinter import ttk, messagebox

PROG = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(PROG)
os.chdir(PROG)
sys.path.insert(0, PROG)
import updater
from paths import setp

HOME = os.path.dirname(TOOLS)
exe = sys.executable
_c = os.path.join(os.path.dirname(exe), 'python.exe')
PY = _c if os.path.basename(exe).lower() == 'pythonw.exe' and os.path.exists(_c) else exe
NOWIN = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
ENV = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
APP_URL = 'https://alex510157.github.io/lifeledger/app/'   # 隨手記網頁（大家共用）

# ---------- 配色主題（右上角 🎨 可以換；記在 設定\ui.json，程式更新不會蓋掉） ----------
FONT = 'Microsoft JhengHei UI'
_BASE = dict(ink='#3D3A4B', ink2='#8A8597', line='#F0E6DD', new='#FFF1C9', done='#E3F6E8', btn='#FFFFFF', pill='#FFFFFF', head_ink='#FFFFFF')
THEMES = {
    'pastel': dict(_BASE, name='🍑 粉彩甜心', bg='#FFF9F3', head=((255, 179, 198), (186, 200, 255)), main='#FF8FA3', hover='#FF7A92', shadow='#F3D9CF',
                   sub='#FFF3F5', btn_ink='#E0607E', tip='#FFF1E6', log='#FBF4EC',
                   tiles=['#FFE4EC', '#FFEBD6', '#E0F5E9', '#DDEFFF', '#ECE4FF', '#FFF4C7', '#DCF4F4', '#EEF0F5']),
    'mint': dict(_BASE, name='🌿 薄荷清新', bg='#F3FBF7', ink='#24423A', ink2='#6E8A81', line='#D9EDE3', head=((125, 222, 185), (140, 205, 245)),
                 main='#34B98A', hover='#2AA67B', shadow='#CDEBDD', sub='#E8FFF5', btn_ink='#2A9D74', tip='#E6F5EE', log='#EEF8F3', done='#D7F2E3',
                 tiles=['#DDF5EA', '#E6F7D9', '#D6F0F5', '#E9F3DA', '#DDEFE9', '#F3F7D4', '#D9F1EE', '#EAF2EE']),
    'ocean': dict(_BASE, name='🌊 海洋藍', bg='#F3F7FF', ink='#22324A', ink2='#6B7C96', line='#DCE6F5', head=((88, 150, 255), (120, 215, 250)),
                  main='#4A86F0', hover='#3B76E0', shadow='#CFDDF6', sub='#EAF2FF', btn_ink='#3B76E0', tip='#E6EEFB', log='#EEF3FC', done='#DDF2E6',
                  tiles=['#DCE9FF', '#DDF3FF', '#E3E5FF', '#D9F2F2', '#E6EEFA', '#E0F0FF', '#DFE8F5', '#EBEFF7']),
    'latte': dict(_BASE, name='☕ 奶茶暖色', bg='#FBF6F0', ink='#4A3B30', ink2='#937F70', line='#EADCCD', head=((205, 160, 120), (238, 200, 165)),
                  main='#C58A5C', hover='#B57A4D', shadow='#EAD9C8', sub='#FFF4EA', btn_ink='#B57A4D', tip='#F4EADF', log='#F7F0E8', new='#FBEFCB', done='#E5F0DF',
                  tiles=['#F6E6D8', '#F3E9DC', '#EFE3D3', '#F7EDE2', '#EDE2D6', '#F8EBD2', '#EEE6DD', '#F1ECE6']),
    'night': dict(_BASE, name='🌙 夜間模式', bg='#1E2030', ink='#ECEAF5', ink2='#A6A3BA', line='#34364A', head=((64, 70, 130), (120, 84, 165)),
                  main='#8C7CF0', hover='#7B6AE6', shadow='#14151F', sub='#E6E1FF', btn='#3A3D55', btn_ink='#C9C0FF', pill='#2A2C40',
                  tip='#272A3C', log='#262838', new='#4A4230', done='#2D4337',
                  tiles=['#33304A', '#3A3245', '#2C3A3A', '#2C3448', '#352F4A', '#3E3A2E', '#2D3943', '#30323F']),
}
T = dict(THEMES['pastel'])


def load_theme():
    try:
        k = json.load(open(setp('ui.json'), encoding='utf8')).get('theme')
    except Exception:
        k = None
    T.clear(); T.update(THEMES.get(k) or THEMES['pastel']); T['key'] = k if k in THEMES else 'pastel'


def save_theme(k):
    try:
        u = json.load(open(setp('ui.json'), encoding='utf8'))
    except Exception:
        u = {}
    u['theme'] = k
    json.dump(u, open(setp('ui.json'), 'w', encoding='utf8'), ensure_ascii=False)


TILES = [  # (emoji, 標題, 小字, 動作名)；底色跟著主題
    ('📊', '月報', '這個月花了多少', 'report'),
    ('📒', '生活帳本', '每一筆都在這', 'book'),
    ('📱', '隨手記', '記現金、收入', 'ledger'),
    ('📗', 'Excel 總帳', '想自己算的話', 'excel'),
    ('📁', '帳本資料夾', '帳單 PDF 放這', 'folder'),
    ('🔑', '密碼與帳號', '帳單密碼、隨手記', 'settings'),
    ('📖', '使用說明', '不知道怎麼用', 'help'),
    ('🔄', '檢查更新', '看看有沒有新版', 'update'),
]


def settings_json():
    try:
        return json.load(open(setp('local_settings.json'), encoding='utf8'))
    except Exception:
        return {}


def out_dir():
    return settings_json().get('out') or HOME


def open_path(p):
    if os.path.exists(p):
        os.startfile(p)
    else:
        messagebox.showinfo('LifeLedger', '還沒有這個檔案，先按「立即更新月報」產生喔。\n\n' + p)


def ledger_url():
    L = settings_json().get('ledger') or {}
    if L.get('app_url'):
        return L['app_url']
    u = (L.get('url') or '').rstrip('/')
    return APP_URL if (not u or 'alexledger.netlify.app' in u) else u


def greeting():
    h = datetime.datetime.now().hour
    return (('早安，今天也一起好好記帳', '☀️') if 5 <= h < 11 else ('午安，吃飯記得記一筆', '🍱') if 11 <= h < 14
            else ('下午好，喝杯茶休息一下', '☕') if 14 <= h < 18 else ('晚安，今天辛苦了', '🌙'))


# ---------- 彩色 emoji 圖片（Windows 內建 Segoe UI Emoji；沒有的話就不顯示圖示） ----------
_IMG = {}


def emoji(ch, size=34):
    k = (ch, size)
    if k in _IMG:
        return _IMG[k]
    try:
        from PIL import Image, ImageDraw, ImageFont, ImageTk
        f = ImageFont.truetype(os.path.join(os.environ.get('WINDIR', r'C:\Windows'), 'Fonts', 'seguiemj.ttf'), size)
        im = Image.new('RGBA', (int(size * 1.4), int(size * 1.4)), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((im.width // 2, im.height // 2), ch, font=f, embedded_color=True, anchor='mm')
        _IMG[k] = ImageTk.PhotoImage(im.crop(im.getbbox() or (0, 0, im.width, im.height)))
    except Exception:
        _IMG[k] = None
    return _IMG[k]


def rrect(cv, x1, y1, x2, y2, r, **kw):
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return cv.create_polygon(pts, smooth=True, **kw)


def shade(hexc, f):
    r, g, b = (int(hexc[i:i + 2], 16) for i in (1, 3, 5))
    return '#%02x%02x%02x' % tuple(max(0, min(255, int(c * f))) for c in (r, g, b))


class App:
    W, H = 720, 660

    def __init__(self, root):
        self.root = root; self.q = queue.Queue(); self.busy = False; self.remote = None
        root.title('LifeLedger 生活總帳'); root.geometry(f'{self.W}x{self.H}'); root.resizable(False, False)
        try:
            root.iconbitmap(default=os.path.join(PROG, 'LifeLedger.ico'))
        except Exception:
            pass
        load_theme()
        self.cv = tk.Canvas(root, width=self.W, height=self.H, highlightthickness=0); self.cv.pack()
        self.pb = ttk.Progressbar(root, mode='indeterminate', length=self.W - 72)
        self.logbox = tk.Text(root, height=4, wrap='word', font=('Consolas', 8), relief='flat', state='disabled', bd=0)
        self._banner = ('', '', None, None)
        self.tip_text = ('💡 小提醒：帳單 PDF 放進「帳本資料夾」裡對應的銀行資料夾，或在「密碼與帳號 → 其他設定」讓程式自動收信。'
                         '手機隨手記記的現金、收入，每天也會一起整理進月報。')
        self.build()
        root.after(100, self.pump)
        root.after(300, lambda: self.check_update(quiet=True))
        self.show_just_updated()
        if self.first_run():
            root.after(700, self.first_setup)

    # ---------- 畫面 ----------
    def build(self):
        """整個畫面（換主題時重畫）"""
        cv = self.cv; cv.delete('all'); _IMG.clear()
        self.root.configure(bg=T['bg']); cv.configure(bg=T['bg'])
        self.logbox.configure(bg=T['log'], fg=T['ink2'])
        self.draw_header()
        self.banner_y = 128; self.banner_items = []
        self.banner(*self._banner)
        self.draw_main_button(176)
        self.draw_tiles(262)
        self.status = cv.create_text(36, 548, text='', anchor='w', font=(FONT, 10), fill=T['ink2'])   # 更新月報時的狀態
        self.tip = [rrect(cv, 28, 548, self.W - 28, 640, 18, fill=T['tip'], outline=''),
                    cv.create_text(48, 594, anchor='w', width=self.W - 110, font=(FONT, 9), fill=T['ink2'], text=self.tip_text)]
        self.show_footer()

    def theme_menu(self, e):
        if self.busy:
            return
        m = tk.Menu(self.root, tearoff=0, font=(FONT, 10))
        self._tv = tk.StringVar(value=T.get('key', 'pastel'))
        for k, th in THEMES.items():
            m.add_radiobutton(label=th['name'], variable=self._tv, value=k, command=lambda k=k: self.set_theme(k))
        m.tk_popup(e.x_root, e.y_root)

    def set_theme(self, k):
        save_theme(k); load_theme(); self.build()

    def draw_header(self):
        cv = self.cv; w = self.W
        a, b = T['head']   # 漸層
        for x in range(0, w, 2):
            t = x / w
            cv.create_line(x, 0, x, 112, width=2, fill='#%02x%02x%02x' % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3)))
        for cx, cy, r in ((610, -6, 44), (700, 60, 34), (520, 112, 26), (20, 8, 30)):   # 淡淡的泡泡
            t = max(0, min(1, cx / w)); base = tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
            cv.create_oval(cx - r, cy - r, cx + r, cy + r, outline='', fill='#%02x%02x%02x' % tuple(int(c + (255 - c) * 0.22) for c in base))
        cv.create_rectangle(0, 112, w, 140, fill=T['bg'], outline='')   # 泡泡超出的部分蓋掉
        try:
            from PIL import Image, ImageTk
            im = Image.open(os.path.join(PROG, 'LifeLedger.ico')).convert('RGBA').resize((60, 60))
            self._logo = ImageTk.PhotoImage(im); cv.create_image(66, 56, image=self._logo)
        except Exception:
            pass
        cv.create_text(110, 40, text='LifeLedger 生活總帳', anchor='w', font=(FONT, 19, 'bold'), fill=T['head_ink'])
        gt, ge = greeting()
        t = cv.create_text(111, 74, text=gt, anchor='w', font=(FONT, 11), fill=T['head_ink'])
        img = emoji(ge, 18)
        if img:
            cv.create_image(cv.bbox(t)[2] + 14, 74, image=img)
        self.ver_pill = rrect(cv, w - 150, 70, w - 20, 98, 14, fill=T['pill'], outline='')
        pal = rrect(cv, w - 196, 70, w - 160, 98, 14, fill=T['pill'], outline='', tags='theme')   # 🎨 換主題
        img = emoji('🎨', 18)
        if img:
            cv.create_image(w - 178, 84, image=img, tags='theme')
        else:
            cv.create_text(w - 178, 84, text='🎨', tags='theme')
        cv.tag_bind('theme', '<Button-1>', self.theme_menu)
        cv.tag_bind('theme', '<Enter>', lambda e: cv.config(cursor='hand2'))
        cv.tag_bind('theme', '<Leave>', lambda e: cv.config(cursor=''))
        self.ver_text = cv.create_text(w - 85, 84, text='', font=(FONT, 9), fill=T['ink'])
        self.show_version()

    def draw_main_button(self, y):
        cv = self.cv; x1, x2, h = 28, self.W - 28, 70
        tag = 'mainbtn'
        rrect(cv, x1, y + 4, x2, y + h + 4, 22, fill=T['shadow'], outline='', tags=tag)   # 影子
        self.main_bg = rrect(cv, x1, y, x2, y + h, 22, fill=T['main'], outline='', tags=tag)
        img = emoji('✨', 30)
        if img:
            cv.create_image(x1 + 44, y + h // 2, image=img, tags=tag)
        self.main_label = cv.create_text(x1 + 74, y + 25, text='立即更新月報', anchor='w', font=(FONT, 15, 'bold'), fill='white', tags=tag)
        self.main_sub = cv.create_text(x1 + 74, y + 49, text='', anchor='w', font=(FONT, 9), fill=T['sub'], tags=tag)
        cv.create_text(x2 - 30, y + h // 2, text='›', font=(FONT, 24, 'bold'), fill='white', tags=tag)
        cv.tag_bind(tag, '<Button-1>', lambda e: self.run_report())
        cv.tag_bind(tag, '<Enter>', lambda e: (cv.itemconfig(self.main_bg, fill=T['hover']), cv.config(cursor='hand2')))
        cv.tag_bind(tag, '<Leave>', lambda e: (cv.itemconfig(self.main_bg, fill=T['main']), cv.config(cursor='')))

    def draw_tiles(self, y0):
        cv = self.cv; cols, gap, x0 = 4, 14, 28
        tw = (self.W - 2 * x0 - gap * (cols - 1)) // cols; th = 118
        for i, (em, title, sub, act) in enumerate(TILES):
            color = T['tiles'][i]
            r, c = divmod(i, cols)
            x, y = x0 + c * (tw + gap), y0 + r * (th + gap)
            tag = 'tile_' + act
            bg = rrect(cv, x, y, x + tw, y + th, 20, fill=color, outline='', tags=tag)
            img = emoji(em, 32)
            if img:
                cv.create_image(x + tw // 2, y + 38, image=img, tags=tag)
            else:
                cv.create_text(x + tw // 2, y + 38, text=em, font=('Segoe UI Emoji', 24), tags=tag)
            cv.create_text(x + tw // 2, y + 76, text=title, font=(FONT, 11, 'bold'), fill=T['ink'], tags=tag)
            cv.create_text(x + tw // 2, y + 97, text=sub, font=(FONT, 8), fill=T['ink2'], tags=tag)
            cv.tag_bind(tag, '<Button-1>', lambda e, a=act: self.action(a))
            cv.tag_bind(tag, '<Enter>', lambda e, b=bg, col=color: (cv.itemconfig(b, fill=shade(col, 1.12 if T.get('key') == 'night' else 0.94)), cv.config(cursor='hand2')))
            cv.tag_bind(tag, '<Leave>', lambda e, b=bg, col=color: (cv.itemconfig(b, fill=col), cv.config(cursor='')))

    def show_footer(self):
        p = os.path.join(out_dir(), '月報', 'LifeLedger月報.html')
        t = ('上次更新：' + datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime('%m/%d %H:%M')) if os.path.exists(p) else '還沒產生過月報，按一下就開始'
        self.cv.itemconfig(self.main_sub, text=t)

    def banner(self, text, color, button=None, command=None):
        """最上面的通知條（有新版、剛自動更新完）"""
        cv = self.cv; self._banner = (text, color, button, command)
        for it in self.banner_items:
            cv.delete(it)
        self.banner_items = []
        if not text:
            wd = '一二三四五六日'[datetime.date.today().weekday()]
            self.banner_items.append(self.cv.create_text(36, self.banner_y + 19, anchor='w', font=(FONT, 10), fill=T['ink2'],
                                     text=datetime.date.today().strftime('%m 月 %d 日').lstrip('0').replace(' 0', ' ') + f'　星期{wd}　・　月報每天早上 7:30 自動更新，有新版也會自動裝好'))
            return
        y = self.banner_y; x1, x2 = 28, self.W - 28
        self.banner_items.append(rrect(cv, x1, y, x2, y + 38, 14, fill=T.get(color, color), outline=''))
        self.banner_items.append(cv.create_text(x1 + 16, y + 19, text=text, anchor='w', font=(FONT, 10), fill=T['ink'], width=x2 - x1 - 150))
        if button:
            b = rrect(cv, x2 - 120, y + 6, x2 - 8, y + 32, 12, fill=T['btn'], outline='', tags='bannerbtn')
            t = cv.create_text(x2 - 64, y + 19, text=button, font=(FONT, 9, 'bold'), fill=T['btn_ink'], tags='bannerbtn')
            cv.tag_bind('bannerbtn', '<Button-1>', lambda e: command())
            cv.tag_bind('bannerbtn', '<Enter>', lambda e: cv.config(cursor='hand2'))
            cv.tag_bind('bannerbtn', '<Leave>', lambda e: cv.config(cursor=''))
            self.banner_items += [b, t]

    # ---------- 動作 ----------
    def action(self, a):
        d = out_dir()
        {'report': lambda: open_path(os.path.join(d, '月報', 'LifeLedger月報.html')),
         'book': lambda: open_path(os.path.join(d, '月報', 'LifeLedger生活帳本.html')),
         'ledger': lambda: webbrowser.open(ledger_url()),
         'excel': lambda: open_path(os.path.join(d, 'LifeLedger_生活總帳.xlsx')),
         'folder': lambda: open_path(d),
         'settings': lambda: Settings(self.root, self.say),
         'help': lambda: open_path(os.path.join(TOOLS, '使用說明.md')),
         'update': lambda: self.check_update(quiet=False)}[a]()

    def say(self, s):
        self.q.put(('log', s))

    def pump(self):
        try:
            while True:
                k, v = self.q.get_nowait()
                if k == 'log':
                    m = re.match(r'\s*===\s*(.+?)\s*===', v)
                    if m:
                        self.cv.itemconfig(self.status, text='正在：' + re.sub(r'^[\d.a-z]+\s*', '', m.group(1)))
                    elif v.strip().startswith(('✓', '已更新', '有新版', '已經是最新版', '檢查更新失敗', '更新失敗')):
                        self.cv.itemconfig(self.status, text=v.strip())
                    self.logbox['state'] = 'normal'; self.logbox.insert('end', v.rstrip() + '\n'); self.logbox.see('end'); self.logbox['state'] = 'disabled'
                elif k == 'call':
                    v()
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    # ---------- 版本與更新 ----------
    def show_version(self):
        lv = updater.local_version()
        self.cv.itemconfig(self.ver_text, text=f'v{lv["version"]}' + ('　✓ 最新' if self.remote and self.remote['build'] <= lv['build'] else ''))

    def show_just_updated(self):
        p = os.path.join(PROG, '.just_updated.json')
        try:
            j = json.load(open(p, encoding='utf8'))
        except Exception:
            return
        notes = '、'.join(j.get('notes') or [])[:80]
        self.banner(f'✨ 已經自動更新到 v{j.get("to")}' + (f'：{notes}' if notes else ''), 'done', '知道了', lambda: (os.path.exists(p) and os.remove(p), self.banner('', '')))

    def check_update(self, quiet=False):
        if not quiet:
            self.cv.itemconfig(self.status, text='檢查更新中…')

        def work():
            try:
                self.remote = updater.remote_version()
            except Exception as e:
                if not quiet:
                    self.say(f'檢查更新失敗（{e}），可能沒有網路，等一下再試')
                return
            lv = updater.local_version()
            if self.remote['build'] > lv['build']:
                notes = '、'.join(self.remote.get('notes') or [])[:60]
                self.q.put(('call', lambda: self.banner(f'🎁 有新版 v{self.remote["version"]}' + (f'：{notes}' if notes else ''), 'new', '現在更新', self.install_update)))
            elif not quiet:
                self.say(f'已經是最新版 v{lv["version"]}')
            self.q.put(('call', self.show_version))
        threading.Thread(target=work, daemon=True).start()

    def install_update(self):
        if self.busy:
            return
        self.busy = True; self.banner('⏳ 下載新版中…', 'new')

        def work():
            st = updater.check(install=True, log=self.say)[0]

            def done():
                self.busy = False; self.banner('', ''); self.show_version()
                if st == 'updated':
                    if messagebox.askyesno('LifeLedger', '更新好了 🎉\n要重新開啟視窗，換成新版嗎？'):
                        subprocess.Popen([sys.executable, os.path.abspath(__file__)], cwd=PROG)
                        self.root.destroy()
                else:
                    self.check_update(quiet=True)
            self.q.put(('call', done))
        threading.Thread(target=work, daemon=True).start()

    # ---------- 更新月報 ----------
    def run_report(self):
        if self.busy:
            return
        if os.path.exists(os.path.join(PROG, '.running')):
            if not messagebox.askyesno('LifeLedger', '看起來排程正在更新（或上次沒正常結束）。還是要現在更新嗎？'):
                return
        self.busy = True
        self.cv.itemconfig(self.main_label, text='更新中…'); self.cv.itemconfig(self.main_sub, text='大約 1–5 分鐘，可以先去做別的事 🍵')
        self.cv.itemconfig(self.status, text='準備中…')
        for it in self.tip:
            self.cv.itemconfig(it, state='hidden')
        self.pb.place(x=36, y=562); self.pb.start(12)
        self.logbox['state'] = 'normal'; self.logbox.delete('1.0', 'end'); self.logbox['state'] = 'disabled'
        self.logbox.place(x=36, y=586, width=self.W - 72, height=62)

        def work():
            p = subprocess.Popen([PY, 'run_local.py', '--auto'], cwd=PROG, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 env=ENV, creationflags=NOWIN, text=True, encoding='utf8', errors='replace')
            for line in p.stdout:
                if line.strip():
                    self.say(line)
            rc = p.wait()

            def done():
                self.busy = False; self.pb.stop(); self.pb.place_forget()
                self.cv.itemconfig(self.main_label, text='立即更新月報'); self.show_footer()
                if rc == 0:
                    self.logbox.place_forget(); self.cv.itemconfig(self.status, text='')
                    for it in self.tip:
                        self.cv.itemconfig(it, state='normal')
                    self.cv.itemconfig(self.tip[1], text='✅ 月報更新好了！可以按上面的「月報」或「生活帳本」看看。')
                    if messagebox.askyesno('LifeLedger', '月報更新好了 🎉 要打開看看嗎？'):
                        open_path(os.path.join(out_dir(), '月報', 'LifeLedger月報.html'))
                else:
                    self.cv.itemconfig(self.status, text='⚠ 更新沒有完成，下面是最後的訊息')
                    messagebox.showwarning('LifeLedger', '更新沒有完成。請把下面框框裡的訊息（或 紀錄 資料夾裡的檔案）傳給管理者看。')
            self.q.put(('call', done))
        threading.Thread(target=work, daemon=True).start()

    # ---------- 第一次使用 ----------
    def first_run(self):
        try:
            L = settings_json().get('ledger') or {}
            has_pw = os.path.exists(setp('passwords.json')) and any(v for k, v in json.load(open(setp('passwords.json'), encoding='utf8')).items() if k != '說明')
            return not has_pw and not (L.get('user') and '填' not in str(L.get('user')))
        except Exception:
            return False

    def first_setup(self):
        messagebox.showinfo('LifeLedger', '歡迎使用 LifeLedger 🎉\n\n先填帳單 PDF 的密碼和隨手記帳號（不用的可以空白），之後按「立即更新月報」就好。')
        Settings(self.root, self.say)


class Settings:
    def __init__(self, parent, say):
        self.say = say
        self.PP = setp('passwords.json'); self.SP = setp('local_settings.json')
        self.PW = json.load(open(self.PP, encoding='utf8')) if os.path.exists(self.PP) else {}
        self.S = json.load(open(self.SP, encoding='utf8'))
        w = self.w = tk.Toplevel(parent, bg=T['bg']); w.title('密碼與帳號'); w.geometry('580x500'); w.resizable(False, False); w.transient(parent); w.grab_set()
        st = ttk.Style(w)
        st.configure('LL.TFrame', background=T['bg']); st.configure('LL.TLabel', background=T['bg'], foreground=T['ink'], font=(FONT, 10))
        st.configure('LLh.TLabel', background=T['bg'], foreground=T['ink'], font=(FONT, 12, 'bold')); st.configure('LLn.TLabel', background=T['bg'], foreground=T['ink2'], font=(FONT, 9))
        st.configure('LLok.TLabel', background=T['bg'], foreground='#2E9E5B', font=(FONT, 9))
        f = ttk.Frame(w, padding=18, style='LL.TFrame'); f.pack(fill='both', expand=True)
        H = lambda t: ttk.Label(f, text=t, style='LLh.TLabel').pack(anchor='w', pady=(8, 2))
        N = lambda t: ttk.Label(f, text=t, style='LLn.TLabel', wraplength=530, justify='left').pack(anchor='w')

        H('🔑 信用卡帳單 PDF 的密碼')
        N('大部分銀行是身分證字號（英文大寫）；有些用生日，例如 19850406。只存在這台電腦。設定過的不會顯示，空白＝不修改。')
        self.e_def = self.field(f, '大部分銀行共用的密碼', show='•', hint='已設定 ✓' if self.PW.get('default') else '')
        self.e_bd = self.field(f, '生日（西元 8 碼，可不填）', show='•', hint='已設定 ✓' if self.PW.get('birthday') else '')
        N('密碼不一樣的銀行：一行一家，「銀行簡稱 密碼」，例如「星展 19850406」。')
        others = [k for k in self.PW if k not in ('default', 'birthday', '說明') and self.PW[k]]
        if others:
            N('目前另外設定的銀行：' + '、'.join(others) + '（要改就再輸入一次）')
        self.t_banks = tk.Text(f, height=3, font=(FONT, 10), relief='flat', bg='white', highlightthickness=1, highlightbackground=T['line']); self.t_banks.pack(fill='x', pady=4)

        H('📱 手機隨手記')
        N('用同一組帳號密碼，每天更新時會自動抓隨手記的紀錄，月報也會加密放到隨手記網站。')
        L = self.S.get('ledger') or {}
        blank = lambda v: not v or '填' in str(v)
        self.e_user = self.field(f, '帳號', value='' if blank(L.get('user')) else L.get('user', ''))
        self.e_lpw = self.field(f, '密碼（空白＝不修改）', show='•', hint='已設定 ✓' if not blank(L.get('password')) else '')

        bf = ttk.Frame(f, style='LL.TFrame'); bf.pack(fill='x', pady=(18, 0))
        ttk.Button(bf, text='其他設定（信箱收帳單、寄月報、線上版）…', command=self.advanced).pack(side='left')
        ttk.Button(bf, text='儲存', command=self.save).pack(side='right')
        ttk.Button(bf, text='取消', command=w.destroy).pack(side='right', padx=6)

    def field(self, f, label, show='', value='', hint=''):
        r = ttk.Frame(f, style='LL.TFrame'); r.pack(fill='x', pady=3)
        ttk.Label(r, text=label, width=22, style='LL.TLabel').pack(side='left')
        e = ttk.Entry(r, show=show, font=(FONT, 10)); e.pack(side='left', fill='x', expand=True)
        if value:
            e.insert(0, value)
        if hint:
            ttk.Label(r, text=hint, style='LLok.TLabel').pack(side='left', padx=6)
        return e

    def save(self):
        d, bd = self.e_def.get().strip(), self.e_bd.get().strip()
        if bd and not re.fullmatch(r'\d{8}', bd):
            messagebox.showwarning('LifeLedger', '生日要 8 碼數字，例如 19850406', parent=self.w); return
        if d:
            self.PW['default'] = d
        if bd:
            self.PW['birthday'] = bd
        for line in self.t_banks.get('1.0', 'end').splitlines():
            parts = line.strip().split(None, 1)
            if len(parts) == 2:
                self.PW[parts[0]] = parts[1].strip()
            elif line.strip():
                messagebox.showwarning('LifeLedger', f'這行看不懂：「{line.strip()}」\n格式是「銀行簡稱 密碼」，中間空一格。', parent=self.w); return
        self.PW.setdefault('說明', '各銀行帳單 PDF 的開啟密碼；default 是共用的，銀行名稱的那一行會優先使用')
        L = self.S.setdefault('ledger', {})
        L.setdefault('url', 'https://alexledger.netlify.app')
        if self.e_user.get().strip():
            L['user'] = self.e_user.get().strip()
        if self.e_lpw.get():
            L['password'] = self.e_lpw.get()
        json.dump(self.PW, open(self.PP, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
        json.dump(self.S, open(self.SP, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
        self.say('✓ 設定已存好（只存在這台電腦）')
        self.w.destroy()

    def advanced(self):
        # 進階設定項目多（多個信箱、Gmail 應用程式密碼、GitHub 權杖），沿用原本的問答式設定精靈
        subprocess.Popen([PY, 'setup_wizard.py'], cwd=PROG, env=ENV, creationflags=getattr(subprocess, 'CREATE_NEW_CONSOLE', 0))


if __name__ == '__main__':
    root = tk.Tk()
    App(root)
    root.mainloop()
