// LifeLedger 隨手記：多人雲端記帳（Netlify Functions + Netlify Blobs）
// 另外存每個人電腦上產生、已用自己密碼加密的「月報」「生活帳本」（伺服器只看得到密文）
// 每個人用自己的「帳號＋密碼」，記錄各自分開存放，互相看不到。
// 環境變數（Netlify › Environment variables）：
//   INVITE_CODE  建立新帳號時要輸入的邀請碼（建議設定，避免陌生人註冊）；不設＝任何人都能建立帳號
//   ADMIN_KEY    （選用）網站管理者幫家人重設忘記的密碼時要輸入的管理碼
//   ADMIN_RECOVERY_PUBKEY （選用）管理者救援用的 RSA 公鑰（SPKI，base64）。私鑰只在管理者的電腦上，伺服器沒有
//
// 用戶端加密（過渡期：明文和加密兩種格式都支援，見 docs/encryption.md）
//   帳本：{ rev, data }（明文，舊版）或 { rev, enc:{v:1, iv, ct} }（用戶端用資料金鑰 DEK 加密，伺服器看不到內容）
//     已經加密的帳本不接受明文寫入（避免舊版程式把加密帳本蓋成明文）
//   登入：x-cf-kind: lk 時，x-cf-key 是用戶端從密碼推出的「登入金鑰」，伺服器看不到密碼本身；
//     沒有 x-cf-kind（舊版）時，x-cf-key 是密碼原文
//   DEK 的三份包裝（都存在帳號資料裡，伺服器解不開）：wrap_pw（密碼）、wrap_rec（救援碼）、wrap_admin（管理者公鑰）
import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

const json = (body, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
const env = k => (globalThis.Netlify && Netlify.env.get(k)) || process.env[k] || "";
const userId = name => crypto.createHash("sha256").update(String(name).trim().toLowerCase()).digest("hex").slice(0, 32);
const hashPw = (pw, salt) => crypto.pbkdf2Sync(String(pw), salt, 120000, 32, "sha256").toString("hex");
const same = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const validName = n => typeof n === "string" && n.trim().length >= 2 && n.trim().length <= 40;
const validPw = p => typeof p === "string" && p.length >= 6 && p.length <= 100;
// 登入金鑰：用戶端 PBKDF2 推出的 32 bytes，以 base64／base64url／hex 傳送
const validLk = k => typeof k === "string" && /^[A-Za-z0-9+/=_-]{32,128}$/.test(k);
const isObj = o => !!o && typeof o === "object" && !Array.isArray(o);
const isB64 = (s, max) => typeof s === "string" && s.length > 0 && s.length <= max && /^[A-Za-z0-9+/]+={0,2}$/.test(s);
// 加密帳本（AES-GCM）：{v:1, iv, ct}
const validEnc = e => isObj(e) && e.v === 1 && isB64(e.iv, 64) && isB64(e.ct, 7000000);
// 用密碼或救援碼推出的金鑰包起來的 DEK：{v:1, salt, iter, iv, ct}
const validWrap = w => isObj(w) && w.v === 1 && isB64(w.salt, 128) && Number.isSafeInteger(w.iter) && w.iter >= 100000 && w.iter <= 10000000
  && isB64(w.iv, 64) && isB64(w.ct, 1024);
// 用管理者公鑰包起來的 DEK：{v:1, alg:"RSA-OAEP-256", kid, ct}
const validAdminWrap = w => isObj(w) && w.v === 1 && w.alg === "RSA-OAEP-256" && typeof w.kid === "string" && /^[0-9a-f]{16}$/.test(w.kid) && isB64(w.ct, 2048);
const pubkeyId = pk => crypto.createHash("sha256").update(pk).digest("hex").slice(0, 16);
// 問題回報：用戶端把紀錄打包成 zip，用隨機 AES 金鑰加密、AES 金鑰再用管理者公鑰（RSA-OAEP）包起來；伺服器看不到內容
const validReport = r => isObj(r) && r.v === 1 && r.alg === "RSA-OAEP-256+A256GCM" && typeof r.kid === "string" && /^[0-9a-f]{16}$/.test(r.kid)
  && isB64(r.ek, 1024) && isB64(r.iv, 64) && isB64(r.ct, 4400000);
const REPORT_ID = /^[0-9a-f]{32}\/\d{8}T\d{6}\d{3}Z$/;   // 帳號代號/上傳時間（UTC，到毫秒）
const REPORT_KEEP = 20;                                      // 每個帳號最多留幾份（舊的自動刪掉）
const LOCK_MS = 15 * 60 * 1000;
async function fail(store, key, a) {   // 驗證失敗：累計 8 次鎖 15 分鐘
  a.fails = (a.fails || 0) + 1;
  if (a.fails >= 8) { a.lockUntil = Date.now() + LOCK_MS; a.fails = 0; }
  await store.setJSON(key, a);
}
// 設定新的登入方式：只留這次給的（沒給的那種刪掉，舊密碼或舊登入金鑰就不能再用）
function setCreds(a, pw, lk) {
  if (pw) a.hash = hashPw(pw, a.salt); else delete a.hash;
  if (lk) a.lkHash = hashPw(lk, a.salt); else delete a.lkHash;
}
// 管理碼（x-admin-key = ADMIN_KEY）：獨立的錯誤次數，登入成功不會歸零；錯 5 次鎖 1 小時。
// 回傳 null＝通過，否則回傳要送出的錯誤回應（避免有帳號的人用正確密碼反覆登入、一直猜管理碼）
const ADMIN_TRIES = 5, ADMIN_LOCK_MS = 60 * 60 * 1000;
async function adminCheck(store, key, a, req) {
  if (a.adminLockUntil && Date.now() < a.adminLockUntil) return json({ error: "管理碼錯太多次，請 1 小時後再試" }, 429);
  const admin = env("ADMIN_KEY"), k = req.headers.get("x-admin-key") || "";
  if (admin && k && same(k, admin)) { if (a.adminFails) { a.adminFails = 0; await store.setJSON(key, a); } return null; }
  a.adminFails = (a.adminFails || 0) + 1;
  if (a.adminFails >= ADMIN_TRIES) { a.adminLockUntil = Date.now() + ADMIN_LOCK_MS; a.adminFails = 0; }
  await store.setJSON(key, a);
  return json({ error: "管理碼不對" }, 403);
}
// 讀 JSON body；失敗回傳 null
async function body(req) { try { const b = await req.json(); return isObj(b) ? b : null; } catch { return null; } }

// 隨手記網頁也可以放在 GitHub Pages（沒有 Netlify 標籤）：允許 *.github.io（和 ALLOW_ORIGINS 列的網址）跨網域呼叫
// 帳號密碼放在 header、不用 cookie，所以別的網站拿不到你的資料
const corsFor = req => {
  const o = req.headers.get("origin") || "";
  const extra = env("ALLOW_ORIGINS").split(",").map(x => x.trim()).filter(Boolean);
  if (!(/^https:\/\/[a-z0-9-]+\.github\.io$/i.test(o) || extra.includes(o))) return {};
  return { "access-control-allow-origin": o, "access-control-allow-methods": "GET,PUT,POST,OPTIONS",
           "access-control-allow-headers": "content-type,x-cf-user,x-cf-key,x-cf-kind,x-admin-key", "access-control-max-age": "86400", "vary": "origin" };
};

export default async (req) => {
  const cors = corsFor(req);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  const res = await handle(req);
  for (const [k, v] of Object.entries(cors)) res.headers.set(k, v);
  return res;
};

async function handle(req) {
  const store = getStore({ name: "cardflow", consistency: "strong" });
  const url = new URL(req.url);
  const action = url.searchParams.get("action");

  /* ---- 管理者救援公鑰（公開，不用登入）：用戶端用它多包一份 DEK ---- */
  if (req.method === "GET" && action === "pubkey") {
    const pk = env("ADMIN_RECOVERY_PUBKEY").replace(/\s+/g, "");
    return json(isB64(pk, 4096) ? { pubkey: pk, kid: pubkeyId(pk) } : { pubkey: null, kid: null });
  }

  /* ---- 建立帳號：密碼（舊版）或登入金鑰（新版）至少要有一個 ---- */
  if (req.method === "POST" && action === "register") {
    const b = await body(req); if (!b) return json({ error: "格式錯誤" }, 400);
    if (!validName(b.user)) return json({ error: "帳號需要 2–40 個字" }, 400);
    const pw = b.password != null ? b.password : null, lk = b.loginKey != null ? b.loginKey : null;
    if (pw == null && lk == null) return json({ error: "密碼至少 6 個字" }, 400);
    if (pw != null && !validPw(pw)) return json({ error: "密碼至少 6 個字" }, 400);
    if (lk != null && !validLk(lk)) return json({ error: "登入金鑰格式不對" }, 400);
    const invite = env("INVITE_CODE");
    if (invite && !same(b.invite || "", invite)) return json({ error: "邀請碼不對" }, 403);
    const uid = userId(b.user);
    if (await store.get("users/" + uid)) return json({ error: "這個帳號已經有人使用，請換一個" }, 409);
    const a = { salt: crypto.randomBytes(16).toString("hex"), created: new Date().toISOString(), fails: 0, lockUntil: 0 };
    setCreds(a, pw, lk);
    await store.setJSON("users/" + uid, a);
    return json({ ok: true });
  }

  /* ---- 忘記密碼（不用登入） ----
   * recwrap：用救援碼取回 wrap_rec（用戶端用救援碼解開 DEK，再用新密碼重新包）
   * adminwrap：用管理碼取回 wrap_admin（管理者電腦上的工具用私鑰解開 DEK）
   * reset：用救援碼或管理碼設定新的密碼／登入金鑰；帳本已經加密的帳號要一起送新的 wrap_pw，否則新密碼解不開資料 */
  if (req.method === "POST" && (action === "reset" || action === "recwrap" || action === "adminwrap")) {
    const b = await body(req); if (!b) return json({ error: "格式錯誤" }, 400);
    if (!validName(b.user)) return json({ error: "帳號格式不對" }, 400);
    const pw = b.newPassword != null ? b.newPassword : null, lk = b.newLoginKey != null ? b.newLoginKey : null;
    if (action === "reset") {
      if ((pw == null && lk == null) || (pw != null && !validPw(pw)) || (lk != null && !validLk(lk)))
        return json({ error: "帳號或新密碼格式不對（密碼至少 6 個字）" }, 400);
      if (b.wrap_pw != null && !validWrap(b.wrap_pw)) return json({ error: "金鑰格式不對" }, 400);
    }
    const RK = "users/" + userId(b.user), ra = await store.get(RK, { type: "json" });
    if (!ra) return json({ error: action === "adminwrap" ? "管理碼不對" : "救援碼不對" }, 403);
    if (ra.lockUntil && Date.now() < ra.lockUntil) return json({ error: "錯太多次，請 15 分鐘後再試" }, 429);
    const code = String(b.code || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    const admin = env("ADMIN_KEY");
    const okRec = action !== "adminwrap" && !!ra.rec && !!code && same(hashPw(code, ra.salt), ra.rec);
    const okAdm = action !== "recwrap" && !!admin && !!b.admin && same(b.admin, admin);
    if (!okRec && !okAdm) {
      await fail(store, RK, ra);
      return json({ error: action === "adminwrap" ? "管理碼不對" : (b.admin ? "管理碼或救援碼不對" : "救援碼不對") }, 403);
    }
    if (action === "recwrap") return json({ wrap_rec: ra.wrap_rec || null });
    if (action === "adminwrap") return json({ wrap_admin: ra.wrap_admin || null, encrypted: !!ra.wrap_pw });
    if (ra.wrap_pw && !b.wrap_pw) return json({ error: "這個帳號的帳本已經加密，請用新版隨手記重設密碼", code: "wrap_required" }, 400);
    setCreds(ra, pw, lk); ra.fails = 0; ra.lockUntil = 0; ra.pwChanged = new Date().toISOString();
    if (b.wrap_pw) ra.wrap_pw = b.wrap_pw;
    if (okRec) { delete ra.rec; delete ra.wrap_rec; }   // 救援碼用過就失效（用它包的那份 DEK 也一起刪），登入後再產生新的
    await store.setJSON(RK, ra);
    return json({ ok: true });
  }

  /* ---- 驗證 ---- */
  const name = decodeURIComponent(req.headers.get("x-cf-user") || ""), key = decodeURIComponent(req.headers.get("x-cf-key") || "");
  const kind = req.headers.get("x-cf-kind") === "lk" ? "lk" : "pw";
  if (!validName(name) || !key) return json({ error: "請先登入" }, 401);
  const uid = userId(name), UK = "users/" + uid;
  const acct = await store.get(UK, { type: "json" });
  if (!acct) return json({ error: "帳號或密碼不對" }, 401);
  if (acct.lockUntil && Date.now() < acct.lockUntil) return json({ error: "密碼錯太多次，請 15 分鐘後再試" }, 429);
  const stored = kind === "lk" ? acct.lkHash : acct.hash;
  // 帳號沒有這種登入方式：不算錯誤次數（沒有比對任何祕密），回傳代碼讓用戶端改用另一種
  if (!stored) return json(kind === "lk" ? { error: "這個帳號還沒有設定登入金鑰", code: "no_login_key" }
                                         : { error: "這個帳號只能用新版隨手記登入", code: "login_key_required" }, 401);
  if (!same(hashPw(key, acct.salt), stored)) {
    await fail(store, UK, acct);
    return json({ error: "帳號或密碼不對" }, 401);
  }
  if (acct.fails) { acct.fails = 0; await store.setJSON(UK, acct); }

  /* ---- 帳號管理（登入後） ---- */
  if (req.method === "POST" && action === "recovery") {
    const raw = crypto.randomBytes(9).toString("base64").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 12).padEnd(12, "X");
    acct.rec = hashPw(raw, acct.salt); acct.recAt = new Date().toISOString();
    delete acct.wrap_rec;   // 舊救援碼包的 DEK 跟著失效；用戶端拿到新救援碼後再用 PUT keys 存新的 wrap_rec
    await store.setJSON(UK, acct);
    return json({ ok: true, code: raw.match(/.{4}/g).join("-"), at: acct.recAt });
  }
  if (req.method === "POST" && action === "changepw") {
    const b = await body(req); if (!b) return json({ error: "格式錯誤" }, 400);
    const pw = b.newPassword != null ? b.newPassword : null, lk = b.newLoginKey != null ? b.newLoginKey : null;
    if ((pw == null && lk == null) || (pw != null && !validPw(pw))) return json({ error: "新密碼至少 6 個字" }, 400);
    if (lk != null && !validLk(lk)) return json({ error: "登入金鑰格式不對" }, 400);
    if (b.wrap_pw != null && !validWrap(b.wrap_pw)) return json({ error: "金鑰格式不對" }, 400);
    if (acct.wrap_pw && !b.wrap_pw) return json({ error: "這個帳號的帳本已經加密，請用新版隨手記改密碼", code: "wrap_required" }, 400);
    setCreds(acct, pw, lk); acct.pwChanged = new Date().toISOString();
    if (b.wrap_pw) acct.wrap_pw = b.wrap_pw;
    await store.setJSON(UK, acct);
    return json({ ok: true });
  }
  // 舊帳號第一次用新版登入：用密碼登入後，補上登入金鑰（之後兩種都能用，直到 dropPassword）
  if (req.method === "POST" && action === "setlogin") {
    const b = await body(req); if (!b) return json({ error: "格式錯誤" }, 400);
    if (b.loginKey != null) { if (!validLk(b.loginKey)) return json({ error: "登入金鑰格式不對" }, 400); acct.lkHash = hashPw(b.loginKey, acct.salt); }
    if (b.dropPassword === true) {
      if (!acct.lkHash) return json({ error: "還沒有登入金鑰，不能停用密碼登入" }, 400);
      delete acct.hash;
    }
    await store.setJSON(UK, acct);
    return json({ ok: true, hasPassword: !!acct.hash, hasLoginKey: !!acct.lkHash });
  }
  if (req.method === "GET" && action === "account")
    return json({ hasRecovery: !!acct.rec, recAt: acct.recAt || "", created: acct.created || "",
                  hasPassword: !!acct.hash, hasLoginKey: !!acct.lkHash });
  // 資料金鑰的包裝：GET 取回 wrap_pw（用戶端用密碼解開）；wrap_rec、wrap_admin 只回答有沒有（和管理者金鑰的 kid）
  if (action === "keys") {
    if (req.method === "GET")
      return json({ wrap_pw: acct.wrap_pw || null, hasRecWrap: !!acct.wrap_rec, adminKid: acct.wrap_admin ? acct.wrap_admin.kid : null });
    if (req.method === "PUT") {
      const b = await body(req); if (!b) return json({ error: "格式錯誤" }, 400);
      if (b.wrap_pw != null && !validWrap(b.wrap_pw)) return json({ error: "金鑰格式不對" }, 400);
      if (b.wrap_rec != null && !validWrap(b.wrap_rec)) return json({ error: "金鑰格式不對" }, 400);
      if (b.wrap_admin != null && !validAdminWrap(b.wrap_admin)) return json({ error: "金鑰格式不對" }, 400);
      // wrap_pw 只有第一次（還沒加密）可以在這裡設定；之後只能透過改密碼／重設密碼換，避免用錯的金鑰蓋掉
      if (b.wrap_pw != null && acct.wrap_pw) return json({ error: "已經有資料金鑰，請用改密碼更換", code: "wrap_exists" }, 409);
      if (b.wrap_rec != null && !acct.rec) return json({ error: "請先產生救援碼" }, 400);
      if (b.wrap_pw != null) acct.wrap_pw = b.wrap_pw;
      if (b.wrap_rec != null) acct.wrap_rec = b.wrap_rec;
      if (b.wrap_admin != null) acct.wrap_admin = b.wrap_admin;
      await store.setJSON(UK, acct);
      return json({ ok: true });
    }
    return json({ error: "不支援" }, 405);
  }

  /* ---- 問題回報（家人電腦按「回報問題」）：上傳加密過的紀錄包。只能新增，不能讀自己的或別人的 ---- */
  if (action === "bugreport" && req.method === "POST") {
    const t = await req.text();
    if (t.length > 4500000) return json({ error: "檔案太大" }, 413);
    let b; try { b = JSON.parse(t); } catch { return json({ error: "格式錯誤" }, 400); }
    const pk = env("ADMIN_RECOVERY_PUBKEY").replace(/\s+/g, "");
    if (!isB64(pk, 4096)) return json({ error: "網站還沒有設定管理者公鑰，不能回報", code: "no_pubkey" }, 400);
    if (!validReport(b)) return json({ error: "格式錯誤" }, 400);
    if (b.kid !== pubkeyId(pk)) return json({ error: "管理者公鑰已經更換，請重新回報一次", code: "kid_mismatch" }, 409);
    const P = "bugreports/" + uid + "/";
    const old = (await store.list({ prefix: P })).blobs.map(x => x.key).sort();
    for (const k of old.slice(0, Math.max(0, old.length - (REPORT_KEEP - 1)))) await store.delete(k);
    let d = Date.now(), ts;   // 20261123T123456789Z；同一毫秒有兩份就往後挪，不會蓋掉
    do { ts = new Date(d++).toISOString().replace(/[-:.]/g, ""); } while (await store.get(P + ts));
    await store.setJSON(P + ts, { v: 1, alg: b.alg, kid: b.kid, ek: b.ek, iv: b.iv, ct: b.ct, size: b.ct.length, savedAt: new Date().toISOString() });
    return json({ ok: true, id: uid + "/" + ts });
  }
  /* ---- 管理者：列出、下載、刪除問題回報（登入自己的帳號，再帶 x-admin-key）。內容是密文，要用管理者私鑰在自己電腦解開 ---- */
  if (action === "bugreports" || action === "bugreportget" || action === "bugreportdel") {
    const denied = await adminCheck(store, UK, acct, req); if (denied) return denied;
    if (action === "bugreports" && req.method === "GET") {
      const out = [];
      for (const x of (await store.list({ prefix: "bugreports/" })).blobs) {
        const id = x.key.slice("bugreports/".length); if (!REPORT_ID.test(id)) continue;
        const v = await store.get(x.key, { type: "json" }); out.push({ id, savedAt: v ? v.savedAt : "", size: v ? v.size : 0 });
      }
      return json({ reports: out.sort((a, b) => a.savedAt < b.savedAt ? 1 : -1) });
    }
    const id = url.searchParams.get("id") || "";
    if (!REPORT_ID.test(id)) return json({ error: "代號格式不對" }, 400);
    const RK = "bugreports/" + id, rep = await store.get(RK, { type: "json" });
    if (!rep) return json({ error: "沒有這份回報" }, 404);
    if (action === "bugreportget" && req.method === "GET") return json(rep);
    if (action === "bugreportdel" && req.method === "POST") { await store.delete(RK); return json({ ok: true }); }
    return json({ error: "不支援" }, 405);
  }

  /* ---- 舊快照重新加密（第 4 階段搬家）：用戶端列出、讀取自己的明文快照，在自己的裝置用資料金鑰加密後換回去 ----
   * 只能把「明文」換成「密文」，而且 rev 要相同（確認換的是同一份）；已經加密的快照不能再換，伺服器不能也不會檢查內容 */
  const DATE = /^\d{4}-\d{2}-\d{2}$/;
  if (action === "snapshots" && req.method === "GET") {
    const P = "snapshots/" + uid + "/";
    const { blobs } = await store.list({ prefix: P });
    return json({ dates: blobs.map(b => b.key.slice(P.length)).filter(d => DATE.test(d)).sort() });
  }
  if (action === "snapshot") {
    const date = url.searchParams.get("date") || "";
    if (!DATE.test(date)) return json({ error: "日期格式不對" }, 400);
    const SK = "snapshots/" + uid + "/" + date, snap = await store.get(SK, { type: "json" });
    if (!snap) return json({ error: "沒有這天的快照" }, 404);
    if (req.method === "GET")
      return json(snap.enc ? { date, rev: snap.rev, savedAt: snap.savedAt, enc: snap.enc } : { date, rev: snap.rev, savedAt: snap.savedAt, data: snap.data });
    if (req.method === "PUT") {
      const b = await body(req); if (!b || !validEnc(b.enc)) return json({ error: "格式錯誤" }, 400);
      if (!acct.wrap_pw) return json({ error: "這個帳號還沒有資料金鑰，不能加密快照", code: "no_key" }, 400);
      if (snap.enc) return json({ error: "這天的快照已經加密", code: "already_encrypted" }, 409);
      if (b.rev !== snap.rev) return json({ error: "快照的版本不符", code: "rev_mismatch" }, 409);
      await store.setJSON(SK, { rev: snap.rev, savedAt: snap.savedAt, enc: b.enc, reencryptedAt: new Date().toISOString() });
      return json({ ok: true });
    }
    return json({ error: "不支援" }, 405);
  }
  /* ---- 搬家進度（只有網站管理者）：登入自己的帳號，再帶 x-admin-key（= ADMIN_KEY）；只回傳數量，不回傳任何人的資料 ---- */
  if (action === "status" && req.method === "GET") {
    const denied = await adminCheck(store, UK, acct, req); if (denied) return denied;
    const pk = env("ADMIN_RECOVERY_PUBKEY").replace(/\s+/g, ""), kidNow = isB64(pk, 4096) ? pubkeyId(pk) : null;
    const s = { accounts: 0, ledgerEncrypted: 0, ledgerPlain: 0, noLedger: 0, withKey: 0, withRecWrap: 0, adminWrapCurrent: 0, passwordLogin: 0, snapshots: 0, snapshotsPlain: 0 };
    for (const u of (await store.list({ prefix: "users/" })).blobs) {
      const id = u.key.slice("users/".length), a = (await store.get(u.key, { type: "json" })) || {}, l = await store.get("ledgers/" + id, { type: "json" });
      s.accounts++;
      if (!l) s.noLedger++; else if (l.enc) s.ledgerEncrypted++; else s.ledgerPlain++;
      if (a.wrap_pw) s.withKey++;
      if (a.wrap_rec) s.withRecWrap++;
      if (kidNow && a.wrap_admin && a.wrap_admin.kid === kidNow) s.adminWrapCurrent++;
      if (a.hash) s.passwordLogin++;
      for (const sn of (await store.list({ prefix: "snapshots/" + id + "/" })).blobs) {
        s.snapshots++;
        const v = await store.get(sn.key, { type: "json" });
        if (v && !v.enc) s.snapshotsPlain++;
      }
    }
    return json(s);
  }

  /* ---- 「立即更新」的狀態：獨立存放（不放在帳本裡，電腦回報時不用重寫整本帳） ---- */
  const page = url.searchParams.get("page");
  if (page === "refresh") {
    const FK = "refresh/" + uid;
    if (req.method === "GET") return json((await store.get(FK, { type: "json" })) || { refreshReq: 0, refreshDone: 0, refreshOk: null, refreshMsg: "" });
    if (req.method === "PUT") {
      const b = await body(req); if (!b) return json({ error: "格式錯誤" }, 400);
      const ts = v => v === undefined || (Number.isSafeInteger(v) && v >= 0);
      if (!ts(b.refreshReq) || !ts(b.refreshDone) || !(b.refreshOk === undefined || b.refreshOk === null || typeof b.refreshOk === "boolean")
          || !(b.refreshMsg === undefined || (typeof b.refreshMsg === "string" && b.refreshMsg.length <= 300))) return json({ error: "格式錯誤" }, 400);
      const cur = (await store.get(FK, { type: "json" })) || { refreshReq: 0, refreshDone: 0, refreshOk: null, refreshMsg: "" };
      for (const k of ["refreshReq", "refreshDone", "refreshOk", "refreshMsg"]) if (b[k] !== undefined) cur[k] = b[k];
      cur.savedAt = new Date().toISOString();
      await store.setJSON(FK, cur);
      return json(cur);
    }
    return json({ error: "不支援" }, 405);
  }

  /* ---- 加密過的月報／生活帳本（電腦每天上傳；網頁 view.html 用自己的密碼在瀏覽器解開） ---- */
  if (page) {
    if (!/^(report|book|cards)$/.test(page)) return json({ error: "不支援" }, 400);
    const PK = "pages/" + uid + "/" + page;
    if (req.method === "GET") return json((await store.get(PK, { type: "json" })) || { blob: null });
    if (req.method === "PUT") {
      const t = await req.text();
      if (t.length > 5500000) return json({ error: "檔案太大" }, 413);
      let b; try { b = JSON.parse(t); } catch { return json({ error: "格式錯誤" }, 400); }
      if (!b || !b.blob || !b.blob.ct || !b.blob.iv || !b.blob.salt) return json({ error: "格式錯誤" }, 400);
      await store.setJSON(PK, { blob: b.blob, savedAt: new Date().toISOString() });
      return json({ ok: true });
    }
    return json({ error: "不支援" }, 405);
  }

  /* ---- 讀寫自己的記帳本：明文 data（舊版）或加密 enc（新版），一次只能是其中一種 ---- */
  const KEY = "ledgers/" + uid;
  const cur = (await store.get(KEY, { type: "json" })) || null;
  const body409 = c => c && c.enc ? { error: "conflict", rev: c.rev, enc: c.enc } : { error: "conflict", rev: c ? c.rev : 0, data: c ? c.data : null };
  if (req.method === "GET") return json(cur && cur.enc ? { rev: cur.rev, enc: cur.enc } : { rev: cur ? cur.rev : 0, data: cur ? cur.data : null });
  if (req.method === "PUT") {
    const b = await body(req); if (!b) return json({ error: "格式錯誤" }, 400);
    const hasData = b.data !== undefined, hasEnc = b.enc !== undefined;
    if (hasData === hasEnc) return json({ error: "格式錯誤" }, 400);
    if (hasEnc) { if (!validEnc(b.enc)) return json({ error: "格式錯誤" }, 400); }
    else {
      const d = b.data;
      if (!d || !Array.isArray(d.records) || !Array.isArray(d.cards)) return json({ error: "格式錯誤" }, 400);
      if (cur && cur.enc) return json({ error: "帳本已經加密，這個版本的程式不能寫入，請更新隨手記或電腦端程式", code: "encrypted" }, 400);
    }
    const curRev = cur ? cur.rev : 0;
    if (Number(b.base) !== curRev) return json(body409(cur), 409);
    const next = hasEnc ? { rev: curRev + 1, savedAt: new Date().toISOString(), enc: b.enc } : { rev: curRev + 1, savedAt: new Date().toISOString(), data: b.data };
    await store.setJSON(KEY, next);
    await store.setJSON("snapshots/" + uid + "/" + next.savedAt.slice(0, 10), next);   // 每天一份快照
    return json({ rev: next.rev });
  }
  return json({ error: "不支援" }, 405);
};

export const config = { path: "/api/ledger" }
