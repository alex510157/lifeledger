/**
 * LifeLedger 生活總帳：每天自動把信用卡帳單 PDF 從 Gmail 存到 Google Drive
 * ------------------------------------------------------------------------
 * 第一次使用：整段貼上 → 存檔 → 上方函式選 setup → 按「執行」→ 授權。
 * 之後每天早上 6–7 點（台北時間）會自動執行，不用再管它。
 *
 * 可手動執行的函式：
 *   setup          安裝（或重裝）每日排程，並立刻抓一次。換新版程式後也跑一次。
 *   runNow         立即抓近 60 天的帳單
 *   backfillAll    補抓 2025/01/01 以後全部帳單（第一次或漏抓很久時用）
 *   checkStatus    在「執行紀錄」看排程是否存在、上次什麼時候跑、結果如何
 *   backfillOld    補抓 2023/01 ~ 2024/12 的舊帳單（自動分段跑完，完成後寄信通知）
 *   cleanupJunk    把已存的繳款單、簽章檔、繳款提醒移到垃圾桶（30 天內可救回）
 *   updateOnce     ★ 換這一版後跑一次就好：清掉多餘附件＋補抓 2025 年以來全部帳單（含遠東商銀）
 *
 * 任何銀行：沒列在 BANKS 的銀行也會自動收（認寄件網域，見下方 OTHER）；要更準可以在 BANKS 加一行 ['銀行簡稱', 'Gmail 搜尋條件']。
 *           （Gmail 搜尋條件請先在 Gmail 搜尋列試，確定只搜得到信用卡帳單信）
 *           報表要認得新銀行，還需請 Claude 加解析程式並提供 PDF 密碼規則。
 * 停用銀行：在那一行最前面加 // 即可，舊帳單會保留。
 */

const ROOT_NAME = 'LifeLedger_生活總帳';
const OLD_ROOT_NAME = 'CardFlow_卡片消費誌';   // 改名前的資料夾：第一次執行時自動改成新名字（裡面的帳單都保留）
const BANKS = [
  ['永豐', 'from:ebillservice@newebill.banksinopac.com.tw'],
  ['台新', 'from:webmaster@bhurecv.taishinbank.com.tw subject:電子帳單'],
  ['星展', 'from:eservicetw@dbs.com subject:對帳單'],
  ['玉山', 'from:estatement@esunbank.com subject:電子帳單'],
  ['聯邦', 'from:estatement@ebillv2.card.ubot.com.tw subject:電子帳單'],
  ['中信', 'from:ebill@estats.ctbcbank.com subject:電子帳單'],
  ['國泰', 'from:service@pxbillrc01.cathaybk.com.tw subject:電子帳單'],
  ['遠東商銀', 'from:service@feib-ecard.com.tw subject:信用卡'],
  // 富邦：帳單信只有網頁連結、沒有 PDF 附件，無法自動抓，請到富邦網站下載 PDF 放進 Google Drive「富邦」資料夾
];

// 不需要的附件（繳款單、簽章檔、行事曆提醒），不存；cleanupJunk 會把已存的移到垃圾桶
const SKIP = /PaymentSlip|繳款聯|smime|設定繳款提醒|\.p7s$|\.ics$/i;

// 通知設定：出錯一定寄信給自己；有新帳單時要不要也寄信通知（true / false）
const NOTIFY_ON_NEW = false;
const TRIGGER_FN = 'dailyRun';

/* ================= 給人按的函式 ================= */

function setup() {
  ScriptApp.getProjectTriggers()
    .filter(t => ['saveCardStatements', TRIGGER_FN].indexOf(t.getHandlerFunction()) >= 0)
    .forEach(t => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger(TRIGGER_FN).timeBased().everyDays(1).atHour(6)
    .inTimezone('Asia/Taipei').create();
  Logger.log('已安裝每日排程（台北時間 6–7 點）。現在先抓一次……');
  runNow();
  checkStatus();
}

function runNow()      { run_('newer_than:60d', '手動'); }

function updateOnce() {
  cleanupJunk();
  backfillAll();
  saveIncome_('after:2025/01/01');
}

/* ================= 收入與存款：各銀行存款／綜合對帳單、薪資單 =================
 * 存到 LifeLedger_生活總帳/_收入/ 底下：薪資入帳、利息、每月帳上餘額都從這裡算。
 * 同一個信箱也會收到家人帳戶的對帳單時，填 ME 只存你自己的。
 * 永豐「電子綜合對帳單」、星展「MTHLYSTMT」本來就跟信用卡帳單一起存在銀行資料夾，不用重複抓。
 * 第三欄是「信裡一定要有的字」，可以用正規表示式（. 代表任一個字）。 */
const ME = '';   // 你的名字（信裡會出現的寫法，例如 王.明；. 代表任一個字）。家人帳戶的對帳單也寄到同一個信箱時才需要
const INCOME = [
  // 存款對帳單（算利息、帳上餘額）：['名稱存款', 'Gmail 搜尋條件', ME]，例如
  // ['富邦存款', 'from:taipeifubon.com.tw subject:銀行對帳單', ME],
  // ['台新存款', 'from:taishinbank.com.tw subject:綜合對帳單', ME],
];

/* 只寄「互動式對帳單」通知信、沒有 PDF 的銀行（要身分證＋驗證碼才能看）：
 * 程式讀不到餘額，但會記一個「這個月的對帳單收到了」的小檔，月報就能提醒哪個月沒收到。 */
const NOTICE = [
  ['LINE Bank存款', 'from:myestatement.linebank.com.tw subject:電子對帳單', ME],
];

function saveNotice_(range) {
  const root = getOrCreate_(root_(), '_收入');
  NOTICE.forEach(([name, q, mustHave]) => {
    const folder = getOrCreate_(root, name);
    let n = 0;
    GmailApp.search(q + ' ' + range, 0, 200).forEach(t => t.getMessages().forEach(m => {
      if (mustHave && !new RegExp(mustHave).test(m.getPlainBody())) return;
      const ym = (m.getSubject().match(/(20\d\d)\s*年\s*(\d{1,2})\s*月/) || []);
      if (!ym[1]) return;
      const d = Utilities.formatDate(m.getDate(), 'Asia/Taipei', 'yyyy-MM-dd');
      const fn = d + '_' + name + '_' + ym[1] + '年' + ym[2] + '月_對帳單通知.txt';
      if (has_(folder, fn)) return;
      save_(folder, fn, m.getSubject() + '\n收到：' + d + '\n（互動式對帳單，餘額請自己開啟查看）', MimeType.PLAIN_TEXT); n++;
    }));
    Logger.log('通知｜' + name + '：新記 ' + n + ' 筆');
  });
}

function incomeOnce() { saveIncome_('after:2025/01/01'); saveNotice_('after:2025/01/01'); }

function saveIncome_(range) {
  const root = getOrCreate_(root_(), '_收入');
  INCOME.forEach(([name, q, mustHave]) => {
    const folder = getOrCreate_(root, name);
    let n = 0;
    GmailApp.search(q + ' has:attachment ' + range, 0, 500).forEach(t => t.getMessages().forEach(m => {
      if (mustHave && !new RegExp(mustHave).test(m.getPlainBody())) return;
      const d = Utilities.formatDate(m.getDate(), 'Asia/Taipei', 'yyyy-MM-dd');
      m.getAttachments().forEach(a => {
        if (/\.(png|jpe?g|gif|p7s|ics)$/i.test(a.getName()) || a.getSize() < 5000) return;   // 簽名檔、圖片不存
        const fn = d + '_' + name + '_' + a.getName();
        if (has_(folder, fn)) return;
        save_(folder, a.copyBlob().setName(fn)); n++;
      });
    }));
    Logger.log('收入｜' + name + '：新存 ' + n + ' 份');
  });
}

function cleanupJunk() {
  const root = root_();
  let n = 0;
  const subs = root.getFolders();
  while (subs.hasNext()) {
    const files = subs.next().getFiles();
    while (files.hasNext()) {
      const f = files.next();
      if (SKIP.test(f.getName())) { f.setTrashed(true); n++; }
    }
  }
  Logger.log('已把 ' + n + ' 個多餘附件移到垃圾桶（30 天內可從 Google Drive 垃圾桶救回）');
}
function backfillAll() { run_('after:2025/01/01', '補抓'); }

function checkStatus() {
  const ts = ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === TRIGGER_FN);
  const p = PropertiesService.getScriptProperties();
  Logger.log(ts.length ? '✅ 每日排程存在（' + ts.length + ' 個）' : '❌ 沒有每日排程，請執行 setup');
  Logger.log('上次執行：' + (p.getProperty('lastRun') || '從未'));
  Logger.log('上次結果：' + (p.getProperty('lastResult') || '—'));
  Logger.log('上次存到新帳單：' + (p.getProperty('lastNewFile') || '—'));
}

/* ================= 排程呼叫 ================= */

function dailyRun() { run_('newer_than:60d', '排程'); try { saveIncome_('newer_than:60d'); } catch (e) { Logger.log('收入：' + e); } try { saveNotice_('newer_than:60d'); } catch (e) { Logger.log('通知：' + e); } }
function saveCardStatements() { dailyRun(); }   // 相容舊版排程名稱

/* ================= 主程式 ================= */

function run_(range, who) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(30000)) { Logger.log('另一個執行還在跑，這次略過'); return; }
  const p = PropertiesService.getScriptProperties();
  const now = Utilities.formatDate(new Date(), 'Asia/Taipei', 'yyyy/MM/dd HH:mm');
  const t0 = Date.now();
  const saved = [], errors = [], skipped = [];
  try {
    const root = root_();
    BANKS.forEach(([bank, q]) => {
      if (Date.now() - t0 > 5 * 60 * 1000) { skipped.push(bank); return; }   // 單次上限 6 分鐘
      try {
        const files = fetchBank_(bank, q, range, getOrCreate_(root, bank));
        files.forEach(f => saved.push(bank + '｜' + f));
      } catch (e) {
        errors.push(bank + '：' + e.message);
      }
    });
    try { otherBanks_(range, root).forEach(f => saved.push(f)); } catch (e) { errors.push('其他銀行：' + e.message); }
    try { einvoice_(range, root).forEach(f => saved.push(f)); } catch (e) { errors.push('電子發票：' + e.message); }
  } catch (e) {
    errors.push('整體：' + e.message);
  } finally {
    lock.releaseLock();
  }

  const result = who + '｜新存 ' + saved.length + ' 份' +
    (skipped.length ? '｜時間不足未抓：' + skipped.join('、') : '') +
    (errors.length ? '｜錯誤 ' + errors.length + ' 個' : '');
  p.setProperty('lastRun', now);
  p.setProperty('lastResult', result);
  if (saved.length) p.setProperty('lastNewFile', now + '｜' + saved.join('；'));
  Logger.log(result);
  saved.forEach(s => Logger.log('  + ' + s));
  errors.forEach(s => Logger.log('  ! ' + s));

  const me = Session.getEffectiveUser().getEmail();
  if (errors.length || skipped.length) {
    MailApp.sendEmail(me, 'LifeLedger 抓帳單有問題（' + now + '）',
      result + '\n\n' + errors.join('\n') +
      (skipped.length ? '\n\n請手動執行 runNow 補抓。' : '') +
      '\n\n開啟 Apps Script 專案 › 執行項目 可看詳細紀錄。');
  } else if (saved.length && NOTIFY_ON_NEW) {
    MailApp.sendEmail(me, 'LifeLedger 存到 ' + saved.length + ' 份新帳單', saved.join('\n'));
  }
}

/* Google Drive 偶爾回「Service error: Drive」（Google 那邊暫時忙線）：自動等一下再試，最多 4 次 */
function retry_(fn) {
  for (let i = 0; ; i++) {
    try { return fn(); } catch (e) {
      if (i >= 3 || !/Service error|Internal error|timed out|temporarily|Service invoked too many times/i.test(String(e))) throw e;
      Utilities.sleep(3000 * (i + 1));
    }
  }
}
function save_(folder, ...a) { return retry_(() => folder.createFile(...a)); }
function has_(folder, name) { return retry_(() => folder.getFilesByName(name).hasNext()); }

function fetchBank_(bank, q, range, folder) {
  const threads = GmailApp.search(q + ' has:attachment ' + range, 0, 500);
  const out = [];
  threads.forEach(t => t.getMessages().forEach(m => {
    const d = Utilities.formatDate(m.getDate(), 'Asia/Taipei', 'yyyy-MM-dd');
    m.getAttachments().forEach(a => {
      if (!/\.pdf$/i.test(a.getName())) return;                // 只存 PDF
      if (SKIP.test(a.getName())) return;                       // 繳款單、繳款聯不存
      const name = d + '_' + bank + '_' + a.getName();
      if (has_(folder, name)) return;       // 已存過就跳過
      save_(folder, a.copyBlob().setName(name));
      out.push(name);
    });
  }));
  Logger.log(bank + '：' + threads.length + ' 封信，新存 ' + out.length + ' 份');
  return out;
}

/* ================= 上面沒列到的銀行：自動認寄件網域（任何一家銀行都收） =================
 * 信用卡帳單存到「銀行簡稱」資料夾；存款／綜合對帳單存到 _收入/<銀行>存款（有設 ME 時只收信裡有你名字的）。 */
const OTHER = [
  ['富邦', /fubon/], ['渣打', /standardchartered|\bsc\.com/], ['第一', /firstbank/], ['華南', /hncb/], ['彰銀', /\bchb\.com|bankchb/],
  ['兆豐', /megabank|megaicbc/], ['合庫', /tcb-bank/], ['土銀', /landbank/], ['臺銀', /\bbot\.com\.tw/], ['上海', /scsb/],
  ['新光', /skbank/], ['凱基', /kgibank|kgi\.com/], ['元大', /yuanta/], ['王道', /o-bank/], ['樂天', /rakuten-bank|rakuten\.com\.tw/],
  ['匯豐', /hsbc/], ['美國運通', /americanexpress|aexp/], ['將來', /nextbank/], ['LINE Bank', /linebank/], ['企銀', /\btbb\.com/],
  ['陽信', /sunnybank/], ['安泰', /entiebank/], ['台中銀', /\btcbbank\.com/], ['京城', /\bktb\.com/], ['華泰', /hwataibank/],
  ['三信', /cotabank/], ['板信', /\bbop\.com\.tw/], ['永豐', /sinopac/], ['台新', /taishin/], ['星展', /\bdbs\.com/], ['玉山', /esunbank/],
  ['聯邦', /ubot\.com/], ['中信', /ctbc/], ['國泰', /cathaybk/], ['遠東商銀', /feib/],
];
const NOT_BILL = /繳款成功|扣款成功|繳款提醒|繳款通知|消費通知|刷卡通知|交易通知|優惠|活動|好禮|抽獎|電子報|驗證碼|信託|基金|證券|投資|保險|貸款/;

function otherBanks_(range, root) {
  const listed = BANKS.map(b => b[0]);
  const out = [];
  GmailApp.search('has:attachment filename:pdf (subject:帳單 OR subject:對帳單 OR subject:statement) ' + range, 0, 300).forEach(t => t.getMessages().forEach(m => {
    const from = (m.getFrom().match(/@([^>\s]+)/) || [])[1] || '';
    const hit = OTHER.find(([, rx]) => rx.test(from.toLowerCase()));
    const subj = m.getSubject();
    if (!hit || NOT_BILL.test(subj)) return;
    const bank = hit[0];
    const deposit = /綜合對帳單|存款|銀行對帳單|帳戶|對帳單/.test(subj) && !/信用卡/.test(subj);
    if (!deposit && listed.indexOf(bank) >= 0) return;                    // 上面 BANKS 已經在抓
    if (deposit && INCOME.some(r => r[0] === bank + '存款')) return;      // 上面 INCOME 已經在抓
    if (deposit && ME && !new RegExp(ME).test(m.getPlainBody())) return;   // 家人（小孩）的帳戶不收
    const folder = deposit && bank !== '永豐' && bank !== '星展' ? getOrCreate_(getOrCreate_(root, '_收入'), bank + '存款') : getOrCreate_(root, bank);
    const tag = deposit && bank !== '永豐' && bank !== '星展' ? bank + '存款' : bank;
    const d = Utilities.formatDate(m.getDate(), 'Asia/Taipei', 'yyyy-MM-dd');
    m.getAttachments().forEach(a => {
      if (!/\.pdf$/i.test(a.getName()) || SKIP.test(a.getName()) || a.getSize() < 5000) return;
      const name = d + '_' + tag + '_' + a.getName();
      if (has_(folder, name)) return;
      save_(folder, a.copyBlob().setName(name)); out.push(tag + '｜' + name);
    });
  }));
  Logger.log('其他銀行（自動認寄件網域）：新存 ' + out.length + ' 份');
  return out;
}

/* 財政部「消費發票彙整通知」的 CSV（有每一張發票的品名）→ _電子發票：月報用來把「網購」拆成 3C、食品、玩具… */
function einvoice_(range, root) {
  const out = [];
  const folder = getOrCreate_(root, '_電子發票');
  GmailApp.search('from:einvoice@einvoice.nat.gov.tw has:attachment filename:csv ' + range, 0, 50).forEach(t => t.getMessages().forEach(m => {
    const d = Utilities.formatDate(m.getDate(), 'Asia/Taipei', 'yyyy-MM-dd');
    m.getAttachments().forEach(a => {
      if (!/\.csv$/i.test(a.getName())) return;
      const name = d + '_雲端發票_' + a.getName();
      if (has_(folder, name)) return;
      save_(folder, a.copyBlob().setName(name)); out.push('電子發票｜' + name);
    });
  }));
  return out;
}

function root_() {
  const top = DriveApp.getRootFolder(), it = top.getFoldersByName(ROOT_NAME);
  if (it.hasNext()) return it.next();
  const old = top.getFoldersByName(OLD_ROOT_NAME);
  if (old.hasNext()) { const f = old.next(); f.setName(ROOT_NAME); return f; }
  return top.createFolder(ROOT_NAME);
}

function getOrCreate_(parent, name) {
  const it = parent.getFoldersByName(name);
  return it.hasNext() ? it.next() : parent.createFolder(name);
}

/* ================= 補抓舊帳單（2023/01 ~ 2024/12） =================
 * 執行 backfillOld 一次就好：一次最多跑 4.5 分鐘，跑不完會自己每 10 分鐘接著跑，
 * 全部抓完自動停止，並寄信通知你。已經存過的檔案會跳過，重跑也不會重複。
 * 想看進度：執行 checkBackfill。想中途停止：執行 stopBackfill。
 */
const OLD_FROM = '2023/01/01';
const OLD_TO   = '2025/01/01';

function backfillOld() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) return;
  const p = PropertiesService.getScriptProperties();
  const st = JSON.parse(p.getProperty('bf') || JSON.stringify({from: OLD_FROM, bank: 0, saved: 0, errors: []}));
  const t0 = Date.now();
  try {
    const root = root_();
    while (st.from < OLD_TO && Date.now() - t0 < 4.5 * 60 * 1000) {
      const to = addMonths_(st.from, 3) < OLD_TO ? addMonths_(st.from, 3) : OLD_TO;
      const [bank, q] = BANKS[st.bank];
      try {
        st.saved += fetchBank_(bank, q, 'after:' + st.from + ' before:' + to, getOrCreate_(root, bank)).length;
      } catch (e) {
        st.errors.push(bank + ' ' + st.from + '：' + e.message);
      }
      st.bank++;
      if (st.bank >= BANKS.length) { st.bank = 0; st.from = to; }
      p.setProperty('bf', JSON.stringify(st));
    }
  } finally {
    lock.releaseLock();
  }
  const done = st.from >= OLD_TO;
  ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === 'backfillOld').forEach(t => ScriptApp.deleteTrigger(t));
  if (done) {
    p.deleteProperty('bf');
    MailApp.sendEmail(Session.getEffectiveUser().getEmail(), 'LifeLedger 舊帳單補抓完成',
      '2023/01 ~ 2024/12 共新存 ' + st.saved + ' 份帳單到 Google Drive「' + ROOT_NAME + '」。' +
      (st.errors.length ? '\n\n有錯誤：\n' + st.errors.join('\n') : '') +
      '\n\n接下來請回到 Claude 說「舊帳單抓好了」，讓它解析。');
    Logger.log('✅ 補抓完成，共新存 ' + st.saved + ' 份');
  } else {
    ScriptApp.newTrigger('backfillOld').timeBased().everyMinutes(10).create();
    Logger.log('⏳ 進度：已到 ' + st.from + '（第 ' + (st.bank + 1) + ' 家銀行），已存 ' + st.saved + ' 份；10 分鐘後自動接著跑');
  }
}

function checkBackfill() {
  const s = PropertiesService.getScriptProperties().getProperty('bf');
  Logger.log(s ? '進行中：' + s : '目前沒有補抓在進行（沒開始，或已完成）');
}

function stopBackfill() {
  ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === 'backfillOld').forEach(t => ScriptApp.deleteTrigger(t));
  Logger.log('已停止。之後再執行 backfillOld 會從上次的進度接著跑。');
}

function addMonths_(ymd, n) {
  const [y, m, d] = ymd.split('/').map(Number);
  return Utilities.formatDate(new Date(y, m - 1 + n, d), 'Asia/Taipei', 'yyyy/MM/dd');
}
