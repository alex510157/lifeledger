# LifeLedger 生活總帳：桌面小視窗（不會跳出黑色命令視窗）
#   顯示版本與更新通知、立即更新月報、打開月報／生活帳本／隨手記／Excel／資料夾、帳單密碼與隨手記設定
import os, sys, json, re, time, datetime, threading, queue, subprocess, webbrowser
import tkinter as tk
from tkinter import ttk, messagebox

PROG = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(PROG)
os.chdir(PROG)
sys.path.insert(0, PROG)
import updater
from paths import setp

HOME = os.path.dirname(TOOLS)
exe = sys.executable
_c = os.path.join(os.path.dirname(exe), 'python.exe')
PY = _c if os.path.basename(exe).lower() == 'pythonw.exe' and os.path.exists(_c) else exe
NOWIN = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
ENV = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
APP_URL = 'https://alex510157.github.io/lifeledger/app/'   # 隨手記網頁（大家共用）
APPID = 'LifeLedger.App'   # 工作列：開著的視窗、釘選的捷徑都用這個 ID，才會合成同一個 LifeLedger 圖示
try:
    import ctypes
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APPID)
except Exception:
    pass
_pw = os.path.join(os.path.dirname(exe), 'pythonw.exe')
PYW = _pw if os.path.exists(_pw) else exe   # 開內建檢視器用（沒有黑色視窗）


def shortcut_paths():
    from win32com.shell import shell, shellcon
    f = lambda c: shell.SHGetFolderPath(0, c, 0, 0)
    name = 'LifeLedger 生活總帳.lnk'
    return {'start': os.path.join(f(shellcon.CSIDL_PROGRAMS), 'LifeLedger 生活總帳', name),
            'desktop': os.path.join(f(shellcon.CSIDL_DESKTOPDIRECTORY), name),
            'startup': os.path.join(f(shellcon.CSIDL_STARTUP), name)}


def make_shortcut(path):
    """指向 LifeLedger.exe 的捷徑，帶 App ID（釘選到工作列後，開著的視窗會合在同一個圖示）"""
    import pythoncom
    from win32com.shell import shell
    from win32com.propsys import propsys, pscon
    exe_ = os.path.join(TOOLS, 'LifeLedger.exe')
    os.makedirs(os.path.dirname(path), exist_ok=True)
    lnk = pythoncom.CoCreateInstance(shell.CLSID_ShellLink, None, pythoncom.CLSCTX_INPROC_SERVER, shell.IID_IShellLink)
    lnk.SetPath(exe_); lnk.SetWorkingDirectory(TOOLS); lnk.SetIconLocation(exe_, 0); lnk.SetDescription('LifeLedger 生活總帳')
    ps = lnk.QueryInterface(propsys.IID_IPropertyStore)
    ps.SetValue(pscon.PKEY_AppUserModel_ID, propsys.PROPVARIANTType(APPID, pythoncom.VT_LPWSTR)); ps.Commit()
    lnk.QueryInterface(pythoncom.IID_IPersistFile).Save(path, 0)


def ensure_shortcuts():
    """第一次（或捷徑壞掉）：開始功能表一定有 LifeLedger；桌面上已經有的捷徑補上 App ID。只做一次（記在 ui.json）"""
    try:
        if not os.path.exists(os.path.join(TOOLS, 'LifeLedger.exe')):
            return
        u = {}
        try:
            u = json.load(open(setp('ui.json'), encoding='utf8'))
        except Exception:
            pass
        sp = shortcut_paths()
        if u.get('shortcuts') == 1 and os.path.exists(sp['start']):
            return
        make_shortcut(sp['start'])
        if os.path.exists(sp['desktop']):
            make_shortcut(sp['desktop'])
        if os.path.exists(sp['startup']):
            make_shortcut(sp['startup'])
        u['shortcuts'] = 1
        json.dump(u, open(setp('ui.json'), 'w', encoding='utf8'), ensure_ascii=False)
    except Exception:
        pass

# ---------- 配色主題（右上角 🎨 可以換；記在 設定\ui.json，程式更新不會蓋掉） ----------
FONT = 'Microsoft JhengHei UI'
_BASE = dict(ink='#3D3A4B', ink2='#8A8597', line='#F0E6DD', new='#FFF1C9', done='#E3F6E8', btn='#FFFFFF', pill='#FFFFFF', head_ink='#FFFFFF')
THEMES = {
    'pastel': dict(_BASE, name='🍑 粉彩甜心', bg='#FFF9F3', head=((255, 179, 198), (186, 200, 255)), main='#FF8FA3', hover='#FF7A92', shadow='#F3D9CF',
                   sub='#FFF3F5', btn_ink='#E0607E', tip='#FFF1E6', log='#FBF4EC',
                   tiles=['#FFE4EC', '#FFEBD6', '#E0F5E9', '#DDEFFF', '#ECE4FF', '#FFF4C7', '#DCF4F4', '#EEF0F5']),
    'mint': dict(_BASE, name='🌿 薄荷清新', bg='#F3FBF7', ink='#24423A', ink2='#6E8A81', line='#D9EDE3', head=((125, 222, 185), (140, 205, 245)),
                 main='#34B98A', hover='#2AA67B', shadow='#CDEBDD', sub='#E8FFF5', btn_ink='#2A9D74', tip='#E6F5EE', log='#EEF8F3', done='#D7F2E3',
                 tiles=['#DDF5EA', '#E6F7D9', '#D6F0F5', '#E9F3DA', '#DDEFE9', '#F3F7D4', '#D9F1EE', '#EAF2EE']),
    'ocean': dict(_BASE, name='🌊 海洋藍', bg='#F3F7FF', ink='#22324A', ink2='#6B7C96', line='#DCE6F5', head=((88, 150, 255), (120, 215, 250)),
                  main='#4A86F0', hover='#3B76E0', shadow='#CFDDF6', sub='#EAF2FF', btn_ink='#3B76E0', tip='#E6EEFB', log='#EEF3FC', done='#DDF2E6',
                  tiles=['#DCE9FF', '#DDF3FF', '#E3E5FF', '#D9F2F2', '#E6EEFA', '#E0F0FF', '#DFE8F5', '#EBEFF7']),
    'latte': dict(_BASE, name='☕ 奶茶暖色', bg='#FBF6F0', ink='#4A3B30', ink2='#937F70', line='#EADCCD', head=((205, 160, 120), (238, 200, 165)),
                  main='#C58A5C', hover='#B57A4D', shadow='#EAD9C8', sub='#FFF4EA', btn_ink='#B57A4D', tip='#F4EADF', log='#F7F0E8', new='#FBEFCB', done='#E5F0DF',
                  tiles=['#F6E6D8', '#F3E9DC', '#EFE3D3', '#F7EDE2', '#EDE2D6', '#F8EBD2', '#EEE6DD', '#F1ECE6']),
    'night': dict(_BASE, name='🌙 夜間模式', bg='#1E2030', ink='#ECEAF5', ink2='#A6A3BA', line='#34364A', head=((64, 70, 130), (120, 84, 165)),
                  main='#8C7CF0', hover='#7B6AE6', shadow='#14151F', sub='#E6E1FF', btn='#3A3D55', btn_ink='#C9C0FF', pill='#2A2C40',
                  tip='#272A3C', log='#262838', new='#4A4230', done='#2D4337',
                  tiles=['#33304A', '#3A3245', '#2C3A3A', '#2C3448', '#352F4A', '#3E3A2E', '#2D3943', '#30323F']),
}
T = dict(THEMES['pastel'])


def load_theme():
    try:
        k = json.load(open(setp('ui.json'), encoding='utf8')).get('theme')
    except Exception:
        k = None
    T.clear(); T.update(THEMES.get(k) or THEMES['pastel']); T['key'] = k if k in THEMES else 'pastel'


def save_theme(k):
    try:
        u = json.load(open(setp('ui.json'), encoding='utf8'))
    except Exception:
        u = {}
    u['theme'] = k
    json.dump(u, open(setp('ui.json'), 'w', encoding='utf8'), ensure_ascii=False)


TILES = [  # (emoji, 標題, 小字, 動作名)；底色跟著主題
    ('📊', '月報', '這個月花了多少', 'report'),
    ('📒', '生活帳本', '每一筆都在這', 'book'),
    ('📱', '隨手記', '記現金、收入', 'ledger'),
    ('📗', 'Excel 總帳', '想自己算的話', 'excel'),
    ('📁', '帳本資料夾', '帳單 PDF 放這', 'folder'),
    ('⚙️', '設定', '帳號、密碼、信箱、寄月報', 'settings'),
    ('📖', '使用說明', '不知道怎麼用', 'help'),
    ('🔄', '檢查更新', '看看有沒有新版', 'update'),
]


def settings_json():
    try:
        return json.load(open(setp('local_settings.json'), encoding='utf8'))
    except Exception:
        return {}


def out_dir():
    return settings_json().get('out') or HOME


def open_path(p):
    if os.path.exists(p):
        os.startfile(p)
    else:
        messagebox.showinfo('LifeLedger', '還沒有這個檔案，先按「立即更新月報」產生喔。\n\n' + p)


def ledger_url():
    L = settings_json().get('ledger') or {}
    if L.get('app_url'):
        return L['app_url']
    u = (L.get('url') or '').rstrip('/')
    return APP_URL if (not u or 'alexledger.netlify.app' in u) else u


def greeting():
    h = datetime.datetime.now().hour
    return (('早安，今天也一起好好記帳', '☀️') if 5 <= h < 11 else ('午安，吃飯記得記一筆', '🍱') if 11 <= h < 14
            else ('下午好，喝杯茶休息一下', '☕') if 14 <= h < 18 else ('晚安，今天辛苦了', '🌙'))


# ---------- 彩色 emoji 圖片（Windows 內建 Segoe UI Emoji；沒有的話就不顯示圖示） ----------
_IMG = {}


def emoji(ch, size=34):
    k = (ch, size)
    if k in _IMG:
        return _IMG[k]
    try:
        from PIL import Image, ImageDraw, ImageFont, ImageTk
        f = ImageFont.truetype(os.path.join(os.environ.get('WINDIR', r'C:\Windows'), 'Fonts', 'seguiemj.ttf'), size)
        im = Image.new('RGBA', (int(size * 1.4), int(size * 1.4)), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((im.width // 2, im.height // 2), ch, font=f, embedded_color=True, anchor='mm')
        _IMG[k] = ImageTk.PhotoImage(im.crop(im.getbbox() or (0, 0, im.width, im.height)))
    except Exception:
        _IMG[k] = None
    return _IMG[k]


def rrect(cv, x1, y1, x2, y2, r, **kw):
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return cv.create_polygon(pts, smooth=True, **kw)


def shade(hexc, f):
    r, g, b = (int(hexc[i:i + 2], 16) for i in (1, 3, 5))
    return '#%02x%02x%02x' % tuple(max(0, min(255, int(c * f))) for c in (r, g, b))


class App:
    W, H = 720, 660

    def __init__(self, root):
        self.root = root; self.q = queue.Queue(); self.busy = False; self.remote = None
        root.title('LifeLedger 生活總帳'); root.geometry(f'{self.W}x{self.H}'); root.minsize(680, 660); root.resizable(True, True)
        self._status = ''; self._busy_title = ''; self._resize_job = None
        try:
            root.iconbitmap(default=os.path.join(PROG, 'LifeLedger.ico'))
        except Exception:
            pass
        load_theme()
        self.cv = tk.Canvas(root, width=self.W, height=self.H, highlightthickness=0); self.cv.pack(fill='both', expand=True)
        root.bind('<Configure>', self.on_resize)
        self.pb = ttk.Progressbar(root, mode='indeterminate', length=self.W - 72)
        self.logbox = tk.Text(root, height=4, wrap='word', font=('Consolas', 8), relief='flat', state='disabled', bd=0)
        self._banner = ('', '', None, None)
        self.tip_text = ('💡 小提醒：帳單 PDF 放進「帳本資料夾」裡對應的銀行資料夾，或在「⚙️ 設定 → 信箱收帳單」讓程式自動收信。'
                         '手機隨手記記的現金、收入，每天也會一起整理進月報。')
        self.build()
        root.after(100, self.pump)
        root.after(300, lambda: self.check_update(quiet=True))
        threading.Thread(target=ensure_shortcuts, daemon=True).start()
        self.show_just_updated()
        if self.first_run():
            root.after(700, self.first_setup)

    # ---------- 畫面 ----------
    def build(self):
        """整個畫面（換主題時重畫）"""
        cv = self.cv; cv.delete('all'); _IMG.clear()
        self.root.configure(bg=T['bg']); cv.configure(bg=T['bg'])
        self.logbox.configure(bg=T['log'], fg=T['ink2'])
        self.draw_header()
        self.banner_y = 128; self.banner_items = []
        self.banner(*self._banner)
        self.tip_top = self.H - 112                                   # 底部：小提醒（更新時換成進度）
        self.th = max(108, min(210, (self.tip_top - 30 - 262 - 14) // 2))   # 視窗拉高，卡片跟著變高
        self.draw_main_button(176)
        self.draw_tiles(262)
        self.status = cv.create_text(36, self.tip_top - 18, text=self._status, anchor='w', font=(FONT, 10), fill=T['ink2'])   # 狀態文字
        self.tip = [rrect(cv, 28, self.tip_top, self.W - 28, self.H - 20, 18, fill=T['tip'], outline=''),
                    cv.create_text(48, self.tip_top + 46, anchor='w', width=self.W - 110, font=(FONT, 9), fill=T['ink2'], text=self.tip_text)]
        self.show_footer()
        if self.busy:   # 更新中調整視窗大小：進度條、紀錄框跟著移
            self.cv.itemconfig(self.main_label, text=f'{self._busy_title}中…'); self.cv.itemconfig(self.main_sub, text='大約 1–5 分鐘，可以先去做別的事 🍵')
            self.place_progress()

    def place_progress(self):
        for it in self.tip:
            self.cv.itemconfig(it, state='hidden')
        self.pb.place(x=36, y=self.tip_top + 6, width=self.W - 72)
        self.logbox.place(x=36, y=self.tip_top + 30, width=self.W - 72, height=max(50, self.H - self.tip_top - 42))

    def set_status(self, t):
        self._status = t; self.cv.itemconfig(self.status, text=t)

    def on_resize(self, e):
        if e.widget is not self.root or (e.width, e.height) == (self.W, self.H):
            return
        if self._resize_job:
            self.root.after_cancel(self._resize_job)

        def go():
            self._resize_job = None
            self.W, self.H = max(680, self.root.winfo_width()), max(660, self.root.winfo_height())
            self.build()
        self._resize_job = self.root.after(120, go)

    def theme_menu(self, e):
        if self.busy:
            return
        m = tk.Menu(self.root, tearoff=0, font=(FONT, 10))
        self._tv = tk.StringVar(value=T.get('key', 'pastel'))
        for k, th in THEMES.items():
            m.add_radiobutton(label=th['name'], variable=self._tv, value=k, command=lambda k=k: self.set_theme(k))
        m.tk_popup(e.x_root, e.y_root)

    def set_theme(self, k):
        save_theme(k); load_theme(); self.build()

    def draw_header(self):
        cv = self.cv; w = self.W
        a, b = T['head']   # 漸層
        for x in range(0, w, 2):
            t = x / w
            cv.create_line(x, 0, x, 112, width=2, fill='#%02x%02x%02x' % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3)))
        for cx, cy, r in ((w - 110, -6, 44), (w - 20, 60, 34), (w - 200, 112, 26), (20, 8, 30)):   # 淡淡的泡泡
            t = max(0, min(1, cx / w)); base = tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
            cv.create_oval(cx - r, cy - r, cx + r, cy + r, outline='', fill='#%02x%02x%02x' % tuple(int(c + (255 - c) * 0.22) for c in base))
        cv.create_rectangle(0, 112, w, 140, fill=T['bg'], outline='')   # 泡泡超出的部分蓋掉
        try:
            from PIL import Image, ImageTk
            im = Image.open(os.path.join(PROG, 'LifeLedger.ico')).convert('RGBA').resize((60, 60))
            self._logo = ImageTk.PhotoImage(im); cv.create_image(66, 56, image=self._logo)
        except Exception:
            pass
        cv.create_text(110, 40, text='LifeLedger 生活總帳', anchor='w', font=(FONT, 19, 'bold'), fill=T['head_ink'])
        gt, ge = greeting()
        t = cv.create_text(111, 74, text=gt, anchor='w', font=(FONT, 11), fill=T['head_ink'])
        img = emoji(ge, 18)
        if img:
            cv.create_image(cv.bbox(t)[2] + 14, 74, image=img)
        self.ver_pill = rrect(cv, w - 150, 70, w - 20, 98, 14, fill=T['pill'], outline='')
        pal = rrect(cv, w - 196, 70, w - 160, 98, 14, fill=T['pill'], outline='', tags='theme')   # 🎨 換主題
        img = emoji('🎨', 18)
        if img:
            cv.create_image(w - 178, 84, image=img, tags='theme')
        else:
            cv.create_text(w - 178, 84, text='🎨', tags='theme')
        cv.tag_bind('theme', '<Button-1>', self.theme_menu)
        cv.tag_bind('theme', '<Enter>', lambda e: cv.config(cursor='hand2'))
        cv.tag_bind('theme', '<Leave>', lambda e: cv.config(cursor=''))
        self.ver_text = cv.create_text(w - 85, 84, text='', font=(FONT, 9), fill=T['ink'])
        self.show_version()

    def draw_main_button(self, y):
        cv = self.cv; x1, x2, h = 28, self.W - 28, 70
        tag = 'mainbtn'
        rrect(cv, x1, y + 4, x2, y + h + 4, 22, fill=T['shadow'], outline='', tags=tag)   # 影子
        self.main_bg = rrect(cv, x1, y, x2, y + h, 22, fill=T['main'], outline='', tags=tag)
        img = emoji('✨', 30)
        if img:
            cv.create_image(x1 + 44, y + h // 2, image=img, tags=tag)
        self.main_label = cv.create_text(x1 + 74, y + 25, text='立即更新月報', anchor='w', font=(FONT, 15, 'bold'), fill='white', tags=tag)
        self.main_sub = cv.create_text(x1 + 74, y + 49, text='', anchor='w', font=(FONT, 9), fill=T['sub'], tags=tag)
        cv.create_text(x2 - 30, y + h // 2, text='›', font=(FONT, 24, 'bold'), fill='white', tags=tag)
        cv.tag_bind(tag, '<Button-1>', lambda e: self.run_report())
        cv.tag_bind(tag, '<Enter>', lambda e: (cv.itemconfig(self.main_bg, fill=T['hover']), cv.config(cursor='hand2')))
        cv.tag_bind(tag, '<Leave>', lambda e: (cv.itemconfig(self.main_bg, fill=T['main']), cv.config(cursor='')))

    def draw_tiles(self, y0):
        cv = self.cv; cols, gap, x0 = 4, 14, 28
        tw = (self.W - 2 * x0 - gap * (cols - 1)) // cols; th = self.th
        for i, (em, title, sub, act) in enumerate(TILES):
            color = T['tiles'][i]
            r, c = divmod(i, cols)
            x, y = x0 + c * (tw + gap), y0 + r * (th + gap)
            tag = 'tile_' + act
            bg = rrect(cv, x, y, x + tw, y + th, 20, fill=color, outline='', tags=tag)
            img = emoji(em, 32)
            if img:
                cv.create_image(x + tw // 2, y + th // 2 - 21, image=img, tags=tag)
            else:
                cv.create_text(x + tw // 2, y + th // 2 - 21, text=em, font=('Segoe UI Emoji', 24), tags=tag)
            cv.create_text(x + tw // 2, y + th // 2 + 17, text=title, font=(FONT, 11, 'bold'), fill=T['ink'], tags=tag)
            cv.create_text(x + tw // 2, y + th // 2 + 38, text=sub, font=(FONT, 8), fill=T['ink2'], tags=tag)
            cv.tag_bind(tag, '<Button-1>', lambda e, a=act: self.action(a))
            cv.tag_bind(tag, '<Enter>', lambda e, b=bg, col=color: (cv.itemconfig(b, fill=shade(col, 1.12 if T.get('key') == 'night' else 0.94)), cv.config(cursor='hand2')))
            cv.tag_bind(tag, '<Leave>', lambda e, b=bg, col=color: (cv.itemconfig(b, fill=col), cv.config(cursor='')))

    def show_footer(self):
        p = os.path.join(out_dir(), '月報', 'LifeLedger月報.html')
        t = ('上次更新：' + datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime('%m/%d %H:%M')) if os.path.exists(p) else '還沒產生過月報，按一下就開始'
        self.cv.itemconfig(self.main_sub, text=t)

    def banner(self, text, color, button=None, command=None):
        """最上面的通知條（有新版、剛自動更新完）"""
        cv = self.cv; self._banner = (text, color, button, command)
        for it in self.banner_items:
            cv.delete(it)
        self.banner_items = []
        if not text:
            wd = '一二三四五六日'[datetime.date.today().weekday()]
            self.banner_items.append(self.cv.create_text(36, self.banner_y + 19, anchor='w', font=(FONT, 10), fill=T['ink2'],
                                     text=datetime.date.today().strftime('%m 月 %d 日').lstrip('0').replace(' 0', ' ') + f'　星期{wd}　・　月報每天早上 7:30 自動更新，有新版也會自動裝好'))
            return
        y = self.banner_y; x1, x2 = 28, self.W - 28
        self.banner_items.append(rrect(cv, x1, y, x2, y + 38, 14, fill=T.get(color, color), outline=''))
        self.banner_items.append(cv.create_text(x1 + 16, y + 19, text=text, anchor='w', font=(FONT, 10), fill=T['ink'], width=x2 - x1 - 150))
        if button:
            b = rrect(cv, x2 - 120, y + 6, x2 - 8, y + 32, 12, fill=T['btn'], outline='', tags='bannerbtn')
            t = cv.create_text(x2 - 64, y + 19, text=button, font=(FONT, 9, 'bold'), fill=T['btn_ink'], tags='bannerbtn')
            cv.tag_bind('bannerbtn', '<Button-1>', lambda e: command())
            cv.tag_bind('bannerbtn', '<Enter>', lambda e: cv.config(cursor='hand2'))
            cv.tag_bind('bannerbtn', '<Leave>', lambda e: cv.config(cursor=''))
            self.banner_items += [b, t]

    # ---------- 動作 ----------
    def action(self, a):
        d = out_dir()
        {'report': lambda: self.view(os.path.join(d, '月報', 'LifeLedger月報.html'), '月報'),
         'book': lambda: self.view(os.path.join(d, '月報', 'LifeLedger生活帳本.html'), '生活帳本'),
         'ledger': lambda: self.view(ledger_url(), '隨手記'),
         'excel': lambda: open_path(os.path.join(d, 'LifeLedger_生活總帳.xlsx')),
         'folder': lambda: open_path(d),
         'settings': lambda: Settings(self.root, self),
         'help': lambda: open_path(os.path.join(TOOLS, '使用說明.md')),
         'update': lambda: self.check_update(quiet=False)}[a]()

    def say(self, s):
        self.q.put(('log', s))

    def view(self, target, title):
        """在 LifeLedger 自己的視窗看（Edge WebView2）；第一次自動安裝 pywebview，裝不起來就用瀏覽器開"""
        web = target.startswith('http')
        if not web and not os.path.exists(target):
            open_path(target); return
        fallback = (lambda: webbrowser.open(target)) if web else (lambda: open_path(target))
        launch = lambda: subprocess.Popen([PYW, os.path.join(PROG, 'viewer.pyw'), target, title], cwd=PROG)
        import importlib, importlib.util
        if importlib.util.find_spec('webview'):
            launch(); return
        self.set_status('第一次使用內建檢視器，正在安裝（約 1 分鐘）…')

        def work():
            r = subprocess.run([PY, '-m', 'pip', 'install', '--disable-pip-version-check', '-q', 'pywebview'], capture_output=True, creationflags=NOWIN)

            def done():
                importlib.invalidate_caches()
                if r.returncode == 0 and importlib.util.find_spec('webview'):
                    self.set_status(''); launch()
                else:
                    self.set_status('內建檢視器裝不起來，先用瀏覽器打開'); fallback()
            self.q.put(('call', done))
        threading.Thread(target=work, daemon=True).start()

    def pump(self):
        try:
            while True:
                k, v = self.q.get_nowait()
                if k == 'log':
                    m = re.match(r'\s*===\s*(.+?)\s*===', v)
                    if m:
                        self.set_status('正在：' + re.sub(r'^[\d.a-z]+\s*', '', m.group(1)))
                    elif v.strip().startswith(('✓', '已更新', '有新版', '已經是最新版', '檢查更新失敗', '更新失敗')):
                        self.set_status(v.strip())
                    self.logbox['state'] = 'normal'; self.logbox.insert('end', v.rstrip() + '\n'); self.logbox.see('end'); self.logbox['state'] = 'disabled'
                elif k == 'call':
                    v()
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    # ---------- 版本與更新 ----------
    def show_version(self):
        lv = updater.local_version()
        self.cv.itemconfig(self.ver_text, text=f'v{lv["version"]}' + ('　✓ 最新' if self.remote and self.remote['build'] <= lv['build'] else ''))

    def show_just_updated(self):
        p = os.path.join(PROG, '.just_updated.json')
        try:
            j = json.load(open(p, encoding='utf8'))
        except Exception:
            return
        notes = '、'.join(j.get('notes') or [])[:80]
        self.banner(f'✨ 已經自動更新到 v{j.get("to")}' + (f'：{notes}' if notes else ''), 'done', '知道了', lambda: (os.path.exists(p) and os.remove(p), self.banner('', '')))

    def check_update(self, quiet=False):
        if not quiet:
            self.set_status('檢查更新中…')

        def work():
            try:
                self.remote = updater.remote_version()
            except Exception as e:
                if not quiet:
                    self.say(f'檢查更新失敗（{e}），可能沒有網路，等一下再試')
                return
            lv = updater.local_version()
            if self.remote['build'] > lv['build']:
                notes = '、'.join(self.remote.get('notes') or [])[:60]
                self.q.put(('call', lambda: self.banner(f'🎁 有新版 v{self.remote["version"]}' + (f'：{notes}' if notes else ''), 'new', '現在更新', self.install_update)))
            elif not quiet:
                self.say(f'已經是最新版 v{lv["version"]}')
            self.q.put(('call', self.show_version))
        threading.Thread(target=work, daemon=True).start()

    def install_update(self):
        if self.busy:
            return
        self.busy = True; self.banner('⏳ 下載新版中…', 'new')

        def work():
            st = updater.check(install=True, log=self.say)[0]

            def done():
                self.busy = False; self.banner('', ''); self.show_version()
                if st == 'updated':
                    if messagebox.askyesno('LifeLedger', '更新好了 🎉\n要重新開啟視窗，換成新版嗎？'):
                        subprocess.Popen([sys.executable, os.path.abspath(__file__)], cwd=PROG)
                        self.root.destroy()
                else:
                    self.check_update(quiet=True)
            self.q.put(('call', done))
        threading.Thread(target=work, daemon=True).start()

    # ---------- 更新月報（和補抓舊帳單、健檢共用：背景執行、顯示進度） ----------
    def run_report(self):
        self.run_task('更新月報', [['run_local.py', '--auto']], open_after=os.path.join(out_dir(), '月報', 'LifeLedger月報.html'), ask_open='月報更新好了 🎉 要打開看看嗎？')

    def run_task(self, title, steps, open_after=None, ask_open=None):
        if self.busy:
            messagebox.showinfo('LifeLedger', '還有工作在進行中，等它做完再試一次。'); return
        if os.path.exists(os.path.join(PROG, '.running')):
            if not messagebox.askyesno('LifeLedger', '看起來排程正在更新（或上次沒正常結束）。還是要現在執行嗎？'):
                return
        self.busy = True; self._busy_title = title
        self.cv.itemconfig(self.main_label, text=f'{title}中…'); self.cv.itemconfig(self.main_sub, text='大約 1–5 分鐘，可以先去做別的事 🍵')
        self.set_status('準備中…')
        self.logbox['state'] = 'normal'; self.logbox.delete('1.0', 'end'); self.logbox['state'] = 'disabled'
        self.place_progress(); self.pb.start(12)

        def work():
            rc = 0
            for args in steps:
                p = subprocess.Popen([PY] + args, cwd=PROG, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     env=ENV, creationflags=NOWIN, text=True, encoding='utf8', errors='replace')
                for line in p.stdout:
                    if line.strip():
                        self.say(line)
                rc = p.wait()
                if rc:
                    break

            def done():
                self.busy = False; self.pb.stop(); self.pb.place_forget()
                self.cv.itemconfig(self.main_label, text='立即更新月報'); self.show_footer()
                if rc == 0:
                    self.logbox.place_forget(); self.set_status('')
                    for it in self.tip:
                        self.cv.itemconfig(it, state='normal')
                    self.cv.itemconfig(self.tip[1], text=f'✅ {title}完成！' + ('可以按上面的「月報」或「生活帳本」看看。' if '月報' in title or '補抓' in title else ''))
                    if open_after and (not ask_open or messagebox.askyesno('LifeLedger', ask_open)):
                        self.view(open_after, '月報') if open_after.endswith('.html') else open_path(open_after)
                else:
                    self.set_status('⚠ 更新沒有完成，下面是最後的訊息')
                    messagebox.showwarning('LifeLedger', f'{title}沒有完成。請把下面框框裡的訊息（或 紀錄 資料夾裡的檔案）傳給管理者看。')
            self.q.put(('call', done))
        threading.Thread(target=work, daemon=True).start()

    # ---------- 第一次使用 ----------
    def first_run(self):
        try:
            L = settings_json().get('ledger') or {}
            has_pw = os.path.exists(setp('passwords.json')) and any(v for k, v in json.load(open(setp('passwords.json'), encoding='utf8')).items() if k != '說明')
            return not has_pw and not (L.get('user') and '填' not in str(L.get('user')))
        except Exception:
            return False

    def first_setup(self):
        messagebox.showinfo('LifeLedger', '歡迎使用 LifeLedger 🎉\n\n接下來一步一步設定：隨手記帳號、帳單密碼、信箱、寄月報。\n不用的可以跳過，之後隨時按「⚙️ 設定」再改。')
        Settings(self.root, self, first=True)


BANKS = ['台新', '永豐', '玉山', '聯邦', '中信', '星展', '國泰', '富邦', '第一', '渣打', '凱基', '遠東', '兆豐', '華南', '合庫', '彰銀',
         '上海', '元大', '新光', '台企', 'LINE Bank', '將來', '樂天']
MAIL_TYPES = [  # (代號, 顯示名稱, 說明, 說明連結)
    ('gmail', 'Gmail', '要用「應用程式密碼」（16 碼），不是平常登入的密碼。先開兩步驟驗證，再到下面的連結建立一組，名稱打 LifeLedger。',
     'https://myaccount.google.com/apppasswords'),
    ('yahoo', 'Yahoo 奇摩', '到 Yahoo 帳號安全性 →「產生應用程式密碼」，貼那組密碼。', 'https://login.yahoo.com/myaccount/security'),
    ('hinet', 'HiNet', '直接用信箱密碼。先到 HiNet 網頁信箱確認有開 IMAP／POP3 收信。只填帳號（@ 前面）也可以。', ''),
    ('outlook', 'Outlook（電腦上的傳統版）', '用這台電腦上已經登入的 Outlook 收信，不用密碼。要是「傳統版」Outlook（有 檔案 → 選項 的那種）；新版 Outlook 不支援。', ''),
    ('imap', '其他信箱（IMAP）', '公司或其他信箱：要知道 IMAP 主機名稱（例如 imap.xxx.com），可以問 IT 或看信箱的說明。', ''),
]


class Settings:
    """設定（全部在視窗裡完成，不用黑色命令視窗）：左邊選項目，右邊填；每一頁都有說明"""
    PAGES = [('👤', '隨手記帳號'), ('💳', '帳單密碼'), ('📬', '信箱收帳單'), ('💌', '每月寄月報'), ('🌐', '加密線上版'), ('🧩', '進階')]
    W, H = 820, 700

    def __init__(self, parent, app, first=False):
        self.app = app; self.first = first
        self.PP = setp('passwords.json'); self.SP = setp('local_settings.json')
        self.PW = json.load(open(self.PP, encoding='utf8')) if os.path.exists(self.PP) else {}
        try:
            self.S = json.load(open(self.SP, encoding='utf8'))
        except Exception:
            self.S = {}
        self.MB = [dict(b) for b in self.S.get('mailboxes', [])]
        w = self.w = tk.Toplevel(parent, bg=T['bg']); w.title('設定'); w.geometry(f'{self.W}x{self.H}'); w.resizable(False, False)
        w.transient(parent); w.grab_set()
        self.style()
        side = tk.Frame(w, bg=T['tip'], width=190); side.pack(side='left', fill='y'); side.pack_propagate(False)
        tk.Label(side, text='⚙️ 設定', bg=T['tip'], fg=T['ink'], font=(FONT, 15, 'bold')).pack(anchor='w', padx=18, pady=(18, 12))
        self.navs = []
        for i, (em, name) in enumerate(self.PAGES):
            b = tk.Label(side, text=f'  {em}  {name}', anchor='w', bg=T['tip'], fg=T['ink'], font=(FONT, 11), cursor='hand2', padx=10, pady=9)
            b.pack(fill='x', padx=10, pady=2); b.bind('<Button-1>', lambda e, i=i: self.show(i)); self.navs.append(b)
        tk.Label(side, text='密碼只存在這台電腦\n（設定 資料夾），不會上傳。', bg=T['tip'], fg=T['ink2'], font=(FONT, 8), justify='left').pack(side='bottom', anchor='w', padx=18, pady=14)
        right = tk.Frame(w, bg=T['bg']); right.pack(side='left', fill='both', expand=True)
        self.body = tk.Frame(right, bg=T['bg']); self.body.pack(fill='both', expand=True, padx=22, pady=(16, 0))
        bar = tk.Frame(right, bg=T['bg']); bar.pack(fill='x', padx=22, pady=14)
        self.b_prev = ttk.Button(bar, text='← 上一步', command=lambda: self.show(self.cur - 1)); self.b_prev.pack(side='left')
        self.b_next = ttk.Button(bar, text='下一步 →', command=lambda: self.show(self.cur + 1)); self.b_next.pack(side='left', padx=6)
        ttk.Button(bar, text='儲存並關閉', style='LLp.TButton', command=self.save_close).pack(side='right')
        ttk.Button(bar, text='取消', command=w.destroy).pack(side='right', padx=6)
        self.pages = [self.page_ledger, self.page_bills, self.page_mail, self.page_report, self.page_web, self.page_adv]
        self.vars = {}
        self.frames = []
        for fn in self.pages:
            f = tk.Frame(self.body, bg=T['bg']); fn(f); self.frames.append(f)
        self.cur = 0; self.show(0)

    # ---------- 外觀小工具 ----------
    def style(self):
        st = ttk.Style(self.w)
        st.configure('LLp.TButton', font=(FONT, 10, 'bold'))
        st.configure('TCheckbutton', background=T['bg'], foreground=T['ink'], font=(FONT, 10))
        st.configure('TRadiobutton', background=T['bg'], foreground=T['ink'], font=(FONT, 10))

    def title(self, f, em, text, sub):
        tk.Label(f, text=f'{em} {text}', bg=T['bg'], fg=T['ink'], font=(FONT, 15, 'bold')).pack(anchor='w')
        tk.Label(f, text=sub, bg=T['bg'], fg=T['ink2'], font=(FONT, 9), wraplength=560, justify='left').pack(anchor='w', pady=(2, 10))

    def note(self, f, text, color=None):
        tk.Label(f, text=text, bg=T['bg'], fg=color or T['ink2'], font=(FONT, 9), wraplength=560, justify='left').pack(anchor='w', pady=(0, 6))

    def link(self, f, text, url):
        l = tk.Label(f, text='🔗 ' + text, bg=T['bg'], fg=T['btn_ink'], font=(FONT, 9, 'underline'), cursor='hand2')
        l.pack(anchor='w', pady=(0, 4)); l.bind('<Button-1>', lambda e: webbrowser.open(url))

    def card(self, f):
        c = tk.Frame(f, bg=T['tip'], padx=14, pady=10); c.pack(fill='x', pady=(0, 10)); return c

    def field(self, f, key, label, value='', secret=False, hint='', width=34):
        r = tk.Frame(f, bg=f['bg']); r.pack(fill='x', pady=3)
        tk.Label(r, text=label, bg=f['bg'], fg=T['ink'], font=(FONT, 10), width=16, anchor='w').pack(side='left')
        v = tk.StringVar(value=value); self.vars[key] = v
        e = ttk.Entry(r, textvariable=v, show='•' if secret else '', width=width, font=(FONT, 10)); e.pack(side='left')
        if secret:
            sv = tk.BooleanVar(value=False)
            ttk.Checkbutton(r, text='顯示', variable=sv, command=lambda: e.config(show='' if sv.get() else '•')).pack(side='left', padx=6)
        if hint:
            tk.Label(r, text=hint, bg=f['bg'], fg='#2E9E5B', font=(FONT, 9)).pack(side='left', padx=4)
        return e

    def show(self, i):
        i = max(0, min(len(self.frames) - 1, i)); self.cur = i
        for f in self.frames:
            f.pack_forget()
        self.frames[i].pack(fill='both', expand=True)
        for j, b in enumerate(self.navs):
            b.config(bg=T['bg'] if j == i else T['tip'], font=(FONT, 11, 'bold' if j == i else 'normal'))
        self.b_prev.config(state='normal' if i else 'disabled')
        self.b_next.config(state='normal' if i < len(self.frames) - 1 else 'disabled')

    def run_bg(self, args, out_label, done=None, timeout=None):
        """背景執行一支程式（不開視窗），結果顯示在 out_label"""
        out_label.config(text='⏳ 執行中，請稍等…', fg=T['ink2'])

        def work():
            try:
                r = subprocess.run([PY] + args, cwd=PROG, capture_output=True, text=True, encoding='utf8', errors='replace', env=ENV, creationflags=NOWIN, timeout=timeout)
                rc, out = r.returncode, (r.stdout + r.stderr).strip()
            except Exception as e:
                rc, out = 1, str(e)
            self.app.q.put(('call', lambda: (out_label.config(text=out[-700:] or ('✓ 完成' if rc == 0 else '✗ 失敗'), fg='#2E9E5B' if rc == 0 else '#C0392B'), done and done(rc, out))))
        threading.Thread(target=work, daemon=True).start()

    # ---------- 1. 隨手記 ----------
    def page_ledger(self, f):
        L = self.S.get('ledger') or {}
        blank = lambda v: not v or '填' in str(v)
        self.title(f, '👤', '隨手記帳號', '手機「隨手記」記的現金、收入，每天更新時會自動抓下來，和帳單對照；月報、生活帳本也會加密放到隨手記網站，用同一組帳號就能在手機上看。')
        c = self.card(f)
        self.field(c, 'l_user', '帳號', '' if blank(L.get('user')) else L.get('user', ''))
        self.field(c, 'l_pw', '密碼', '', secret=True, hint='已設定 ✓' if not blank(L.get('password')) else '')
        tk.Label(c, text='已經設定過的密碼不會顯示；密碼欄空白＝不修改。', bg=c['bg'], fg=T['ink2'], font=(FONT, 9)).pack(anchor='w')
        self.note(f, '還沒有帳號？用手機打開下面的隨手記網址 → 建立帳號（需要邀請碼，跟分享給你的人拿），再把同一組帳號密碼填在這裡。')
        self.link(f, '打開隨手記網頁', ledger_url())
        adv = self.card(f)
        tk.Label(adv, text='進階：隨手記伺服器（一般不用改）', bg=adv['bg'], fg=T['ink2'], font=(FONT, 9)).pack(anchor='w')
        self.field(adv, 'l_url', '伺服器網址', L.get('url') or 'https://alexledger.netlify.app')

    # ---------- 2. 帳單密碼 ----------
    def page_bills(self, f):
        self.title(f, '💳', '信用卡帳單 PDF 的密碼', '銀行寄來的帳單 PDF 大多有密碼。填好之後程式會自動打開帳單、整理每一筆消費。已經設定過的密碼不會顯示，空白＝不修改。')
        c = self.card(f)
        self.field(c, 'p_def', '共用密碼', '', secret=True, hint='已設定 ✓' if self.PW.get('default') else '')
        tk.Label(c, text='大部分銀行是「身分證字號」（英文字母大寫），填這裡就好。', bg=c['bg'], fg=T['ink2'], font=(FONT, 9)).pack(anchor='w')
        self.field(c, 'p_bd', '生日（西元 8 碼）', '', secret=True, hint='已設定 ✓' if self.PW.get('birthday') else '')
        tk.Label(c, text='例如 19850406。有些銀行用生日當密碼（例如星展）；填了程式會自動試：生日 8 碼、民國生日、月日、身分證後 4 碼＋月日。', bg=c['bg'], fg=T['ink2'], font=(FONT, 9), wraplength=540, justify='left').pack(anchor='w')
        tk.Label(f, text='密碼跟上面不一樣的銀行', bg=T['bg'], fg=T['ink'], font=(FONT, 11, 'bold')).pack(anchor='w', pady=(6, 2))
        self.note(f, '一家一行。同一家不同帳單密碼不一樣也沒關係：程式會把你存的每一組密碼都試一遍。')
        lf = tk.Frame(f, bg=T['bg']); lf.pack(fill='x')
        self.bank_list = tk.Listbox(lf, height=5, font=(FONT, 10), relief='flat', highlightthickness=1, highlightbackground=T['line'], bg='white', fg='#333')
        self.bank_list.pack(side='left', fill='x', expand=True)
        self.banks = {k: v for k, v in self.PW.items() if k not in ('default', 'birthday', '說明') and v}
        self.bank_new = {}
        self.refresh_banks()
        bf = tk.Frame(f, bg=T['bg']); bf.pack(fill='x', pady=6)
        tk.Label(bf, text='銀行', bg=T['bg'], fg=T['ink'], font=(FONT, 10)).pack(side='left')
        self.cb_bank = ttk.Combobox(bf, values=BANKS, width=10, font=(FONT, 10)); self.cb_bank.pack(side='left', padx=4)
        tk.Label(bf, text='密碼', bg=T['bg'], fg=T['ink'], font=(FONT, 10)).pack(side='left', padx=(8, 0))
        self.e_bpw = ttk.Entry(bf, show='•', width=18, font=(FONT, 10)); self.e_bpw.pack(side='left', padx=4)
        ttk.Button(bf, text='＋ 加入／修改', command=self.add_bank).pack(side='left', padx=4)
        ttk.Button(bf, text='刪除選取的', command=self.del_bank).pack(side='left')
        self.note(f, '銀行清單裡沒有的，直接在「銀行」欄打名字（跟帳本資料夾裡的銀行資料夾名稱一樣）。')

    def refresh_banks(self):
        self.bank_list.delete(0, 'end')
        for k in sorted(self.banks):
            self.bank_list.insert('end', f'  {k}　　{"（新設定）" if k in self.bank_new else "已設定 ✓"}')
        if not self.banks:
            self.bank_list.insert('end', '  （目前沒有）')

    def add_bank(self):
        b, p = self.cb_bank.get().strip(), self.e_bpw.get().strip()
        if not b or not p:
            messagebox.showinfo('設定', '請選銀行並填密碼', parent=self.w); return
        self.banks[b] = p; self.bank_new[b] = p
        self.cb_bank.set(''); self.e_bpw.delete(0, 'end'); self.refresh_banks()

    def del_bank(self):
        sel = self.bank_list.curselection()
        if not sel or not self.banks:
            return
        k = sorted(self.banks)[sel[0]]
        if messagebox.askyesno('設定', f'刪除「{k}」的帳單密碼？', parent=self.w):
            self.banks.pop(k, None); self.bank_new.pop(k, None); self.refresh_banks()

    # ---------- 3. 信箱 ----------
    def page_mail(self, f):
        self.title(f, '📬', '從信箱自動收帳單', '設定之後，每次更新會先到信箱收新的帳單（任何銀行的信用卡帳單、存款／綜合對帳單），自動放進帳本資料夾，不用自己下載。可以設好幾個信箱。')
        self.note(f, '已經用 Google Apps Script 把 Gmail 帳單存到雲端硬碟的，那個 Gmail 不用再設；Yahoo、HiNet、第二個 Gmail、Outlook 收的信才需要。')
        lf = tk.Frame(f, bg=T['bg']); lf.pack(fill='x')
        self.mb_list = tk.Listbox(lf, height=5, font=(FONT, 10), relief='flat', highlightthickness=1, highlightbackground=T['line'], bg='white', fg='#333')
        self.mb_list.pack(fill='x')
        self.refresh_mb()
        bf = tk.Frame(f, bg=T['bg']); bf.pack(fill='x', pady=6)
        ttk.Button(bf, text='＋ 新增信箱', command=lambda: self.edit_mb(None)).pack(side='left')
        ttk.Button(bf, text='修改', command=lambda: self.edit_mb(self.mb_sel())).pack(side='left', padx=4)
        ttk.Button(bf, text='刪除', command=self.del_mb).pack(side='left')
        ttk.Button(bf, text='🔌 測試連線（只看信、不存檔）', command=self.test_mb).pack(side='right')
        self.mb_out = tk.Label(f, text='', bg=T['bg'], fg=T['ink2'], font=('Consolas', 8), wraplength=560, justify='left', anchor='w')
        self.mb_out.pack(fill='x', pady=4)
        c = self.card(f)
        self.field(c, 'my_name', '你的名字（可不填）', self.S.get('my_name', ''))
        tk.Label(c, text='同一個信箱也會收到家人（例如小孩）帳戶的存款對帳單時才需要：填你在對帳單上的名字，就只收你的。中間的字可以用 . 代替，例如「王.明」會認得 王小明、王＊明。',
                 bg=c['bg'], fg=T['ink2'], font=(FONT, 9), wraplength=540, justify='left').pack(anchor='w')

    def mb_label(self, b):
        t = {'outlook': 'Outlook'}.get(b.get('type'), 'IMAP')
        return f'  {b.get("name") or b.get("user") or "Outlook"}　（{t}{"，" + b["host"] if b.get("host") else ""}）'

    def refresh_mb(self):
        self.mb_list.delete(0, 'end')
        for b in self.MB:
            self.mb_list.insert('end', self.mb_label(b))
        if not self.MB:
            self.mb_list.insert('end', '  （目前沒有設定信箱）')

    def mb_sel(self):
        s = self.mb_list.curselection()
        return s[0] if s and self.MB else None

    def del_mb(self):
        i = self.mb_sel()
        if i is not None and messagebox.askyesno('設定', f'刪除信箱「{self.MB[i].get("name")}」？', parent=self.w):
            self.MB.pop(i); self.refresh_mb()

    def edit_mb(self, idx):
        if idx is None and self.mb_list.curselection() and not self.MB:
            idx = None
        MailDialog(self, None if idx is None else self.MB[idx], idx)

    def test_mb(self):
        if not self.MB:
            self.mb_out.config(text='還沒有信箱可以測試'); return
        self.save(quiet=True)   # 測試用的是存好的設定
        since = (datetime.date.today() - datetime.timedelta(days=90)).isoformat()
        self.run_bg(['mail_fetch.py', '--test', '--since', since], self.mb_out, timeout=300)

    # ---------- 4. 寄月報 ----------
    def page_report(self, f):
        M = self.S.get('mail') or {}
        blank = lambda v: not v or '填' in str(v)
        self.title(f, '💌', '每月自動寄月報到信箱', '每個月指定的那天之後，第一次自動更新完會把月報寄到你的信箱。需要一個 Gmail 當寄件人。')
        self.vars['m_on'] = tk.BooleanVar(value=bool(M.get('enabled')))
        ttk.Checkbutton(f, text='開啟每月寄月報', variable=self.vars['m_on']).pack(anchor='w', pady=(0, 6))
        c = self.card(f)
        self.field(c, 'm_from', '寄件的 Gmail', '' if blank(M.get('from')) else M.get('from', ''))
        self.field(c, 'm_pw', '應用程式密碼', '', secret=True, hint='已設定 ✓' if not blank(M.get('app_password')) else '')
        self.field(c, 'm_to', '收月報的信箱', M.get('to') or '')
        r = tk.Frame(c, bg=c['bg']); r.pack(fill='x', pady=3)
        tk.Label(r, text='每月幾號寄', bg=c['bg'], fg=T['ink'], font=(FONT, 10), width=16, anchor='w').pack(side='left')
        self.vars['m_day'] = tk.StringVar(value=str(M.get('mail_day', 12)))
        ttk.Spinbox(r, from_=1, to=28, textvariable=self.vars['m_day'], width=5, font=(FONT, 10)).pack(side='left')
        tk.Label(r, text='（建議 12 號以後：大部分銀行帳單都到了）', bg=c['bg'], fg=T['ink2'], font=(FONT, 9)).pack(side='left', padx=6)
        tk.Label(f, text='怎麼拿「應用程式密碼」（16 碼，不是 Gmail 登入密碼）：', bg=T['bg'], fg=T['ink'], font=(FONT, 10, 'bold')).pack(anchor='w', pady=(4, 2))
        self.note(f, '① 先開「兩步驟驗證」（已經開了就跳過）\n② 打開「應用程式密碼」→ 名稱打 LifeLedger → 建立\n③ 畫面出現 4 組共 16 個英文字母，複製後貼到上面\n※ 網頁顯示「你要找的設定不適用於你的帳戶」＝兩步驟驗證還沒開好')
        self.link(f, '① 開兩步驟驗證', 'https://myaccount.google.com/signinoptions/twosv')
        self.link(f, '② 建立應用程式密碼', 'https://myaccount.google.com/apppasswords')
        bf = tk.Frame(f, bg=T['bg']); bf.pack(fill='x', pady=4)
        ttk.Button(bf, text='🔌 測試 Gmail 登入', command=self.test_gmail).pack(side='left')
        self.m_out = tk.Label(bf, text='', bg=T['bg'], fg=T['ink2'], font=(FONT, 9), wraplength=420, justify='left'); self.m_out.pack(side='left', padx=8)

    def gmail_creds(self):
        M = self.S.get('mail') or {}
        u = self.vars['m_from'].get().strip()
        p = self.vars['m_pw'].get().replace(' ', '') or M.get('app_password', '')
        return u, p

    def test_gmail(self):
        u, p = self.gmail_creds()
        if not u or not p:
            self.m_out.config(text='請先填寄件的 Gmail 和應用程式密碼', fg='#C0392B'); return
        self.m_out.config(text='⏳ 測試中…', fg=T['ink2'])

        def work():
            try:
                import smtplib
                with smtplib.SMTP_SSL('smtp.gmail.com', 465, timeout=20) as s:
                    s.login(u, p)
                msg, ok = '✓ Gmail 登入成功', True
            except Exception as e:
                msg, ok = f'✗ 登入失敗：{str(e)[:120]}（確認是 16 碼應用程式密碼、兩步驟驗證已開）', False
            self.app.q.put(('call', lambda: (self.m_out.config(text=msg, fg='#2E9E5B' if ok else '#C0392B'), ok and self.vars['m_on'].set(True))))
        threading.Thread(target=work, daemon=True).start()

    # ---------- 5. 線上版 ----------
    def page_web(self, f):
        W = self.S.get('web') or {}
        blank = lambda v: not v or '填' in str(v)
        self.title(f, '🌐', '加密線上版（手機也能看）', '把月報、生活帳本加密後放到你自己的 GitHub 網頁。網址是公開的，但內容要輸入「看網頁用的密碼」才能解開。不需要的話可以跳過。')
        self.note(f, '（有設定隨手記帳號的話，月報已經會加密放到隨手記網站，通常不用再開這個。）', T['ink2'])
        self.vars['w_on'] = tk.BooleanVar(value=bool(W.get('enabled')))
        ttk.Checkbutton(f, text='開啟加密線上版', variable=self.vars['w_on']).pack(anchor='w', pady=(0, 6))
        c = self.card(f)
        self.field(c, 'w_token', 'GitHub 權杖', '', secret=True, hint='已設定 ✓' if not blank(W.get('token')) else '')
        self.field(c, 'w_pw', '看網頁用的密碼', '', secret=True, hint='已設定 ✓' if not blank(W.get('password')) else '')
        self.field(c, 'w_pw2', '再輸入一次', '', secret=True)
        self.field(c, 'w_repo', '網站名稱（repo）', W.get('repo') if W.get('repo') not in (None, '', 'cardflow') else 'lifeledger')
        tk.Label(f, text='怎麼拿 GitHub 權杖：', bg=T['bg'], fg=T['ink'], font=(FONT, 10, 'bold')).pack(anchor='w', pady=(4, 2))
        self.note(f, '① 沒有 GitHub 帳號先免費註冊\n② 打開下面的連結 → Note 打 LifeLedger，Expiration 選 No expiration，勾選 public_repo → 最下面 Generate token\n③ 複製 ghp_ 開頭的那串，貼到上面\n看網頁用的密碼至少 8 個字。')
        self.link(f, '建立 GitHub 權杖', 'https://github.com/settings/tokens/new')
        bf = tk.Frame(f, bg=T['bg']); bf.pack(fill='x', pady=4)
        ttk.Button(bf, text='☁️ 儲存並上傳一次（約 1 分鐘）', command=self.publish_web).pack(side='left')
        self.w_out = tk.Label(f, text='', bg=T['bg'], fg=T['ink2'], font=('Consolas', 8), wraplength=560, justify='left', anchor='w'); self.w_out.pack(fill='x', pady=4)

    def publish_web(self):
        if not self.vars['w_on'].get():
            self.vars['w_on'].set(True)
        if not self.save(quiet=True):
            return

        def done(rc, out):
            if rc == 0 and os.path.exists(os.path.join(PROG, 'web_url.txt')):
                url = open(os.path.join(PROG, 'web_url.txt'), encoding='utf8').read().strip()
                self.w_out.config(text=f'✓ 線上版網址：{url}（GitHub 第一次開站要等 1–3 分鐘才打得開）', fg='#2E9E5B')
            else:
                self.S.setdefault('web', {})['enabled'] = False; self.vars['w_on'].set(False); self.save(quiet=True)
        self.run_bg(['publish_web.py', '--force'], self.w_out, done, timeout=600)

    # ---------- 6. 進階 ----------
    def page_adv(self, f):
        self.title(f, '🧩', '進階', '一般不用改。需要時再來這裡。')
        c = self.card(f)
        tk.Label(c, text='📅 補抓舊帳單', bg=c['bg'], fg=T['ink'], font=(FONT, 11, 'bold')).pack(anchor='w')
        cur = self.S.get('report_start') or '（自動：最早的一份帳單）'
        tk.Label(c, text=f'月報、生活帳本、Excel 從哪個月開始算。目前：{cur}。改了之後會從信箱補抓那個月以後的帳單（信多的話要 10–30 分鐘），再重新整理。',
                 bg=c['bg'], fg=T['ink2'], font=(FONT, 9), wraplength=540, justify='left').pack(anchor='w')
        r = tk.Frame(c, bg=c['bg']); r.pack(fill='x', pady=4)
        tk.Label(r, text='從', bg=c['bg'], fg=T['ink'], font=(FONT, 10)).pack(side='left')
        self.vars['bf_y'] = tk.StringVar(value=(self.S.get('report_start') or str(datetime.date.today().year))[:4])
        ttk.Spinbox(r, from_=2015, to=datetime.date.today().year, textvariable=self.vars['bf_y'], width=6, font=(FONT, 10)).pack(side='left', padx=4)
        tk.Label(r, text='年', bg=c['bg'], fg=T['ink'], font=(FONT, 10)).pack(side='left')
        self.vars['bf_m'] = tk.StringVar(value=str(int((self.S.get('report_start') or 'x-01')[-2:] or 1)))
        ttk.Spinbox(r, from_=1, to=12, textvariable=self.vars['bf_m'], width=4, font=(FONT, 10)).pack(side='left', padx=4)
        tk.Label(r, text='月開始', bg=c['bg'], fg=T['ink'], font=(FONT, 10)).pack(side='left')
        ttk.Button(r, text='開始補抓', command=self.backfill).pack(side='left', padx=10)

        c = self.card(f)
        tk.Label(c, text='📁 其他帳單資料夾', bg=c['bg'], fg=T['ink'], font=(FONT, 11, 'bold')).pack(anchor='w')
        tk.Label(c, text='帳本資料夾以外，還有其他放帳單 PDF 的地方（例如 Google 雲端硬碟同步下來的資料夾），加進來就會一起讀。', bg=c['bg'], fg=T['ink2'], font=(FONT, 9), wraplength=540, justify='left').pack(anchor='w')
        r = tk.Frame(c, bg=c['bg']); r.pack(fill='x', pady=4)
        self.bills = [b for b in self.S.get('bills', []) if b]
        self.bills_lb = tk.Listbox(r, height=3, font=(FONT, 9), relief='flat', bg='white', fg='#333'); self.bills_lb.pack(side='left', fill='x', expand=True)
        bb = tk.Frame(r, bg=c['bg']); bb.pack(side='left', padx=6)
        ttk.Button(bb, text='＋ 加資料夾', command=self.add_bill_dir).pack(fill='x')
        ttk.Button(bb, text='移除', command=self.del_bill_dir).pack(fill='x', pady=2)
        self.refresh_bills()

        c = self.card(f)
        tk.Label(c, text='👪 家人附卡、薪資', bg=c['bg'], fg=T['ink'], font=(FONT, 11, 'bold')).pack(anchor='w')
        self.field(c, 'spouse', '配偶附卡名字', '、'.join(self.S.get('spouse_names', [])))
        tk.Label(c, text='帳單上配偶附卡的英文拼音名字，例如 WANG XIAO MEI（多個用「、」隔開）。這些附卡的消費會算進自己的支出。', bg=c['bg'], fg=T['ink2'], font=(FONT, 9), wraplength=540, justify='left').pack(anchor='w')
        self.field(c, 'salary', '薪資匯款人', self.S.get('salary_payer', ''))
        tk.Label(c, text='存款對帳單上，薪資入帳時顯示的公司名稱（可以只填一部分），用來辨認薪資。', bg=c['bg'], fg=T['ink2'], font=(FONT, 9), wraplength=540, justify='left').pack(anchor='w')

        c = self.card(f)
        tk.Label(c, text='📌 開始功能表、工作列、開機', bg=c['bg'], fg=T['ink'], font=(FONT, 11, 'bold')).pack(anchor='w')
        tk.Label(c, text='想放到工作列：打開 LifeLedger 後，在工作列上的圖示按右鍵 →「釘選到工作列」。想放到開始：開始功能表找到 LifeLedger 生活總帳 → 右鍵 →「釘選到開始」。（Windows 不讓程式自己釘選，要自己按一下）',
                 bg=c['bg'], fg=T['ink2'], font=(FONT, 9), wraplength=540, justify='left').pack(anchor='w')
        r = tk.Frame(c, bg=c['bg']); r.pack(fill='x', pady=4)
        try:
            on = os.path.exists(shortcut_paths()['startup'])
        except Exception:
            on = False
        self.vars['autostart'] = tk.BooleanVar(value=on)
        ttk.Checkbutton(r, text='開機時自動打開 LifeLedger', variable=self.vars['autostart'], command=self.toggle_autostart).pack(side='left')
        ttk.Button(r, text='重新建立開始功能表、桌面捷徑', command=self.fix_shortcuts).pack(side='right')
        r = tk.Frame(f, bg=T['bg']); r.pack(fill='x', pady=4)
        ttk.Button(r, text='🩺 健檢（檢查安裝、信箱、帳單、排程，產生報告）', command=self.health).pack(side='left')

    def toggle_autostart(self):
        try:
            p = shortcut_paths()['startup']
            if self.vars['autostart'].get():
                make_shortcut(p)
            elif os.path.exists(p):
                os.remove(p)
        except Exception as e:
            messagebox.showwarning('設定', f'沒有設定成功：{e}', parent=self.w)

    def fix_shortcuts(self):
        try:
            sp = shortcut_paths(); make_shortcut(sp['start']); make_shortcut(sp['desktop'])
            messagebox.showinfo('設定', '開始功能表和桌面的「LifeLedger 生活總帳」都建立好了。', parent=self.w)
        except Exception as e:
            messagebox.showwarning('設定', f'沒有建立成功：{e}', parent=self.w)

    def refresh_bills(self):
        self.bills_lb.delete(0, 'end')
        for b in self.bills:
            self.bills_lb.insert('end', ' ' + b)
        if not self.bills:
            self.bills_lb.insert('end', ' （只用帳本資料夾）')

    def add_bill_dir(self):
        from tkinter import filedialog
        d = filedialog.askdirectory(parent=self.w, title='選擇放帳單 PDF 的資料夾')
        if d and os.path.normpath(d) not in self.bills:
            self.bills.append(os.path.normpath(d)); self.refresh_bills()

    def del_bill_dir(self):
        s = self.bills_lb.curselection()
        if s and self.bills:
            self.bills.pop(s[0]); self.refresh_bills()

    def backfill(self):
        try:
            ym = f'{int(self.vars["bf_y"].get()):04d}-{int(self.vars["bf_m"].get()):02d}'
        except ValueError:
            messagebox.showwarning('設定', '年、月要填數字', parent=self.w); return
        if not messagebox.askyesno('補抓舊帳單', f'月報改成從 {ym} 開始，並從信箱補抓那以後的帳單、重新整理。\n信多的話要 10–30 分鐘，可以先關掉設定視窗。要開始嗎？', parent=self.w):
            return
        self.S['report_start'] = ym; self.S['mail_since'] = ym + '-01'
        if not self.save(quiet=True):
            return
        steps = ([['mail_fetch.py', '--since', ym + '-01']] if self.S.get('mailboxes') else []) + [['run_local.py', '--auto', '--no-mail']]
        self.w.destroy()
        self.app.run_task(f'補抓 {ym} 以後的帳單', steps)

    def health(self):
        self.w.destroy()
        self.app.run_task('健檢', [['health_check.py']], open_after=os.path.join(TOOLS, '紀錄', '健檢報告.txt'))

    # ---------- 存檔 ----------
    def save(self, quiet=False):
        v = lambda k: self.vars[k].get() if k in self.vars else ''
        bd = v('p_bd').strip()
        if bd and not re.fullmatch(r'\d{8}', bd):
            self.show(1); messagebox.showwarning('設定', '生日要 8 碼數字，例如 19850406', parent=self.w); return False
        wp, wp2 = v('w_pw'), v('w_pw2')
        if wp and (len(wp) < 8 or wp != wp2):
            self.show(4); messagebox.showwarning('設定', '看網頁用的密碼至少 8 個字，而且兩次要一樣', parent=self.w); return False
        # 帳單密碼
        if v('p_def').strip():
            self.PW['default'] = v('p_def').strip()
        if bd:
            self.PW['birthday'] = bd
        for k in [k for k in self.PW if k not in ('default', 'birthday', '說明')]:
            if k not in self.banks:
                self.PW.pop(k)
        self.PW.update(self.banks)
        self.PW.setdefault('說明', '各銀行帳單 PDF 的開啟密碼；default 是共用的，銀行名稱的那一行會優先使用')
        S = self.S
        # 隨手記
        L = S.setdefault('ledger', {})
        L['url'] = v('l_url').strip() or 'https://alexledger.netlify.app'
        if v('l_user').strip():
            L['user'] = v('l_user').strip()
        if v('l_pw'):
            L['password'] = v('l_pw')
        # 信箱
        S['mailboxes'] = self.MB
        if v('my_name').strip() or 'my_name' in S:
            S['my_name'] = v('my_name').strip()
        # 寄月報
        M = S.setdefault('mail', {})
        M['from'] = v('m_from').strip(); M['to'] = v('m_to').strip() or M['from']
        if v('m_pw'):
            M['app_password'] = v('m_pw').replace(' ', '')
        try:
            M['mail_day'] = max(1, min(28, int(v('m_day'))))
        except ValueError:
            M['mail_day'] = 12
        M['enabled'] = bool(self.vars['m_on'].get()) and bool(M['from']) and bool(M.get('app_password'))
        # 線上版
        W = S.setdefault('web', {})
        if v('w_token').strip():
            W['token'] = v('w_token').strip()
        if wp:
            W['password'] = wp
        W['repo'] = v('w_repo').strip() or 'lifeledger'
        W['enabled'] = bool(self.vars['w_on'].get()) and bool(W.get('token')) and len(str(W.get('password') or '')) >= 8
        # 進階
        S['bills'] = self.bills
        # 英文名字中間有空白（例如 WANG XIAO MEI），只用「、」逗號、分號、換行分開
        S['spouse_names'] = [x.strip() for x in re.split(r'[、,，;；\n]+', v('spouse')) if x.strip()]
        S['salary_payer'] = v('salary').strip()
        os.makedirs(os.path.dirname(self.PP), exist_ok=True)
        json.dump(self.PW, open(self.PP, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
        json.dump(S, open(self.SP, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
        if not quiet:
            self.app.say('✓ 設定已存好（只存在這台電腦）')
        return True

    def save_close(self):
        if self.vars['m_on'].get() and not (self.vars['m_from'].get().strip() and (self.vars['m_pw'].get() or (self.S.get('mail') or {}).get('app_password'))):
            self.show(3)
            if not messagebox.askyesno('設定', '「每月寄月報」還沒填寄件 Gmail 或應用程式密碼，會先不開啟。還是要儲存嗎？', parent=self.w):
                return
        if self.save():
            self.w.destroy()
            if self.first:
                if messagebox.askyesno('LifeLedger', '設定好了 🎉 要現在更新一次月報嗎？（第一次會比較久）'):
                    self.app.run_report()


class MailDialog:
    """新增／修改一個收帳單的信箱"""

    def __init__(self, st, mb, idx):
        self.st, self.idx = st, idx
        mb = mb or {}
        w = self.w = tk.Toplevel(st.w, bg=T['bg']); w.title('信箱' if mb else '新增信箱'); w.geometry('560x440'); w.resizable(False, False); w.transient(st.w); w.grab_set()
        f = tk.Frame(w, bg=T['bg'], padx=20, pady=16); f.pack(fill='both', expand=True)
        tk.Label(f, text='信箱種類', bg=T['bg'], fg=T['ink'], font=(FONT, 11, 'bold')).pack(anchor='w')
        guess = 'outlook' if mb.get('type') == 'outlook' else ('gmail' if 'gmail' in str(mb.get('user', '')) else 'yahoo' if 'yahoo' in str(mb.get('user', ''))
                                                              else 'hinet' if 'hinet' in str(mb.get('user', '')) else ('imap' if mb.get('host') else 'gmail'))
        self.kind = tk.StringVar(value=guess)
        rf = tk.Frame(f, bg=T['bg']); rf.pack(anchor='w', pady=4)
        for i, (k, name, _, _) in enumerate(MAIL_TYPES):
            ttk.Radiobutton(rf, text=name, value=k, variable=self.kind, command=self.refresh).grid(row=i // 3, column=i % 3, sticky='w', padx=(0, 14), pady=2)
        self.tip = tk.Label(f, text='', bg=T['tip'], fg=T['ink'], font=(FONT, 9), wraplength=500, justify='left', padx=10, pady=8); self.tip.pack(fill='x', pady=6)
        self.lnk = tk.Label(f, text='', bg=T['bg'], fg=T['btn_ink'], font=(FONT, 9, 'underline'), cursor='hand2'); self.lnk.pack(anchor='w')
        self.form = tk.Frame(f, bg=T['bg']); self.form.pack(fill='x', pady=6)
        self.v = {k: tk.StringVar(value=str(mb.get(k, ''))) for k in ('user', 'password', 'host', 'port', 'account')}
        if not self.v['port'].get():
            self.v['port'].set('993')
        self.had_pw = bool(mb.get('password'))
        bf = tk.Frame(f, bg=T['bg']); bf.pack(side='bottom', fill='x')
        ttk.Button(bf, text='確定', command=self.ok).pack(side='right')
        ttk.Button(bf, text='取消', command=w.destroy).pack(side='right', padx=6)
        self.refresh()

    def row(self, label, key, secret=False, hint=''):
        r = tk.Frame(self.form, bg=T['bg']); r.pack(fill='x', pady=3)
        tk.Label(r, text=label, bg=T['bg'], fg=T['ink'], font=(FONT, 10), width=12, anchor='w').pack(side='left')
        e = ttk.Entry(r, textvariable=self.v[key], show='•' if secret else '', width=32, font=(FONT, 10)); e.pack(side='left')
        if hint:
            tk.Label(r, text=hint, bg=T['bg'], fg='#2E9E5B', font=(FONT, 9)).pack(side='left', padx=4)

    def refresh(self):
        k = self.kind.get()
        _, name, tip, url = next(m for m in MAIL_TYPES if m[0] == k)
        self.tip.config(text=tip)
        self.lnk.config(text=('🔗 打開說明網頁' if url else '')); self.lnk.bind('<Button-1>', lambda e: url and webbrowser.open(url))
        for c in self.form.winfo_children():
            c.destroy()
        if k == 'outlook':
            self.row('只收這個信箱', 'account')
            tk.Label(self.form, text='填信箱地址的一部分就好；空白＝Outlook 裡全部信箱都收。', bg=T['bg'], fg=T['ink2'], font=(FONT, 9)).pack(anchor='w')
            return
        self.row('信箱地址', 'user')
        self.row('應用程式密碼' if k in ('gmail', 'yahoo') else '密碼', 'password', secret=True, hint='已設定 ✓' if self.had_pw else '')
        if self.had_pw:
            tk.Label(self.form, text='密碼欄空白＝沿用原本的密碼。', bg=T['bg'], fg=T['ink2'], font=(FONT, 9)).pack(anchor='w')
        if k == 'imap':
            self.row('IMAP 主機', 'host'); self.row('連接埠', 'port')

    def ok(self):
        k = self.kind.get(); v = {x: self.v[x].get().strip() for x in self.v}
        old = self.st.MB[self.idx] if self.idx is not None else {}
        if k == 'outlook':
            mb = {'type': 'outlook', 'name': 'Outlook' + (f'（{v["account"]}）' if v['account'] else ''), 'account': v['account']}
        else:
            if not v['user']:
                messagebox.showinfo('信箱', '請填信箱地址', parent=self.w); return
            user = v['user'] + ('@ms1.hinet.net' if k == 'hinet' and '@' not in v['user'] else '')
            pw = (v['password'].replace(' ', '') if k in ('gmail', 'yahoo') else v['password']) or old.get('password', '')
            if not pw:
                messagebox.showinfo('信箱', '請填密碼', parent=self.w); return
            mb = {'type': 'imap', 'name': user, 'user': user, 'password': pw}
            if k == 'imap':
                if not v['host']:
                    messagebox.showinfo('信箱', '請填 IMAP 主機', parent=self.w); return
                mb['host'] = v['host']; mb['port'] = int(v['port']) if v['port'].isdigit() else 993
        MB = self.st.MB
        if self.idx is not None:
            MB[self.idx] = mb
        else:   # 同一個信箱只留一個（跟原本的設定精靈一樣）
            MB[:] = [b for b in MB if not (b.get('type') == mb['type'] and (b.get('user') or b.get('account')) == (mb.get('user') or mb.get('account')))]
            MB.append(mb)
        self.st.refresh_mb(); self.w.destroy()


if __name__ == '__main__':
    root = tk.Tk()
    App(root)
    root.mainloop()
