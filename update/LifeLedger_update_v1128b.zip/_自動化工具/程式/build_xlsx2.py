import json, collections, re, os
from datetime import date
import datetime as _dt
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import ColorScaleRule, DataBarRule, CellIsRule, FormulaRule
from openpyxl.chart import BarChart, Reference
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.formatting.formatting import ConditionalFormattingList as _CFL
_cf_add = _CFL.add


def _safe_cf_add(self, rng, rule):   # 資料很少（新使用者、只有一兩期帳單）時，空的範圍（例如 H20:H19）直接略過
    try:
        if all(int(re.sub(r'\D', '', a.split(':')[0]) or 0) <= int(re.sub(r'\D', '', a.split(':')[-1]) or 0) for a in str(rng).split()):
            return _cf_add(self, rng, rule)
    except (TypeError, ValueError):
        pass


_CFL.add = _safe_cf_add

os.chdir(os.path.dirname(os.path.abspath(__file__)))
import banks as _bk
RA = json.load(open('rows.json'))
RA = sorted(RA + _bk.prov_rows(RA), key=lambda r: (r['date'], r['bank']))   # 全部交易（含家人附卡、代付）＋隨手記暫列（帳單還沒到，和月報、生活帳本一致）
R = [r for r in RA if _bk.mine(r)]                                                # 我的消費（分析用）
PTS = [p for p in json.load(open('points.json')) if p[2]]
RECUR = json.load(open('recur.json'))
BANKS = _bk.order(RA)          # 有幾家銀行就列幾家
NB = len(BANKS)
_C7 = {'台新': '2A78D6', '永豐': 'EB6834', '玉山': '1BAF7A', '聯邦': 'EDA100', '中信': 'E87BA4', '星展': '008300', '國泰': '4A3AA7'}
_T7 = {'台新': 'DCE9F8', '永豐': 'FCE3D8', '玉山': 'D6F2E7', '聯邦': 'FCEFCC', '中信': 'FAE3EC', '星展': 'D3EBD3', '國泰': 'E1DDF3'}
def _tint(h):
    return ''.join(f'{round(int(h[i:i + 2], 16) * .18 + 255 * .82):02X}' for i in (0, 2, 4))
BCOL = [_C7.get(b) or _bk.color(i)[1:].upper() for i, b in enumerate(BANKS)]
BTINT = [_T7.get(b) or _tint(BCOL[i]) for i, b in enumerate(BANKS)]
CATS = ['旅遊住宿', '網購', '保險', '稅費', '餐飲', '醫療', '教育', '交通停車加油', '汽車保養', '超市便利商店', '生活繳費', '百貨購物', '運動休閒', '年費手續費', '其他']
import subcat as _scf
for _r in RA:   # 報表用細分類：交通・停車、旅遊・住宿、網購・3C家電…（回饋計算仍用原本大分類）
    _r['category'] = _scf.fine(_r)
RA = _scf.spread(RA)   # 自己分攤的大筆：分到各月
R = [r for r in RA if _bk.mine(r)]
CATS = _scf.expand_cats(CATS, {r['category'] for r in RA})
NC = len(CATS)
HC0 = 10 + NC   # 消費分類頁「分類 × 銀行」表的起始列
REB = '回饋折抵'
CFG = json.load(open('config.json'))
CY, CM = CFG['cur_year'], CFG['cur_month']; PY = CY - 1
LASTM = CFG['last_month']; START = CFG['start']; SY = int(START[:4])
LBL_PREV = f'{PY} 全年'; LBL_CUR = f'{CY} 1–{CM} 月'; LBL_PSAME = f'{PY} 1–{CM} 月'
MONTHS = []
_y, _m = int(START[:4]), int(START[5:])
while f'{_y}-{_m:02d}' <= LASTM:
    MONTHS.append(f'{_y}-{_m:02d}'); _m += 1
    if _m > 12: _y += 1; _m = 1
NALL = sum(1 for m in MONTHS if m <= f'{CY}-{CM:02d}')
PARTIAL = [m for m in MONTHS if m > f'{CY}-{CM:02d}']
S_ALL = int(START[:4]) * 100 + int(START[5:]); E_ALL = int(LASTM[:4]) * 100 + int(LASTM[5:])
MAXR = 6000  # ledger rows covered by formulas (room to append)

FN = 'Microsoft JhengHei'; MONO = 'Microsoft JhengHei'
NAVY = '0E2035'; NAVY2 = '16304D'; GOLD = 'C9A45C'; HINK = 'F3F6FA'; HINK2 = 'A9B8CB'
INK = '121821'; INK2 = '465061'; MUTED = '7B8494'; LINE = 'D9DFE6'; LINE2 = 'E9EDF1'; BG = 'EEF1F4'; ZEBRA = 'F6F8FA'
POS = 'B3372B'; NEG = '17784B'; BLUE = '1D5C8F'
NUM = '#,##0;[Color10]-#,##0;"–"'
NUMS = '#,##0;-#,##0;"–"'
PCT = '0.0%;-0.0%;"–"'
DPCT = '[Red]"▲"0.0%;[Color10]"▼"0.0%;"–"'   # 文字一律加引號，Excel 才不會判定格式錯誤


def F(size=10, bold=False, color=INK, name=FN, italic=False):
    return Font(name=name, size=size, bold=bold, color=color, italic=italic)


def fill(c):
    return PatternFill('solid', fgColor=c)


thin = Side(style='thin', color=LINE)
hair = Side(style='thin', color=LINE2)
wb = Workbook()


def paint(ws, r1, r2, c1, c2, color):
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            ws.cell(r, c).fill = fill(color)


def setup(ws, widths, bg=BG):
    ws.sheet_view.showGridLines = False
    ws.sheet_view.zoomScale = 100
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[L(i)].width = w
    ws.sheet_properties.outlinePr.summaryBelow = False


def chapter(ws, row, c1, c2, num, title, note=''):
    ws.cell(row, c1, num).font = F(10, color=MUTED, name=MONO)
    ws.cell(row, c1 + 1, title).font = F(18, True, INK)
    if note:
        ws.cell(row, c2, note).font = F(9.5, color=INK2)
        ws.cell(row, c2).alignment = Alignment(horizontal='right', vertical='bottom')
    ws.row_dimensions[row].height = 32
    for c in range(c1, c2 + 1):
        ws.cell(row, c).border = Border(bottom=Side(style='medium', color=INK))


def card_bg(ws, r1, r2, c1, c2):
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            ws.cell(r, c).fill = fill('FFFFFF')
    for c in range(c1, c2 + 1):
        ws.cell(r1, c).border = Border(top=thin, left=thin if c == c1 else None, right=thin if c == c2 else None)
        ws.cell(r2, c).border = Border(bottom=thin, left=thin if c == c1 else None, right=thin if c == c2 else None)
    for r in range(r1 + 1, r2):
        ws.cell(r, c1).border = Border(left=thin)
        ws.cell(r, c2).border = Border(right=thin)


def thead(ws, row, c1, labels, aligns=None):
    for i, t in enumerate(labels):
        c = ws.cell(row, c1 + i, t)
        c.font = F(9, color=MUTED)
        c.fill = fill('FFFFFF')
        c.border = Border(bottom=thin)
        c.alignment = Alignment(horizontal=(aligns[i] if aligns else ('left' if i == 0 else 'right')), vertical='center')
    ws.row_dimensions[row].height = 22


def trow(ws, row, c1, c2, nums=(), pcts=(), dp=(), mono=True):
    for c in range(c1, c2 + 1):
        cell = ws.cell(row, c)
        cell.fill = fill('FFFFFF')
        cell.border = Border(bottom=hair)
        cell.font = F(10)
        cell.alignment = Alignment(vertical='center')
        if c in nums:
            cell.number_format = NUM; cell.font = F(10, name=MONO); cell.alignment = Alignment(horizontal='right', vertical='center')
        if c in pcts:
            cell.number_format = PCT; cell.font = F(9.5, color=MUTED, name=MONO); cell.alignment = Alignment(horizontal='right', vertical='center')
        if c in dp:
            cell.number_format = DPCT; cell.font = F(9.5, True, name=MONO); cell.alignment = Alignment(horizontal='right', vertical='center')
    ws.row_dimensions[row].height = 21


def ttotal(ws, row, c1, c2):
    for c in range(c1, c2 + 1):
        cell = ws.cell(row, c)
        cell.fill = fill('FFFFFF')
        cell.font = Font(name=cell.font.name if cell.font else FN, size=10, bold=True, color=INK)
        cell.border = Border(top=Side(style='medium', color=INK))
    ws.row_dimensions[row].height = 23


def bankcell(ws, r, c, i):
    cell = ws.cell(r, c, '● ' + BANKS[i]) if isinstance(i, int) else ws.cell(r, c)
    cell.font = F(10, True, BCOL[i])



from cards import CARDINFO, last4, dispname

# ===================== 交易明細 =====================
tx = wb.active; tx.title = '交易明細'
TXR = sorted(RA, key=lambda r: (r['date'], r['stmt'], r['bank']), reverse=True)   # 明細：新 → 舊
setup(tx, [13, 7, 10, 9, 8, 9, 34, 24, 36, 13, 13, 16, 9, 13])
cols = ['日期', '年', '月份', '月序', '銀行', '末四碼', '卡片', '商家', '帳單說明', '分類', '金額', '海外地區', '付款方式', '帳單日']
tx.append(cols)
for r in TXR:
    y, m, d = map(int, r['date'].split('-'))
    sy, sm, sd = map(int, r['stmt'].split('-')) if r['stmt'] else (0, 0, 0)   # 暫列：帳單還沒到，沒有帳單日
    rr = tx.max_row + 1
    tx.append([date(y, m, d), r['date'][:4], r['date'][:7], y * 100 + m, r['bank'], last4(r), f'=IFERROR(INDEX(卡片清單!$I$5:$I$80,MATCH(E{rr}&"|"&F{rr},卡片清單!$J$5:$J$80,0)),"帳戶回饋／調整")', r['merchant'],
               r['desc'] if r['desc'] != r['merchant'] else '', r['category'], r['amount'],
               r['country'] or ('其他海外' if r['foreign'] else ''), '暫列（帳單還沒到）' if r.get('prov') else ('分期' if r['installment'] else '一般'), date(sy, sm, sd) if sy else None])
N = len(RA) + 1
for c in tx[1]:
    c.font = F(10, True, 'FFFFFF'); c.fill = fill(NAVY); c.alignment = Alignment(horizontal='center', vertical='center')
tx.row_dimensions[1].height = 26
for row in tx.iter_rows(min_row=2, max_row=N):
    for c in row:
        c.font = F(10)
    row[0].number_format = 'yyyy/mm/dd'; row[13].number_format = 'yyyy/mm/dd'
    row[10].number_format = NUM
    row[5].number_format = '@'; row[5].font = F(9.5, color=MUTED)
    row[3].font = F(9, color=MUTED, name=MONO)
    bi = BANKS.index(row[4].value); row[4].font = F(10, True, BCOL[bi])
t = Table(displayName='Ledger', ref=f'A1:U{N}')
t.tableStyleInfo = TableStyleInfo(name='TableStyleLight1', showRowStripes=True)
tx.add_table(t)
tx.freeze_panes = 'A2'
# 歸屬（依卡片清單）、代付（自己勾）、識別碼（隱藏，讓勾選跨月保留）
from banks import txkey as _txkey
tx['R1'] = '歸屬'; tx['S1'] = '代付'; tx['T1'] = 'key'; tx['U1'] = '子分類'
tx.column_dimensions['U'].width = 14
for c in ('R1', 'S1', 'T1', 'U1'):
    tx[c].font = F(10, True, 'FFFFFF'); tx[c].fill = fill(NAVY); tx[c].alignment = Alignment(horizontal='center', vertical='center')
tx.column_dimensions['R'].width = 7; tx.column_dimensions['S'].width = 7; tx.column_dimensions['T'].hidden = True
_dvp = DataValidation(type='list', formula1='"✔,25%,50%,75%"', allow_blank=True, showErrorMessage=False,
                      promptTitle='代付', prompt='全部幫別人刷的選 ✔；只代墊一部分就打比例（例如 50%），下次更新會拆成自付和代墊兩筆')
tx.add_data_validation(_dvp); _dvp.add(f'S2:S{MAXR}')
HINTFILL = fill('FFE3B3')
for i, r in enumerate(TXR):
    rr = i + 2
    tx.cell(rr, 18, f'=IFERROR(INDEX(卡片清單!$P$5:$P$120,MATCH(E{rr}&"|"&F{rr},卡片清單!$J$5:$J$120,0)),"我")').font = F(9.5, color=INK2)
    tx.cell(rr, 18).alignment = Alignment(horizontal='center')
    c = tx.cell(rr, 19, '✔' if r.get('paid') else (f"{r['paid_ratio'] * 100:.0f}%" if r.get('paid_ratio') else None)); c.font = F(11, True, POS); c.alignment = Alignment(horizontal='center')
    if r.get('hint'):
        c.fill = HINTFILL
        from openpyxl.comments import Comment
        c.comment = Comment(f"可能是代付？{r['hint']}。是的話選 ✔", 'LifeLedger')
    tx.cell(rr, 20, r['key']).font = F(8, color=MUTED)
    if r.get('sub') or r.get('sub_items'):   # 子分類；沒有子分類的（例如餐飲）就放發票上的品項
        _u = tx.cell(rr, 21, r.get('sub') or ('🧾 ' + r['sub_items'][:24])); _u.font = F(9.5, color=INK2)
        if r.get('sub_items'):
            from openpyxl.comments import Comment as _Cm
            _u.comment = _Cm('發票品名：' + r['sub_items'], 'LifeLedger')
tx.conditional_formatting.add(f'A2:N{MAXR}', FormulaRule(formula=['$S2="✔"'], font=Font(color='9AA3B0', strike=True)))
tx.conditional_formatting.add(f'R2:R{MAXR}', CellIsRule(operator='equal', formula=['"家人"'], font=Font(name=FN, bold=True, color='A86A00'), fill=fill('FBF0DA')))
tx['O1'] = '篩選'; tx['O1'].font = F(9, True, 'FFFFFF'); tx['O1'].fill = fill(NAVY)
for rr in range(2, N + 1):
    tx.cell(rr, 15, f'=IF(AND(OR(F_B="*",E{rr}=F_B),OR(F_K="*",G{rr}=F_K),OR(F_P="*",M{rr}=F_P),R{rr}="我",S{rr}<>"✔"),1,0)').font = F(8, color=MUTED)
    tx.cell(rr, 16, f'=IF(AND(O{rr}=1,D{rr}>=P_S,D{rr}<=P_E,J{rr}<>"回饋折抵"),K{rr},0)').font = F(8, color=MUTED)
    tx.cell(rr, 17, f'=IF(P{rr}>0,1,0)').font = F(8, color=MUTED)
tx['Q1'] = '期間筆'; tx['Q1'].font = F(9, True, 'FFFFFF'); tx['Q1'].fill = fill(NAVY); tx.column_dimensions['Q'].hidden = True
tx['P1'] = '期間金額'; tx['P1'].font = F(9, True, 'FFFFFF'); tx['P1'].fill = fill(NAVY)
tx.column_dimensions['O'].hidden = True; tx.column_dimensions['P'].hidden = True


def rng(col):
    return f"交易明細!${col}$2:${col}${MAXR}"


DT, YR, MO, MI, BK, CD, MR, DS, CT, AM, CTY, PAY = (rng(c) for c in 'ABCDEGHIJKLM')

# ===================== 點數 =====================
pt = wb.create_sheet('點數')
setup(pt, [8, 9, 12, 12, 40])
pt.append(['銀行', '月序', '新增點數', '點數種類', '說明'])
for b, d, p, u in PTS:
    pt.append([b, int(d[:4]) * 100 + int(d[5:7]), p, u, '帳單日 ' + d])
NP = len(PTS) + 1
for c in pt[1]:
    c.font = F(10, True, 'FFFFFF'); c.fill = fill(NAVY)
for row in pt.iter_rows(min_row=2, max_row=NP):
    for c in row:
        c.font = F(10)
    row[2].font = F(10, color='0000FF', name=MONO); row[2].number_format = NUMS
pt.cell(NP + 2, 1, '藍字為各期帳單抄錄的新增點數（台新Point、玉山 e point、星展現金積點、國泰小樹點／蝦幣、永豐豐點、聯邦紅利）。1 點以 1 元估算，聯邦紅利不換算。').font = F(9, color=MUTED)
PB, PM, PP, PU = (f"點數!${c}$2:${c}$500" for c in 'ABCD')

# ===================== 計算 (helpers) =====================
hp = wb.create_sheet('計算')
setup(hp, [22, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 12, 14])
hp['A1'] = '篩選設定（由「總覽」的選單決定）'; hp['A1'].font = F(11, True)
# lists for dropdowns
hp['N1'] = '月份清單'; hp['O1'] = '銀行選單'; hp['P1'] = '卡片選單'; hp['Q1'] = '付款選單'; hp['R1'] = '銀行清單'; hp['S1'] = '分類清單'; hp['T1'] = '卡片名單'
for i, m in enumerate(MONTHS):
    hp.cell(2 + i, 14, m)
for i, b in enumerate(['全部銀行'] + BANKS):   # 銀行數不固定
    hp.cell(2 + i, 15, b)
for i, b in enumerate(BANKS):
    hp.cell(2 + i, 18, b)
for i, c in enumerate(CATS):
    hp.cell(2 + i, 19, c)
for i, p in enumerate(['全部', '一般', '分期']):
    hp.cell(2 + i, 17, p)
NCARD = len([k for k in set((r['bank'], last4(r)) for r in RA) if k[1] != '—'])
hp.cell(2, 16, '全部卡片')
for i in range(NCARD):
    hp.cell(3 + i, 16, f'=卡片清單!$I${5 + i}')
    hp.cell(2 + i, 20, f'=卡片清單!$I${5 + i}')
for nm, rg in [('月份清單', f'計算!$N$2:$N${1 + len(MONTHS)}'), ('銀行選單', f'計算!$O$2:$O${2 + NB}'), ('卡片選單', f'計算!$P$2:$P${2 + NCARD}'),
               ('付款選單', '計算!$Q$2:$Q$4'), ('銀行清單', f'計算!$R$2:$R${1 + NB}'), ('分類清單', f'計算!$S$2:$S${1 + len(CATS)}'), ('卡片名單', f'計算!$T$2:$T${1 + NCARD}')]:
    wb.defined_names[nm] = DefinedName(nm, attr_text=rg)
hp['A8'] = '目前篩選'; hp['B8'] = '=IF(B9=B10,總覽!$D$6,總覽!$D$6&" – "&總覽!$F$6)&IF(總覽!$H$6<>"全部銀行","・"&總覽!$H$6,"")&IF(總覽!$J$6<>"全部卡片","・"&總覽!$J$6,"")&IF(總覽!$M$6<>"全部","・"&總覽!$M$6&"付款","")'
hp['A9'] = '起始月序'; hp['B9'] = '=MIN(VALUE(SUBSTITUTE(總覽!$D$6,"-","")),VALUE(SUBSTITUTE(總覽!$F$6,"-","")))'
hp['A10'] = '結束月序'; hp['B10'] = '=MAX(VALUE(SUBSTITUTE(總覽!$D$6,"-","")),VALUE(SUBSTITUTE(總覽!$F$6,"-","")))'
hp['A11'] = '月數'; hp['B11'] = '=(INT(B10/100)*12+MOD(B10,100))-(INT(B9/100)*12+MOD(B9,100))+1'
hp['A12'] = '有去年同期'; hp['B12'] = f'=B9-100>={S_ALL}'
hp['A13'] = '銀行條件'; hp['B13'] = '=IF(總覽!$H$6="全部銀行","*",總覽!$H$6)'
hp['A14'] = '卡片條件'; hp['B14'] = '=IF(總覽!$J$6="全部卡片","*",總覽!$J$6)'
hp['A15'] = '付款條件'; hp['B15'] = '=IF(總覽!$M$6="全部","*",總覽!$M$6)'
for nm, cell in [('P_S', 'B9'), ('P_E', 'B10'), ('P_N', 'B11'), ('P_YOY', 'B12'), ('F_B', 'B13'), ('F_K', 'B14'), ('F_P', 'B15')]:
    wb.defined_names[nm] = DefinedName(nm, attr_text=f'計算!${cell[0]}${cell[1:]}')
FLT = f'{rng("O")},1'
PER = f'{MI},">="&P_S,{MI},"<="&P_E,' + FLT
PRV = f'{MI},">="&(P_S-100),{MI},"<="&(P_E-100),' + FLT
MINE = f'{rng("R")},"我",{rng("S")},"<>✔"'   # 只算你的消費：不含家人附卡、代付（勾 ✔）
SP0 = f'{CT},"<>{REB}"'
SP = SP0 + ',' + MINE


def S(*crit, prev=False):
    return f'SUMIFS({AM},{PRV if prev else PER}' + ''.join(',' + c for c in crit) + ')'


def C(*crit):
    return f'COUNTIFS({PER}' + ''.join(',' + c for c in crit) + ')'


# merchant helper
mt = collections.defaultdict(float); mcat = {}; mbanks = collections.defaultdict(set)
for r in R:
    if r['category'] == REB:
        continue
    mt[r['merchant']] += r['amount']; mcat.setdefault(r['merchant'], r['category']); mbanks[r['merchant']].add(r['bank'])
merchs = sorted(mt, key=lambda k: -mt[k])
H0 = 20
hp.cell(H0 - 1, 1, '商家彙整（期間內，含微小序號以排名）').font = F(11, True)
hdr = ['商家', '期間金額+序', '筆數', '分類', '刷卡銀行'] + [f'{b}' for b in BANKS]
for j, h in enumerate(hdr):
    hp.cell(H0, 1 + j, h).font = F(10, True)
def crit(m):
    return '"' + m.replace('~', '~~').replace('*', '~*').replace('?', '~?').replace('"', '""') + '"'


for i, m in enumerate(merchs):
    r = H0 + 1 + i
    hp.cell(r, 1, m)
    hp.cell(r, 2, f'=SUMIFS({rng("P")},{MR},{crit(m)})+ROW()/1E7')
    hp.cell(r, 3, f'=SUMIFS({rng("Q")},{MR},{crit(m)})')
    hp.cell(r, 4, mcat[m])
    hp.cell(r, 5, '・'.join(b for b in BANKS if b in mbanks[m]))
    for j, b in enumerate(BANKS):
        hp.cell(r, 6 + j, f'=SUMIFS({rng("P")},{MR},{crit(m)},{BK},"{b}")+ROW()/1E7')
HM1, HM2 = H0 + 1, H0 + len(merchs)

# card x category helper
cards = []
for r in RA:
    k = (r['bank'], last4(r))
    if k not in cards and k[1] != '—':
        cards.append(k)
from cards import owner as _own_of, STATUS as _CST
cards.sort(key=lambda k: (_own_of(*k) != '我', _CST.get(k) == '已停卡', BANKS.index(k[0]) if k[0] in BANKS else 99, k[1]))   # 我的卡 → 家人卡 → 停卡；同組依銀行
CARDROW = {k: 5 + i for i, k in enumerate(cards)}  # row in 卡片清單
C0 = HM2 + 4
hp.cell(C0 - 1, 1, '卡片 × 分類（期間內）').font = F(11, True)
hp.cell(C0, 1, '卡片'); hp.cell(C0, 2, '銀行')
for j, c in enumerate(CATS):
    hp.cell(C0, 3 + j, c)
for i, (b, n) in enumerate(cards):
    r = C0 + 1 + i
    hp.cell(r, 1, f'=卡片清單!$I${CARDROW[(b, n)]}'); hp.cell(r, 2, b)
    for j in range(len(CATS)):
        hp.cell(r, 3 + j, f'={S(f"{BK},$B{r}", f"{CD},$A{r}", f"{CT},{L(3 + j)}${C0}")}')
HC1 = C0 + 1
hp.sheet_state = 'hidden'


# ===================== 卡片清單 =====================
kl = wb.create_sheet('卡片清單')
setup(kl, [2.5, 9, 8, 30, 8, 11, 22, 2, 38, 12])
thead(kl, 4, 2, ['銀行', '末四碼', '卡片名稱（可修改）', '正／附卡', '持卡人', '資料來源', '', '報表上顯示為', 'key'], ['left'] * 9)
for k in cards:
    r = CARDROW[k]
    b, l4 = k
    nm, role, holder, src = CARDINFO.get(k, (f'{b}卡（卡名待確認）', '—', '', '未知'))
    kl.cell(r, 2, b); kl.cell(r, 3, l4); kl.cell(r, 4, nm); kl.cell(r, 5, role); kl.cell(r, 6, holder); kl.cell(r, 7, src)
    kl.cell(r, 9, f'=D{r}&IF(E{r}="附卡","（附卡"&IF(F{r}<>"","・"&F{r},"")&"）","")&IF(ISNUMBER(--C{r})," ·"&C{r},"")')
    kl.cell(r, 10, f'=B{r}&"|"&C{r}')
    trow(kl, r, 2, 10)
    kl.cell(r, 2).font = F(10, True, BCOL[BANKS.index(b)])
    kl.cell(r, 3).number_format = '@'; kl.cell(r, 3).font = F(10, color=INK2)
    kl.cell(r, 4).font = F(10, True, '0000FF')
    kl.cell(r, 7).font = F(8.5, color=MUTED)
    kl.cell(r, 9).font = F(9.5, color=INK2)
    kl.cell(r, 5).alignment = Alignment(horizontal='center', vertical='center')
    if '待確認' in nm or src.startswith('推測'):
        kl.cell(r, 4).fill = fill('FFF6D6')
kl.column_dimensions['J'].hidden = True
# 卡片封面＋卡號／有效期限／安全碼／狀態（取自信用卡管理總表；照片在 _自動化工具/設定/卡片照片/銀行_末四碼.jpg）
# 這些只放進本機 Excel，不會進網頁、月報或分享版
from openpyxl.drawing.image import Image as XLImage
from openpyxl.drawing.spreadsheet_drawing import OneCellAnchor, AnchorMarker
from openpyxl.utils.units import pixels_to_EMU
from openpyxl.drawing.xdr import XDRPositiveSize2D
from cards import MASTER, STATUS, ALIAS
_COVERS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '設定', '卡片照片')
for col, w in zip('KLMNOP', [24, 22, 9, 7, 16, 9]):
    kl.column_dimensions[col].width = w
thead(kl, 4, 11, ['卡片封面', '卡號', '有效期限', '安全碼', '狀態', '歸屬'], ['left'] * 6)
from cards import owner as _owner
_dvo = DataValidation(type='list', formula1='"我,家人"', allow_blank=False, promptTitle='歸屬',
                      prompt='「家人」＝這張卡是家人在刷，消費另外列、不算進你的消費')
kl.add_data_validation(_dvo)
_CH = 64
_today = date.today()


def _soon(mmyy):
    try:
        m, y = map(int, mmyy.split('/')); return (2000 + y) * 12 + m - (_today.year * 12 + _today.month) <= 12
    except Exception:
        return False


def _card_extra(r, k, status):
    kl.row_dimensions[r].height = 52 if os.path.exists(os.path.join(_COVERS, '%s_%s.jpg' % ALIAS.get(k, k))) else 28
    for c in range(2, 17):
        kl.cell(r, c).alignment = Alignment(horizontal=kl.cell(r, c).alignment.horizontal, vertical='center', wrap_text=c in (4, 7, 15))
    m = MASTER.get(ALIAS.get(k, k))
    if m:
        kl.cell(r, 12, m['number']).font = F(10, color=INK, name=MONO)
        kl.cell(r, 13, m['expiry']).font = F(10, color=INK, name=MONO)
        kl.cell(r, 14, m['cvv']).font = F(10, color=INK, name=MONO)
        if _soon(m['expiry']):
            kl.cell(r, 13).fill = fill('FFE8CC')
    kl.cell(r, 15, status)
    kl.cell(r, 15).font = F(9.5, True, {'使用中': '17784B', '已停卡': '9AA3B0'}.get(status, 'A86A00'))
    for c in range(11, 17):
        kl.cell(r, c).border = Border(bottom=Side(style='thin', color='E3E8EE'))
    if r <= 4 + len(cards):
        o = kl.cell(r, 16, _owner(*k)); _dvo.add(o.coordinate)
        o.font = F(10, True, 'A86A00' if o.value == '家人' else '17784B'); o.fill = fill('FFF6D6'); o.alignment = Alignment(horizontal='center', vertical='center')
    fimg = os.path.join(_COVERS, '%s_%s.jpg' % ALIAS.get(k, k))
    if os.path.exists(fimg):
        im = XLImage(fimg); w = round(im.width * _CH / im.height); im.width, im.height = w, _CH
        im.anchor = OneCellAnchor(_from=AnchorMarker(col=10, colOff=pixels_to_EMU(6), row=r - 1, rowOff=pixels_to_EMU(3)),
                                  ext=XDRPositiveSize2D(pixels_to_EMU(w), pixels_to_EMU(_CH)))
        kl.add_image(im)
    else:
        kl.cell(r, 11, '—').font = F(9, color=MUTED)


for k in cards:
    st = STATUS.get(k) or ('使用中' if MASTER.get(ALIAS.get(k, k)) else ('—' if k[1] in ('—',) else '總表未列，請確認'))
    _card_extra(CARDROW[k], k, st)
    if st == '已停卡':
        for c in (2, 3, 4, 9):
            kl.cell(CARDROW[k], c).font = F(10, False, '9AA3B0')
        for c in range(2, 17):
            kl.cell(CARDROW[k], c).fill = fill('F4F5F7')
    elif _own_of(*k) == '家人':
        for c in list(range(3, 10)) + list(range(12, 16)):
            kl.cell(CARDROW[k], c).fill = fill('FFF9EC')
# 每月結帳日（從各銀行帳單讀出的實際結帳日；同一家銀行的卡同一天結帳）＋下次結帳、提醒（打開 Excel 依今天自動算）
try:
    from cycles import by_bank as _cyc_by_bank
    _CYC = _cyc_by_bank()
except Exception:
    _CYC = {}
for col, w in zip('QRS', [11, 13, 20]):
    kl.column_dimensions[col].width = w
thead(kl, 4, 17, ['每月結帳日', '下次結帳（約）', '提醒'], ['center', 'center', 'left'])
for k in cards:
    r = CARDROW[k]; cy = _CYC.get(k[0])
    if not cy or _CST.get(k) == '已停卡' or not str(k[1]).isdigit():
        kl.cell(r, 17, '—').font = F(9, color=MUTED); kl.cell(r, 17).alignment = Alignment(horizontal='center', vertical='center')
        continue
    q = kl.cell(r, 17, cy['day']); q.number_format = '"每月 "0" 日"'; q.font = F(10.5, True, NAVY); q.alignment = Alignment(horizontal='center', vertical='center')
    nx = kl.cell(r, 18, f'=IF(DAY(TODAY())<=Q{r},DATE(YEAR(TODAY()),MONTH(TODAY()),Q{r}),DATE(YEAR(TODAY()),MONTH(TODAY())+1,Q{r}))')
    nx.number_format = 'm/d (aaa)'; nx.font = F(10, color=INK); nx.alignment = Alignment(horizontal='center', vertical='center')
    tp = kl.cell(r, 19, f'=IF(R{r}-TODAY()=0,"⚠ 今天結帳，先別刷",IF(R{r}-TODAY()<=3,"⚠ "&(R{r}-TODAY())&" 天後結帳，先別刷",IF(R{r}-TODAY()>=25,"✓ 剛結帳，適合刷","還有 "&(R{r}-TODAY())&" 天")))')
    tp.font = F(9.5, color=INK2); tp.alignment = Alignment(vertical='center')
    for c in (17, 18, 19):
        kl.cell(r, c).border = Border(bottom=Side(style='thin', color='E3E8EE'))
_last = 4 + len(cards)
from openpyxl.formatting.rule import FormulaRule as _FR
kl.conditional_formatting.add(f'S5:S{_last}', _FR(formula=['LEFT(S5,1)="⚠"'], font=Font(bold=True, color='C0392B'), fill=fill('FDECEA')))
kl.conditional_formatting.add(f'S5:S{_last}', _FR(formula=['LEFT(S5,1)="✓"'], font=Font(bold=True, color='17784B'), fill=fill('E8F6EF')))
for r in range(1, 4):
    for c in range(17, 20):
        kl.cell(r, c).fill = fill(NAVY)
# 分組小標（寫在最左邊 A 欄，不影響公式）
_prev = None
for k in cards:
    g = '已停卡' if _CST.get(k) == '已停卡' else ('家人' if _own_of(*k) == '家人' else '我的卡')
    if g != _prev:
        kl.cell(CARDROW[k], 1).border = Border(top=Side(style='medium', color=INK))
        for c in range(2, 17):
            kl.cell(CARDROW[k], c).border = Border(top=Side(style='medium', color={'我的卡': '1BAF7A', '家人': 'C98A00', '已停卡': '9AA3B0'}[g]), bottom=Side(style='thin', color='E3E8EE'))
    _prev = g
_n_me = sum(1 for k in cards if _own_of(*k) == '我' and _CST.get(k) != '已停卡'); _n_fam = sum(1 for k in cards if _own_of(*k) == '家人' and _CST.get(k) != '已停卡')
_n_stop = sum(1 for k in cards if _CST.get(k) == '已停卡')
kl['B3'] = f'共 {len(cards)} 張有消費的卡：我的 {_n_me} 張（綠線）・家人 {_n_fam} 張（黃底）・已停卡 {_n_stop} 張（灰底）。卡名、卡號、效期、安全碼取自「信用卡管理總表」。⚠ 含完整卡號與安全碼：總表只在這台電腦讀取、只寫進這份 Excel，不會上傳到隨手記、網頁或月報；但這份 Excel 放在 OneDrive 時會跟著同步到雲端，請勿外傳或分享這個檔案。'

# 總表有、但帳單還沒出現消費的卡（列在下方，供對照）
_extra = [k for k in sorted(MASTER) if k not in CARDROW]
if _extra:
    r0 = 4 + len(cards) + 6
    kl.cell(r0 - 1, 2, '總表有、帳單尚無消費的卡').font = F(11, True, INK)
    thead(kl, r0, 2, ['銀行', '末四碼', '卡片名稱', '正／附卡', '持卡人', '說明'], ['left'] * 6)
    thead(kl, r0, 11, ['卡片封面', '卡號', '有效期限', '安全碼', '狀態'], ['left'] * 5)
    for i, k in enumerate(_extra):
        r = r0 + 1 + i; m = MASTER[k]
        for c, v in zip(range(2, 8), [k[0], k[1], m['name'], m['role'], m['holder'] or m['holder_tag'], '銀行帳單尚未匯入或近期未使用' if k[0] in BANKS else 'LifeLedger 還沒有這家銀行的消費（帳單放進對應資料夾就會自動加入）']):
            kl.cell(r, c, v).font = F(10, c == 4, INK2 if c != 4 else INK)
        kl.cell(r, 3).number_format = '@'
        _card_extra(r, k, '使用中')
    KL_EXTRA_END = r0 + len(_extra)
KL_END = 4 + len(cards)
kl.cell(KL_END + 2, 2, '總表有的卡以總表為準；總表沒有的卡（判斷依據不是「信用卡管理總表」）可直接改藍字卡名。橘底有效期限＝一年內到期；灰字＝已停卡。').font = F(9.5, color=INK2)
kl.cell(KL_END + 3, 2, '「歸屬」選「家人」的卡（預設：附卡），消費在各分析頁不算進你的消費，另外列在「代付與家人」。').font = F(9.5, color=INK2)

# ===================== 總覽 =====================
ov = wb.create_sheet('總覽', 0)
setup(ov, [2.5] + [12.5] * 12 + [2.5])
W1, W2 = 1, 14
paint(ov, 1, 19, W1, W2, NAVY)
for r in range(20, 40):
    for c in range(W1, W2 + 1):
        ov.cell(r, c).fill = fill(BG)
ov.row_dimensions[1].height = 14
ov['B2'] = 'LIFELEDGER · 生活總帳'; ov['B2'].font = F(9, True, GOLD, MONO)
ov['B3'] = 'LifeLedger'; ov['B3'].font = Font(name=FN, size=30, bold=True, color=HINK)
ov.row_dimensions[3].height = 48
ov['B4'] = f'生活總帳　｜　{"・".join(BANKS)}　｜　帳單 {START.replace("-", "/")} 起，資料至 {CFG["data_through"]}'; ov['B4'].font = F(10, color=HINK2)
ctl_lab = [('D5', '起始月份'), ('F5', '結束月份'), ('H5', '銀行'), ('J5', '卡片'), ('M5', '付款方式')]
for c, t in ctl_lab:
    ov[c] = t; ov[c].font = F(9, color=HINK2); ov[c].alignment = Alignment(vertical='bottom')
ov['B6'] = '篩選 ▸'; ov['B6'].font = F(10, True, GOLD); ov['B6'].alignment = Alignment(horizontal='left', vertical='center')
ov['E6'] = '至'; ov['E6'].font = F(10, color=HINK2); ov['E6'].alignment = Alignment(horizontal='center', vertical='center')
ov['D6'] = f'{CY}-01'; ov['F6'] = f'{CY}-{CM:02d}'; ov['H6'] = '全部銀行'; ov['J6'] = '全部卡片'; ov['M6'] = '全部'
for c in ('D6', 'F6', 'H6', 'J6', 'M6'):
    ov[c].font = F(10.5, True, NAVY); ov[c].fill = fill(HINK); ov[c].alignment = Alignment(horizontal='center', vertical='center', shrink_to_fit=True)
for c in ('K6', 'L6'):
    ov[c].fill = fill(HINK)
ov.merge_cells('J6:L6')
ov.row_dimensions[5].height = 16; ov.row_dimensions[6].height = 26
for rng_, src in [('D6', '=月份清單'), ('F6', '=月份清單'), ('H6', '=銀行選單'), ('J6', '=卡片選單'), ('M6', '=付款選單')]:
    dv = DataValidation(type='list', formula1=src, allow_blank=False); ov.add_data_validation(dv); dv.add(rng_)
ov['B7'] = '點選黃底格子的下拉選單切換期間、銀行、卡片與付款方式，整本活頁簿會一起更新。'; ov['B7'].font = F(9, color=HINK2)
_PERA = f'{MI},">="&P_S,{MI},"<="&P_E,{SP0}'
ov['J7'] = (f'="不含　家人附卡 NT$ "&TEXT(SUMIFS({AM},{_PERA},{rng("R")},"家人"),"#,##0")'
            f'&"　代付 NT$ "&TEXT(SUMIFS({AM},{_PERA},{rng("R")},"我",{rng("S")},"✔"),"#,##0")&"（見「代付與家人」）"')
ov['J7'].font = F(9, True, GOLD); ov['J7'].alignment = Alignment(horizontal='right')

# KPI tiles: rows 8-11, 6 tiles x 2 cols
TILE_BG = '132A44'
kp = [
    ('刷卡消費總額', f'={S(SP)}', '"NT$ "#,##0', f'=IF(P_YOY,TEXT(B9/{S(SP, prev=True)}-1,"▲0.0%;▼0.0%")&"　去年同期 "&TEXT({S(SP, prev=True)},"#,##0"),計算!$B$8)'),
    ('每月平均', '=B9/P_N', '"NT$ "#,##0', '="以 "&P_N&" 個月計"'),
    ('消費筆數', f'={C(SP, AM + ",\">0\"")}', '#,##0 "筆"', '="平均每筆 NT$ "&TEXT(B9/F9,"#,##0")'),
    ('回饋（現金＋點數）', f'=-{S(f"{CT},\"{REB}\"")}+{S(f"{CT},\"{REB}\"", f"{MR},\"*積點兌換*\"")}+SUMIFS({PP},{PM},">="&P_S,{PM},"<="&P_E,{PU},"<>紅利點數")', '"NT$ "#,##0', '="回饋率 "&TEXT(H9/B9,"0.0%")'),
    ('年費＋海外手續費', f'={S(f"{CT},\"年費手續費\"")}', '"NT$ "#,##0', '="佔總額 "&TEXT(J9/B9,"0.0%")'),
    ('海外消費', f'={S(SP, f"{CT},\"<>年費手續費\"", f"{CTY},\"<>\"")}', '"NT$ "#,##0', '="佔總額 "&TEXT(L9/B9,"0.0%")'),
]
for i, (lab, f_, fmt, sub) in enumerate(kp):
    c1 = 2 + i * 2
    paint(ov, 8, 11, c1, c1 + 1, ' 34A4A'.strip() if False else ('2A3B44' if i == 0 else TILE_BG))
    for r in (8, 9, 10):
        ov.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c1 + 1)
    ov.cell(8, c1, lab).font = F(9.5, color=HINK2)
    v = ov.cell(9, c1, f_); v.number_format = fmt; v.font = Font(name=MONO, size=17, bold=False, color=GOLD if i == 0 else HINK)
    ov.cell(10, c1, sub).font = F(9, color=HINK2)
    for r in (8, 9, 10):
        ov.cell(r, c1).alignment = Alignment(horizontal='left', vertical='center', indent=1, shrink_to_fit=(r == 10))
    for c in (c1, c1 + 1):
        ov.cell(11, c).border = Border(bottom=Side(style='thin', color='2E4560'))
    ov.cell(8, c1).border = Border(left=Side(style='thin', color='2E4560'))
ov.row_dimensions[8].height = 24; ov.row_dimensions[9].height = 32; ov.row_dimensions[10].height = 20; ov.row_dimensions[11].height = 6

# ===================== 月份分析 =====================
mo = wb.create_sheet('月份分析', 1)
TOTC = 3 + NB; MOMC, YOYC, CNTC, BCATC, BIGC, MIC, INC = (TOTC + k for k in range(1, 8)); XC = max(24, INC + 7)
TL, ML_, YL, NL, MIL, INL, XL = L(TOTC), L(MOMC), L(YOYC), L(CNTC), L(MIC), L(INC), L(XC)
setup(mo, [2.5, 10] + [11] * NB + [12, 10, 10, 8, 14, 26, 11, 6, 2.5])
mo['B2'] = '月份分析'; mo['B2'].font = F(22, True, INK)
mo['B3'] = f'依消費日歸月，分期款依入帳月份。灰色月份不在目前分析期間；{"、".join(m.replace("-", "/") for m in PARTIAL) or "無"} 帳單未到齊。'; mo['B3'].font = F(9.5, color=INK2)
mo['N2'] = '="分析期間：" & 計算!$B$8'; mo['N2'].font = F(10, True, BLUE)
chapter(mo, 5, 2, 10 + NB, '01', '逐月 × 銀行', '金額為淨額（已扣退款），不含回饋折抵')
hdrs = ['月份'] + BANKS + ['合計', '較上月', '較去年同月', '筆數', '最大分類', '最大一筆', '月序', '期間']
thead(mo, 6, 2, hdrs, ['left'] + ['right'] * (NB + 5) + ['left', 'left', 'right', 'right'])
for j in range(NB):
    mo.cell(6, 3 + j).font = F(9, True, BCOL[j])
# static per-month biggest purchase (merchant + amount)
big = {}
for m in MONTHS:
    xs = [r for r in R if r['date'][:7] == m and r['category'] != REB]
    b = max(xs, key=lambda r: r['amount']) if xs else None
    big[m] = f"{b['merchant']}　{int(b['amount']):,}" if b else '—'
M1 = 7
ML = M1 + len(MONTHS) - 1
HC = 32 if ML < 31 else ML + 3   # 「月份 × 分類」表的位置：月份多（超過 24 個月）時往下移到月份表下面
HH, HD = HC + 2, HC + 3          # 表頭列、第一個月份那列
for i, m in enumerate(MONTHS):
    r = M1 + i
    mi = int(m[:4]) * 100 + int(m[5:])
    mo.cell(r, 2, m.replace('-', '/') + ('*' if m in PARTIAL else ''))
    mo.cell(r, MIC, mi)
    for j, b in enumerate(BANKS):
        mo.cell(r, 3 + j, f'=SUMIFS({AM},{MI},${MIL}{r},{BK},"{b}",{SP})')
    mo.cell(r, TOTC, f'=SUM(C{r}:{L(2 + NB)}{r})')
    mo.cell(r, MOMC, f'=IF({TL}{r - 1}=0,"",{TL}{r}/{TL}{r - 1}-1)' if i else '')
    mo.cell(r, YOYC, f'={TL}{r}/{TL}{r - 12}-1' if i >= 12 else '')
    mo.cell(r, CNTC, f'=COUNTIFS({MI},${MIL}{r},{SP},{AM},">0")')
    _hc = L(2 + NC)
    mo.cell(r, BCATC, f'=INDEX(月份分析!$C${HH}:${_hc}${HH},MATCH(MAX(C{r + HD - M1}:{_hc}{r + HD - M1}),C{r + HD - M1}:{_hc}{r + HD - M1},0))')
    mo.cell(r, BIGC, big[m])
    mo.cell(r, INC, f'=AND({MIL}{r}>=P_S,{MIL}{r}<=P_E)')
    trow(mo, r, 2, INC, nums=tuple(range(3, TOTC + 1)) + (CNTC,), dp=(MOMC, YOYC))
    mo.cell(r, 2).font = F(10, name=MONO); mo.cell(r, TOTC).font = F(10, True, name=MONO)
    mo.cell(r, BIGC).font = F(9.5, color=INK2); mo.cell(r, MIC).font = F(8, color='B0B7C2', name=MONO); mo.cell(r, INC).font = F(8, color='B0B7C2')
ML = M1 + len(MONTHS) - 1
mo.conditional_formatting.add(f'B{M1}:{L(BIGC)}{ML}', FormulaRule(formula=[f'${INL}{M1}=FALSE'], font=Font(color='B0B7C2'), fill=fill('F7F8FA')))
mo.conditional_formatting.add(f'{TL}{M1}:{TL}{ML}', DataBarRule(start_type='num', start_value=0, end_type='max', color='5B9AD6', showValue=True))
tr = ML + 1
mo.cell(tr, 2, '期間合計')
for c in list(range(3, TOTC + 1)) + [CNTC]:
    mo.cell(tr, c, f'=SUMIFS({L(c)}{M1}:{L(c)}{ML},${INL}${M1}:${INL}${ML},TRUE)')
mo.cell(tr, BCATC, f'="月平均 "&TEXT({TL}{tr}/P_N,"#,##0")')
trow(mo, tr, 2, INC, nums=tuple(range(3, TOTC + 1)) + (CNTC,)); ttotal(mo, tr, 2, INC)
for c in list(range(3, TOTC + 1)) + [CNTC]:
    mo.cell(tr, c).number_format = NUM

# heatmap month x category (rows 33..)
chapter(mo, HC, 2, INC, '02', '月份 × 分類', '顏色越深金額越高；最下面是各年度每個分類的合計')
mo.cell(HH, 2, '月份')
for j, c in enumerate(CATS):
    mo.cell(HH, 3 + j, c)
thead(mo, HH, 2, ['月份'] + CATS)
for i, m in enumerate(MONTHS):
    r = HD + i
    mo.cell(r, 2, m.replace('-', '/'))
    for j in range(len(CATS)):
        mo.cell(r, 3 + j, f'=SUMIFS({AM},{MI},${MIL}{M1 + i},{CT},{L(3 + j)}${HH},{MINE})')
    trow(mo, r, 2, 2 + len(CATS), nums=tuple(range(3, 3 + len(CATS))))
    mo.cell(r, 2).font = F(10, name=MONO)
HL = HD + len(MONTHS) - 1
_TC = 3 + len(CATS)   # 每月合計欄
mo.cell(HH, _TC, '合計'); thead(mo, HH, 2, ['月份'] + CATS + ['合計'])
for r in range(HD, HL + 1):
    mo.cell(r, _TC, f'=SUM(C{r}:{L(_TC - 1)}{r})'); mo.cell(r, _TC).number_format = NUM; mo.cell(r, _TC).font = F(10, True, name=MONO)
# 各年度每個分類的合計（月份 × 分類 下面）
_yrs = sorted({m[:4] for m in MONTHS})
for k, y in enumerate(_yrs):
    r = HL + 1 + k
    idx = [i for i, m in enumerate(MONTHS) if m[:4] == y]
    mo.cell(r, 2, f'{y} 年合計')
    if len(idx) < 12: mo.cell(r, 2).comment = None
    for c in range(3, _TC + 1):
        mo.cell(r, c, f'=SUM({L(c)}{HD + idx[0]}:{L(c)}{HD + idx[-1]})')
    trow(mo, r, 2, _TC, nums=tuple(range(3, _TC + 1))); ttotal(mo, r, 2, _TC)
    for c in range(3, _TC + 1):
        mo.cell(r, c).number_format = NUM
HY = HL + len(_yrs)
mo.conditional_formatting.add(f'C{HD}:{L(2 + len(CATS))}{HL}', ColorScaleRule(start_type='num', start_value=0, start_color='FFFFFF', mid_type='percentile', mid_value=80, mid_color='9EC5F4', end_type='max', end_color='1F5F99'))
mo.conditional_formatting.add(f'B{HD}:B{HL}', FormulaRule(formula=[f'${INL}{M1}=FALSE'], font=Font(color='B0B7C2')))
for c in range(3, 3 + len(CATS)):
    mo.column_dimensions[L(c)].width = max(mo.column_dimensions[L(c)].width or 0, 11)

chapter(mo, HY + 3, 2, INC, '03', '每月刷卡金額（依銀行堆疊）')
ch = BarChart(); ch.type = 'col'; ch.grouping = 'stacked'; ch.overlap = 100; ch.gapWidth = 45
ch.add_data(Reference(mo, min_col=3, max_col=2 + NB, min_row=6, max_row=ML), titles_from_data=True)
ch.set_categories(Reference(mo, min_col=2, min_row=M1, max_row=ML))
for j, s in enumerate(ch.series):
    s.graphicalProperties.solidFill = BCOL[j]; s.graphicalProperties.line.solidFill = 'FFFFFF'
ch.y_axis.numFmt = '#,##0'; ch.y_axis.majorGridlines.spPr = None
ch.height = 10; ch.width = 32; ch.legend.position = 't'
mo.add_chart(ch, f'B{HY + 5}')
mo.freeze_panes = 'C7'

# ===================== 銀行分析 =====================
bk = wb.create_sheet('銀行分析', 2)
setup(bk, [2.5] + [12, 11, 11, 2] * 4 + [2.5])
bk['B2'] = '銀行分析'; bk['B2'].font = F(22, True, INK)
bk['B3'] = '="期間：" & 計算!$B$8 & "　｜　回饋含點數估值，點數兌換的刷卡金不重複計算"'; bk['B3'].font = F(9.5, color=INK2)
order26 = sorted(range(NB), key=lambda i: -sum(r['amount'] for r in R if r['bank'] == BANKS[i] and r['date'][:4] == str(CY) and r['category'] != REB))
TOT = f'{S(SP)}'
for pos, i in enumerate(order26):
    b = BANKS[i]
    row0 = 5 + (pos // 4) * 13
    c1 = 2 + (pos % 4) * 4
    c3 = c1 + 2
    card_bg(bk, row0, row0 + 11, c1, c3)
    paint(bk, row0, row0, c1, c3, BCOL[i]); bk.row_dimensions[row0].height = 6
    bk.cell(row0 + 1, c1, b).font = Font(name=FN, size=16, bold=True, color=INK)
    sh = bk.cell(row0 + 1, c3, f'=IFERROR(B{row0 + 2 - row0 + row0}/1,0)')
    # amount
    amt = bk.cell(row0 + 2, c1, f'={S(f"{BK},\"{b}\"", SP)}')
    amt.number_format = '"NT$ "#,##0'; amt.font = Font(name=MONO, size=15, color=INK)
    bk.merge_cells(start_row=row0 + 2, start_column=c1, end_row=row0 + 2, end_column=c3)
    A = f'{L(c1)}{row0 + 2}'
    sh.value = f'=IFERROR({A}/{TOT},0)'; sh.number_format = '0.0%'; sh.font = F(10, color=MUTED, name=MONO); sh.alignment = Alignment(horizontal='right')
    # share bar row
    bar = bk.cell(row0 + 3, c1, f'={L(c3)}{row0 + 1}')
    bar.number_format = ';;;'; bk.merge_cells(start_row=row0 + 3, start_column=c1, end_row=row0 + 3, end_column=c3)
    bk.conditional_formatting.add(f'{L(c1)}{row0 + 3}', DataBarRule(start_type='num', start_value=0, end_type='num', end_value=1, color=BCOL[i], showValue=False))
    n = f'{C(f"{BK},\"{b}\"", SP, AM + ",\">0\"")}'
    rows = [
        ('筆數', f'={n}', '#,##0" 筆"'),
        ('平均每筆', f'=IFERROR({A}/{n},0)', '#,##0'),
        ('有使用的卡', f'=COUNTIFS(卡別分析!$B$7:$B$160,"{b}",卡別分析!$E$7:$E$160,">0")', '0" 張"'),
        ('主要分類', f'=IF({A}<=0,"–",INDEX(消費分類!$B${HC0 + 3}:$B${HC0 + 2 + NC},MATCH(MAX(消費分類!{L(3 + i)}${HC0 + 3}:{L(3 + i)}${HC0 + 2 + NC}),消費分類!{L(3 + i)}${HC0 + 3}:{L(3 + i)}${HC0 + 2 + NC},0)))', '@'),
        ('最常刷', f'=IF({A}<=0,"–",INDEX(計算!$A${HM1}:$A${HM2},MATCH(MAX(計算!{L(6 + i)}${HM1}:{L(6 + i)}${HM2}),計算!{L(6 + i)}${HM1}:{L(6 + i)}${HM2},0)))', '@'),
        ('回饋', f'=回饋與費用!F{7 + i}', '#,##0'),
        ('回饋率', f'=回饋與費用!G{7 + i}', '0.0%;-0.0%;"–"'),
    ]
    for k, (lab, fm, nf) in enumerate(rows):
        r = row0 + 4 + k
        bk.cell(r, c1, lab).font = F(9.5, color=MUTED)
        v = bk.cell(r, c1 + 1, fm); v.number_format = nf
        v.font = F(10, name=MONO) if nf not in ('@',) else F(10)
        v.alignment = Alignment(horizontal='right', shrink_to_fit=True)
        bk.merge_cells(start_row=r, start_column=c1 + 1, end_row=r, end_column=c3)
    for r in range(row0 + 1, row0 + 12):
        bk.row_dimensions[r].height = 20 if r != row0 + 2 else 26
# year comparison
Y0 = 5 + -(-NB // 4) * 13 + 2; YT = Y0 + 2 + NB
chapter(bk, Y0, 2, 16, '', '各銀行年度比較', f'{CY} 只比 1–{CM} 月')
thead(bk, Y0 + 1, 2, ['銀行', '', LBL_PREV, '', '佔比', '', LBL_PSAME, '', LBL_CUR, '', '佔比', '', '同期增減'])
for k, i in enumerate(order26):
    r = Y0 + 2 + k
    b = BANKS[i]
    bk.cell(r, 2, '● ' + b)
    bk.cell(r, 4, f'=SUMIFS({AM},{YR},"{PY}",{BK},"{b}",{SP})')
    bk.cell(r, 6, f'=IFERROR(D{r}/$D${YT},"")')
    bk.cell(r, 8, f'=SUMIFS({AM},{MI},">="&{PY * 100 + 1},{MI},"<="&{PY * 100 + CM},{BK},"{b}",{SP})')
    bk.cell(r, 10, f'=SUMIFS({AM},{MI},">="&{CY * 100 + 1},{MI},"<="&{CY * 100 + CM},{BK},"{b}",{SP})')
    bk.cell(r, 12, f'=J{r}/$J${YT}')
    bk.cell(r, 14, f'=IF(H{r}=0,"",J{r}/H{r}-1)')
    trow(bk, r, 2, 15, nums=(4, 8, 10), pcts=(6, 12), dp=(14,))
    bk.cell(r, 2).font = F(10, True, BCOL[i])
r = YT
bk.cell(r, 2, '合計')
for c in (4, 8, 10):
    bk.cell(r, c, f'=SUM({L(c)}{Y0 + 2}:{L(c)}{YT - 1})')
bk.cell(r, 14, f'=IF(H{r}=0,"",J{r}/H{r}-1)')
trow(bk, r, 2, 15, nums=(4, 8, 10), dp=(14,)); ttotal(bk, r, 2, 15)
for c in (4, 8, 10):
    bk.cell(r, c).number_format = NUM
bk.cell(r, 14).number_format = DPCT
paint(bk, 1, 60, 1, 18, BG) if False else None

# ===================== 卡別分析 =====================
cd = wb.create_sheet('卡別分析', 3)
setup(cd, [2.5, 8, 30, 9, 13, 9, 8, 10, 14, 12, 2.5])
cd['B2'] = '卡別分析'; cd['B2'].font = F(22, True, INK)
cd['B3'] = '="期間：" & 計算!$B$8 & "　｜　正卡、附卡分開列；狀態依期間內金額與筆數判斷"'; cd['B3'].font = F(9.5, color=INK2)
thead(cd, 6, 2, ['銀行', '卡片', '狀態', '刷卡金額', '佔比', '筆數', '平均每筆', '主要用途', '最後刷卡'], ['left', 'left', 'center', 'right', 'right', 'right', 'right', 'left', 'right'])
tot_by = collections.defaultdict(float)
for r_ in R:
    if r_['category'] != REB and r_['date'][:4] == str(CY):
        tot_by[(r_['bank'], last4(r_))] += r_['amount']
from cards import owner as _own2
cards_sorted = sorted([k for k in cards if _own2(*k) == '我'], key=lambda k: -tot_by[k])   # 家人的附卡列在「代付與家人」
for k, (b, n) in enumerate(cards_sorted):
    r = 7 + k
    hr = HC1 + cards.index((b, n))
    cd.cell(r, 2, b); cd.cell(r, 3, f'=卡片清單!$I${CARDROW[(b, n)]}')
    cd.cell(r, 5, f'={S(f"{BK},B{r}", f"{CD},C{r}", SP)}')
    cd.cell(r, 6, f'=IF(E{r}<=0,"",E{r}/{TOT})')
    cd.cell(r, 7, f'={C(f"{BK},B{r}", f"{CD},C{r}", SP, AM + ",\">0\"")}')
    cd.cell(r, 8, f'=IF(G{r}=0,"",E{r}/G{r})')
    cd.cell(r, 9, f'=IF(E{r}<=0,"–",INDEX(計算!$C${HC1 - 1}:${L(2 + len(CATS))}${HC1 - 1},MATCH(MAX(計算!$C${hr}:${L(2 + len(CATS))}${hr}),計算!$C${hr}:${L(2 + len(CATS))}${hr},0)))')
    cd.cell(r, 10, f'=_xlfn.MAXIFS({DT},{BK},B{r},{CD},C{r},{AM},">0",{SP})')
    cd.cell(r, 4, f'=IF(OR(E{r}<=0,G{r}=0),"未使用",IF(E{r}/{TOT}>=0.1,"主力",IF(G{r}>=P_N,"常用","偶爾")))')
    trow(cd, r, 2, 10, nums=(5, 7, 8), pcts=(6,))
    cd.cell(r, 2).font = F(10, True, BCOL[BANKS.index(b)])
    cd.cell(r, 4).alignment = Alignment(horizontal='center', vertical='center')
    cd.cell(r, 9).alignment = Alignment(indent=1, vertical='center')
    cd.cell(r, 10).number_format = 'yyyy/mm/dd'; cd.cell(r, 10).font = F(9.5, color=MUTED, name=MONO); cd.cell(r, 10).alignment = Alignment(horizontal='right')
CL = 6 + len(cards_sorted)
cd.conditional_formatting.add(f'E7:E{CL}', DataBarRule(start_type='num', start_value=0, end_type='max', color='C9A45C', showValue=True))
for txt, fc, bgc in [('主力', BLUE, 'E3EDF6'), ('常用', NEG, 'DFF2E8'), ('偶爾', 'A86A00', 'FBF0DA'), ('未使用', '9AA3B0', 'F1F3F6')]:
    cd.conditional_formatting.add(f'D7:D{CL}', CellIsRule(operator='equal', formula=[f'"{txt}"'], font=Font(name=FN, bold=True, color=fc), fill=fill(bgc)))
cd.conditional_formatting.add(f'B7:J{CL}', FormulaRule(formula=['$D7="未使用"'], font=Font(color='9AA3B0')))
cd.freeze_panes = 'D7'

# ===================== 回饋與費用 =====================
rw = wb.create_sheet('回饋與費用', 4)
setup(rw, [2.5, 9, 13, 15, 12, 13, 10, 13, 12, 12, 2.5, 3])
rw['B2'] = '回饋與費用'; rw['B2'].font = F(22, True, INK)
rw['B3'] = '="期間：" & 計算!$B$8 & "　｜　回饋 = 現金回饋／刷卡金（永豐大戶回饋入帳戶也算）＋ 新增點數（1 點 ≈ 1 元）"'; rw['B3'].font = F(9.5, color=INK2)
thead(rw, 6, 2, ['銀行', '刷卡金額', '現金回饋／刷卡金', '新增點數', '回饋合計', '回饋率', '年費（實收）', '海外手續費', '淨收益'])
for i, b in enumerate(BANKS):
    r = 7 + i
    rw.cell(r, 2, '● ' + b)
    rw.cell(r, 3, f'={S(f"{BK},\"{b}\"", SP)}')
    rw.cell(r, 4, f'=-{S(f"{BK},\"{b}\"", f"{CT},\"{REB}\"")}+{S(f"{BK},\"{b}\"", f"{CT},\"{REB}\"", f"{MR},\"*積點兌換*\"")}')
    rw.cell(r, 5, f'=SUMIFS({PP},{PB},"{b}",{PM},">="&P_S,{PM},"<="&P_E,{PU},"<>紅利點數")')
    rw.cell(r, 6, f'=D{r}+E{r}')
    rw.cell(r, 7, f'=IF(C{r}<=0,"",F{r}/C{r})')
    rw.cell(r, 8, f'={S(f"{BK},\"{b}\"", f"{MR},\"*年費*\"")}')
    rw.cell(r, 9, f'={S(f"{BK},\"{b}\"", f"{CT},\"年費手續費\"")}-H{r}')
    rw.cell(r, 10, f'=F{r}-H{r}-I{r}')
    trow(rw, r, 2, 10, nums=(3, 4, 5, 6, 8, 9, 10), pcts=(7,))
    rw.cell(r, 2).font = F(10, True, BCOL[i]); rw.cell(r, 6).font = F(10, True, name=MONO)
    rw.cell(r, 7).font = F(10, name=MONO); rw.cell(r, 7).number_format = '0.00%;-0.00%;"–"'
RT = 7 + NB; RE = RT - 1
r = RT
rw.cell(r, 2, '合計')
for c in (3, 4, 5, 6, 8, 9, 10):
    rw.cell(r, c, f'=SUM({L(c)}7:{L(c)}{RE})')
rw.cell(r, 7, f'=F{RT}/C{RT}')
trow(rw, r, 2, 10, nums=(3, 4, 5, 6, 8, 9, 10), pcts=(7,)); ttotal(rw, r, 2, 10)
for c in (3, 4, 5, 6, 8, 9, 10):
    rw.cell(r, c).number_format = NUM
rw.cell(r, 7).number_format = '0.00%'
rw.conditional_formatting.add(f'G7:G{RE}', DataBarRule(start_type='num', start_value=0, end_type='max', color='1BAF7A', showValue=True))
rw.conditional_formatting.add(f'J7:J{RE}', CellIsRule(operator='lessThan', formula=['0'], font=Font(name=MONO, bold=True, color=POS)))
rw.conditional_formatting.add(f'J7:J{RE}', CellIsRule(operator='greaterThan', formula=['0'], font=Font(name=MONO, color=NEG)))
rw.conditional_formatting.add(f'H7:H{RE}', CellIsRule(operator='greaterThan', formula=['0'], font=Font(name=MONO, bold=True, color=POS)))
rw.cell(RT + 1, 2, '點數來源見「點數」分頁（藍字為帳單抄錄）。星展「現金積點兌換刷卡金」已從現金回饋扣除，避免重複。聯邦紅利不換算；中信紅利點數在帳單影像中無法讀取。').font = F(9, color=MUTED)

chapter(rw, RT + 4, 2, 10, '', '年費紀錄', '全部期間')
thead(rw, RT + 5, 2, ['月份', '銀行', '項目', '', '收取', '減免', '實付'], ['left', 'left', 'left', 'left', 'right', 'right', 'right'])
fees = collections.OrderedDict()
for r_ in R:
    if '年費' in r_['merchant'] + r_['desc'] and r_['amount'] != 0:
        key = (r_['date'][:7], r_['bank'], r_['merchant'].replace('減免', ''))
        fees.setdefault(key, [0, 0])
        fees[key][0 if r_['amount'] > 0 else 1] += r_['amount']
for k, ((m, b, name), (chg, wv)) in enumerate(fees.items()):
    r = RT + 6 + k
    rw.cell(r, 2, m.replace('-', '/')); rw.cell(r, 3, '● ' + b); rw.cell(r, 4, name)
    rw.cell(r, 6, chg); rw.cell(r, 7, wv); rw.cell(r, 8, f'=F{r}+G{r}')
    trow(rw, r, 2, 8, nums=(6, 7, 8))
    rw.cell(r, 3).font = F(10, True, BCOL[BANKS.index(b)]); rw.cell(r, 2).font = F(10, name=MONO)
    rw.cell(r, 8).font = F(10, True, name=MONO)
FL = RT + 5 + len(fees)
rw.conditional_formatting.add(f'H{RT + 6}:H{FL}', CellIsRule(operator='greaterThan', formula=['0'], font=Font(name=MONO, bold=True, color=POS), fill=fill('FBE7E4')))
rw.cell(FL + 1, 2, '減免＝銀行退還的年費；實付為 0 表示該年度符合免年費條件。').font = F(9, color=MUTED)

rc = BarChart(); rc.type = 'bar'; rc.title = None
rc.add_data(Reference(rw, min_col=7, min_row=6, max_row=RE), titles_from_data=True)
rc.set_categories(Reference(rw, min_col=2, min_row=7, max_row=RE))
rc.series[0].graphicalProperties.solidFill = '1BAF7A'; rc.legend = None
rc.y_axis.numFmt = '0.0%'; rc.x_axis.scaling.orientation = 'maxMin'; rc.height = 7; rc.width = 13
rw.add_chart(rc, 'B' + str(FL + 4))

# ===================== 消費分類 =====================
ca = wb.create_sheet('消費分類', 5)
setup(ca, [2.5, 13, 13, 9, 13, 11, 2.5] + [11] * max(7, NB) + [2.5])
ca['B2'] = '消費分類'; ca['B2'].font = F(22, True, INK)
ca['B3'] = f'="期間：" & 計算!$B$8 & IF(P_YOY,"　｜　同期增減為與去年同期比較","") & "　｜　回饋折抵不計入總額"'; ca['B3'].font = F(9.5, color=INK2)
thead(ca, 6, 2, ['分類', '金額', '佔比', '去年同期', '同期增減'])
for k, c in enumerate(CATS):
    r = 7 + k
    ca.cell(r, 2, c)
    ca.cell(r, 3, f'={S(f"{CT},B{r}")}')
    ca.cell(r, 4, f'=C{r}/{TOT}')
    ca.cell(r, 5, f'=IF(P_YOY,{S(f"{CT},B{r}", prev=True)},"")')
    ca.cell(r, 6, f'=IF(OR(E{r}="",E{r}=0),"",C{r}/E{r}-1)')
    trow(ca, r, 2, 6, nums=(3, 5), pcts=(4,), dp=(6,))
r = 7 + len(CATS)
ca.cell(r, 2, '合計'); ca.cell(r, 3, f'=SUM(C7:C{r - 1})'); ca.cell(r, 5, f'=IF(P_YOY,SUM(E7:E{r - 1}),"")'); ca.cell(r, 6, f'=IF(E{r}="","",C{r}/E{r}-1)')
trow(ca, r, 2, 6, nums=(3, 5), dp=(6,)); ttotal(ca, r, 2, 6)
ca.cell(r, 3).number_format = NUM; ca.cell(r, 5).number_format = NUM; ca.cell(r, 6).number_format = DPCT
ca.cell(r + 1, 2, '回饋折抵'); ca.cell(r + 1, 3, f'={S(f"{CT},\"{REB}\"")}')
trow(ca, r + 1, 2, 6, nums=(3,)); ca.cell(r + 1, 2).font = F(10, color=NEG)
ca.conditional_formatting.add(f'C7:C{6 + len(CATS)}', DataBarRule(start_type='num', start_value=0, end_type='max', color='2F6FAE', showValue=True))
# category x bank heat at rows 21..
chapter(ca, HC0, 2, max(14, 2 + NB), '', '分類 × 銀行', '顏色越深金額越高')
thead(ca, HC0 + 2, 2, ['分類'] + BANKS)
for j in range(NB):
    ca.cell(HC0 + 2, 3 + j).font = F(9, True, BCOL[j])
for k, c in enumerate(CATS):
    r = HC0 + 3 + k
    ca.cell(r, 2, c)
    for j, b in enumerate(BANKS):
        ca.cell(r, 3 + j, f'={S(f"{CT},$B{r}", f"{BK},\"{b}\"")}')
    trow(ca, r, 2, 2 + NB, nums=tuple(range(3, 3 + NB)))
ca.conditional_formatting.add(f'C{HC0 + 3}:{L(2 + NB)}{HC0 + 2 + NC}', ColorScaleRule(start_type='num', start_value=0, start_color='FFFFFF', mid_type='percentile', mid_value=80, mid_color='9EC5F4', end_type='max', end_color='1F5F99'))
for j in range(NB):
    ca.column_dimensions[L(3 + j)].width = max(ca.column_dimensions[L(3 + j)].width or 0, 11)
# 子分類拆解：交通、旅遊、網購再分細
import subcat as _sc
SU = rng('U')
_SUBS = [(_p, [c for c in CATS if c.startswith(_scf.FINE_PARENT[_p] + '・')]) for _p in ('交通停車加油', '旅遊住宿', '網購')]
_SUBS = [x for x in _SUBS if x[1]]
SB0 = HC0 + 3 + NC + 2
chapter(ca, SB0, 2, 7, '', '交通・旅遊・網購 合計', '分類已拆細；這裡把同一大類加總對照。網購用電子發票品名判斷（沒發票明細的列「未分類」）')
thead(ca, SB0 + 2, 2, ['大類', '細分類', '金額', '佔該大類', '去年同期'])
_r = SB0 + 3
for _cat, _subs in _SUBS:
    _first = _r
    for _sb in _subs:
        ca.cell(_r, 2, _scf.FINE_PARENT[_cat] if _r == _first else '')
        ca.cell(_r, 3, _sb.split('・', 1)[1])
        _c1 = CT + ',"' + _sb + '"'
        ca.cell(_r, 4, '=' + S(_c1))
        ca.cell(_r, 5, f'=IFERROR(D{_r}/SUM(D${_first}:D${_first + len(_subs) - 1}),0)')
        ca.cell(_r, 6, '=IF(P_YOY,' + S(_c1, prev=True) + ',"")')
        trow(ca, _r, 2, 6, nums=(4, 6), pcts=(5,))
        _r += 1
    ca.cell(_first, 2).font = F(10, True, INK)
    ca.conditional_formatting.add(f'D{_first}:D{_r - 1}', DataBarRule(start_type='num', start_value=0, end_type='max', color='1BAF7A', showValue=True))
    _r += 1
cc = BarChart(); cc.type = 'bar'
cc.add_data(Reference(ca, min_col=3, min_row=6, max_row=6 + len(CATS)), titles_from_data=True)
cc.set_categories(Reference(ca, min_col=2, min_row=7, max_row=6 + len(CATS)))
cc.series[0].graphicalProperties.solidFill = '2F6FAE'; cc.legend = None
cc.x_axis.scaling.orientation = 'maxMin'; cc.y_axis.numFmt = '#,##0'; cc.height = 8.5; cc.width = 14
ca.add_chart(cc, 'K5')

# ===================== 海外消費 =====================
fx = wb.create_sheet('海外消費', 6)
setup(fx, [2.5, 20, 13, 9, 9, 3, 9, 13, 11, 11, 9, 2.5])
fx['B2'] = '海外消費'; fx['B2'].font = F(22, True, INK)
fx['B3'] = '="期間：" & 計算!$B$8 & "　｜　外幣消費與海外商店（如 Hotels.com），手續費另列"'; fx['B3'].font = F(9.5, color=INK2)
ctrys = sorted(set(r_['country'] for r_ in R if r_['country']), key=lambda c: -sum(r_['amount'] for r_ in R if r_['country'] == c))
thead(fx, 6, 2, ['地區', '金額', '佔比', '筆數'])
for k, c in enumerate(ctrys):
    r = 7 + k
    fx.cell(r, 2, c)
    fx.cell(r, 3, f'={S(f"{CTY},B{r}", SP, f"{CT},\"<>年費手續費\"")}')
    fx.cell(r, 4, f'=IF(C{r}=0,"",C{r}/SUM($C$7:$C${6 + len(ctrys)}))')
    fx.cell(r, 5, f'={C(f"{CTY},B{r}", SP, f"{CT},\"<>年費手續費\"", AM + ",\">0\"")}')
    trow(fx, r, 2, 5, nums=(3, 5), pcts=(4,))
fx.conditional_formatting.add(f'C7:C{6 + len(ctrys)}', DataBarRule(start_type='num', start_value=0, end_type='max', color='2F6FAE', showValue=True))
thead(fx, 6, 7, ['銀行', '海外刷卡', '手續費筆數', '手續費', '費率'], ['left', 'right', 'right', 'right', 'right'])
for i, b in enumerate(BANKS):
    r = 7 + i
    fx.cell(r, 7, '● ' + b)
    fx.cell(r, 8, f'={S(f"{BK},\"{b}\"", f"{CTY},\"<>\"", SP, f"{CT},\"<>年費手續費\"")}')
    fx.cell(r, 9, f'={C(f"{BK},\"{b}\"", f"{CT},\"年費手續費\"", f"{MR},\"<>*年費*\"", AM + ",\">0\"")}')
    fx.cell(r, 10, f'={S(f"{BK},\"{b}\"", f"{CT},\"年費手續費\"")}-{S(f"{BK},\"{b}\"", f"{MR},\"*年費*\"")}')
    fx.cell(r, 11, f'=IF(H{r}<=0,"",J{r}/H{r})')
    trow(fx, r, 7, 11, nums=(8, 9, 10), pcts=(11,))
    fx.cell(r, 7).font = F(10, True, BCOL[i])
FT = 7 + NB
fx.cell(FT, 7, '合計')
for c in (8, 9, 10):
    fx.cell(FT, c, f'=SUM({L(c)}7:{L(c)}{FT - 1})')
trow(fx, FT, 7, 11, nums=(8, 9, 10)); ttotal(fx, FT, 7, 11)
for c in (8, 9, 10):
    fx.cell(FT, c).number_format = NUM
fx.conditional_formatting.add(f'J7:J{FT - 1}', CellIsRule(operator='greaterThan', formula=['0'], font=Font(name=MONO, color=POS)))

# ===================== 商家排行 =====================
me = wb.create_sheet('商家排行', 7)
setup(me, [2.5, 5, 30, 13, 22, 13, 9, 7, 2.5])
me['B2'] = '商家排行'; me['B2'].font = F(22, True, INK)
me['B3'] = '="期間：" & 計算!$B$8 & "　｜　依淨額排序（已扣退款）"'; me['B3'].font = F(9.5, color=INK2)
thead(me, 6, 2, ['#', '商家', '分類', '刷卡銀行', '金額', '佔比', '筆數'], ['right', 'left', 'left', 'left', 'right', 'right', 'right'])
HMR = f'計算!$B${HM1}:$B${HM2}'
for k in range(20):
    r = 7 + k
    me.cell(r, 2, k + 1)
    me.cell(r, 3, f'=IFERROR(INDEX(計算!$A${HM1}:$A${HM2},MATCH(LARGE({HMR},B{r}),{HMR},0)),"")')
    me.cell(r, 4, f'=IFERROR(INDEX(計算!$D${HM1}:$D${HM2},MATCH(LARGE({HMR},B{r}),{HMR},0)),"")')
    me.cell(r, 5, f'=IFERROR(INDEX(計算!$E${HM1}:$E${HM2},MATCH(LARGE({HMR},B{r}),{HMR},0)),"")')
    me.cell(r, 6, f'=IFERROR(ROUND(LARGE({HMR},B{r}),0),"")')
    me.cell(r, 7, f'=IFERROR(F{r}/{TOT},"")')
    me.cell(r, 8, f'=IFERROR(INDEX(計算!$C${HM1}:$C${HM2},MATCH(LARGE({HMR},B{r}),{HMR},0)),"")')
    trow(me, r, 2, 8, nums=(2, 6, 8), pcts=(7,))
    me.cell(r, 2).font = F(9.5, color=MUTED, name=MONO); me.cell(r, 4).font = F(9.5, color=MUTED); me.cell(r, 5).font = F(9.5, color=INK2)
me.conditional_formatting.add('F7:F26', DataBarRule(start_type='num', start_value=0, end_type='max', color='2F6FAE', showValue=True))

# ===================== 固定支出 =====================
rc2 = wb.create_sheet('固定支出', 8)
setup(rc2, [2.5, 24, 34, 24, 13, 13, 12, 2.5])
rc2['B2'] = '固定支出'; rc2['B2'].font = F(22, True, INK)
rc2['B3'] = '每月或每年重複出現的扣款（依商家關鍵字歸類，數字為整理時的固定值）'; rc2['B3'].font = F(9.5, color=INK2)
thead(rc2, 6, 2, ['項目', '說明', '扣款銀行', LBL_PREV, LBL_CUR, f'月均（{CY}）'], ['left', 'left', 'left', 'right', 'right', 'right'])
for k, (name, sub, banks, a, b) in enumerate(RECUR):
    r = 7 + k
    rc2.cell(r, 2, name); rc2.cell(r, 3, sub); rc2.cell(r, 4, banks); rc2.cell(r, 5, a); rc2.cell(r, 6, b); rc2.cell(r, 7, f'=F{r}/{CM}')
    trow(rc2, r, 2, 7, nums=(5, 6, 7))
    rc2.cell(r, 2).font = F(10, True); rc2.cell(r, 3).font = F(9.5, color=MUTED); rc2.cell(r, 4).font = F(9.5, color=INK2)
r = 7 + len(RECUR)
rc2.cell(r, 2, '合計')
for c in (5, 6, 7):
    rc2.cell(r, c, f'=SUM({L(c)}7:{L(c)}{r - 1})')
trow(rc2, r, 2, 7, nums=(5, 6, 7)); ttotal(rc2, r, 2, 7)
for c in (5, 6, 7):
    rc2.cell(r, c).number_format = NUM
rc2.conditional_formatting.add(f'E7:E{r - 1}', DataBarRule(start_type='num', start_value=0, end_type='max', color='C9A45C', showValue=True))

# ===================== 總覽: callouts, nav, mini charts =====================
paint(ov, 12, 19, 1, 14, NAVY)
# spark chart (monthly totals)
sp = BarChart(); sp.type = 'col'; sp.gapWidth = 30
sp.add_data(Reference(mo, min_col=TOTC, min_row=M1, max_row=ML), titles_from_data=False)
sp.set_categories(Reference(mo, min_col=2, min_row=M1, max_row=ML))
sp.series[0].graphicalProperties.solidFill = GOLD; sp.series[0].graphicalProperties.line.noFill = True
sp.legend = None; sp.y_axis.delete = True; sp.y_axis.majorGridlines = None
sp.x_axis.tickLblPos = 'low'
from openpyxl.chart.shapes import GraphicalProperties
sp.plot_area.graphicalProperties = GraphicalProperties(noFill=True)
sp.graphical_properties = GraphicalProperties(noFill=True)
from openpyxl.drawing.line import LineProperties
sp.graphical_properties.line = LineProperties(noFill=True)
sp.height = 4.2; sp.width = 28.5
ov.add_chart(sp, 'B12')

# callouts rows 21-25
CO = 21
ov.cell(CO - 1, 2, '重點摘要').font = F(13, True, INK)
ov.row_dimensions[CO - 1].height = 26
callouts = [
    ('最大分類', f'=INDEX(消費分類!$B$7:$B${6 + NC},MATCH(MAX(消費分類!$C$7:$C${6 + NC}),消費分類!$C$7:$C${6 + NC},0))&" 佔 "&TEXT(MAX(消費分類!$C$7:$C${6 + NC})/B9,"0.0%")', f'="期間內共 NT$ "&TEXT(MAX(消費分類!$C$7:$C${6 + NC}),"#,##0")', BLUE),
    ('主力銀行', f'=INDEX(回饋與費用!$B$7:$B${RE},MATCH(MAX(回饋與費用!$C$7:$C${RE}),回饋與費用!$C$7:$C${RE},0))&"　"&TEXT(MAX(回饋與費用!$C$7:$C${RE})/B9,"0.0%")', '="主力卡："&卡別分析!$B$7&" "&卡別分析!$C$7', BLUE),
    ('花最多的月份', f'=INDEX(月份分析!$B${M1}:$B${ML},MATCH(MAX(月份分析!${XL}${M1}:${XL}${ML}),月份分析!${XL}${M1}:${XL}${ML},0))&"　NT$ "&TEXT(MAX(月份分析!${XL}${M1}:${XL}${ML}),"#,##0")', f'="是期間月平均的 "&TEXT(MAX(月份分析!${XL}${M1}:${XL}${ML})/D9,"0.0")&" 倍"', POS),
    ('年費與手續費', '="NT$ "&TEXT(J9,"#,##0")', f'=IF(回饋與費用!$H${RT}>0,"含年費 NT$ "&TEXT(回饋與費用!$H${RT},"#,##0"),"期間內的卡年費都已減免，只剩海外手續費")', NEG),
]
# helper col X on 月份分析: period values excluding 2026-09
for i in range(len(MONTHS)):
    r = M1 + i
    mo.cell(r, XC, f'=IF(AND({INL}{r},{MIL}{r}<={CY * 100 + CM}),{TL}{r},0)').font = F(8, color='FFFFFF')
mo.column_dimensions[XL].hidden = True
mo.column_dimensions[MIL].hidden = True
mo.column_dimensions[INL].hidden = True
for k, (t, h, p, col) in enumerate(callouts):
    c1 = 2 + k * 3
    card_bg(ov, CO, CO + 3, c1, c1 + 2)
    for r in range(CO, CO + 4):
        ov.cell(r, c1).border = Border(left=Side(style='thick', color=col), top=thin if r == CO else None, bottom=thin if r == CO + 3 else None)
    ov.cell(CO, c1, t).font = F(9, color=MUTED)
    ov.cell(CO + 1, c1, h).font = F(12, True, INK)
    ov.cell(CO + 2, c1, p).font = F(9.5, color=INK2)
    for r in range(CO, CO + 3):
        ov.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c1 + 2)
        ov.cell(r, c1).alignment = Alignment(indent=1, vertical='center', shrink_to_fit=True)
ov.row_dimensions[CO].height = 20; ov.row_dimensions[CO + 1].height = 26; ov.row_dimensions[CO + 2].height = 20; ov.row_dimensions[CO + 3].height = 8

# chapter navigation
NV = 28
ov.cell(NV, 2, '章節').font = F(13, True, INK)
chs = [('01', '月份分析'), ('02', '比較'), ('03', '銀行分析'), ('04', '卡別分析'), ('05', '分期付款'), ('06', '回饋與費用'), ('07', '消費分類'), ('08', '海外消費'), ('09', '商家排行'), ('10', '固定支出'), ('11', '代付與家人'), ('12', '交易明細')]
desc = ['逐月 × 銀行、較上月／去年同月、月份 × 分類熱度表、堆疊圖', '任選兩個月對比；挑銀行／分類／卡片看逐月走勢', '各銀行卡片：金額、佔比、筆數、主要分類、最常刷、回饋率；年度比較', '每張卡（正／附卡）的金額、佔比、筆數、主要用途、最後刷卡、狀態', '分期方案進度、剩餘未繳、每月分期入帳', '現金回饋、點數、回饋率、年費實收、海外手續費、淨收益；年費紀錄', '分類金額與同期增減、分類 × 銀行熱度表', '依地區的海外消費、各銀行手續費與費率', '期間內前 20 名商家', '保險、停車、加油、電信等重複扣款', '家人刷的附卡、你幫別人刷的代付（不算進你的消費）；本月可能代付的提醒', '全部交易，可篩選；「代付」欄勾 ✔ 就不算你的消費']
for k, ((n, nm), d) in enumerate(zip(chs, desc)):
    r = NV + 1 + k
    ov.cell(r, 2, n).font = F(10, color=MUTED, name=MONO)
    c = ov.cell(r, 3, nm); c.hyperlink = f"#'{nm}'!A1"; c.font = Font(name=FN, size=11, bold=True, color=BLUE, underline='single')
    ov.cell(r, 5, d).font = F(9.5, color=INK2)
    for cc_ in range(2, 14):
        ov.cell(r, cc_).border = Border(bottom=hair)
    ov.row_dimensions[r].height = 22
ov.cell(NV + 14, 2, '金額為新臺幣。永豐幣倍卡日圓帳單以 1 日圓 ≈ 0.21 元換算；繳款、溢繳退還不計入消費；退款以負數抵銷。分類依商家名稱自動判斷，中信商家名由帳單影像人工判讀。').font = F(9, color=MUTED)
for r in range(20, 45):
    for c in range(1, 15):
        if ov.cell(r, c).fill is None or ov.cell(r, c).fill.fgColor.rgb in (None, '00000000'):
            ov.cell(r, c).fill = fill(BG)

# bank mini charts on 銀行分析 under each card (row+12)? keep compact: add charts of monthly per bank in a strip
for pos, i in enumerate(order26):
    row0 = 5 + (pos // 4) * 13
    c1 = 2 + (pos % 4) * 4
mini_r = YT + 3
bk.cell(mini_r, 2, '各銀行每月走勢').font = F(13, True, INK)
for pos, i in enumerate(order26):
    m = BarChart(); m.type = 'col'; m.gapWidth = 25
    m.add_data(Reference(mo, min_col=3 + i, min_row=M1, max_row=ML), titles_from_data=False)
    m.set_categories(Reference(mo, min_col=2, min_row=M1, max_row=ML))
    m.series[0].graphicalProperties.solidFill = BCOL[i]
    m.legend = None; m.title = BANKS[i]; m.y_axis.numFmt = '#,##0'; m.y_axis.majorGridlines = None
    m.height = 5.2; m.width = 9.6
    bk.add_chart(m, f'{L(2 + (pos % 4) * 4)}{mini_r + 1 + (pos // 4) * 11}')


def band(ws, ncol, sub_row=3, chip=True):
    for r in range(1, 5):
        for c in range(1, ncol + 1):
            ws.cell(r, c).fill = fill(NAVY)
    ws.row_dimensions[1].height = 10; ws.row_dimensions[2].height = 36; ws.row_dimensions[3].height = 20; ws.row_dimensions[4].height = 12
    ws['B2'].font = F(20, True, HINK); ws['B2'].alignment = Alignment(vertical='center')
    ws['B3'].font = F(9.5, color=HINK2)
    if not chip:
        return
    pc = ws.cell(2, ncol - 2, '=計算!$B$8'); pc.font = F(10, True, NAVY); pc.fill = fill(GOLD)
    ws.cell(2, ncol - 1).fill = fill(GOLD)
    ws.merge_cells(start_row=2, start_column=ncol - 2, end_row=2, end_column=ncol - 1)
    pc.alignment = Alignment(horizontal='center', vertical='center', shrink_to_fit=True)
for ws_, nc in [(mo, INC), (bk, 16), (cd, 10), (rw, 10), (ca, max(14, 2 + NB)), (fx, 11), (me, 8)]:
    band(ws_, nc + 1)
rc2.cell(2, 2).font = F(20, True, HINK)
for r in range(1, 5):
    for c in range(1, 9):
        rc2.cell(r, c).fill = fill(NAVY)
rc2['B3'].font = F(9.5, color=HINK2); rc2.row_dimensions[2].height = 36
kl['B2'] = '卡片清單'
for r in range(1, 4):
    for c in range(1, 18):
        kl.cell(r, c).fill = fill(NAVY)
kl['B2'].font = F(20, True, HINK); kl['B3'].font = F(9.5, color=HINK2); kl.row_dimensions[2].height = 36
mo['N2'] = None

# ===================== 比較 =====================
from openpyxl.chart import LineChart
cp = wb.create_sheet('比較')
setup(cp, [2.5, 13, 12, 12, 12, 10, 11, 13, 12, 12, 12, 10, 2.5, 12, 2.5])
cp['B2'] = '比較'; cp['B3'] = '自選兩個月份對比，或挑銀行／分類／卡片看逐月走勢。本頁不受總覽篩選影響，金額為淨額、不含回饋折抵。'
_pm = (CY, CM - 1) if CM > 1 else (CY - 1, 12)
cp['B6'] = '月份 A'; cp['E6'] = '月份 B'
cp['C6'] = f'{_pm[0]}-{_pm[1]:02d}'; cp['F6'] = f'{CY}-{CM:02d}'
for c in ('B6', 'E6'):
    cp[c].font = F(10, True, INK2); cp[c].alignment = Alignment(horizontal='right', vertical='center')
for c in ('C6', 'F6'):
    cp[c].font = F(11, True, NAVY); cp[c].fill = fill('FFF6D6'); cp[c].alignment = Alignment(horizontal='center', vertical='center')
    cp[c].border = Border(left=thin, right=thin, top=thin, bottom=thin)
    dv = DataValidation(type='list', formula1='=月份清單', allow_blank=False); cp.add_data_validation(dv); dv.add(c)
cp['H6'] = '← 黃底格可下拉選月份'; cp['H6'].font = F(9, color=MUTED)
cp.row_dimensions[6].height = 26
cp['N6'] = '=VALUE(SUBSTITUTE(C6,"-",""))'; cp['N7'] = '=VALUE(SUBSTITUTE(F6,"-",""))'
for c in ('N6', 'N7'):
    cp[c].font = F(8, color='B0B7C2')
MA, MB = '$N$6', '$N$7'
chapter(cp, 5, 2, 14, '01', '月份對比')
cp.row_dimensions[5].height = 32
# tiles row 8-10
tiles = [('="月份 A："&C6', f'=SUMIFS({AM},{MI},{MA},{SP})', NUM),
         ('="月份 B："&F6', f'=SUMIFS({AM},{MI},{MB},{SP})', NUM),
         ('差額（B − A）', '=C9-B9', '+#,##0;[Color10]-#,##0;"–"'),
         ('變化', '=IF(B9=0,"",C9/B9-1)', DPCT)]
# use cols B,C,D,E for values (one tile each, merged 2-col? keep 1 col each in wider cols)
tcols = [(2, 3), (5, 6), (8, 9), (10, 11)]
vals = []
for k, (lab, val, fmt) in enumerate(tiles):
    c1, c2 = tcols[k]
    card_bg(cp, 8, 10, c1, c2)
    cp.cell(8, c1, lab).font = F(9, color=MUTED)
    cp.cell(9, c1).number_format = fmt
    vals.append((c1, val))
    cp.merge_cells(start_row=8, start_column=c1, end_row=8, end_column=c2)
    cp.merge_cells(start_row=9, start_column=c1, end_row=9, end_column=c2)
    for r in (8, 9):
        cp.cell(r, c1).alignment = Alignment(indent=1, vertical='center')
cp.cell(9, 2, f'=SUMIFS({AM},{MI},{MA},{SP})'); cp.cell(9, 5, f'=SUMIFS({AM},{MI},{MB},{SP})')
cp.cell(9, 8, '=E9-B9'); cp.cell(9, 10, '=IF(B9=0,"",E9/B9-1)')
for c1, fmt in [(2, NUM), (5, NUM), (8, '+#,##0;[Color10]-#,##0;"–"'), (10, DPCT)]:
    cp.cell(9, c1).number_format = fmt; cp.cell(9, c1).font = F(18, True, INK)
cp.cell(10, 2, f'=COUNTIFS({MI},{MA},{SP},{AM},">0")&" 筆"').font = F(9, color=INK2)
cp.cell(10, 5, f'=COUNTIFS({MI},{MB},{SP},{AM},">0")&" 筆"').font = F(9, color=INK2)
cp.row_dimensions[8].height = 20; cp.row_dimensions[9].height = 30; cp.row_dimensions[10].height = 18
# bank table (B..F) and category table (H..L)
T0 = 12
cp.cell(T0, 2, '依銀行').font = F(12, True, INK); cp.cell(T0, 8, '依分類').font = F(12, True, INK)
thead(cp, T0 + 1, 2, ['銀行', '=C6', '=F6', '差額', '變化'])
thead(cp, T0 + 1, 8, ['分類', '=C6', '=F6', '差額', '變化'])
for i, b in enumerate(BANKS):
    r = T0 + 2 + i
    cp.cell(r, 2, b)
    cp.cell(r, 3, f'=SUMIFS({AM},{MI},{MA},{BK},"{b}",{SP})'); cp.cell(r, 4, f'=SUMIFS({AM},{MI},{MB},{BK},"{b}",{SP})')
    cp.cell(r, 5, f'=D{r}-C{r}'); cp.cell(r, 6, f'=IF(C{r}=0,"",D{r}/C{r}-1)')
    trow(cp, r, 2, 6, nums=(3, 4, 5), dp=(6,))
    bankcell(cp, r, 2, i)
for i, c in enumerate(CATS):
    r = T0 + 2 + i
    cp.cell(r, 8, c)
    cp.cell(r, 9, f'=SUMIFS({AM},{MI},{MA},{CT},$H{r},{MINE})'); cp.cell(r, 10, f'=SUMIFS({AM},{MI},{MB},{CT},$H{r},{MINE})')
    cp.cell(r, 11, f'=J{r}-I{r}'); cp.cell(r, 12, f'=IF(I{r}=0,"",J{r}/I{r}-1)')
    trow(cp, r, 8, 12, nums=(9, 10, 11), dp=(12,))
rb = T0 + 2 + len(BANKS); rcz = T0 + 2 + len(CATS)
cp.cell(rb, 2, '合計')
for c in (3, 4, 5):
    cp.cell(rb, c, f'=SUM({L(c)}{T0 + 2}:{L(c)}{rb - 1})')
cp.cell(rb, 6, f'=IF(C{rb}=0,"",D{rb}/C{rb}-1)')
trow(cp, rb, 2, 6, nums=(3, 4, 5), dp=(6,)); ttotal(cp, rb, 2, 6)
cp.cell(rcz, 8, '合計')
for c in (9, 10, 11):
    cp.cell(rcz, c, f'=SUM({L(c)}{T0 + 2}:{L(c)}{rcz - 1})')
cp.cell(rcz, 12, f'=IF(I{rcz}=0,"",J{rcz}/I{rcz}-1)')
trow(cp, rcz, 8, 12, nums=(9, 10, 11), dp=(12,)); ttotal(cp, rcz, 8, 12)
for (c1, c2, n) in [(3, 6, rb), (9, 12, rcz)]:
    for c in (c1, c1 + 1, c1 + 2):
        cp.cell(n, c).number_format = NUM
    cp.cell(n, c2).number_format = DPCT
cp.conditional_formatting.add(f'E{T0 + 2}:E{rb - 1}', DataBarRule(start_type='min', end_type='max', color='C9A45C', showValue=True))
cp.conditional_formatting.add(f'K{T0 + 2}:K{rcz - 1}', DataBarRule(start_type='min', end_type='max', color='C9A45C', showValue=True))

# 02 逐月比較
C0 = rcz + 3
chapter(cp, C0, 2, 14, '02', '逐月比較', '選比較類型，再挑最多 7 個項目')
cp.cell(C0 + 2, 2, '比較類型').font = F(10, True, INK2)
cp.cell(C0 + 2, 3, '銀行')
tc = cp.cell(C0 + 2, 3); tc.font = F(11, True, NAVY); tc.fill = fill('FFF6D6'); tc.alignment = Alignment(horizontal='center')
tc.border = Border(left=thin, right=thin, top=thin, bottom=thin)
dv = DataValidation(type='list', formula1='"銀行,分類,卡片"', allow_blank=False); cp.add_data_validation(dv); dv.add(tc.coordinate)
TYP = f'$C${C0 + 2}'
cp.cell(C0 + 2, 5, '項目可從黃底下拉選單切換（清單會隨類型變化）；留空表示不比較。').font = F(9, color=MUTED)
IR = C0 + 4  # item header row
cp.cell(IR, 2, '月份')
PAL = BCOL
PAL = BCOL + [_bk.color(i)[1:].upper() for i in range(NB, 7)]
for k in range(7):
    c = cp.cell(IR, 3 + k, BANKS[k] if k < NB else None)
    c.font = F(10, True, NAVY); c.fill = fill('FFF6D6'); c.alignment = Alignment(horizontal='center', shrink_to_fit=True)
    c.border = Border(left=thin, right=thin, top=thin, bottom=Side(style='medium', color=PAL[k]))
    dvi = DataValidation(type='list', formula1=f'=INDIRECT(IF({TYP}="銀行","銀行清單",IF({TYP}="分類","分類清單","卡片名單")))', allow_blank=True)
    cp.add_data_validation(dvi); dvi.add(c.coordinate)
cp.cell(IR, 2).font = F(9, color=MUTED)
cp.cell(IR, 10, '合計（所選）').font = F(9, color=MUTED); cp.cell(IR, 10).alignment = Alignment(horizontal='right')
cp.row_dimensions[IR].height = 24
for i, m in enumerate(MONTHS):
    r = IR + 1 + i
    mi = int(m[:4]) * 100 + int(m[5:])
    cp.cell(r, 2, m.replace('-', '/') + ('*' if m in PARTIAL else ''))
    cp.cell(r, 14, mi)
    for k in range(7):
        it = f'{L(3 + k)}${IR}'
        cp.cell(r, 3 + k, f'=IF({it}="",NA(),IF({TYP}="銀行",SUMIFS({AM},{MI},$N{r},{BK},{it},{SP}),IF({TYP}="分類",SUMIFS({AM},{MI},$N{r},{CT},{it},{MINE}),SUMIFS({AM},{MI},$N{r},{CD},{it},{SP}))))')
    cp.cell(r, 10, f'=SUMIF(C{r}:I{r},">-1E15")')
    trow(cp, r, 2, 10, nums=tuple(range(3, 11)))
    cp.cell(r, 2).font = F(10, name=MONO); cp.cell(r, 14).font = F(8, color='B0B7C2')
CL = IR + len(MONTHS)
tr2 = CL + 1
cp.cell(tr2, 2, '全期合計')
for c in range(3, 11):
    cp.cell(tr2, c, f'=SUMIF({L(c)}{IR + 1}:{L(c)}{CL},">-1E15")' if c == 10 else f'=IF({L(c)}${IR}="","",SUMIF({L(c)}{IR + 1}:{L(c)}{CL},">-1E15"))')
trow(cp, tr2, 2, 10, nums=tuple(range(3, 11))); ttotal(cp, tr2, 2, 10)
for c in range(3, 11):
    cp.cell(tr2, c).number_format = NUM
cp.conditional_formatting.add(f'C{IR + 1}:I{CL}', FormulaRule(formula=[f'ISNA(C{IR + 1})'], font=Font(color='FFFFFF')))
cp.conditional_formatting.add(f'C{IR + 1}:I{CL}', ColorScaleRule(start_type='num', start_value=0, start_color='FFFFFF', end_type='max', end_color='9EC5F4'))
lc = LineChart(); lc.height = 9.5; lc.width = 30
lc.add_data(Reference(cp, min_col=3, max_col=9, min_row=IR, max_row=CL), titles_from_data=True)
lc.set_categories(Reference(cp, min_col=2, min_row=IR + 1, max_row=CL))
for k, s in enumerate(lc.series):
    s.graphicalProperties.line.solidFill = PAL[k]; s.graphicalProperties.line.width = 26000; s.smooth = False
    s.marker.symbol = 'circle'; s.marker.size = 5; s.marker.graphicalProperties = GraphicalProperties(solidFill=PAL[k]); s.marker.graphicalProperties.line.solidFill = PAL[k]
lc.y_axis.numFmt = '#,##0'; lc.y_axis.majorGridlines.spPr = None; lc.legend.position = 't'
lc.y_axis.delete = False; lc.x_axis.delete = False
cp.add_chart(lc, f'B{tr2 + 2}')
cp.column_dimensions['N'].hidden = True
cp.freeze_panes = 'A5'

# ===================== 分期付款 =====================
PL = json.load(open('plans.json'))
PL.sort(key=lambda p: (p['left'] > 0, p['end'], p['start']), reverse=True)
ip = wb.create_sheet('分期付款')
setup(ip, [2.5, 11, 28, 30, 7, 10, 11, 9, 9, 11, 10, 10, 12, 2.5])
ip['B2'] = '分期付款'; ip['B3'] = '由帳單上的「第 n/N 期」自動串成分期方案；每月更新。交易明細的「付款方式」欄可篩選一般／分期。'
act = [p for p in PL if p['left'] > 0]
tiles = [('進行中的分期', f'{len(act)} 筆', '・'.join(f"{p['bank']} {p['merchant']}" for p in act) or '目前沒有'),
         ('剩餘未繳', f"NT$ {sum(p['remain'] for p in act):,}", f"還有 {sum(p['left'] for p in act)} 期"),
         ('每月分期負擔', f"NT$ {sum(p['per'] for p in act):,}", '進行中方案每期合計'),
         ('歷來分期總額', f"NT$ {sum(p['total'] for p in PL):,}", f'共 {len(PL)} 筆方案')]
for k, (t, v, s_) in enumerate(tiles):
    c1 = 2 + k * 3; c2 = c1 + 2
    card_bg(ip, 6, 9, c1, c2)
    for r in range(6, 10):
        ip.cell(r, c1).border = Border(left=Side(style='thick', color=[GOLD, POS, BLUE, INK2][k]), top=thin if r == 6 else None, bottom=thin if r == 9 else None)
    ip.cell(6, c1, t).font = F(9, color=MUTED)
    ip.cell(7, c1, v).font = F(17, True, INK)
    ip.cell(8, c1, s_).font = F(9, color=INK2)
    for r in (6, 7, 8):
        ip.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
        ip.cell(r, c1).alignment = Alignment(indent=1, vertical='center', shrink_to_fit=True)
ip.row_dimensions[7].height = 30; ip.row_dimensions[9].height = 8
chapter(ip, 11, 2, 13, '01', '分期方案', '進度條＝已繳期數／總期數')
thead(ip, 12, 2, ['銀行', '商家', '卡片', '期數', '每期', '總額', '已繳', '剩餘期', '剩餘金額', '開始', '結束', '進度'],
      ['left', 'left', 'left', 'right', 'right', 'right', 'right', 'right', 'right', 'center', 'center', 'right'])
for i, p in enumerate(PL):
    r = 13 + i
    vals_ = [p['bank'], p['merchant'], p['card'], p['N'], p['per'], p['total'], p['paid'], p['left'], p['remain'], p['start'].replace('-', '/'), p['end'].replace('-', '/'), p['paid'] / p['N']]
    for j, v in enumerate(vals_):
        ip.cell(r, 2 + j, v)
    trow(ip, r, 2, 13, nums=(5, 6, 7, 8, 9, 10), pcts=(13,))
    bankcell(ip, r, 2, BANKS.index(p['bank']))
    ip.cell(r, 4).font = F(9.5, color=INK2)
    for c in (11, 12):
        ip.cell(r, c).alignment = Alignment(horizontal='center'); ip.cell(r, c).font = F(9.5, color=INK2, name=MONO)
    ip.cell(r, 13).number_format = '0%'
    if p['left'] > 0:
        for c in range(2, 14):
            ip.cell(r, c).fill = fill('FFF6D6')
        ip.cell(r, 10).font = F(10, True, POS, MONO)
PE = 13 + len(PL) - 1
ip.conditional_formatting.add(f'M13:M{PE}', DataBarRule(start_type='num', start_value=0, end_type='num', end_value=1, color='1BAF7A', showValue=True))
ip.cell(PE + 1, 2, '黃底＝尚未繳完').font = F(9, color=MUTED)
# 02 monthly installment amounts by bank (formula from ledger)
Q0 = PE + 4
chapter(ip, Q0, 2, 13, '02', '每月分期入帳', '依帳單入帳月份；佔比＝分期 ÷ 當月總消費')
thead(ip, Q0 + 1, 2, ['月份'] + BANKS + ['分期合計', '當月總額', '佔比'])
QT, QA, QP = 3 + NB, 4 + NB, 5 + NB
for j in range(NB):
    ip.cell(Q0 + 1, 3 + j).font = F(9, True, BCOL[j])
for i, m in enumerate(MONTHS):
    r = Q0 + 2 + i
    mi = int(m[:4]) * 100 + int(m[5:])
    ip.cell(r, 2, m.replace('-', '/'))
    for j, b in enumerate(BANKS):
        ip.cell(r, 3 + j, f'=SUMIFS({AM},{MI},{mi},{BK},"{b}",{PAY},"分期",{MINE})')
    ip.cell(r, QT, f'=SUM(C{r}:{L(2 + NB)}{r})')
    ip.cell(r, QA, f'=SUMIFS({AM},{MI},{mi},{SP})')
    ip.cell(r, QP, f'=IF({L(QA)}{r}=0,"",{L(QT)}{r}/{L(QA)}{r})')
    trow(ip, r, 2, QP, nums=tuple(range(3, QP)), pcts=(QP,))
    ip.cell(r, 2).font = F(10, name=MONO); ip.cell(r, QT).font = F(10, True, name=MONO)
QL = Q0 + 1 + len(MONTHS)
ip.conditional_formatting.add(f'{L(QT)}{Q0 + 2}:{L(QT)}{QL}', DataBarRule(start_type='num', start_value=0, end_type='max', color='C9A45C', showValue=True))
qt = QL + 1
ip.cell(qt, 2, '合計')
for c in range(3, QP):
    ip.cell(qt, c, f'=SUM({L(c)}{Q0 + 2}:{L(c)}{QL})')
ip.cell(qt, QP, f'=IF({L(QA)}{qt}=0,"",{L(QT)}{qt}/{L(QA)}{qt})')
trow(ip, qt, 2, QP, nums=tuple(range(3, QP)), pcts=(QP,)); ttotal(ip, qt, 2, QP)
for c in range(3, QP):
    ip.cell(qt, c).number_format = NUM
ip.cell(qt, QP).number_format = PCT
ch2 = BarChart(); ch2.type = 'col'; ch2.grouping = 'stacked'; ch2.overlap = 100; ch2.gapWidth = 45
ch2.add_data(Reference(ip, min_col=3, max_col=2 + NB, min_row=Q0 + 1, max_row=QL), titles_from_data=True)
ch2.set_categories(Reference(ip, min_col=2, min_row=Q0 + 2, max_row=QL))
for j, s in enumerate(ch2.series):
    s.graphicalProperties.solidFill = BCOL[j]; s.graphicalProperties.line.solidFill = 'FFFFFF'
ch2.y_axis.numFmt = '#,##0'; ch2.y_axis.majorGridlines.spPr = None; ch2.height = 8.5; ch2.width = 30; ch2.legend.position = 't'
ch2.y_axis.delete = False; ch2.x_axis.delete = False
ip.add_chart(ch2, f'B{qt + 2}')
band(cp, 14, chip=False); band(ip, 14, chip=False)

# ===================== 回饋核對 =====================
import os as _os
RC = json.load(open('rewards_check.json')) if _os.path.exists('rewards_check.json') else dict(checks=[], missed=[], summary=[], cut='')
rk = wb.create_sheet('回饋核對')
setup(rk, [2.5, 11, 24, 11, 11, 10, 10, 9, 10, 46, 2.5])
rk['B2'] = '回饋核對'; rk['B3'] = f'依各卡 2026 下半年權益估算應得回饋，和帳單實際入帳比對；並列出近 6 個月（{RC["cut"].replace("-", "/")} 起的帳單）刷了卻沒拿到回饋的消費。'
_chk = [c for c in RC['checks'] if c['actual'] is not None]
_bad = [c for c in _chk if c['status'].startswith('⚠️')]
_ms = RC['missed']
tiles = [('核對期數', f'{len(_chk)} 期', '・'.join(sorted({c['bank'] + ' ' + re.sub(r'（.*|\s*·.*', '', c['card'])[:6] for c in _chk})) or '尚無權益規則'),
         ('少給回饋', f'{len(_bad)} 期', '差額超過 5%（至少 30 元）才算' if not _bad else '・'.join(f"{c['bank']} {c['stmt'][5:]}" for c in _bad)),
         ('沒拿到回饋的消費', f"NT$ {sum(m['amount'] for m in _ms):,}", f'{len(_ms)} 筆（含分期、規費等本來就沒有的）'),
         ('換卡可多拿', f"NT$ {sum(m['gain'] for m in _ms):,}", '依建議卡片的回饋率估算')]
for k, (t, v, s_) in enumerate(tiles):
    c1 = 2 + k * 2 + (1 if k > 0 else 0); c2 = c1 + (2 if k == 0 else 1)
    card_bg(rk, 6, 9, c1, c2)
    for r in range(6, 10):
        rk.cell(r, c1).border = Border(left=Side(style='thick', color=['1BAF7A', POS, GOLD, BLUE][k]), top=thin if r == 6 else None, bottom=thin if r == 9 else None)
    rk.cell(6, c1, t).font = F(9, color=MUTED); rk.cell(7, c1, v).font = F(17, True, INK); rk.cell(8, c1, s_).font = F(9, color=INK2)
    for r in (6, 7, 8):
        rk.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
        rk.cell(r, c1).alignment = Alignment(indent=1, vertical='center', shrink_to_fit=True)
rk.row_dimensions[7].height = 30; rk.row_dimensions[9].height = 8
r0 = 11
chapter(rk, r0, 2, 10, '01', '每期回饋核對', '應得＝依權益規則估算；差額為負且超過 5% 標紅')
thead(rk, r0 + 1, 2, ['銀行', '卡片', '帳單日', '計回饋消費', '應得', '實得', '差額', '狀態', '說明'],
      ['left', 'left', 'center', 'right', 'right', 'right', 'right', 'center', 'left'])
r = r0 + 2
for c in RC['checks']:
    vals_ = [c['bank'], c['card'], c['stmt'].replace('-', '/'), c['base'], c['expected'], c['actual'], c['diff'], c['status'], c['note']]
    for j, v in enumerate(vals_):
        rk.cell(r, 2 + j, v)
    trow(rk, r, 2, 10, nums=(5, 6, 7, 8))
    bankcell(rk, r, 2, BANKS.index(c['bank']))
    rk.cell(r, 4).alignment = Alignment(horizontal='center'); rk.cell(r, 4).font = F(9.5, color=INK2, name=MONO)
    rk.cell(r, 9).alignment = Alignment(horizontal='center')
    rk.cell(r, 10).font = F(9, color=INK2)
    if c['status'].startswith('⚠️'):
        for cc in range(2, 11):
            rk.cell(r, cc).fill = fill('FDE8E6')
        rk.cell(r, 8).font = F(10, True, POS, MONO)
    elif c['actual'] is None:
        for cc in range(2, 11):
            rk.cell(r, cc).fill = fill('FFF6D6')
    r += 1
r += 2
chapter(rk, r, 2, 10, '02', '沒拿到回饋：依原因', '可多拿＝改用建議卡片的估計回饋')
thead(rk, r + 1, 2, ['原因', '', '筆數', '金額', '可多拿', '', '', '', '建議'], ['left', 'left', 'right', 'right', 'right', 'right', 'right', 'right', 'left'])
r += 2
_sug = {}
for m in _ms:
    _sug.setdefault(m['reason'], m['suggest'])
for s_ in RC['summary']:
    rk.cell(r, 2, s_['reason']); rk.cell(r, 4, s_['n']); rk.cell(r, 5, s_['amount']); rk.cell(r, 6, s_['gain']); rk.cell(r, 10, _sug.get(s_['reason'], ''))
    trow(rk, r, 2, 10, nums=(4, 5, 6))
    rk.merge_cells(start_row=r, start_column=2, end_row=r, end_column=3)
    rk.cell(r, 2).alignment = Alignment(wrap_text=True, vertical='center'); rk.cell(r, 10).font = F(9, color=INK2)
    rk.cell(r, 10).alignment = Alignment(wrap_text=True, vertical='center')
    rk.row_dimensions[r].height = 30
    if s_['gain'] >= 50:
        rk.cell(r, 6).font = F(10, True, POS, MONO)
    r += 1
r += 2
chapter(rk, r, 2, 10, '03', '沒拿到回饋：逐筆明細', '這些就是「不該用這張卡刷」的候選')
thead(rk, r + 1, 2, ['銀行', '卡片', '日期', '商家', '金額', '可多拿', '', '', '原因／建議'], ['left', 'left', 'center', 'left', 'right', 'right', 'right', 'right', 'left'])
r += 2
MS0 = r
for m in _ms:
    rk.cell(r, 2, m['bank']); rk.cell(r, 3, m['cardname']); rk.cell(r, 4, m['date'].replace('-', '/')); rk.cell(r, 5, m['merchant'])
    rk.cell(r, 6, m['amount']); rk.cell(r, 7, m['gain']); rk.cell(r, 10, f"{m['reason']} → {m['suggest']}")
    trow(rk, r, 2, 10, nums=(6, 7))
    bankcell(rk, r, 2, BANKS.index(m['bank']))
    rk.cell(r, 3).font = F(9, color=INK2); rk.cell(r, 4).alignment = Alignment(horizontal='center'); rk.cell(r, 4).font = F(9.5, color=INK2, name=MONO)
    rk.cell(r, 5).font = F(10); rk.cell(r, 5).alignment = Alignment(horizontal='left', vertical='center')
    rk.cell(r, 10).font = F(9, color=INK2); rk.cell(r, 10).alignment = Alignment(wrap_text=True, vertical='center')
    rk.row_dimensions[r].height = 30
    r += 1
if _ms:
    rk.auto_filter.ref = f'B{MS0 - 1}:J{r - 1}'
rk.freeze_panes = 'A5'
band(rk, 10, chip=False)

# ===================== 代付與家人 =====================
pf = wb.create_sheet('代付與家人')
setup(pf, [2.5, 11, 9, 30, 28, 12, 30, 2.5])
pf['B2'] = '代付與家人'
pf['B3'] = '這裡的消費不算進你的消費。家人附卡＝「卡片清單」歸屬選家人的卡；代付＝「交易明細」代付欄勾 ✔（或打比例如 50%）、或在生活帳本網頁上勾的交易。'
_FAM = [r for r in RA if r.get('owner') == '家人' and r['category'] != REB]
_PD = [r for r in RA if r.get('paid') and r.get('owner') == '我']
_HT = [r for r in RA if r.get('hint')]
_ym = lambda r: r['date'][:7]
_cur = f'{CY}-{CM:02d}'
_tiles = [('本月可能代付', f'{len(_HT)} 筆', '到「交易明細」的代付欄選 ✔' if _HT else '這個月沒有需要確認的'),
          (f'家人附卡（{CY} 1–{CM} 月）', f"NT$ {round(sum(r['amount'] for r in _FAM if r['date'][:4] == str(CY) and _ym(r) <= _cur)):,}", f'{len({(r["bank"], r["card"]) for r in _FAM})} 張附卡'),
          ('已勾代付（全期）', f"NT$ {round(sum(r['amount'] for r in _PD)):,}", f'{len(_PD)} 筆')]
for k, (t, v, s_) in enumerate(_tiles):
    c1 = 2 + k * 2 + (1 if k else 0); c2 = c1 + (2 if k == 0 else 1)
    card_bg(pf, 6, 9, c1, c2)
    for r in range(6, 10):
        pf.cell(r, c1).border = Border(left=Side(style='thick', color=[GOLD, 'A86A00', BLUE][k]), top=thin if r == 6 else None, bottom=thin if r == 9 else None)
    pf.cell(6, c1, t).font = F(9, color=MUTED); pf.cell(7, c1, v).font = F(17, True, INK); pf.cell(8, c1, s_).font = F(9, color=INK2)
    for r in (6, 7, 8):
        pf.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
        pf.cell(r, c1).alignment = Alignment(indent=1, vertical='center', shrink_to_fit=True)
pf.row_dimensions[7].height = 30; pf.row_dimensions[9].height = 8


def _list(r0, num, title, note, rows_, why=None):
    chapter(pf, r0, 2, 7, num, title, note)
    thead(pf, r0 + 1, 2, ['日期', '銀行', '卡片', '商家', '金額', why or '帳單說明'], ['left', 'left', 'left', 'left', 'right', 'left'])
    r = r0 + 2
    for x in rows_:
        for j, v in enumerate([x['date'].replace('-', '/'), '● ' + x['bank'], x['cardname'], x['merchant'], x['amount'], x.get('hint') if why else x['desc']]):
            pf.cell(r, 2 + j, v)
        trow(pf, r, 2, 7, nums=(6,))
        pf.cell(r, 4).font = F(9, color=INK2); pf.cell(r, 7).font = F(9, color=INK2); pf.cell(r, 2).font = F(9.5, name=MONO)
        r += 1
    if not rows_:
        pf.cell(r, 2, '（沒有）').font = F(9.5, color=MUTED); r += 1
    return r


r = _list(11, '01', '本月可能代付', '橘底＝建議確認；確定是代付就到「交易明細」勾 ✔', _HT, '為什麼列出')
lk = pf.cell(r, 2, '→ 前往「交易明細」勾代付'); lk.hyperlink = "#'交易明細'!S1"; lk.font = Font(name=FN, size=10, bold=True, color=BLUE, underline='single')
r = _list(r + 3, '02', '已勾代付', '全部期間', sorted(_PD, key=lambda x: x['date'], reverse=True))
# 03 家人附卡：每張卡近 12 個月
r += 2
chapter(pf, r, 2, 7, '03', '家人附卡每月金額', '近 12 個月；回饋折抵不計')
_fc = sorted({(x['bank'], x['cardname']) for x in _FAM}, key=lambda k: -sum(x['amount'] for x in _FAM if (x['bank'], x['cardname']) == k))
_ms12 = [m for m in MONTHS if m <= _cur][-12:]
thead(pf, r + 1, 2, ['月份'] + [f'{b}・{re.sub(r"（附卡・?", "（", n)}' for b, n in _fc] + ['合計'])
for j in range(len(_fc) + 1):
    pf.column_dimensions[L(3 + j)].width = max(pf.column_dimensions[L(3 + j)].width or 0, 16)
    pf.cell(r + 1, 3 + j).alignment = Alignment(horizontal='right', wrap_text=True, vertical='center')
pf.row_dimensions[r + 1].height = 34
for i, m in enumerate(_ms12):
    rr = r + 2 + i
    pf.cell(rr, 2, m.replace('-', '/'))
    vs = [round(sum(x['amount'] for x in _FAM if (x['bank'], x['cardname']) == k and _ym(x) == m)) for k in _fc]
    for j, v in enumerate(vs + [sum(vs)]):
        pf.cell(rr, 3 + j, v)
    trow(pf, rr, 2, 3 + len(_fc), nums=tuple(range(3, 4 + len(_fc))))
    pf.cell(rr, 2).font = F(10, name=MONO); pf.cell(rr, 3 + len(_fc)).font = F(10, True, name=MONO)
if _fc:
    pf.conditional_formatting.add(f'C{r + 2}:{L(2 + len(_fc))}{r + 1 + len(_ms12)}', ColorScaleRule(start_type='num', start_value=0, start_color='FFFFFF', end_type='max', end_color='F2C47E'))
band(pf, 8, chip=False)


# ===================== 收支總覽、隨手記對照（有 income.json 才產生） =====================
_extra_sheets = []
if os.path.exists('income.json'):
    INC = json.load(open('income.json', encoding='utf8'))
    LR = json.load(open('ledger_recon.json', encoding='utf8')) if os.path.exists('ledger_recon.json') else dict(records=[], missing=[])
    io = wb.create_sheet('收支總覽'); _extra_sheets.append(io)
    setup(io, [2.5, 11, 12, 11, 12, 10, 12, 12, 12, 9, 2.5, 11, 16, 12, 2.5])
    io['B2'] = '收支總覽'; io['B3'] = '收入＝薪資實際入帳（富邦存款對帳單）＋業外收入（房租、投資收入與配息〔保單配息、股利〕、存款利息、隨手記記的其他收入）；支出＝你和配偶 的刷卡（不含家人附卡、代付、回饋折抵）＋隨手記的現金＋銀行帳戶扣款（房貸、分期、固定轉帳；富邦存款對帳單）。刷卡含隨手記「暫列」（帳單還沒到）；帳戶扣款含「預估」（對帳單還沒到）。'
    import banks as _bkc
    incc = collections.defaultdict(float)   # (月份, 收入分類)
    for x in INC['salary']:
        incc[(x['date'][:7], '薪資')] += x['amount']
    for x in INC.get('other', []):
        incc[(x['date'][:7], _bkc.inc_cat(x['source']))] += x['amount']
    sal_m = collections.defaultdict(float); oth_m = collections.defaultdict(float); card_m = collections.defaultdict(float); cash_m = collections.defaultdict(float)
    for x in INC['salary']:
        sal_m[x['date'][:7]] += x['amount']
    for x in INC.get('other', []):
        oth_m[x['date'][:7]] += x['amount']
    inc_m = collections.defaultdict(float)
    for m_, v_ in list(sal_m.items()) + list(oth_m.items()):
        inc_m[m_] += v_
    for r in R:
        if r['category'] != REB:
            card_m[r['date'][:7]] += r['amount']   # 跟月報一致：分期依入帳月
    for x in INC['cash']:
        cash_m[x['date'][:7]] += x['amount']
    bank_m = collections.defaultdict(float)
    for x in INC.get('bank_out', []):
        bank_m[x['date'][:7]] += x['amount']
    for m_ in list(bank_m):
        cash_m[m_] += 0
    def exp_m(m): return card_m[m] + cash_m[m] + bank_m[m]
    _ms = [m for m in MONTHS if m <= f'{CY}-{CM:02d}' or inc_m.get(m)]
    _yr = [m for m in _ms if m[:4] == str(CY) and m <= f'{CY}-{CM:02d}']
    _ti = sum(inc_m[m] for m in _yr); _te = sum(exp_m(m) for m in _yr)
    _tiles = [(f'{CY} 1–{CM} 月收入', f'NT$ {round(_ti):,}', f'薪資 {round(sum(sal_m[m] for m in _yr)):,}・業外 {round(sum(oth_m[m] for m in _yr)):,}', '1BAF7A'),
              (f'{CY} 1–{CM} 月支出', f'NT$ {round(_te):,}', f'刷卡 {round(sum(card_m[m] for m in _yr)):,}・帳戶扣款 {round(sum(bank_m[m] for m in _yr)):,}・現金 {round(sum(cash_m[m] for m in _yr)):,}', POS),
              ('結餘', f'NT$ {round(_ti - _te):,}', '收入 − 支出', BLUE),
              ('儲蓄率', f'{(_ti - _te) / _ti * 100:.1f}%' if _ti else '–', f'月均結餘 NT$ {round((_ti - _te) / max(1, len(_yr))):,}', GOLD)]
    for k, (t, v, s_, col) in enumerate(_tiles):
        c1 = [2, 4, 6, 8][k]; c2 = [3, 5, 7, 9][k]
        card_bg(io, 6, 9, c1, c2)
        for r in range(6, 10):
            io.cell(r, c1).border = Border(left=Side(style='thick', color=col), top=thin if r == 6 else None, bottom=thin if r == 9 else None)
        io.cell(6, c1, t).font = F(9, color=MUTED); io.cell(7, c1, v).font = F(16, True, INK); io.cell(8, c1, s_).font = F(9, color=INK2)
        for r in (6, 7, 8):
            io.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
            io.cell(r, c1).alignment = Alignment(indent=1, vertical='center', shrink_to_fit=True)
    io.row_dimensions[7].height = 30; io.row_dimensions[9].height = 8
    chapter(io, 11, 2, 10, '01', '每月收支', '收入依入帳日、刷卡依消費日（分期依入帳月）歸月')
    thead(io, 12, 2, ['月份', '薪資入帳', '業外收入', '刷卡支出', '現金支出', '帳戶扣款', '總支出', '結餘', '儲蓄率'])
    r0 = 13
    for i, m in enumerate(_ms):
        r = r0 + i
        io.cell(r, 2, m.replace('-', '/') + ('*' if m in PARTIAL else ''))
        io.cell(r, 3, round(sal_m[m])); io.cell(r, 4, round(oth_m[m])); io.cell(r, 5, round(card_m[m])); io.cell(r, 6, round(cash_m[m])); io.cell(r, 7, round(bank_m[m]))
        io.cell(r, 8, f'=E{r}+F{r}+G{r}'); io.cell(r, 9, f'=C{r}+D{r}-H{r}'); io.cell(r, 10, f'=IF(C{r}+D{r}=0,"",I{r}/(C{r}+D{r}))')
        trow(io, r, 2, 10, nums=(3, 4, 5, 6, 7, 8, 9), pcts=(10,))
        io.cell(r, 2).font = F(10, name=MONO); io.cell(r, 9).font = F(10, True, name=MONO)
    rl = r0 + len(_ms) - 1; rt = rl + 1
    io.cell(rt, 2, '合計')
    for c in (3, 4, 5, 6, 7, 8, 9):
        io.cell(rt, c, f'=SUM({L(c)}{r0}:{L(c)}{rl})')
    io.cell(rt, 10, f'=IF(C{rt}+D{rt}=0,"",I{rt}/(C{rt}+D{rt}))')
    trow(io, rt, 2, 10, nums=(3, 4, 5, 6, 7, 8, 9), pcts=(10,)); ttotal(io, rt, 2, 10)
    for c in (3, 4, 5, 6, 7, 8, 9):
        io.cell(rt, c).number_format = NUM
    io.cell(rt, 10).number_format = PCT
    io.conditional_formatting.add(f'C{r0}:C{rl}', DataBarRule(start_type='num', start_value=0, end_type='max', color='1BAF7A', showValue=True))
    io.conditional_formatting.add(f'H{r0}:H{rl}', DataBarRule(start_type='num', start_value=0, end_type='max', color='E07A6E', showValue=True))
    io.conditional_formatting.add(f'I{r0}:I{rl}', CellIsRule(operator='lessThan', formula=['0'], font=Font(name=MONO, bold=True, color=POS), fill=fill('FBE7E4')))
    io.conditional_formatting.add(f'I{r0}:I{rl}', CellIsRule(operator='greaterThan', formula=['0'], font=Font(name=MONO, bold=True, color=NEG)))
    _pv = collections.defaultdict(float)
    for r_ in R:
        if r_.get('prov') and r_['category'] != REB: _pv[r_['date'][:7]] += r_['amount']
    _es = [x for x in INC.get('bank_out', []) if '預估' in (x.get('summary') or '')]
    _nt = ('；刷卡含暫列（隨手記記了、帳單還沒到）：' + '、'.join(f"{m.replace('-', '/')} NT$ {round(v):,}" for m, v in sorted(_pv.items()) if m in _ms)) if any(m in _ms for m in _pv) else ''
    _nt += ('；帳戶扣款含預估（對帳單還沒到）：' + '、'.join(f"{x['date'][:7].replace('-', '/')} {x.get('summary') or x['label']} NT$ {round(x['amount']):,}" for x in _es if x['date'][:7] in _ms)) if any(x['date'][:7] in _ms for x in _es) else ''
    io.cell(rt + 1, 2, '* 帳單還沒到齊的月份，支出會再增加' + _nt + '。1、8、12 月有年終、年中獎金，薪資較高；結餘偏低的月份多半有旅遊或保費等大額支出。').font = F(9, color=MUTED)
    ic = BarChart(); ic.type = 'col'; ic.gapWidth = 40; ic.overlap = -10
    io.cell(12, 20, '收入'); io.cell(12, 21, '支出')
    for i, m in enumerate(_ms):
        io.cell(r0 + i, 20, round(inc_m[m])); io.cell(r0 + i, 21, f'=H{r0 + i}')
    io.column_dimensions['T'].hidden = True; io.column_dimensions['U'].hidden = True
    ic.add_data(Reference(io, min_col=20, max_col=21, min_row=12, max_row=rl), titles_from_data=True)
    ic.set_categories(Reference(io, min_col=2, min_row=r0, max_row=rl))
    ic.series[0].graphicalProperties.solidFill = '1BAF7A'; ic.series[1].graphicalProperties.solidFill = 'E07A6E'
    for s_ in ic.series: s_.graphicalProperties.line.noFill = True
    ic.y_axis.numFmt = '#,##0'; ic.y_axis.majorGridlines.spPr = None; ic.legend.position = 't'; ic.height = 8.5; ic.width = 24
    ic.y_axis.delete = False; ic.x_axis.delete = False
    io.add_chart(ic, f'B{rt + 3}')
    # 收入明細
    chapter(io, 11, 12, 14, '02', '收入與帳戶支出明細')
    thead(io, 12, 12, ['日期', '項目', '金額'], ['left', 'left', 'right'])
    _incs = [(x['date'], '［薪資］' + x['payer'] + ' 薪資', x['amount']) for x in INC['salary']] + [(x['date'], f"［{_bkc.inc_cat(x['source'])}］{x['source']}", x['amount']) for x in INC.get('other', [])] + [(x['date'], '［支出］' + x['label'] + ('（預估：對帳單還沒到）' if '預估' in (x.get('summary') or '') else ''), -x['amount']) for x in INC.get('bank_out', [])]
    for i, (d_, src_, a_) in enumerate(sorted(_incs, reverse=True)):
        r = 13 + i
        io.cell(r, 12, d_.replace('-', '/')); io.cell(r, 13, src_); io.cell(r, 14, a_)
        trow(io, r, 12, 14, nums=(14,)); io.cell(r, 12).font = F(10, name=MONO)
        if a_ < 0: io.cell(r, 14).font = F(10, color=POS, name=MONO)
        elif a_ >= 200000: io.cell(r, 14).font = F(10, True, NEG, MONO)
    io.freeze_panes = 'A5'
    band(io, 15, chip=False)

    # 03 年度比較
    Y0r = rt + 22
    chapter(io, Y0r, 2, 8, '03', '年度比較', f'{CY} 年到 {CM} 月為止；同期＝每年都只看 1–{CM} 月')
    _years = sorted({m[:4] for m in _ms})
    thead(io, Y0r + 1, 2, ['年度', '月數', '薪資', '業外收入', '收入', '總支出', '結餘', '儲蓄率'])
    for i, y in enumerate(_years):
        r = Y0r + 2 + i
        ms_ = [m for m in _ms if m[:4] == y and m <= f'{CY}-{CM:02d}']
        sa_ = sum(sal_m[m] for m in ms_); ot_ = sum(oth_m[m] for m in ms_); exp_ = sum(exp_m(m) for m in ms_)
        for j, v in enumerate([y + (' *' if len(ms_) < 12 else ''), len(ms_), round(sa_), round(ot_), round(sa_ + ot_), round(exp_), round(sa_ + ot_ - exp_), (sa_ + ot_ - exp_) / (sa_ + ot_) if sa_ + ot_ else None]):
            io.cell(r, 2 + j, v)
        trow(io, r, 2, 9, nums=(3, 4, 5, 6, 7, 8), pcts=(9,)); io.cell(r, 2).font = F(10, True); io.cell(r, 8).font = F(10, True, NEG, MONO)
    rs = Y0r + 2 + len(_years) + 1
    io.cell(rs, 2, f'同期比較（1–{CM} 月）：薪資＋業外').font = F(11, True, INK)
    thead(io, rs + 1, 2, ['年度', '月數', '薪資', '業外收入', '收入', '總支出', '結餘', '薪資增減'])
    _prev = None
    for i, y in enumerate(_years):
        r = rs + 2 + i
        ms_ = [f'{y}-{k:02d}' for k in range(1, CM + 1)]
        sa_ = sum(sal_m[m] for m in ms_); ot_ = sum(oth_m[m] for m in ms_); exp_ = sum(exp_m(m) for m in ms_)
        for j, v in enumerate([y, CM, round(sa_), round(ot_), round(sa_ + ot_), round(exp_), round(sa_ + ot_ - exp_), (sa_ / _prev - 1) if _prev else None]):
            io.cell(r, 2 + j, v)
        trow(io, r, 2, 9, nums=(3, 4, 5, 6, 7, 8), dp=(9,)); io.cell(r, 2).font = F(10, True)
        _prev = sa_ or None
    # 收入組成（同期）
    rki = rs + 2 + len(_years) + 1
    io.cell(rki, 2, f'收入組成（同期 1–{CM} 月）').font = F(11, True, INK)
    thead(io, rki + 1, 2, ['分類'] + [f'{y} 1–{CM} 月' for y in _years] + (['增減', '變化'] if len(_years) >= 2 else []))
    for i, k_ in enumerate(_bkc.INC_CATS + ['收入合計']):
        r = rki + 2 + i
        vals = [sum(v for (m, c_), v in incc.items() if m[:4] == y and int(m[5:]) <= CM and (k_ == '收入合計' or c_ == k_)) for y in _years]
        io.cell(r, 2, k_)
        for j, v in enumerate(vals):
            io.cell(r, 3 + j, round(v))
        ce = 2 + len(_years)
        if len(_years) >= 2:
            io.cell(r, ce + 1, round(vals[-1] - vals[-2])); io.cell(r, ce + 2, (vals[-1] / vals[-2] - 1) if vals[-2] else None); ce += 2
        trow(io, r, 2, ce, nums=tuple(range(3, 3 + len(_years) + (1 if len(_years) >= 2 else 0))), dp=((ce,) if len(_years) >= 2 else ()))
        if k_ == '收入合計': ttotal(io, r, 2, ce)
        elif k_ == '薪資': io.cell(r, 2).font = F(10, True, '1F8A5B')
    rs = rki   # 下面的章節接在收入組成後面
    _years_k = len(_bkc.INC_CATS) + 1
    # 04 每月 × 年度
    rg = rs + 2 + _years_k + 2
    chapter(io, rg, 2, 8, '04', '每月結餘 × 年度', '同一個月份跨年對照；綠＝存下來、紅＝透支')
    thead(io, rg + 1, 2, ['月份'] + [f'{y} 結餘' for y in _years])
    for k in range(1, 13):
        r = rg + 1 + k
        io.cell(r, 2, f'{k} 月')
        for j, y in enumerate(_years):
            m = f'{y}-{k:02d}'
            io.cell(r, 3 + j, round(inc_m[m] - exp_m(m)) if (m in inc_m or m in card_m) and m <= f'{CY}-{CM:02d}' else None)
        trow(io, r, 2, 2 + len(_years), nums=tuple(range(3, 3 + len(_years))))
    io.conditional_formatting.add(f'C{rg + 2}:{L(2 + len(_years))}{rg + 13}', ColorScaleRule(start_type='min', start_color='F4B6AE', mid_type='num', mid_value=0, mid_color='FFFFFF', end_type='max', end_color='8FD1AE'))
    io.cell(rg + 15, 2, f'{int(CY) + 1} 年開始：現金支出也記在隨手記（付款方式選「現金／其他」），收支總覽就會是完整的家庭支出。').font = F(9.5, True, BLUE)
    # 05 支出分類 × 年度（刷卡＋現金）
    rc_ = rg + 18
    chapter(io, rc_, 2, 8, '05', '支出分類 × 年度', f'同期 1–{CM} 月；刷卡依帳單分類、現金依隨手記分類')
    _cy = collections.defaultdict(float)
    for r_ in R:
        if r_['category'] != REB and int(r_['date'][5:7]) <= CM:
            _cy[(r_['category'], r_['date'][:4])] += r_['amount']
    for x in INC['cash']:
        if int(x['date'][5:7]) <= CM:
            _cy[(x['category'], x['date'][:4])] += x['amount']
    for x in INC.get('bank_out', []):
        if int(x['date'][5:7]) <= CM:
            _cy[(__import__('xrows').boutcat(x), x['date'][:4])] += x['amount']   # 和月報、生活帳本同一套分類
    _cats = sorted({k[0] for k in _cy}, key=lambda c: -sum(v for (c2, y), v in _cy.items() if c2 == c and y == str(CY)))
    thead(io, rc_ + 1, 2, ['分類'] + _years + (['增減'] if len(_years) >= 2 else []))
    for i, c in enumerate(_cats):
        r = rc_ + 2 + i
        io.cell(r, 2, c)
        for j, y in enumerate(_years):
            io.cell(r, 3 + j, round(_cy[(c, y)]))
        if len(_years) >= 2:
            a_, b_ = _cy[(c, _years[-2])], _cy[(c, _years[-1])]
            io.cell(r, 3 + len(_years), (b_ / a_ - 1) if a_ > 0 else None)
        trow(io, r, 2, 3 + len(_years), nums=tuple(range(3, 3 + len(_years))), dp=(3 + len(_years),))
    io.conditional_formatting.add(f'{L(2 + len(_years))}{rc_ + 2}:{L(2 + len(_years))}{rc_ + 1 + len(_cats)}', DataBarRule(start_type='num', start_value=0, end_type='max', color='E07A6E', showValue=True))

    # ---------- 活動回饋（自己填） ----------
    ACT = json.load(open('activity.json', encoding='utf8')) if os.path.exists('activity.json') else []
    av = wb.create_sheet('活動回饋'); _extra_sheets.append(av)
    setup(av, [2.5, 11, 9, 24, 30, 12, 12, 24, 16, 2.5])
    av['B2'] = '活動回饋'; av['B3'] = '信用卡本身回饋以外的登錄活動、加碼（例如 Unicard 活動、uniopen icash Pay 加碼）。在下方黃底列填一筆，下次更新會自動對帳單看有沒有入帳。'
    _tot = sum(a['amount'] for a in ACT); _ok = sum(a['amount'] for a in ACT if a['status'] == '已入帳')
    _t3 = [('登錄的活動', f'{len(ACT)} 筆', '全部期間', BLUE), ('預計回饋', f'NT$ {round(_tot):,}', '自己填的金額', GOLD),
           ('已入帳', f'NT$ {round(_ok):,}', '帳單上找到相符的刷卡金', '1BAF7A'), ('還沒入帳', f'NT$ {round(_tot - _ok):,}', '超過 3 個月會標紅', POS)]
    for k, (t, v, s_, col) in enumerate(_t3):
        c1 = [2, 4, 6, 8][k]; c2 = [3, 5, 7, 9][k]
        card_bg(av, 6, 9, c1, c2)
        for r in range(6, 10):
            av.cell(r, c1).border = Border(left=Side(style='thick', color=col), top=thin if r == 6 else None, bottom=thin if r == 9 else None)
        av.cell(6, c1, t).font = F(9, color=MUTED); av.cell(7, c1, v).font = F(16, True, INK); av.cell(8, c1, s_).font = F(9, color=INK2)
        for r in (6, 7, 8):
            av.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2); av.cell(r, c1).alignment = Alignment(indent=1, vertical='center')
    av.row_dimensions[7].height = 30; av.row_dimensions[9].height = 8
    chapter(av, 11, 2, 9, '', '活動清單', '黃底自己填；狀態、入帳日自動判斷（點數、現金可在狀態欄自己打「已入帳」）')
    thead(av, 12, 2, ['活動月份', '銀行', '卡片', '活動名稱', '預計回饋', '形式', '備註', '狀態', '入帳日'], ['left'] * 4 + ['right'] + ['left'] * 4)
    _dvb = DataValidation(type='list', formula1='=銀行清單', allow_blank=True); _dvk = DataValidation(type='list', formula1='"刷卡金,點數,現金"', allow_blank=True)
    av.add_data_validation(_dvb); av.add_data_validation(_dvk)
    _stc = {'已入帳': NEG, '等待入帳': 'A86A00', '超過 3 個月還沒入帳': POS}
    for i in range(max(30, len(ACT) + 15)):
        r = 13 + i; a = ACT[i] if i < len(ACT) else None
        vals = [a['month'].replace('-', '/'), a['bank'], a['card'], a['name'], a['amount'], a['kind'], a['note'], a['status'], (a['paid_date'] or '').replace('-', '/')] if a else [None] * 9
        for j, v in enumerate(vals):
            c = av.cell(r, 2 + j, v); c.border = Border(bottom=hair); c.font = F(10)
            if j < 7: c.fill = fill('FFF9E6')
        av.cell(r, 6).number_format = NUM; av.cell(r, 2).number_format = '@'
        _dvb.add(f'C{r}'); _dvk.add(f'G{r}')
        if a: av.cell(r, 9).font = F(9.5, True, _stc.get(a['status'], INK2))
    av.cell(13 + max(30, len(ACT) + 15) + 1, 2, '活動月份打 2026/11 這種格式。銀行從下拉選；形式選「刷卡金」才會自動對帳單。').font = F(9, color=MUTED)
    av.freeze_panes = 'A13'
    band(av, 10, chip=False)

    # ---------- 隨手記對照 ----------
    lr = wb.create_sheet('隨手記對照'); _extra_sheets.append(lr)
    setup(lr, [2.5, 11, 9, 22, 26, 11, 13, 30, 11, 2.5])
    lr['B2'] = '隨手記對照'; lr['B3'] = '隨手記記的每一筆刷卡，和信用卡帳單逐筆比對（同銀行、金額相近、日期差 5 天內；補記的允許晚 3 週）。'
    _cnt = collections.Counter(x['status'] for x in LR['records'])
    _t2 = [('隨手記筆數', f'{len(LR["records"])} 筆', f'{LR.get("start", "").replace("-", "/")} 起', BLUE),
           ('對上帳單', f'{_cnt["對上"] + _cnt["對上（補記）"]} 筆', f'其中補記 {_cnt["對上（補記）"]} 筆', '1BAF7A'),
           ('帳單還沒到', f'{_cnt["帳單還沒到"]} 筆', '下期帳單到了再對', GOLD),
           ('帳單找不到', f'{_cnt["帳單找不到"]} 筆', '可能記錯卡、金額或日期', POS)]
    for k, (t, v, s_, col) in enumerate(_t2):
        c1 = [2, 4, 6, 8][k]; c2 = [3, 5, 7, 8][k]
        card_bg(lr, 6, 9, c1, c2)
        for r in range(6, 10):
            lr.cell(r, c1).border = Border(left=Side(style='thick', color=col), top=thin if r == 6 else None, bottom=thin if r == 9 else None)
        lr.cell(6, c1, t).font = F(9, color=MUTED); lr.cell(7, c1, v).font = F(16, True, INK); lr.cell(8, c1, s_).font = F(9, color=INK2)
        for r in (6, 7, 8):
            if c2 > c1: lr.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
            lr.cell(r, c1).alignment = Alignment(indent=1, vertical='center', shrink_to_fit=True)
    lr.row_dimensions[7].height = 30; lr.row_dimensions[9].height = 8
    chapter(lr, 11, 2, 9, '01', '隨手記 → 帳單', '紅底＝帳單找不到；黃底＝帳單還沒到')
    thead(lr, 12, 2, ['記帳日', '銀行', '隨手記卡片', '備註', '金額', '狀態', '帳單上的商家', '帳單金額'], ['left', 'left', 'left', 'left', 'right', 'center', 'left', 'right'])
    _ord = {'帳單找不到': 0, '帳單還沒到': 1, '對上（補記）': 2, '對上': 3}
    for i, x in enumerate(sorted(LR['records'], key=lambda x: (_ord.get(x['status'], 9), x['date']))):
        r = 13 + i
        for j, v in enumerate([x['date'].replace('-', '/'), '● ' + x['bank'] if x['bank'] in BANKS else x['bank'], x['card'], x['note'] or x['category'], x['amount'], x['status'],
                               x.get('bill_merchant', ''), x.get('bill_amount')]):
            lr.cell(r, 2 + j, v)
        trow(lr, r, 2, 9, nums=(6, 9))
        lr.cell(r, 2).font = F(9.5, name=MONO); lr.cell(r, 4).font = F(9, color=INK2); lr.cell(r, 8).font = F(9, color=INK2)
        lr.cell(r, 7).alignment = Alignment(horizontal='center', vertical='center')
        col = {'帳單找不到': ('FDE8E6', POS), '帳單還沒到': ('FFF6D6', 'A86A00'), '對上（補記）': ('EAF6F0', NEG), '對上': ('FFFFFF', NEG)}[x['status']]
        lr.cell(r, 7).font = F(9.5, True, col[1])
        if col[0] != 'FFFFFF':
            for c in range(2, 10): lr.cell(r, c).fill = fill(col[0])
    r = 13 + len(LR['records']) + 2
    chapter(lr, r, 2, 9, '02', '帳單有、隨手記沒記', f'{LR.get("start", "").replace("-", "/")} 之後，你和配偶 的刷卡')
    thead(lr, r + 1, 2, ['消費日', '銀行', '卡片', '商家', '金額', '分類'], ['left', 'left', 'left', 'left', 'right', 'left'])
    for i, m in enumerate(LR['missing']):
        rr = r + 2 + i
        for j, v in enumerate([m['date'].replace('-', '/'), '● ' + m['bank'], m['card'], m['merchant'], m['amount'], m['category']]):
            lr.cell(rr, 2 + j, v)
        trow(lr, rr, 2, 7, nums=(6,)); lr.cell(rr, 2).font = F(9.5, name=MONO); lr.cell(rr, 4).font = F(9, color=INK2)
    lr.freeze_panes = 'A5'
    band(lr, 10, chip=False)

# ===================== 存款與資產（各銀行存款／綜合對帳單） =====================
DEPJ = json.load(open('deposits.json', encoding='utf8')) if os.path.exists('deposits.json') else None
if DEPJ and DEPJ.get('latest'):
    dv = wb.create_sheet('存款與資產'); _extra_sheets.append(dv)
    _dbanks = sorted(DEPJ['latest'], key=lambda b: -DEPJ['latest'][b]['balance'])
    _nc = 2 + len(_dbanks) + 4
    setup(dv, [2.5, 11] + [13] * len(_dbanks) + [14, 14, 14, 11, 2.5])
    dv['B2'] = '存款與資產'
    dv['B3'] = '取自各銀行寄來的存款／綜合對帳單：帳上餘額（含外幣折台幣、投資以對帳單列示金額）、房貸餘額、利息收入。沒收到對帳單的月份沿用上一期餘額（灰字）。'
    _tot = sum(v['balance'] for v in DEPJ['latest'].values()); _loan = sum(v.get('loan', 0) for v in DEPJ['latest'].values())
    _yr = str(date.today().year)
    _iy = sum(x['amount'] for x in DEPJ.get('interest', []) if x['date'][:4] == _yr)
    _ipy = sum(x['amount'] for x in DEPJ.get('interest', []) if x['date'][:4] == str(int(_yr) - 1))
    _cards = [('目前帳上存款', f'NT$ {_tot:,.0f}', f'{len(_dbanks)} 家銀行・最新一期對帳單', BLUE),
              ('房貸／貸款餘額', f'NT$ {_loan:,.0f}', '對帳單上的貸款總計', POS),
              ('存款 − 貸款', f'NT$ {_tot - _loan:,.0f}', '不含房屋價值、保單、股票', GOLD),
              (f'{_yr} 年利息收入', f'NT$ {_iy:,.0f}', f'去年 NT$ {_ipy:,.0f}', '1BAF7A')]
    _span = max(2, (_nc - 2) // 4)
    for k, (t, v, s_, col) in enumerate(_cards):
        c1 = 2 + k * _span; c2 = min(c1 + _span - 1, _nc - 1)
        card_bg(dv, 6, 9, c1, c2)
        for r in range(6, 10):
            dv.cell(r, c1).border = Border(left=Side(style='thick', color=col), top=thin if r == 6 else None, bottom=thin if r == 9 else None)
        dv.cell(6, c1, t).font = F(9, color=MUTED); dv.cell(7, c1, v).font = F(16, True, INK); dv.cell(8, c1, s_).font = F(9, color=INK2)
        for r in (6, 7, 8):
            if c2 > c1: dv.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
            dv.cell(r, c1).alignment = Alignment(indent=1, vertical='center', shrink_to_fit=True)
    dv.row_dimensions[7].height = 30; dv.row_dimensions[9].height = 8
    # 01 每月餘額 × 銀行（新到舊）
    chapter(dv, 11, 2, _nc - 1, '01', '每月帳上餘額', '月份＝對帳單月份；灰字＝那個月沒有對帳單，沿用上一期')
    thead(dv, 12, 2, ['月份'] + [_bk.full(b) for b in _dbanks] + ['存款合計', '貸款餘額', '存款 − 貸款', '較上月'])
    _bym = {(s['bank'], s['month']): s for s in DEPJ['stmts'] if s.get('balance') is not None}
    _months = sorted({s['month'] for s in DEPJ['stmts']})
    _rows, _last = [], {}
    for mth in _months:
        vals = []
        for b in _dbanks:
            s = _bym.get((b, mth))
            if s:
                _last[b] = (s['balance'], s.get('loan', 0)); vals.append((s['balance'], False))
            else:
                vals.append((_last[b][0], True) if b in _last else (None, True))
        tot = sum(v for v, _ in vals if v is not None); loan = sum(_last[b][1] for b in _dbanks if b in _last)
        _rows.append((mth, vals, tot, loan))
    for i, (mth, vals, tot, loan) in enumerate(reversed(_rows)):
        r = 13 + i
        dv.cell(r, 2, mth.replace('-', '/'))
        for j, (v, carried) in enumerate(vals):
            dv.cell(r, 3 + j, v)
        c0 = 3 + len(_dbanks)
        dv.cell(r, c0, tot); dv.cell(r, c0 + 1, loan); dv.cell(r, c0 + 2, tot - loan)
        prev = list(reversed(_rows))[i + 1][2] if i + 1 < len(_rows) else None
        dv.cell(r, c0 + 3, (tot - prev) if prev is not None else None)
        trow(dv, r, 2, c0 + 3, nums=tuple(range(3, c0 + 4)))
        dv.cell(r, 2).font = F(9.5, name=MONO)
        for j, (v, carried) in enumerate(vals):
            if carried: dv.cell(r, 3 + j).font = F(10, color='A0A8B4', name=MONO)
        dv.cell(r, c0).font = F(10, True, INK, name=MONO)
        d = dv.cell(r, c0 + 3).value
        if d: dv.cell(r, c0 + 3).font = F(9.5, True, NEG if d > 0 else POS, name=MONO)
    # 02 利息收入
    r = 13 + len(_rows) + 2
    chapter(dv, r, 2, _nc - 1, '02', '利息收入', '對帳單交易明細的 利息／活存息／結息 存入（台幣）；也會算進「收支總覽」的其他收入')
    _yrs = sorted({x['date'][:4] for x in DEPJ.get('interest', [])}, reverse=True)
    thead(dv, r + 1, 2, ['年度'] + [_bk.full(b) for b in _dbanks] + ['合計'])
    for i, y in enumerate(_yrs):
        rr = r + 2 + i
        dv.cell(rr, 2, y)
        for j, b in enumerate(_dbanks):
            dv.cell(rr, 3 + j, sum(x['amount'] for x in DEPJ['interest'] if x['date'][:4] == y and x['bank'] == b) or None)
        dv.cell(rr, 3 + len(_dbanks), sum(x['amount'] for x in DEPJ['interest'] if x['date'][:4] == y))
        trow(dv, rr, 2, 3 + len(_dbanks), nums=tuple(range(3, 4 + len(_dbanks)))); dv.cell(rr, 3 + len(_dbanks)).font = F(10, True, INK, name=MONO)
    rr = r + 3 + len(_yrs)
    thead(dv, rr, 2, ['入帳日', '銀行', '金額'], ['left', 'left', 'right'])
    for i, x in enumerate(sorted(DEPJ.get('interest', []), key=lambda x: x['date'], reverse=True)):
        dv.cell(rr + 1 + i, 2, x['date'].replace('-', '/')); dv.cell(rr + 1 + i, 3, '● ' + x['bank'] if x['bank'] in BANKS else _bk.full(x['bank'])); dv.cell(rr + 1 + i, 4, x['amount'])
        trow(dv, rr + 1 + i, 2, 4, nums=(4,)); dv.cell(rr + 1 + i, 2).font = F(9.5, name=MONO)
    # 03 對帳單收件狀況：有對帳單的銀行都列（沒錢也列），沒寄到的月份提醒
    if DEPJ.get('status'):
        r = dv.max_row + 2
        chapter(dv, r, 2, _nc - 1, '03', '對帳單收件狀況', '每家有對帳單的銀行；紅字＝該寄沒寄到的月份（請到網銀下載，或檢查 Gmail）')
        thead(dv, r + 1, 2, ['銀行', '餘額', '最新對帳單', '狀態', '缺的月份'])
        for i, x in enumerate(DEPJ['status']):
            rr = r + 2 + i
            st = ('手動回填・要補' if x['missing'] else '手動回填・已是最新') if x.get('manual') else ('有缺件' if x['missing'] else ('已到齊' if x['regular'] else '不定期寄送'))
            dv.cell(rr, 2, _bk.full(x['bank'])); dv.cell(rr, 3, x['balance'] if x['balance'] is not None else '讀不到（需手動）')
            dv.cell(rr, 4, x['last'].replace('-', '/') if x['last'] else '—'); dv.cell(rr, 5, st)
            dv.cell(rr, 6, '、'.join(m.replace('-', '/') for m in x['missing']))
            trow(dv, rr, 2, 6, nums=(3,))
            dv.cell(rr, 5).font = F(10, True, POS if x['missing'] else ('1BAF7A' if st == '已到齊' else MUTED))
            dv.cell(rr, 6).font = F(9.5, color=POS); dv.cell(rr, 6).alignment = Alignment(shrink_to_fit=True, vertical='center')
            if x['balance'] is None: dv.cell(rr, 3).font = F(9, color=MUTED)
        if _nc - 1 > 6: dv.merge_cells(start_row=r + 1, start_column=6, end_row=r + 1, end_column=_nc - 1)
        for i in range(len(DEPJ['status'])):
            if _nc - 1 > 6: dv.merge_cells(start_row=r + 2 + i, start_column=6, end_row=r + 2 + i, end_column=_nc - 1)
    dv.freeze_panes = 'C13'
    band(dv, _nc, chip=False)

# ===================== 銀行徽章 =====================
BFULL = {b: _bk.full(b) for b in BANKS}
for ws in [ov, mo, cp, bk, cd, ip, rw, rk, ca, fx, me, rc2, kl, pf] + _extra_sheets:
    for row in ws.iter_rows():
        for c in row:
            v = c.value
            if not isinstance(v, str) or type(c).__name__ == 'MergedCell':
                continue
            if v.startswith('● ') and v[2:] in BANKS:
                i = BANKS.index(v[2:])
                c.value = BFULL[v[2:]]
                c.fill = fill(BCOL[i]); c.font = F(9.5, True, 'FFFFFF')
                c.alignment = Alignment(horizontal='center', vertical='center')
                c.border = Border(bottom=Side(style='thin', color='FFFFFF'), top=Side(style='thin', color='FFFFFF'))
            elif v in BANKS and c.font is not None and c.font.color is not None and c.font.color.rgb and c.font.color.rgb[-6:] == BCOL[BANKS.index(v)] \
                    and not (c.fill and c.fill.fgColor and c.fill.fgColor.rgb and c.fill.fgColor.rgb[-6:] == 'FFF6D6'):
                i = BANKS.index(v)
                c.fill = fill(BCOL[i]); c.font = F(9, True, 'FFFFFF'); c.alignment = Alignment(horizontal='center', vertical='center')
for rr in range(2, N + 1):
    c = tx.cell(rr, 5); i = BANKS.index(c.value)
    c.fill = fill(BTINT[i]); c.alignment = Alignment(horizontal='center')

# sheet order & tabs：常用的在前面（深色），進階的在後面（灰色）
_ex = {ws.title: ws for ws in _extra_sheets}
_core = [ov, _ex.get('收支總覽'), mo, ca, bk, cd, rw, ip, rc2, pf, _ex.get('存款與資產'), tx, kl]
_adv = [cp, me, fx, rk, _ex.get('活動回饋'), _ex.get('隨手記對照'), pt]
_core = [w for w in _core if w is not None]; _adv = [w for w in _adv if w is not None]
order = _core + _adv + [w for w in wb._sheets if w not in _core and w not in _adv and w is not hp] + [hp]
wb._sheets = order
_cc = {'總覽': NAVY, '收支總覽': '1BAF7A', '月份分析': BLUE, '消費分類': BLUE, '銀行分析': GOLD, '卡別分析': GOLD, '回饋與費用': POS,
       '分期付款': '2F6FAE', '固定支出': '2F6FAE', '代付與家人': 'A86A00', '存款與資產': '1D5C8F', '交易明細': INK2, '卡片清單': GOLD}
for ws in order:
    ws.sheet_properties.tabColor = _cc.get(ws.title, 'B0B7C2')
# 總覽右邊放「目錄」：點一下就跳到那一頁，每頁一句話說明
_DESC = {'收支總覽': '每月收入、支出、存下多少', '月份分析': '每個月刷多少、跟去年比', '消費分類': '錢花在哪些分類', '銀行分析': '各銀行刷多少、回饋多少',
         '卡別分析': '每張卡刷多少', '回饋與費用': '回饋、年費、手續費', '分期付款': '分期還剩幾期、多少錢', '固定支出': '每月固定扣款（訂閱、保費…）',
         '代付與家人': '幫別人付的、家人附卡', '存款與資產': '各銀行存款餘額', '交易明細': '每一筆刷卡（可篩選；代付欄打 ✔ 或 50%）', '卡片清單': '所有卡片、歸屬（我／家人）',
         '比較': '（進階）兩段期間比較', '商家排行': '（進階）最常消費的商家', '海外消費': '（進階）國外刷卡', '回饋核對': '（進階）有沒有刷錯卡',
         '活動回饋': '（進階）登錄活動回饋', '隨手記對照': '（進階）隨手記 vs 帳單', '點數': '（進階）各家點數'}
_c0 = ov.max_column + 2
ov.cell(2, _c0, '目錄（點名稱跳過去）').font = F(11, True, NAVY)
_r = 3
for ws in order[1:]:
    if ws.sheet_state == 'hidden':
        continue
    c = ov.cell(_r, _c0, ws.title); c.hyperlink = __import__('openpyxl').worksheet.hyperlink.Hyperlink(ref=c.coordinate, location=f"'{ws.title}'!A1", display=ws.title); c.font = F(10, True, '2F6FAE' if ws.title not in _DESC or not _DESC[ws.title].startswith('（進階）') else '7B8494')
    ov.cell(_r, _c0 + 1, _DESC.get(ws.title, '')).font = F(9, color='7B8494')
    _r += 1
ov.column_dimensions[L(_c0)].width = 12; ov.column_dimensions[L(_c0 + 1)].width = 34
# ===================== 自動調整欄寬：避免數字顯示成 ##### =====================
def _autofit(ws):
    merged = set()
    for mr in ws.merged_cells.ranges:
        for r in range(mr.min_row, mr.max_row + 1):
            for c in range(mr.min_col, mr.max_col + 1):
                merged.add((r, c))
    need = {}
    for row in ws.iter_rows():
        for c in row:
            v = c.value
            if v is None or (c.row, c.column) in merged or type(c).__name__ == 'MergedCell':
                continue
            fmt = c.number_format or 'General'
            isf = isinstance(v, str) and v.startswith('=')
            if isinstance(v, (_dt.date, _dt.datetime)) or (isf and 'yy' in fmt):
                s = '2026/12/31' + (' 23:59' if 'h' in fmt else '')
                sz = (c.font.sz if c.font and c.font.sz else 10)
                need[c.column_letter] = max(need.get(c.column_letter, 0), len(s) * sz / 10 * 1.25 + 2)
                continue
            if isinstance(v, bool) or not (isinstance(v, (int, float)) or (isf and fmt != 'General' and '@' not in fmt)):
                continue
            if isf:
                s = '−99,999,999' if '%' not in fmt else '−100.0%'      # 公式算出來的值不知道多大：預留 8 位數＋負號
            elif '%' in fmt:
                s = f'{v * 100:.1f}%'
            elif fmt == 'General':
                s = str(v)
            else:
                s = f'{v:,.{1 if ".0" in fmt else 0}f}'
            if '"' in fmt or '▲' in fmt:
                s = '▲' + s
            sz = (c.font.sz if c.font and c.font.sz else 10)
            w = len(s) * sz / 10 * 1.2 + 2
            need[c.column_letter] = max(need.get(c.column_letter, 0), w)
            al = c.alignment
            c.alignment = Alignment(horizontal=al.horizontal, vertical=al.vertical or 'center', indent=al.indent, wrap_text=False, shrink_to_fit=True)
    for col, w in need.items():
        cd_ = ws.column_dimensions[col]
        if cd_.hidden:
            continue
        cur = cd_.width or 8.43
        if w > cur:
            cd_.width = round(min(w, cur + 8), 1)   # 最多加寬 6，剩下靠「縮小字型以適合欄寬」


for ws in wb.worksheets:
    if ws.sheet_state != 'hidden':
        _autofit(ws)
for ws in wb.worksheets:   # 圖表資料放在隱藏欄（T/U 等）：要設成「隱藏的也畫」，不然 Excel 顯示空白圖
    for ch in ws._charts:
        ch.visible_cells_only = False
wb.active = 0
_out = os.environ.get('CARDFLOW_OUT', '/mnt/user-data/outputs')
_alt = os.path.join(_out, 'LifeLedger_生活總帳（新版，請關閉舊檔後改名）.xlsx')
try:
    wb.save(os.path.join(_out, os.environ.get('CARDFLOW_XLSX', 'LifeLedger_生活總帳.xlsx')))
    if os.path.exists(_alt):   # 上次因為檔案開著存成的備用檔：這次正式檔已經是最新，備用檔刪掉免得搞混
        try:
            os.remove(_alt)
        except OSError:
            pass
except PermissionError:   # Excel 檔正開著（Windows 會鎖檔）：先存成另一個檔名，不中斷月報
    wb.save(os.path.join(_out, 'LifeLedger_生活總帳（新版，請關閉舊檔後改名）.xlsx'))
    print('⚠ LifeLedger_生活總帳.xlsx 正被開著，這次存成「LifeLedger_生活總帳（新版，請關閉舊檔後改名）.xlsx」')
print('saved', N, len(merchs), len(cards))
