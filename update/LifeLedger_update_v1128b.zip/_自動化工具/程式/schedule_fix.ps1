$t = Get-ScheduledTask -TaskName 'LifeLedger Daily'
$t.Settings.StartWhenAvailable = $true
$t.Settings.DisallowStartIfOnBatteries = $false
$t.Settings.StopIfGoingOnBatteries = $false
Set-ScheduledTask -InputObject $t | Out-Null
$s = (Get-ScheduledTask -TaskName 'LifeLedger Daily').Settings
"StartWhenAvailable=$($s.StartWhenAvailable) DisallowStartIfOnBatteries=$($s.DisallowStartIfOnBatteries) StopIfGoingOnBatteries=$($s.StopIfGoingOnBatteries)"
