import subprocess,re,glob,os
from PIL import Image, ImageDraw
from html.parser import HTMLParser
os.makedirs('ctbc_strips',exist_ok=True); os.makedirs('ctbc_strips/rows',exist_ok=True)
rows_all=[]
for f in sorted(glob.glob('dec/中信__*.pdf')):
    tag=re.search(r'Estatement_(\d+)',f).group(1)
    html=subprocess.run(['pdftotext','-bbox',f,'-'],capture_output=True,text=True).stdout
    pages=html.split('<page ')[1:]
    strips=[]; n_in=0   # 列號＝「帳單期別-第幾列」：之後補進更早的帳單也不會讓舊的列號跑掉
    for pi,pg in enumerate(pages):
        W=float(re.search(r'width="([\d.]+)"',pg).group(1)); H=float(re.search(r'height="([\d.]+)"',pg).group(1))
        words=[(float(a),float(b),float(c),float(d),w) for a,b,c,d,w in re.findall(r'xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">([^<]*)<',pg)]
        # rows: two date tokens on same y
        dates=[w for w in words if re.match(r'^1[01]\d/\d\d/\d\d$',w[4])]
        used=set()
        for w in dates:
            same=[x for x in dates if abs(x[1]-w[1])<2 and x is not w]
            if not same or w[0]>same[0][0]: continue
            key=round(w[1])
            if key in used: continue
            used.add(key)
            line=[x for x in words if abs(x[1]-w[1])<2.5]
            line.sort()
            txt=' '.join(x[4] for x in line)
            if not re.search(r'\s-?[\d,]+\s',txt+' '): continue
            img=f'ctbc_img/{tag}-{pi+1}.png'
            im=Image.open(img); sx=im.width/W; sy=im.height/H
            crop=im.crop((int(same[0][2]*sx)+2,int((w[1]-3)*sy),int(W*0.62*sx),int((w[3]+3)*sy)))
            rid=f'{tag}-{n_in}'; n_in+=1
            rows_all.append((rid,txt)); strips.append((rid,crop))
            try: crop.resize((crop.width*3,crop.height*3)).save(f'ctbc_strips/rows/{rid}.png')   # 給自動文字辨識用
            except Exception: pass
    if strips:
        h=sum(c.height+6 for _,c in strips); wmax=max(c.width for _,c in strips)+90
        M=Image.new('RGB',(wmax,h),'white'); y=0; d=ImageDraw.Draw(M)
        for rid,c in strips:
            d.text((2,y+3),rid,fill='red'); M.paste(c,(88,y)); y+=c.height+6
        M=M.resize((M.width*2,M.height*2))
        M.save(f'ctbc_strips/{tag}.png')
open('ctbc_rows.txt','w').write('\n'.join(f'{a}\t{b}' for a,b in rows_all))
print(len(rows_all))
