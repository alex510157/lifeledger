import json, os

os.chdir(os.path.dirname(os.path.abspath(__file__)))
CARDINFO = {}   # 卡名請在 Excel「卡片清單」修改，下次執行會記住

try:   # 帳單上自動辨識的卡名、正附卡（分享版沒有卡片總表時靠這個；總表、Excel 改過的名稱優先）
    from cardnames import scan as _scan
    for _k, (_nm, _role, _conf) in _scan(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'txt')).items():
        if _k not in CARDINFO:
            CARDINFO[_k] = (_nm, _role or '正卡', '', '帳單自動辨識' + ('（帳單只寫卡等級）' if _conf < 3 else ''))
except Exception:
    pass

# 使用者在 Excel「卡片清單」修改過的名稱（由 sync_cards.py 從現有 Excel 讀出）
_ov = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'card_overrides.json')
if os.path.exists(_ov):
    # 舊版自動產生、後來用信用卡管理總表核對更正過的卡名：Excel 裡若還是這些舊名就不沿用
    _STALE = {'LINE Pay 信用卡（換發新卡號）', '御璽卡（年費帳務）', 'DAWAY 御璽卡（新卡號）'}
    for k, v in json.load(open(_ov, encoding='utf8')).items():
        b, l4 = k.split('|')
        if '待確認' in str(v[0]) or v[0] in _STALE:
            continue
        v = list(v)
        if v[2] in ('太太', '老婆'):   # 配偶的稱呼統一用 配偶
            v[2] = '配偶'
        CARDINFO[(b, l4)] = tuple(v)

# 卡名、正附卡、持卡人以「信用卡管理總表」為準（要改卡名請改總表）
from card_master import load as _load_master
MASTER = _load_master()
for (b, l4), m in MASTER.items():
    old = CARDINFO.get((b, l4), ('', '', '', ''))
    holder = (m['holder'] or old[2] or m['holder_tag']) if m['role'] == '附卡' else (old[2] or '')
    CARDINFO[(b, l4)] = (m['name'], m['role'], holder, '信用卡管理總表')
for _k in [k for k in CARDINFO if k[0] == '聯邦' and k[1] == '分期']:
    CARDINFO[_k] = ('M 卡保費分期（想分就分）', '—', '', '帳單「想分就分專案」區：M 卡 ·---- 刷的保費轉成分期，不是另一張卡')

# 卡片狀態（帳單上還看得到舊交易，但卡已不用）
STATUS = {}   # (銀行, 末四碼): '已停卡'
ALIAS = {}   # 卡號、效期等資料借用哪一張實體卡


# 卡片歸屬（我／家人）：預設附卡算家人；可在 Excel「卡片清單」的「歸屬」欄改，下次更新會保留
_own = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '設定', '卡片歸屬.json')
OWNER = json.load(open(_own, encoding='utf8')) if os.path.exists(_own) else {}


SPOUSE = ('太太', '老婆', '先生', '老公')   # 配偶附卡上的名字請填在 設定\local_settings.json 的 spouse_names
try:   # 設定\local_settings.json 的 "spouse_names"：配偶附卡上的名字（英文拼音），這些附卡算進自己的支出
    SPOUSE += tuple(json.load(open(os.path.join(os.path.dirname(_own), 'local_settings.json'), encoding='utf8')).get('spouse_names', []))
except Exception:
    pass


def default_owner(b, l4):
    info = CARDINFO.get((b, l4))
    if not info or info[1] != '附卡':
        return '我'
    return '我' if any(x in (info[2] or '') for x in SPOUSE) else '家人'


def owner(b, l4):
    v = OWNER.get(f'{b}|{l4}')
    return v if v in ('我', '家人') else default_owner(b, l4)


def last4(r):
    c = r['card']
    if not c:
        return '分期' if r['bank'] == '聯邦' and '想分' in r['cardname'] else '—'
    return c
def dispname(b, l4):
    info = CARDINFO.get((b, l4))
    if not info:
        return '帳戶回饋／調整' if l4 == '—' else f'{b}卡 ·{l4}'
    nm, role, holder, src = info
    extra = '・'.join(x for x in [role if role in ('附卡',) else '', holder if role == '附卡' else ''] if x)
    return nm + (f'（{extra}）' if extra else '') + (f' ·{l4}' if l4.isdigit() else '')

