# 用法: python decrypt_all.py <帳單資料夾1> [<帳單資料夾2> …]   （每個資料夾底下是各銀行的子資料夾）
# 多個資料夾都會掃（Google 雲端硬碟同步過來的、自己下載放進 OneDrive 的），同一份帳單只處理一次。
# 檔名沒有日期（例如遠東「202511 cycle-statement.pdf」）也可以：從帳單上的「結帳日」判斷。
# 文字是圖片或特殊字型、轉不出中文的帳單（遠東），自動改用 OCR（Tesseract 繁體中文）。
import sys, os, glob, re, subprocess, json, shutil, datetime, pikepdf
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from paths import setp
from banks import short
PW = json.load(open(setp('passwords.json'), encoding='utf8')) if os.path.exists(setp('passwords.json')) else {}
SKIP = re.compile(r'PaymentSlip|繳款聯|綜合對帳單|MTHLYSTMT|smime|設定繳款提醒|銀行對帳單|存款對帳單|\.ics$|\.p7s$', re.I)
os.makedirs('dec', exist_ok=True); os.makedirs('txt', exist_ok=True)


def pdftext(pdf):
    r = subprocess.run(['pdftotext', '-layout', pdf, '-'], capture_output=True)
    return r.stdout.decode('utf8', 'replace').replace('\r\n', '\n')


def unreadable(t):
    """轉出來的字幾乎沒有中文、卻有一堆亂碼 → 要 OCR"""
    s = re.sub(r'\s', '', t)
    if len(s) < 80:
        return True
    cjk = len(re.findall(r'[\u4e00-\u9fff]', s))
    return cjk / len(s) < 0.03


def tess():
    for p in [shutil.which('tesseract'), os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs', 'Tesseract-OCR', 'tesseract.exe'),
              r'C:\Program Files\Tesseract-OCR\tesseract.exe']:
        if p and os.path.exists(p):
            return p
    return None


def _bd_variants():
    """設定精靈填了生日（西元 YYYYMMDD）時，常見的帳單密碼組合也一起試：生日 8 碼、民國生日、月日、身分證後 4 碼＋月日…"""
    bd = re.sub(r'\D', '', str(PW.get('birthday') or ''))
    if len(bd) != 8:
        return []
    y, md = bd[:4], bd[4:]
    roc = str(int(y) - 1911)
    ids = [v for k, v in PW.items() if isinstance(v, str) and re.fullmatch(r'[A-Za-z]\d{9}', v)]
    out = [bd, roc.zfill(3) + md, roc + md, md, bd[2:], md + y]
    for i in ids:
        out += [i[-4:] + md, i[-4:] + bd, i.upper() + md, i[-6:], i[-4:]]
    return list(dict.fromkeys(out))


BDV = _bd_variants()


def tessdata():
    for d in [os.environ.get('TESSDATA_PREFIX', ''), os.path.join(os.environ.get('LOCALAPPDATA', ''), 'CardFlow', 'tessdata'),
              os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs', 'Tesseract-OCR', 'tessdata'), r'C:\Program Files\Tesseract-OCR\tessdata']:
        if d and os.path.isfile(os.path.join(d, 'chi_tra.traineddata')):
            return ['--tessdata-dir', d]
    return []


TD = tessdata()


def ocr(pdf, tag):
    exe = tess()
    if not exe:
        print('⚠ 這份帳單要用 OCR，但沒有安裝 Tesseract：', tag); return ''
    d = os.path.join('ocr_tmp', __import__('hashlib').md5(tag.encode('utf8')).hexdigest()[:12]); os.makedirs(d, exist_ok=True)   # 只用英數字，避免中文路徑讓 Tesseract 讀不到
    subprocess.run(['pdftoppm', '-r', '300', '-png', pdf, os.path.join(d, 'p')])
    out = []
    for img in sorted(glob.glob(os.path.join(d, 'p*.png'))):
        r = subprocess.run([exe, img, 'stdout', '-l', 'chi_tra+eng', '--psm', '6', '-c', 'preserve_interword_spaces=1'] + TD, capture_output=True)
        if r.returncode and not out:
            print('⚠ OCR 失敗（繁體中文語言檔 chi_tra 沒裝好？請重跑「安裝或換電腦」）：', r.stderr.decode('utf8', 'replace')[-200:])
        out.append(r.stdout.decode('utf8', 'replace'))
    shutil.rmtree(d, ignore_errors=True)
    return '\n\f'.join(out)


def stmt_date(fn, text, path):
    m = re.match(r'(\d{4})-(\d{2})-(\d{2})_', fn)
    if m:
        return '-'.join(m.groups())
    m = re.search(r'(?:帳單)?結帳日[^\d\n]{0,12}(\d{3,4})\s*[/年.-]\s*(\d{1,2})\s*[/月.-]\s*(\d{1,2})', text)
    if m:
        y = int(m.group(1)); y += 1911 if y < 1911 else 0
        return f'{y}-{int(m.group(2)):02d}-{int(m.group(3)):02d}'
    import generic_parse
    v = generic_parse.table_value(text, '結帳日')
    m = re.fullmatch(r'(\d{3,4})/(\d{1,2})/(\d{1,2})', v or '')
    if m:
        y = int(m.group(1)); y += 1911 if y < 1911 else 0
        return f'{y}-{int(m.group(2)):02d}-{int(m.group(3)):02d}'
    m = re.search(r'(1[01]\d)\s*年\s*(\d{1,2})\s*月', fn)        # 民國年檔名：114年12月
    if m:
        return f'{int(m.group(1)) + 1911}-{int(m.group(2)):02d}-28'
    m = re.search(r'(20\d{2})[-_ ]?(\d{2})(?!\d)', fn)
    if m and 1 <= int(m.group(2)) <= 12:
        return f'{m.group(1)}-{m.group(2)}-28'
    return datetime.date.fromtimestamp(os.path.getmtime(path)).isoformat()


import hashlib
ok = fail = 0
seen = set(); hashes = {}
NOTCARD = re.compile(r'信託處|信託財產專戶|Trust Division')   # 例如永豐員工持股信託對帳單，混在信用卡資料夾


def _drop(bank, fn):   # 同一份帳單的重複檔／不是信用卡帳單：清掉之前產生的檔案，不重複計算
    for p in [f'dec/{bank}__{fn}'] + glob.glob(f'txt/{bank}__*{re.sub(r"[^\w-]+", "_", fn[:-4])}*.txt') + glob.glob(f'txt/{bank}__{glob.escape(fn[:-4])}.txt'):
        try:
            os.remove(p)
        except OSError:
            pass

for SRC in sys.argv[1:]:
    if not os.path.isdir(SRC):
        continue
    for f in sorted(glob.glob(os.path.join(SRC, '*', '*.pdf'))):
        folder = os.path.basename(os.path.dirname(f)); fn = os.path.basename(f)
        bank = short(folder)
        if SKIP.search(fn) or folder.startswith(('_', '月報', 'Claude')) or (bank, fn) in seen:
            continue
        seen.add((bank, fn))
        try:
            h = hashlib.md5(open(f, 'rb').read()).hexdigest()
        except OSError:
            continue
        if h in hashes and hashes[h] != (bank, fn):   # 內容一模一樣的檔案（不同資料夾、不同檔名）只算一次
            _drop(bank, fn); continue
        hashes[h] = (bank, fn)
        out = f'dec/{bank}__{fn}'
        if os.path.exists(out):
            _t = [t for t in glob.glob(f'txt/{bank}__*.txt') if fn[:-4] in t or re.sub(r'[^\w-]+', '_', fn[:-4]) in t]
            if not (_t and all(os.path.getsize(t) < 200 for t in _t)):
                continue
            os.remove(out); [os.remove(t) for t in _t]; print('· 上次轉出來是空的，重新判讀：', folder, fn)
        for pw in dict.fromkeys([PW.get(folder), PW.get(bank), PW.get('default'), ''] + [v for k, v in PW.items() if k not in ('說明', 'birthday') and isinstance(v, str)] + BDV):
            if pw is None: continue
            try:
                pikepdf.open(f, password=pw).save(out); ok += 1; break
            except pikepdf.PasswordError:
                pass
        else:
            fail += 1; print('無法解密（密碼不對？）:', f); continue
        dated = re.match(r'\d{4}-\d{2}-\d{2}_', fn)
        if dated and bank in ('台新', '永豐', '玉山', '聯邦', '中信', '星展', '國泰'):
            subprocess.run(['pdftotext', '-layout', out, f'txt/{bank}__{fn[:-4]}.txt'])
        else:
            text = pdftext(out)
            if NOTCARD.search(text) and '信用卡' not in text:
                _drop(bank, fn); continue
            if unreadable(text):
                print('· OCR 判讀', folder, fn); text = ocr(out, 'o' + hashlib.md5((bank + fn).encode()).hexdigest()[:10]) or text
            sd = stmt_date(fn, text, f)
            base = fn[:-4] if dated else f'{sd}_{bank}_{re.sub(r"[^\w-]+", "_", fn[:-4])}'
            open(f'txt/{bank}__{base}.txt', 'w', encoding='utf8').write(text)
        if bank == '中信':
            tag = re.search(r'Estatement_(\d+)', fn).group(1)
            os.makedirs('ctbc_img', exist_ok=True)
            subprocess.run(['pdftoppm', '-r', '110', '-png', out, f'ctbc_img/{tag}'])
# OCR 轉出來的帳單（渣打、凱基…）：日期、金額改用 PDF 文字層裡的數字（OCR 常認錯數字），說明照用 OCR。
# 舊的文字檔也會補做一次（檔案開頭有校正標記的就略過）
import generic_parse as _gp
for t in sorted(glob.glob('txt/*.txt')):
    _b = os.path.basename(t).split('__')[0]
    if _b in ('台新', '永豐', '玉山', '聯邦', '中信', '星展', '國泰'):
        continue   # 這幾家有專屬解析，文字層本來就讀得到
    try:
        tx = open(t, encoding='utf8', errors='ignore').read()
        if tx.startswith(_gp.LAYER_MARK):
            continue
        _pdf = glob.glob(glob.escape('dec/' + os.path.basename(t)[:-4]) + '.*')
        if not _pdf:
            continue
        _raw = pdftext(_pdf[0])
        if not unreadable(_raw):
            continue   # 不是 OCR 的帳單
        _new = _gp.merge_pdf_layer(tx, _raw)
        if _new:
            open(t, 'w', encoding='utf8').write(_new); print('· 用 PDF 文字層校正金額：', os.path.basename(t))
    except Exception as e:
        print('· 文字層校正失敗（沿用 OCR）：', os.path.basename(t), e)
# 之前已轉好、但其實不是信用卡帳單的（例如永豐員工持股信託對帳單）→ 清掉，不算進消費
for t in glob.glob('txt/*.txt'):
    try:
        tx = open(t, encoding='utf8', errors='ignore').read()
    except OSError:
        continue
    if NOTCARD.search(tx) and '信用卡' not in tx:
        os.remove(t); print('· 不是信用卡帳單，略過：', os.path.basename(t))
print('新解密', ok, '失敗', fail)
