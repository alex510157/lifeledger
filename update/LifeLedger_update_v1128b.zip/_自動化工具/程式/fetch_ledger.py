# 從 LifeLedger 隨手記（Netlify 雲端）抓最新記帳 → 設定/隨手記.json
# 帳號密碼放在 設定/local_settings.json 的 "ledger"：{"url": "https://alexledger.netlify.app", "user": "…", "password": "…"}
# 只讀不寫；抓不到（沒網路、沒設定）就沿用上次的檔案
# 新版網站：用登入金鑰登入（不送密碼原文），帳本加密的話在這台電腦解開（見 ledger_client.py）
import os, json
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from paths import setp
from ledger_client import Client

S = json.load(open(setp('local_settings.json'), encoding='utf8'))
if 'ledger' not in S:   # 第一次：幫你在設定檔加好欄位，填帳號密碼就能用
    S['ledger'] = {'說明': '隨手記的帳號密碼（只存在這台電腦），每天更新時自動抓最新記帳', 'url': 'https://alexledger.netlify.app',
                   'user': '填你的隨手記帳號', 'password': '填密碼'}
    json.dump(S, open(setp('local_settings.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=1)
L = S.get('ledger') or {}
if not (L.get('url') and L.get('user') and L.get('password')) or '填' in str(L.get('user')):
    print('隨手記：local_settings.json 的 ledger 還沒填，沿用上次的資料'); raise SystemExit(0)
_enc = False
try:
    _C = Client(L)
    _rev, d, _enc = _C.get_ledger()
    d = d or {}
except Exception as e:
    _m = '帳號或密碼不對（請到 LifeLedger「⚙️ 設定 → 隨手記帳號」重新輸入跟隨手記網站一模一樣的帳號密碼）' if getattr(e, 'status', None) == 401 else str(e)
    print('隨手記：抓不到（', _m, '），沿用上次的資料')
    try:
        from paths import LOG; import datetime as _d; os.makedirs(LOG, exist_ok=True)
        open(os.path.join(LOG, '線上狀態.txt'), 'a', encoding='utf8').write(f'{_d.datetime.now():%Y-%m-%d %H:%M} 抓隨手記失敗：{_m}（{L["url"]}）\n')
    except Exception:
        pass
    raise SystemExit(0)
try:   # 完整備份（只存在這台電腦）：換隨手記網站時，在新網站「設定 → 匯入備份」選這個檔就能整份搬過去
    if d.get('records') is not None:
        json.dump(d, open(setp('隨手記_完整備份.json'), 'w', encoding='utf8'), ensure_ascii=False)
except Exception:
    pass
cards = [[c.get('id'), c.get('bank', '其他'), c.get('name', '')] for c in d.get('cards', [])]
rec = [[x.get('date'), x.get('amount'), x.get('cardId'), x.get('category', '其他'), x.get('note', ''), x.get('pay', ''), x.get('id', ''), x.get('inst') or 0, x.get('instStart') or '']
       for x in d.get('records', []) if x.get('date') and x.get('amount')]
inc = [[x.get('date'), x.get('amount'), x.get('source', '其他收入'), x.get('note', '')] for x in d.get('incomes', []) if x.get('date') and x.get('amount')]
json.dump({'cards': cards, 'rec': rec, 'inc': inc}, open(setp('隨手記.json'), 'w', encoding='utf8'), ensure_ascii=False)

# 生活帳本網頁上勾的代墊（可部分比例）→ 設定/代付標記.json（比 Excel 新的才套用）
marks = [m for m in (d.get('paidMarks') or []) if isinstance(m, dict) and m.get('k')]
# 暫列（帳單還沒到）上勾的代墊：網頁上的代號是 r+隨手記那筆的 id；記帳時勾「幫別人代墊／代刷」也算。帳單到了 income.py 會轉到帳單那筆
_pf0 = setp('代付標記.json')
_P0 = json.load(open(_pf0, encoding='utf8')) if os.path.exists(_pf0) else {'ticked': []}
_prov = dict(_P0.get('prov', {}))
for x in d.get('records', []):
    if x.get('advance') and x.get('id') and x['id'] not in _prov:
        _prov[x['id']] = [1.0, '']
    elif not x.get('advance') and x.get('id') in _prov and _prov[x['id']][1] == '':
        del _prov[x['id']]   # 記帳時勾的代墊又取消了
for m in sorted((m for m in marks if str(m['k']).startswith('r')), key=lambda m: m.get('t', '')):
    rid = m['k'][1:]
    if m.get('t', '') > (_prov.get(rid) or [0, ''])[1]:
        _prov[rid] = [max(0.0, min(1.0, float(m.get('r', 1)))), m.get('t', '')]
if _prov != _P0.get('prov', {}):
    _P0['prov'] = _prov
    json.dump(_P0, open(_pf0, 'w', encoding='utf8'), ensure_ascii=False, indent=0)
marks = [m for m in marks if not str(m['k']).startswith('r')]
# 生活帳本裡自己改的明細名稱／分類 → 設定/明細修改.json（build_data.py 套用）
_E = {}
for e in sorted((e for e in (d.get('txEdits') or []) if isinstance(e, dict) and e.get('k')), key=lambda e: e.get('t', '')):
    if e.get('del'):
        _E.pop(e['k'], None)
    elif e.get('m') or e.get('c') or e.get('n'):
        _E[e['k']] = {'m': str(e.get('m') or '')[:40], 'c': str(e.get('c') or '')[:30], 't': e.get('t', '')}
        if str(e.get('n') or '').isdigit() and 1 < int(e['n']) <= 120:   # 自己分攤 N 個月（機票、手機這類大筆）
            _E[e['k']].update(n=int(e['n']), s=str(e.get('s') or '')[:7])
json.dump(_E, open(setp('明細修改.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=0)
_RU = {}
for e in sorted((e for e in (d.get('catRules') or []) if isinstance(e, dict) and e.get('m')), key=lambda e: e.get('t', '')):
    if e.get('del') or not e.get('c'):
        _RU.pop(e['m'], None)
    else:
        _RU[str(e['m'])[:60]] = str(e['c'])[:30]
json.dump(_RU, open(setp('商家分類.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=0)
if _E:
    print(f'隨手記：生活帳本裡改過的明細 {len(_E)} 筆')
if marks:
    pf = setp('代付標記.json')
    P = json.load(open(pf, encoding='utf8')) if os.path.exists(pf) else {'ticked': []}
    tick, ratio, online = set(P.get('ticked', [])), dict(P.get('ratio', {})), dict(P.get('online', {}))
    last = P.get('online_ts', '')
    n = 0
    import hashlib   # 網頁上只有 key 的雜湊（不放卡號末四碼、商家全名），用上次的 rows.json 對回完整 key
    H = {}
    if os.path.exists('rows.json'):
        for x in json.load(open('rows.json', encoding='utf8')):
            b = str(x.get('key', '')).split('#')[0]
            if b:
                x_ = hashlib.sha1(b.encode('utf8')).hexdigest(); H['h' + x_[:6] + 'k' + x_[6:12]] = b
    for m in sorted(marks, key=lambda m: m.get('t', '')):
        if m.get('t', '') <= last:
            continue
        k = H.get(m['k'])
        if not k:
            continue
        r = max(0.0, min(1.0, float(m.get('r', 1))))
        tick.discard(k); ratio.pop(k, None)
        if r >= 0.999: tick.add(k)
        elif r > 0.001: ratio[k] = round(r, 4)
        online[k] = [r, m.get('t', '')]; last = max(last, m.get('t', '')); n += 1
    P.update({'ticked': sorted(tick), 'ratio': ratio, 'online': online, 'online_ts': last})
    json.dump(P, open(pf, 'w', encoding='utf8'), ensure_ascii=False, indent=0)
    if n: print(f'隨手記：網頁上勾的代墊 {n} 筆已套用')

# 隨手記裡回填的存款餘額（沒有電子對帳單的銀行）→ 設定/存款_隨手記.json，deposits.py 會一起算
deps = [x for x in (d.get('deposits') or []) if isinstance(x, dict) and x.get('bank') and x.get('month')]
json.dump({'balances': deps}, open(setp('存款_隨手記.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=0)
if deps: print(f'隨手記：手動回填的存款 {len(deps)} 筆')
print(f'隨手記：{len(rec)} 筆支出、{len(inc)} 筆收入、{len(cards)} 張卡（含現金）' + ('（雲端帳本已加密，在這台電腦解開）' if _enc else ''))
