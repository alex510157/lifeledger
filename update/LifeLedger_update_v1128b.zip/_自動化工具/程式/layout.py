# 帳本資料夾整理（一次性，每次更新開頭檢查）：帳單都搬到「帳單」底下
#   舊：<帳本>\<銀行>\         →  新：<帳本>\帳單\信用卡\<銀行>\
#       <帳本>\_收入\<銀行>存款\ →      <帳本>\帳單\存款對帳單\<銀行>存款\
#       <帳本>\_收入\薪資單\     →      <帳本>\帳單\薪資單\
#       <帳本>\_電子發票\        →      <帳本>\帳單\電子發票\
#   只搬看得出是帳單的資料夾（認得的銀行名稱，或裡面有 PDF）；同名檔案內容一樣就合併，不一樣就改名保留，絕不覆蓋。
#   每一筆搬動都記在 _自動化工具\紀錄\資料夾整理紀錄.txt。程式讀帳單時新、舊位置都會讀，所以搬到一半也不會漏。
import os, sys, glob, shutil, hashlib, datetime

PROG = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROG)
from paths import CARD, DEPOSIT, INVOICE, SALARY, LOG
from banks import KNOWN, short

SKIP = ('_', '月報', '帳單', 'Claude', 'CardFlow', 'LifeLedger')


def _same(a, b):
    if os.path.getsize(a) != os.path.getsize(b):
        return False
    h = lambda p: hashlib.md5(open(p, 'rb').read()).hexdigest()
    return h(a) == h(b)


def _merge(src, dst, log):
    """把 src 資料夾整個搬進 dst（dst 已經有的話逐檔合併）。回傳搬了幾個檔"""
    if not os.path.exists(dst):
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(src, dst)
        n = sum(len(fs) for _, _, fs in os.walk(dst)); log(f'搬移 {src} → {dst}（{n} 個檔）'); return n
    n = 0
    for root, _, fs in os.walk(src):
        for f in fs:
            s = os.path.join(root, f); d = os.path.join(dst, os.path.relpath(s, src))
            os.makedirs(os.path.dirname(d), exist_ok=True)
            if os.path.exists(d):
                if _same(s, d):
                    os.remove(s); log(f'重複（內容一樣，只留一份）：{s}'); continue
                base, ext = os.path.splitext(d); i = 2
                while os.path.exists(f'{base}_{i}{ext}'):
                    i += 1
                d = f'{base}_{i}{ext}'
            shutil.move(s, d); n += 1; log(f'搬移 {s} → {d}')
    for root, ds, fs in sorted(os.walk(src), key=lambda x: -len(x[0])):   # 搬空的資料夾刪掉
        try:
            os.rmdir(root)
        except OSError:
            pass
    return n


def is_bank_folder(path, name):
    if name.startswith(SKIP) or not os.path.isdir(path):
        return False
    if short(name) in KNOWN or name.endswith(('銀行', '商銀')):
        return True
    return bool(glob.glob(os.path.join(path, '*.[Pp][Dd][Ff]')))


def plan(root):
    """要搬哪些：[(來源, 目的地)]"""
    moves = []
    for d in sorted(os.listdir(root)) if os.path.isdir(root) else []:
        p = os.path.join(root, d)
        if is_bank_folder(p, d):
            moves.append((p, os.path.join(root, CARD, d)))
    inc = os.path.join(root, '_收入')
    for d in sorted(os.listdir(inc)) if os.path.isdir(inc) else []:
        p = os.path.join(inc, d)
        if os.path.isdir(p):
            moves.append((p, os.path.join(root, SALARY if '薪資' in d else os.path.join(DEPOSIT, d))))
    inv = os.path.join(root, '_電子發票')
    if os.path.isdir(inv):
        moves.append((inv, os.path.join(root, INVOICE)))
    return moves


def migrate(root, log=print):
    """搬到新版面。回傳搬了幾個檔；已經是新版面就什麼都不做"""
    moves = plan(root)
    if not moves:
        return 0
    os.makedirs(LOG, exist_ok=True)
    lines = []

    def L(s):
        lines.append(s)
    total = 0
    for s, d in moves:
        try:
            total += _merge(s, d, L)
        except Exception as e:
            L(f'⚠ 搬不動 {s}：{e}（下次更新會再試；程式新、舊位置都會讀，不影響月報）')
    inc = os.path.join(root, '_收入')
    for p in (inc,):
        try:
            os.rmdir(p)   # 空了才刪
        except OSError:
            pass
    with open(os.path.join(LOG, '資料夾整理紀錄.txt'), 'a', encoding='utf8') as f:
        f.write(f'==== {datetime.datetime.now():%Y-%m-%d %H:%M:%S} 帳單搬到「帳單」資料夾 ====\n' + '\n'.join(lines) + '\n')
    log(f'整理帳本資料夾：帳單都搬到「帳單」底下（{len(moves)} 個資料夾、{total} 個檔；紀錄在 紀錄\\資料夾整理紀錄.txt）')
    return total


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    import json
    from paths import setp, HOME
    S = json.load(open(setp('local_settings.json'), encoding='utf8')) if os.path.exists(setp('local_settings.json')) else {}
    r = S.get('out') or HOME
    if '--plan' in sys.argv:
        for s, d in plan(r):
            print(s, '→', d)
    else:
        migrate(r)
