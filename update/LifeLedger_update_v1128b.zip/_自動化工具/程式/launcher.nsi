﻿; LifeLedger.exe：桌面捷徑用的小啟動程式（由 make_share.py 編譯）
; 找到這台電腦的 pythonw.exe（沒有黑色視窗的 Python），打開 程式\LifeLedger.pyw，自己馬上結束
Unicode true
ManifestDPIAware true
!ifndef OUT
  !define OUT "LifeLedger.exe"
!endif
!ifdef ICON
  Icon "${ICON}"
!endif
Name "LifeLedger 生活總帳"
OutFile "${OUT}"
RequestExecutionLevel user
SilentInstall silent
VIProductVersion "1.0.0.0"
VIAddVersionKey /LANG=0 "ProductName" "LifeLedger 生活總帳"
VIAddVersionKey /LANG=0 "FileDescription" "LifeLedger 生活總帳"
VIAddVersionKey /LANG=0 "FileVersion" "1.0"
VIAddVersionKey /LANG=0 "LegalCopyright" "LifeLedger"

!macro TRY KEY VER
  StrCmp $0 "" 0 +4
  ReadRegStr $0 ${KEY} "Software\Python\PythonCore\${VER}\InstallPath" "WindowedExecutablePath"
  IfFileExists "$0" +2 0
  StrCpy $0 ""
!macroend
!macro TRYFILE P
  StrCmp $0 "" 0 +3
  IfFileExists "${P}" 0 +2
  StrCpy $0 "${P}"
!macroend

Section
  StrCpy $0 ""
  !insertmacro TRY HKCU 3.13
  !insertmacro TRY HKCU 3.12
  !insertmacro TRY HKCU 3.11
  !insertmacro TRY HKLM 3.13
  !insertmacro TRY HKLM 3.12
  !insertmacro TRY HKLM 3.11
  !insertmacro TRYFILE "$LOCALAPPDATA\Programs\Python\Python313\pythonw.exe"
  !insertmacro TRYFILE "$LOCALAPPDATA\Programs\Python\Python312\pythonw.exe"
  !insertmacro TRYFILE "$LOCALAPPDATA\Programs\Python\Python311\pythonw.exe"
  !insertmacro TRYFILE "$PROGRAMFILES64\Python313\pythonw.exe"
  !insertmacro TRYFILE "$PROGRAMFILES64\Python312\pythonw.exe"
  !insertmacro TRYFILE "$PROGRAMFILES64\Python311\pythonw.exe"
  !insertmacro TRYFILE "$WINDIR\pyw.exe"
  !insertmacro TRYFILE "$LOCALAPPDATA\Programs\Python\Launcher\pyw.exe"
  StrCmp $0 "" 0 found
  MessageBox MB_ICONEXCLAMATION "這台電腦還沒裝好 LifeLedger 需要的 Python。$\r$\n$\r$\n請重新執行 LifeLedger 安裝檔（會自動安裝需要的工具）。"
  Quit
  found:
  SetOutPath "$EXEDIR\程式"
  Exec '"$0" "$EXEDIR\程式\LifeLedger.pyw"'
SectionEnd
