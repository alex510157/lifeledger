# LifeLedger 子分類：把大分類再拆細，看清楚錢真正花在哪
#   交通 → 加油／停車／過路費／大眾運輸；旅遊 → 機票／住宿／票券行程／當地交通…
#   網購 → 用「電子發票明細」（財政部雲端發票，蝦皮、PChome、momo 都有品名）判斷買的是 3C、食品、玩具…
#   發票明細來源：帳本資料夾\帳單\電子發票\*.csv（舊版面：_電子發票）
#     (1) 財政部「消費發票彙整通知」信的附件（從信箱自動收）
#     (2) 自己到 財政部電子發票整合服務平台 → 載具 → 消費查詢 → 匯出（可以一次補一整年）
import os, re, glob, datetime, collections
try:
    from paths import invoice_dirs
except ImportError:   # 舊版 paths.py
    invoice_dirs = lambda r: [os.path.join(r, '_電子發票')]

SUB_RULES = {
    '交通停車加油': [
        ('加油', r'中油|加油|COSMO|石油|台塑|全國加油|ENEOS|SHELL|油品'),
        ('停車', r'停車|Autopass|嘟嘟房|iParking|PARKING|Parking|車旅|永固便利|uTagGo'),
        ('過路費 eTag', r'eTag|ETAG|ETC|NEXCO|高速公路|遠通'),
        ('悠遊卡加值', r'悠遊卡自動加值|悠遊卡加值|一卡通.{0,6}加值|icash.{0,6}加值|愛金卡.{0,6}加值'),
        ('大眾運輸', r'高鐵|台鐵|捷運|悠遊卡|捷利卡|一卡通|UBER|Uber|計程車|TAXI|Taxi|公車|客運|EasyWay'),
    ],
    '旅遊住宿': [
        ('機票', r'航空|虎航|EVA AIR|e Ticket|AIRLINE|Airline|樂桃|PEACH|酷航|SCOOT|捷星|JETSTAR|AIRASIA'),
        ('住宿', r'HOTEL|Hotel|酒店|飯店|福朋|喜來|Hyatt|Hotels\.com|HCOM|HOTELCOM|AGODA|Agoda|GUESTHOU|PRINCE|RESORT|RIZOTO|旅店|INTERCONTINENT|天合|民宿|Airbnb|AIRBNB|LENTO|YATSUPARISUTE|STUDIO CITY|INN\b|HOSTEL'),
        ('票券行程', r'KK ?day|Klook|客路|門票|ticket|Ticket|樂園|DISNEY|USJ|Flickket|美術館|博物館'),
        ('當地交通／租車', r'RENT-A-CAR|租車|機場接送|貴賓專接|Grab|全鋒|共樂遊|SHUTTLE|Shuttle|JR\b|RAILWAY|MOBILITY'),
        ('簽證／網卡', r'E-VISA|VISA|eSIM|DJB|AsiaWiFi|saily|WiFi|SIM'),
        ('機場服務', r'機場貴賓|貴賓室|LOUNGE|Lounge|CHITOSE AIRPORT|AIRPORT'),
        ('旅行社／套裝', r'易遊網|酷遊天|旅行社|TRIP\.COM|Trip\.com|雄獅|可樂旅遊|東南旅'),
    ],
    '汽車保養': [   # 大分類「汽車保養」報表上顯示成「汽機車・購車」「汽機車・保養維修」
        ('購車', r'車業|機車行|機車股份|摩托車|KYMCO|Kymco|光陽|SYM|三陽工業|YAMAHA|Yamaha|山葉|Gogoro(?! ?Network)|睿能|PGO|摩特動力|宏佳騰|TESLA|Tesla|特斯拉|裕隆|和泰汽車|國瑞汽車|中華汽車|汽車商行|中古車|二手車|購車|買車|新車|交車'),
    ],
}
SUB_DEFAULT = {'交通停車加油': '其他交通', '旅遊住宿': '當地消費', '汽車保養': '保養維修'}

# 網購：依發票品名判斷（每個關鍵字 1 分，~ 開頭 0.5 分，分數最高的類別勝；同分取前面的）
ITEM_CLASSES = [
    ('禮券票券', '即享券|禮券|好禮即享|兌換券|電子票|票券|序號|點數卡|儲值金|商品卡|提貨卡|禮物卡|GIFT CARD'),
    ('玩具母嬰', '玩具|水槍|積木|樂高|LEGO|畫板|拼圖|兒童|寶寶|嬰兒|嬰幼|尿布|拉拉褲|幫寶適|奶瓶|奶粉|童裝|浴盆|巧虎|公仔|扭蛋|桌遊|繪本|故事書|安撫|學步|陀螺|寶可夢|Pokemon|皮卡丘|娃娃|玩偶|模型|黏土|貼紙書'),
    ('手機配件', '手機殼|保護殼|保護貼|玻璃貼|貼膜|螢幕貼|保護膜|鋼化|充電線|傳輸線|充電頭|充電器|快充|行動電源|磁吸|MagSafe|Qi2|錶帶|手機架|~支架|~適用|AirTag|充電座|充電盤|無線充|Qi2'),
    ('3C家電', '路由器|WiFi|Wi-Fi|耳機|藍牙|~Apple Watch|~AirPods|~iPad|MacBook|筆電|電腦|螢幕|顯示器|鍵盤|滑鼠|延長線|GaN|Xiaomi|小米|ASUS|華碩|吸塵器|電視|相機|SSD|記憶卡|硬碟|喇叭|音響|家電|電扇|風扇|除濕|清淨機|電鍋|微波|烤箱|咖啡機|吹風機|刮鬍|電動牙刷|印表機|墨水|HDMI|USB|Switch|PS5|遊戲片|~iPhone|對拷|NVMe|M.2|CarPlay|Android Auto'),
    ('食品飲料', '氣泡水|礦泉水|巧克力|洋芋片|零食|米餅|米菓|餅乾|咖啡豆|濾掛|茶包|茶葉|飲料|蜜餞|堅果|纖果|泡麵|白米|肉乾|果乾|果汁|牛奶|奶茶|食品|罐頭|調味|醬|麵條|保健|維他命|益生菌|膠囊|雞精|零嘴|糖|凍乾|水果乾|優格|豆漿|氣泡|礦沛|咖啡|拿鐵|麵包|餐包|餅'),
    ('服飾美妝', '上衣|T恤|外套|褲|裙|鞋|襪|帽|背包|包包|皮夾|保養|面膜|乳液|精華液|防曬|洗面|洗髮|沐浴|化妝|口紅|香水|內衣'),
    ('運動戶外', '跳繩|瑜珈|運動|健身|啞鈴|露營|登山|自行車|單車|球拍|泳鏡|泳衣|滑板車|滑板|直排輪|腳踏車'),
    ('居家生活', '凳|椅|桌|收納|置物|層板|隔板|掛牆|掛墻|除垢|除鈣|清潔|洗衣|衛生紙|毛巾|寢具|枕|棉被|床|窗簾|燈|浴室|廚房|鍋|杯|碗|盤|垃圾|拖把|香氛|擴香|地墊|花瓶|裝飾|~架|水龍頭|蓮蓬頭|花灑|過濾器|濾芯|時鐘|電子鐘|鬧鐘|削皮|去皮|泡麵碗|便當碗|收納箱|收納袋|BOX|BAG'),
    ('工具五金', '工具|螺絲|五金|膠帶|電鑽|扳手|鉗|量尺|水電|DIY|車用|汽車|機車|雨刷|輪胎|洗車'),
]
_IC = [(n, [(k.lstrip('~'), 0.5 if k.startswith('~') else 1.0) for k in p.split('|')]) for n, p in ITEM_CLASSES]
NOT_ITEM = re.compile(r'折扣|折價|優惠券|蝦幣|運費|手續費|購物金|紅利折抵|^\s*$')
ONLINE_SELLER = [('蝦皮', r'蝦皮'), ('PChome', r'網路家庭|PChome'), ('momo', r'富邦媒體|momo'), ('Yahoo', r'雅虎|Yahoo'), ('博客來', r'博客來'), ('露天', r'露天')]
CARD_SELLER = {'蝦皮': r'蝦皮|SHOPEE|樂購', 'PChome': r'PCHOME|PChome', 'momo': r'momo|MOMO', 'Yahoo': r'Yahoo|YAHOO', '博客來': r'博客來', '露天': r'露天'}
MERCHANT_SUB = [('3C家電', r'蘋果電腦|Apple|小米|Xiaomi|神腦|燦坤|全國電子|順發|STUDIO ?A|德誼|傑昇|地標網通|iPhone|iPad|MacBook'), ('禮券票券', r'可創活動|票'), ('娛樂', r'疾風匣|ASPOR'), ('其他', r'房屋')]
NO_INVOICE = '未分類（沒有發票明細）'
VOUCHER = re.compile(r'商品卡|提貨卡|禮贈|禮券|即享券|星享券|電票|誠券|商品券|禮物卡')   # 用禮券／商品卡折抵的那一行
# 可以用悠遊卡、一卡通、icash 付的店：小額發票對不到刷卡，多半是用卡片餘額付的（加值時已經算過）
EZ_STORE = re.compile(r'統一超商|全家|萊爾富|來來|OK|全聯|和德昌|麥當勞|星巴克|悠旅|統一多拿滋|85度C|摩斯|康是美|屈臣氏|寶雅|捷運|停車|嘟嘟房|台灣大車隊|康達盛通|家樂福|新東陽|松深|丸龜|爭鮮|善商')


def item_class(name):
    best, bs = '其他', 0.0
    nl = (name or '').lower()
    for n, kws in _IC:
        sc = sum(w for k, w in kws if k and k.lower() in nl)
        if sc > bs:
            best, bs = n, sc
    return best


def note_class(note):
    """隨手記備註寫了買什麼（例如「手機殼」「尿布」「麥當勞即享券」）→ 直接用備註分；分不出來回 None"""
    if not note:
        return None
    c = item_class(note)
    return None if c == '其他' else c


def _read(f):
    for enc in ('utf-8-sig', 'cp950', 'big5'):
        try:
            return open(f, encoding=enc).read()
        except Exception:
            pass
    return ''


def _parse_file(txt):
    """一個發票檔 → {發票號碼: 表頭}, {發票號碼: [(品名, 金額)]}。兩種財政部格式都吃：
    (1) 彙整通知附件：M 表頭／D 明細，用 | 分隔　(2) 平台「載具發票明細下載」：逗號分隔，一列一個品項"""
    fm, fd = {}, collections.defaultdict(list)
    if txt.lstrip().startswith('載具'):
        import csv, io
        rows = list(csv.reader(io.StringIO(txt)))
        h = rows[0] if rows else []
        try:
            ix = {k: h.index(k) for k in ('發票日期', '發票號碼', '發票狀態', '賣方名稱', '消費明細_金額', '消費明細_品名')}
        except ValueError:
            return fm, fd
        ia = h.index('賣方地址') if '賣方地址' in h else len(h)
        for p in rows[1:]:
            if len(p) > len(h):   # 地址裡有沒加引號的逗號：地址之後的欄位往後移
                sh = len(p) - len(h)
                p = p[:ia] + [','.join(p[ia:ia + sh + 1])] + p[ia + sh + 1:]
            if len(p) <= max(ix.values()) or not re.fullmatch(r'[A-Z]{2}\d{8}', p[ix['發票號碼']].strip()):
                continue
            no, dt = p[ix['發票號碼']].strip(), p[ix['發票日期']].strip()
            try:
                a = float(p[ix['消費明細_金額']] or 0)
            except ValueError:
                continue
            m = fm.setdefault(no, {'date': f'{dt[:4]}-{dt[4:6]}-{dt[6:8]}', 'seller': p[ix['賣方名稱']], 'total': 0.0, 'void': False})
            m['total'] += a; m['void'] = m['void'] or '作廢' in p[ix['發票狀態']]
            fd[no].append((p[ix['消費明細_品名']].strip(), a))
        return fm, fd
    for l in txt.splitlines():
        p = l.split('|')
        try:
            if p[0] == 'M' and len(p) >= 8:
                fm[p[6]] = {'date': f'{p[3][:4]}-{p[3][4:6]}-{p[3][6:8]}', 'seller': p[5], 'total': float(p[7] or 0), 'void': '作廢' in (p[8] if len(p) > 8 else '')}
            elif p[0] == 'D' and len(p) >= 4:
                fd[p[1]].append((p[3], float(p[2] or 0)))
        except ValueError:
            pass
    return fm, fd


def load_invoices(roots, online_only=True):
    """讀 帳本資料夾\\_電子發票 裡所有發票檔。同一張發票出現在好幾個檔（期間重疊）只算一次；之後的檔標作廢就改成作廢。
    online_only=True：只回蝦皮、PChome、momo… 網購（用來分網購子分類）；False：所有店家（用來幫每筆消費找品項明細）"""
    M, D = {}, {}
    for r in roots:
        for f in sorted(x for d in invoice_dirs(r) for x in glob.glob(os.path.join(d, '**', '*.csv'), recursive=True)):
            fm, fd = _parse_file(_read(f))
            for no, m in fm.items():
                if no not in M:
                    M[no] = m; D[no] = fd.get(no, [])
                elif m['void']:
                    M[no]['void'] = True
    out = []
    for no, m in M.items():
        if m['void']:
            continue
        shop = next((s for s, rx in ONLINE_SELLER if re.search(rx, m['seller'])), None)
        if online_only and not shop:
            continue
        items = [(n, a) for n, a in D.get(no, []) if a > 0 and not NOT_ITEM.search(n)]
        if not items:
            continue   # 只有手續費／運費：通常是你「賣東西」的發票，不是買東西
        vouch = sum(-a for n, a in D.get(no, []) if a < 0 and VOUCHER.search(n))
        score = collections.Counter()
        for n, a in items:
            c = item_class(n)
            if a >= 3000 and c != '3C家電' and any(k in n for k, _ in dict(_IC)['3C家電']):
                c = '3C家電'   # 單價高、又有 3C 字眼（例如 Apple Watch 本體）→ 3C，不是配件
            score[c] += a
        out.append({'no': no, 'date': m['date'], 'shop': shop, 'seller': m['seller'], 'total': m['total'], 'cls': score.most_common(1)[0][0],
                    'items': [n for n, _ in items][:3], 'vouch': vouch})
    return out


def _d(s):
    return datetime.date.fromisoformat(s[:10])


def assign(rows, roots):
    """幫每一筆資料列加上 sub（子分類）。網購用發票明細配對（同一家、金額相同、日期接近）"""
    for r in rows:
        cat = r.get('category')
        d = r.get('desc', '') + ' ' + r.get('merchant', '')
        if cat in SUB_RULES:
            r['sub'] = next((n for n, rx in SUB_RULES[cat] if re.search(rx, d)), SUB_DEFAULT.get(cat, '其他'))
        elif cat == '網購':
            r['sub'] = next((n for n, rx in MERCHANT_SUB if re.search(rx, d)), None) or note_class(r.get('memo'))
        else:
            r['sub'] = ''
    inv = load_invoices(roots)
    used, hit = set(), 0
    for r in sorted((r for r in rows if r.get('category') == '網購' and r.get('sub') is None and r.get('amount', 0) > 0), key=lambda r: r.get('txn_date') or r['date']):
        d = r.get('desc', '') + ' ' + r.get('merchant', '')
        shop = next((s for s, rx in CARD_SELLER.items() if re.search(rx, d)), None)
        try:
            td = _d(r.get('txn_date') or r['date'])
        except Exception:
            continue
        cands = [i for i in inv if i['no'] not in used and i['shop'] == shop and -3 <= (td - _d(i['date'])).days <= 7]
        one = next((i for i in sorted(cands, key=lambda i: abs((td - _d(i['date'])).days)) if abs(i['total'] - r['amount']) <= 1), None)
        pick = [one] if one else []
        if not pick:   # 一次結帳拆成好幾張發票：同一天的發票加起來剛好等於刷卡金額
            byday = collections.defaultdict(list)
            for i in cands:
                byday[i['date']].append(i)
            for day, g in byday.items():
                if 2 <= len(g) <= 6 and abs(sum(i['total'] for i in g) - r['amount']) <= 1:
                    pick = g; break
        if pick:
            for i in pick:
                used.add(i['no'])
            sc = collections.Counter()
            for i in pick:
                sc[i['cls']] += i['total']
            r['sub'] = sc.most_common(1)[0][0]; r['sub_items'] = '、'.join(sum((i['items'] for i in pick), []))[:80]
            r['inv_no'] = ','.join(i['no'] for i in pick)
            hit += 1
        else:
            r['sub'] = NO_INVOICE
    for r in rows:
        if r.get('sub') is None:
            r['sub'] = NO_INVOICE
    hit += match_all(rows, roots, used)
    return hit, len(inv)


_ALIAS = [(r'7-?ELEVEN|7-?11|統一超商|ibon', '統一超商'), (r'全家|FAMILY', '全家'), (r'全聯|PX', '全聯'), (r'麥當勞|MCDONALD', '和德昌'),
          (r'IKEA|宜家', '宜家'), (r'家樂福|CARREFOUR', '家福'), (r'COSTCO|好市多', '好市多'), (r'中油|CPC', '中油'), (r'嘟嘟房', '嘟嘟房'),
          (r'中華電信|電話費|11411', '中華電信'), (r'LALAPORT|三井|MITSUI', '三井'), (r'CITYLINK', '潤泰'), (r'台電|電費', '台灣電力'), (r'自來水|水費', '自來水'), (r'路易莎|LOUISA', '路易莎'), (r'星巴克|STARBUCKS', '星巴克'), (r'壽司郎', '壽司郎'), (r'UNIQLO', '優衣庫')]
_GENERIC = re.compile(r'股份|有限|公司|分公司|台灣|臺灣|台北|臺北|新北|門市|營業|事業|國際|實業|企業|商店|連加|街口|全支付|LINE ?PAY|\*|\s')


_PAYWALL = re.compile(r'LINE ?PAY|LINEPAY|街口|全支付|綠界|藍新|悠遊付|icash ?Pay|PX ?Pay|歐付寶|台灣Pay|TWQR|Pi 拍錢包|連加|連支|OPEN錢包', re.I)
_PARKPAY = re.compile(r'Autopass|uTagGo|USPACE|停車', re.I)   # 用 ETC／停車 App 付的停車費：發票店名是停車場公司


def _names_match(card, seller, items=''):
    for rx, key in _ALIAS:
        if re.search(rx, card, re.I) and key in seller:
            return True
    c = _GENERIC.sub('', card).upper(); sl = _GENERIC.sub('', seller).upper()
    cj = [c[i:i + 2] for i in range(len(c) - 1) if all('\u4e00' <= ch <= '\u9fff' for ch in c[i:i + 2])]
    asc = re.findall(r'[A-Z]{4,}', c)
    it = _GENERIC.sub('', items).upper()
    if _PARKPAY.search(card) and '停車' in seller + items:
        return True
    return any(x in sl or x in it for x in cj) or any(x in sl or x in it for x in asc)


def match_all(rows, roots, used=None):
    """每一筆刷卡消費（不只網購）都去找同金額、日期相近的發票，把發票上的品項帶過來（sub_items）。
    交通、旅遊再用品項修正子分類（例如帳單只寫支付平台，發票寫「停車費」→ 停車）"""
    used = set(used or ())
    inv = [i for i in load_invoices(roots, online_only=False) if i['no'] not in used]
    n0 = match_installments(rows, inv, used)
    byamt = collections.defaultdict(list)
    for i in inv:
        byamt[round(i['total'])].append(i)
    n = 0
    for phase in (0, 1):   # 先配店名對得上的，再配「支付平台＋同一天同金額」的
      for r in sorted((r for r in rows if r.get('kind') == 'spend' and not r.get('sub_items') and (r.get('amount') or 0) >= 20),
                      key=lambda r: r.get('txn_date') or r['date']):
          try:
              td = _d(r.get('txn_date') or r['date'])
          except Exception:
              continue
          card = (r.get('merchant') or '') + ' ' + (r.get('desc') or '')
          a = round(r['amount'])
          online = bool(re.search('|'.join(CARD_SELLER.values()), card))
          lo, hi = (-10, 7) if online else (-1, 3)   # 網購的發票常在刷卡後幾天才開
          near = [i for k in (a - 1, a, a + 1) for i in byamt.get(k, []) if i['no'] not in used and min(lo, -5) <= (td - _d(i['date'])).days <= max(hi, 5)]
          # 店名對得上的放寬到前後 5 天（電信費、有線電視：信用卡代扣日跟發票日常差幾天）
          named = sorted((i for i in near if _names_match(card, i['seller'], ' '.join(i['items']))), key=lambda i: abs((td - _d(i['date'])).days))
          cands = [i for i in near if lo <= (td - _d(i['date'])).days <= hi]
          if not named and not cands:
              if phase == 1:   # 同一天好幾家合併扣一筆（例如長德 348 ＋ 中嘉 699 = 1,047）
                  pool = [i for i in inv if i['no'] not in used and abs((td - _d(i['date'])).days) <= 2 and i['total'] < a]
                  pick2 = None
                  for x in range(len(pool)):
                      for y in range(x + 1, len(pool)):
                          g2 = [pool[x], pool[y]]
                          if abs(sum(i['total'] for i in g2) - a) <= 1 and any(_names_match(card, i['seller'], ' '.join(i['items'])) for i in g2):
                              pick2 = g2; break
                      if pick2:
                          break
                  if pick2:
                      for i in pick2:
                          used.add(i['no'])
                      n += 1
                      r['sub_items'] = '、'.join(sum((i['items'] for i in pick2), []))[:80]; r['inv_no'] = ','.join(i['no'] for i in pick2)
              continue
          weak = _PAYWALL.search(card)   # 帳單只寫支付平台（LINE Pay、街口…）、看不出店名
          same = [i for i in cands if i['date'] == td.isoformat()]
          pick = named[0] if named else (
              same[0] if weak and len(same) == 1 and a >= 30 else        # 支付平台、同一天、同金額只有一張
              cands[0] if weak and len(cands) == 1 and a >= 100 and abs((td - _d(cands[0]['date'])).days) <= 1 else None)
          if not pick:
              continue
          used.add(pick['no']); n += 1
          r['sub_items'] = '、'.join(pick['items'])[:80]; r['inv_no'] = pick['no']
          cat = r.get('category')
          if cat in SUB_RULES and r.get('sub') == SUB_DEFAULT.get(cat):
              t = ' '.join(pick['items']) + ' ' + pick['seller']
              r['sub'] = next((nm for nm, rx in SUB_RULES[cat] if re.search(rx, t)), r['sub'])
          elif cat == '網購' and r.get('sub') == NO_INVOICE:
              r['sub'] = pick['cls']
    return n + n0


def match_installments(rows, inv, used):
    """分期：發票是總額（例如神腦 iPhone 46,500），帳單是每期（15,500 × 3）。
    同一筆分期（同卡、同消費日、同期數）找「每期金額 × 期數 ≈ 發票總額」的發票；網購的發票常在出貨時才開，最晚可到刷卡後 75 天"""
    grp = collections.defaultdict(list)
    for r in rows:
        if r.get('kind') == 'spend' and r.get('installment') and r.get('inst_N') and (r.get('amount') or 0) > 0:
            grp[(r['bank'], r.get('cardname'), r.get('txn_date') or r['date'], int(r['inst_N']), r.get('merchant'))].append(r)
    n = 0
    for (bank, card, td, N, mer), rs in sorted(grp.items(), key=lambda kv: kv[0][2]):
        if N < 2 or any(r.get('inv_no') for r in rs):
            continue
        try:
            d0 = _d(td)
        except Exception:
            continue
        per = max(r['amount'] for r in rs)
        text = (rs[0].get('merchant') or '') + ' ' + (rs[0].get('desc') or '')
        cands = [i for i in inv if i['no'] not in used and abs(i['total'] / N - per) <= max(5, N) and -3 <= (_d(i['date']) - d0).days <= 75
                 and ((i['shop'] and re.search(CARD_SELLER.get(i['shop'], '^$'), text)) or _names_match(text, i['seller'], ' '.join(i['items'])))]
        if not cands:
            continue
        pick = min(cands, key=lambda i: (abs(i['total'] / N - per), abs((_d(i['date']) - d0).days)))
        used.add(pick['no']); n += 1
        for r in rs:
            r['sub_items'] = '、'.join(pick['items'])[:80]; r['inv_no'] = pick['no']
            if r.get('category') == '網購':
                r['sub'] = pick['cls']
    return n


def gaps(rows, roots, recs, cover_until, start='', ignore=()):
    """把每張發票分到：
       cash   帳上找不到 → 多半是現金
       ez     帳上找不到、但是能用悠遊卡／禮券付的小額店家，而且你有悠遊卡自動加值 → 用卡片餘額付的，加值時已經算過，不要再記
       recent 比最近一期帳單還新 → 帳單可能還沒到
       另外回傳 matched：已經對上的（刷卡哪一筆、或隨手記）"""
    byno = {}
    for r in rows:
        for n in str(r.get('inv_no') or '').split(','):
            if n and n not in byno:
                byno[n] = r
    ign = set(ignore)
    R = [(_d(d), float(a)) for d, a in recs if d and a]
    has_ez = any('加值' in (r.get('merchant', '') + r.get('desc', '')) and re.search(r'悠遊|一卡通|icash|愛金', r.get('merchant', '') + r.get('desc', '')) for r in rows)
    out, matched = [], []
    for i in load_invoices(roots, online_only=False):
        if start and i['date'][:7] < start:
            continue
        seller = re.sub(r'股份有限公司|有限公司|股份公司', '', i['seller']).strip()
        base = {'no': i['no'], 'date': i['date'], 'seller': seller, 'total': round(i['total']), 'items': '、'.join(i['items'])[:80], 'cls': i['cls']}
        r = byno.get(i['no'])
        if r:
            matched.append(dict(base, via='card', card=r.get('cardname', ''), rdate=r.get('txn_date') or r['date'], ramount=round(r['amount']),
                                inst=(f"{r.get('inst_N')} 期" if r.get('installment') and r.get('inst_N') else '')))
            continue
        if i['no'] in ign or i['total'] < 10:
            continue
        dd = _d(i['date'])
        hit = next((d for d, a in R if abs(a - i['total']) <= 1 and abs((d - dd).days) <= 2), None)
        if hit:
            matched.append(dict(base, via='ledger', card='隨手記', rdate=hit.isoformat(), ramount=round(i['total']), inst=''))
            continue
        kind = 'recent' if cover_until and i['date'] > cover_until else \
               'ez' if has_ez and i['total'] <= 1000 and (EZ_STORE.search(i['seller']) or i.get('vouch')) else 'cash'
        out.append(dict(base, recent=kind == 'recent', kind=kind, vouch=round(i.get('vouch') or 0),
                        fixed=1 if re.search(r'中華電信|台灣大哥大|遠傳|中嘉|長德|金頻道|凱擘|台固|有線電視|寬頻|台灣電力|自來水|瓦斯', i['seller']) else 0))
    return sorted(out, key=lambda x: x['date'], reverse=True), sorted(matched, key=lambda x: x['date'], reverse=True)


# ===== 顯示用的細分類：交通・停車、交通・加油、旅遊・住宿、網購・3C家電… =====
#   報表（Excel、月報、生活帳本）直接用細分類當分類；回饋計算、隨手記仍用原本的大分類
FINE_PARENT = {'交通停車加油': '交通', '旅遊住宿': '旅遊', '網購': '網購', '汽車保養': '汽機車'}
FINE_ORDER = {
    '交通停車加油': [n for n, _ in SUB_RULES['交通停車加油']] + ['其他交通'],
    '旅遊住宿': [n for n, _ in SUB_RULES['旅遊住宿']] + ['當地消費'],
    '網購': [n for n, _ in ITEM_CLASSES] + ['娛樂', '其他', NO_INVOICE],
    '汽車保養': ['購車', '保養維修'],
}
_SHORT = {'其他交通': '其他', NO_INVOICE: '未分類（沒發票）', '過路費 eTag': '過路費'}


def fine_name(cat, sub):
    if cat in FINE_PARENT and sub:
        return FINE_PARENT[cat] + '・' + _SHORT.get(sub, sub)
    return cat


def fine(r):
    """把交易的分類換成細分類（只改這一份資料；呼叫的程式自己決定用不用）"""
    return fine_name(r.get('category'), r.get('sub'))


def expand_cats(cats, present):
    """分類清單：交通停車加油／旅遊住宿／網購 換成實際出現的細分類（照固定順序）"""
    out = []
    for c in cats:
        if c in FINE_PARENT:
            kids = [fine_name(c, s) for s in FINE_ORDER[c]]
            kids = [k for k in kids if k in present] + sorted(k for k in present if k.startswith(FINE_PARENT[c] + '・') and k not in kids)
            out += kids or [c]
        else:
            out.append(c)
    return out


def unfine(name):
    """細分類名稱 → (大分類, 子分類)。例如「交通・停車」→ ('交通停車加油', '停車')"""
    if '・' in (name or ''):
        p, k = name.split('・', 1)
        par = {v: c for c, v in FINE_PARENT.items()}.get(p)
        if par:
            return par, {v: c for c, v in _SHORT.items()}.get(k, k)
    return name, SUB_DEFAULT.get(name, '')


# ---------- 自己分攤：一次刷/付的大筆（機票、手機、機車…）報表上分成 N 個月算 ----------
#   r['spread'] = [N, 'YYYY-MM'(起始月，空白 = 下個月)]；銀行本身的分期（帳單上已經是每期一筆）不再拆
#   只拆到「這個月」為止；回饋計算仍用原本那一筆（rows.json 不變）
SPREAD_PLANS = []


def _addm(d, k):
    import calendar
    y, m = int(d[:4]), int(d[5:7]) - 1 + k
    y += m // 12; m = m % 12 + 1
    return f'{y:04d}-{m:02d}-{min(int(d[8:10] or 1), calendar.monthrange(y, m)[1]):02d}'


def spread(rows, today=None):
    import datetime
    cm = (today or datetime.date.today().isoformat())[:7]
    out = []; SPREAD_PLANS.clear()
    for r in rows:
        sp = r.get('spread')
        if not sp or r.get('installment') or r.get('amount', 0) <= 0 or int(sp[0] or 0) < 2:
            out.append(r); continue
        n = int(sp[0]); st = sp[1] if re.fullmatch(r'\d{4}-\d{2}', str(sp[1] or '')) else _addm(r['date'], 1)[:7]
        acc = 0; k = 0; nxt = ''
        for k in range(1, n + 1):
            d = _addm(st + r['date'][7:], k - 1)
            if d[:7] > cm:
                nxt = d; k -= 1; break
            d = min(d, today or datetime.date.today().isoformat())
            amt = round(r['amount'] - acc, 2) if k == n else round(r['amount'] / n)
            acc += amt
            x = dict(r, date=d, amount=amt, spread_k=k, spread_n=n, buy_date=r['date'])
            x['desc'] = (r.get('desc') or r['merchant']) + f'（分攤 {k}/{n}・{int(r["date"][5:7])}/{int(r["date"][8:10])} 刷 {round(r["amount"]):,}）'
            out.append(x)
        SPREAD_PLANS.append(dict(date=r['date'], name=r['merchant'], category=r['category'], total=r['amount'], n=n, per=round(r['amount'] / n),
                                 paid=k, left=round(r['amount'] - acc), next=nxt, payee='', bank=r.get('bank', ''), card=r.get('cardname', ''),
                                 start=st, end=_addm(st + '-01', n - 1)[:7], mine=r.get('owner', '我')))
    return out
