# LifeLedger：網頁上按「⟳ 立即更新」→ 記下 refreshReq → 這支每 10 分鐘看一次，有新要求就馬上跑一次完整更新
#   refreshReq／refreshDone 放在新版網站獨立的 ?page=refresh；帳本還沒加密時，帳本裡也有一份（舊版網頁寫那裡），兩邊都看、都寫
#   排程「LifeLedger 立即更新偵測」由 run_local.py 自動建立（每 10 分鐘，用 pythonw 不跳視窗）
#   沒有要求的時候只是一個很小的讀取，不會動到任何資料
import os, sys, json, time, subprocess, datetime
BASE = os.path.dirname(os.path.abspath(__file__)); os.chdir(BASE)
from paths import setp, LOG
from ledger_client import Client

S = json.load(open(setp('local_settings.json'), encoding='utf8'))
L = S.get('ledger') or {}
if not (L.get('url') and L.get('user') and L.get('password')) or '填' in str(L.get('user')):
    sys.exit(0)
C = Client(L)   # 版本號檢查、409 重試、加密帳本的規則都在 ledger_client.py 的 Client.mutate


def log(t):
    os.makedirs(LOG, exist_ok=True)
    open(os.path.join(LOG, 'daily_log.txt'), 'a', encoding='utf8').write(f'{datetime.datetime.now():%Y-%m-%d %H:%M} [立即更新] {t}\n')


try:
    _rev, d, ENC = C.get_ledger()
    d = d or {}
    rf = C.get_refresh()   # 新版網站：獨立存放的「立即更新」狀態（舊版網站沒有，回傳 {}）
except Exception:
    sys.exit(0)            # 沒網路、解不開：下次再看
req = max(int(d.get('refreshReq') or 0), int(rf.get('refreshReq') or 0))
done = int(open('.refresh_done').read().strip() or 0) if os.path.exists('.refresh_done') else 0
if req <= done:
    sys.exit(0)
if os.path.exists('.running') and time.time() - os.path.getmtime('.running') < 45 * 60:
    sys.exit(0)            # 排程的更新正在跑：它跑完就是最新的，下一輪再看要不要補
open('.refresh_done', 'w').write(str(req))
log('網頁要求更新，開始')
py = sys.executable.replace('pythonw.exe', 'python.exe')
with open(os.path.join(LOG, 'daily_log.txt'), 'a', encoding='utf8') as lf:
    r = subprocess.run([py, 'run_local.py', '--auto', '--no-mail'], stdout=lf, stderr=subprocess.STDOUT,
                       env=dict(os.environ, PYTHONUTF8='1'), creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
ok = r.returncode == 0
log('完成' if ok else f'失敗（{r.returncode}）')
now = int(time.time() * 1000)
try:   # 新版網站：寫獨立的 page=refresh（帳本加密後只寫這裡）
    if C.v2 and not C.put_refresh(refreshDone=now, refreshOk=ok):
        log('回報完成狀態失敗：網站沒有接受 page=refresh')
except Exception as e:
    log(f'回報完成狀態失敗：{e}')
if not ENC:   # 帳本還沒加密：帳本裡也寫一份（舊版網頁讀這裡）；別台剛好在存檔就重抓再改，最多 3 次
    try:
        C.mutate(lambda d: d.update(refreshDone=now, refreshOk=ok))
    except Exception as e:
        log(f'回報完成狀態（帳本）失敗：{e}')
