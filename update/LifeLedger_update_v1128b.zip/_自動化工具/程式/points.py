import re,glob,os,json,collections
def n(x): return int(x.replace(',',''))
out=[]
for f in sorted(glob.glob('txt/*.txt')):
    fn=os.path.basename(f); b=fn.split('__')[0]; d=re.search(r'(\d{4}-\d{2}-\d{2})',fn).group(1); s=open(f).read()
    p=None; unit=''
    if b=='台新':
        a=re.search(r'新增回饋\s+([\d,]+)',s); c=re.search(r'活動回饋/調整\s+(-?[\d,]+)',s)
        if a: p=n(a.group(1))+(n(c.group(1)) if c else 0); unit='台新Point'
    elif b=='玉山':
        a=re.search(r'^\s*([\d,]+) 點\s+([\d,]+) 點\s+([\d,]+) 點\s+([\d,]+) 點\s+([\d,]+) 點',s,re.M)
        if a: p=n(a.group(2)); unit='e point'
    elif b=='星展':
        a=re.search(r'現金積點 : 上期結餘 [\d,]+ 。 本期新增 ([\d,]+) 。 本期調整 (-?[\d,]+)',s)
        if a: p=n(a.group(1))+n(a.group(2)); unit='現金積點'
    elif b=='國泰':
        a=re.search(r'小樹點\(信用卡\)\s+([\d,]+)\s+([\d,]+)',s)
        if a: p=n(a.group(2)); unit='小樹點'
        z=re.search(r'蝦幣點數新增(-?\d+)點，贈送(\d+)點',s)
        if z: p=(p or 0)+int(z.group(1))+int(z.group(2))
    elif b=='永豐':
        a=re.search(r'本期消費新增點數\s+([\d,]+)點',s); c=re.search(r'活動調整點數\s+(-?[\d,]+)點',s)
        if a: p=n(a.group(1))+(n(c.group(1)) if c else 0); unit='豐點'
    elif b=='聯邦':
        a=re.search(r'您的紅利點數\s*\n\s*([\d,]+)\s+([\d,]+)\s+([\d,]+)\s+([\d,]+)\s+([\d,]+)',s)
        if a: p=n(a.group(2)); unit='紅利點數'
    out.append((b,d,p,unit))
json.dump(out,open('points.json','w'),ensure_ascii=False)
agg=collections.defaultdict(int); miss=collections.Counter()
for b,d,p,u in out:
    if p is None: miss[b]+=1
    else: agg[(b,d[:4],u)]+=p
print(dict(agg)); print(miss)
