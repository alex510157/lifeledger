# 把中信帳單的列（ctbc_rows.txt）配上商家名 → ctbc_txns.json
#   商家名來源（優先順序）：你填的（設定\ctbc_names.json／ctbc_names.txt）> 自動文字辨識（設定\ctbc_names_ocr.json）
#   列號格式：「帳單期別-第幾列」，例如 11510-3（打開 ctbc_strips 資料夾裡的圖片，每列左邊紅字就是列號）
import re, json, glob, os, subprocess, shutil
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from paths import setp

rows = [l.rstrip('\n').split('\t') for l in open('ctbc_rows.txt', encoding='utf8') if '\t' in l]
NJ, NT, NO = setp('ctbc_names.json'), setp('ctbc_names.txt'), setp('ctbc_names_ocr.json')
names = json.load(open(NJ, encoding='utf8')) if os.path.exists(NJ) else None
if names is None and not rows:
    names = {}   # 還沒有中信帳單：先不建檔（等有帳單時再把舊格式轉過來）
elif names is None:   # 第一次：把舊格式（全部帳單連續編號）換成新列號
    names = {}
    if os.path.exists(NT):
        old = {}
        for l in open(NT, encoding='utf8'):
            l = l.strip()
            if l and ' ' in l:
                i, n = l.split(' ', 1)
                if i.isdigit():
                    old[int(i)] = n.strip()
        for k, (rid, _) in enumerate(rows):
            if k in old:
                names[rid] = old[k]
    json.dump(names, open(NJ, 'w', encoding='utf8'), ensure_ascii=False, indent=0)
# 你在 ctbc_names.txt 用新列號補的（例如「11510-3 全家便利商店」）也收進來
if os.path.exists(NT):
    ch = 0
    for l in open(NT, encoding='utf8'):
        l = l.strip()
        m = re.match(r'^(\d{5}-\d+)\s+(.+)$', l)
        if m and names.get(m.group(1)) != m.group(2).strip():
            names[m.group(1)] = m.group(2).strip(); ch = 1
    if ch:
        json.dump(names, open(NJ, 'w', encoding='utf8'), ensure_ascii=False, indent=0)
ocr = json.load(open(NO, encoding='utf8')) if os.path.exists(NO) else {}


def tess():
    exe = shutil.which('tesseract') or next((x for x in [os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs', 'Tesseract-OCR', 'tesseract.exe'), r'C:\Program Files\Tesseract-OCR\tesseract.exe'] if os.path.exists(x)), None)
    td = next((d for d in [os.environ.get('TESSDATA_PREFIX', ''), os.path.join(os.environ.get('LOCALAPPDATA', ''), 'CardFlow', 'tessdata'),
                           os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs', 'Tesseract-OCR', 'tessdata'), r'C:\Program Files\Tesseract-OCR\tessdata']
               if d and os.path.isfile(os.path.join(d, 'chi_tra.traineddata'))), None)
    return exe, td


def read_img(rid, exe, td):
    img = f'ctbc_strips/rows/{rid}.png'
    if not (exe and td and os.path.exists(img)):
        return None
    r = subprocess.run([exe, img, 'stdout', '-l', 'chi_tra+eng', '--psm', '7', '--tessdata-dir', td], capture_output=True)
    t = r.stdout.decode('utf8', 'replace').strip()
    t = re.sub(r'\s+', ' ', t)
    t = re.sub(r'(?<=[\u4e00-\u9fff]) (?=[\u4e00-\u9fff])', '', t)   # 中文字之間的空格拿掉
    t = re.sub(r'^[\W_]+|[\W_]+$', '', t)
    return t if len(re.sub(r'[\W_]', '', t)) >= 2 else None


stmt = {}
for f in glob.glob('dec/中信__*.pdf'):
    tag = re.search(r'Estatement_(\d+)', f).group(1)
    stmt[tag] = re.search(r'(\d{4}-\d{2}-\d{2})', f).group(1)
exe, td = tess()
out, missing, new_ocr = [], [], 0
for rid, txt in rows:
    tag = rid.split('-')[0]
    if tag not in stmt:
        continue
    d = re.match(r'(\d+)/(\d+)/(\d+)', txt).groups(); dt = f'{int(d[0]) + 1911}-{d[1]}-{d[2]}'
    toks = txt.split()
    m = re.search(r'(HCOMCLP\*?\d+|HOTELCOM\d+)', txt)
    desc = 'Hotels.com 訂房' if m else names.get(rid)
    if desc is None:
        if rid not in ocr:
            t = read_img(rid, exe, td)
            if t:
                ocr[rid] = t; new_ocr += 1
        desc = ocr.get(rid)
        if desc is None:
            missing.append(rid); desc = '（待判讀）'
    # 台幣金額＝卡號末四碼「前面那一個數字」（卡號後面接消費地代碼，或已經是最後一欄）。
    #   不能取「日期後第一個數字」：商家名稱裡的數字（例如 E-MART 24）會被當成金額
    ci = next((i for i in range(3, len(toks)) if re.fullmatch(r'\d{4}', toks[i]) and re.fullmatch(r'-?[\d,]+', toks[i - 1])
               and (i + 1 == len(toks) or re.fullmatch(r'[A-Z]{2}', toks[i + 1]))), None)
    if ci is not None:
        a = float(toks[ci - 1].replace(',', '')); card = [toks[ci]]
    else:   # 沒有卡號的列（例如現金回饋折抵）：只有一個金額
        amt = [t for t in toks[2:] if re.match(r'^-?[\d,]+$', t) and not re.match(r'^\d{4}$', t)]
        a = float(amt[0].replace(',', ''))
        card = [t for t in toks if re.match(r'^\d{4}$', t)]
    out.append(dict(bank='中信', stmt=stmt[tag], date=dt, desc=desc, amount=a, orig_amount=None, bill_cur='TWD',
                    card=card[0] if card else '', currency='JPY' if 'JPY' in txt else 'TWD', src=f'中信_{tag}', kind='refund' if a < 0 else 'spend'))
if new_ocr:
    json.dump(ocr, open(NO, 'w', encoding='utf8'), ensure_ascii=False, indent=0)
    print(f'自動辨識了 {new_ocr} 筆中信商家名（不準的話在 ctbc_names.txt 用「列號 商家名」改）')
json.dump(out, open('ctbc_txns.json', 'w'), ensure_ascii=False)
print('rows', len(out), 'missing names:', missing)
