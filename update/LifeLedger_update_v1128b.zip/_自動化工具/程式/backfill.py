# LifeLedger：補抓舊帳單（例如從 2024 年 1 月開始），並讓月報、生活帳本、Excel 從那個月開始算
#   雙擊 _自動化工具\補抓舊帳單.bat
import os, sys, json, re, subprocess, datetime
BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)
from paths import setp

S = json.load(open(setp('local_settings.json'), encoding='utf8'))
cur = S.get('report_start') or json.load(open('config.json', encoding='utf8')).get('start') or '（還沒有）'
print(f'目前報表從 {cur} 開始。')
print('要從哪一年開始？例如 2024（從 2024 年 1 月起）、或 2024-07（從 2024 年 7 月起）')
v = input('輸入年份或年-月（直接 Enter＝取消）：').strip()
if not v:
    sys.exit(0)
m = re.fullmatch(r'(20\d\d)(?:[-/.](\d{1,2}))?', v)
if not m or not (2015 <= int(m.group(1)) <= datetime.date.today().year):
    sys.exit('格式不對，請輸入例如 2024 或 2024-07')
ym = f'{m.group(1)}-{int(m.group(2) or 1):02d}'
S['report_start'] = ym
S['mail_since'] = ym + '-01'
json.dump(S, open(setp('local_settings.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=1)
print(f'\n✓ 報表改成從 {ym} 開始。')
env = dict(os.environ, PYTHONUTF8='1')
if S.get('mailboxes'):
    print(f'\n從信箱補抓 {ym} 以後的帳單（信件多的話要 10–30 分鐘，視窗不要關）…')
    subprocess.run([sys.executable, 'mail_fetch.py', '--since', ym + '-01'], env=env)
else:
    print('（沒有設定信箱：請把舊帳單 PDF 放進對應的銀行資料夾）')
print('\n重新整理月報、生活帳本、Excel…')
subprocess.run([sys.executable, 'run_local.py', '--auto', '--no-mail'], env=env)
print(f'\n✓ 完成。信箱裡還留著的舊帳單都收進來了；信箱已經刪掉的月份，可以到銀行網站下載 PDF 放進銀行資料夾，再按「立即更新月報」。')
