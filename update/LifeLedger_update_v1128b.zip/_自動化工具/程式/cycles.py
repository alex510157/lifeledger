# 各銀行信用卡「結帳日」：從帳單文字讀出每一期實際的結帳日，取最常見的日子當每月結帳日，再推下一次結帳日。
# 同一家銀行的卡合併在同一張帳單，所以結帳日以銀行為單位。只用帳單上的日期，不用猜。
# 另外讀最新一期的「繳款截止日」「本期應繳總金額」，讓隨手記提醒什麼時候要繳、要繳多少。
import os, re, glob, json, collections, datetime as D

_DT = r'(\d{3,4})\s*[/.\-年]\s*(\d{1,2})\s*[/.\-月]\s*(\d{1,2})'


def _d(y, m, d):
    y = int(y); y = y + 1911 if y < 1000 else y
    try:
        return D.date(y, int(m), int(d))
    except ValueError:
        return None


def _all(s):
    for m in re.finditer(r'(?<!\d)' + _DT + r'(?!\d)', s):
        x = _d(*m.groups())
        if x:
            yield x, m.start()


def _close(bank, s, sent):
    """這份帳單的結帳日；sent＝帳單寄出日（檔名日期）。結帳日一定在寄出前 0~12 天。"""
    ok = lambda x: x and -1 <= (sent - x).days <= 12
    # 1) 有寫「結帳日」字樣的（台新、永豐、遠東、富邦、其他銀行）
    for m in re.finditer(r'結帳日(?:期)?[^\d\n]{0,14}' + _DT, s):
        x = _d(*m.groups()[-3:])
        if ok(x):
            return x
    m = re.search(r'帳單結帳日.*\n\s*\n?\s*(.*)', s)       # 表格：標題一行、數值下一行（富邦）
    if m:
        for x, _ in _all(m.group(1)):
            if ok(x):
                return x
    # 2) 帳單期間「起 - 迄」（星展）
    m = re.search(_DT + r'\s*[-~～至]\s*' + _DT, s)
    if m:
        x = _d(*m.groups()[3:])
        if ok(x):
            return x
    # 3) 版面沒標字（中信、國泰、玉山、聯邦）：首頁摘要區（前 80 行）裡、寄出前 12 天內最晚的日期
    head = '\n'.join(s.splitlines()[:80])
    c = [x for x, _ in _all(head) if ok(x)]
    return max(c) if c else None


_DUE_KEYS = ('本期應繳總金額', '本期應繳總額', '本期應繳金額', '應繳總金額', '應繳總額')


def _due(s, close):
    """這份帳單的繳款截止日：一定在結帳日後 10～28 天。有順延通知（例如「繳款截止日至 115/10/19」）就用順延後的日子"""
    ok = lambda x: x and 10 <= (x - close).days <= 28
    c = [x for m in re.finditer(r'繳款截止日(?:期)?[^\d\n]{0,14}' + _DT, s) for x in [_d(*m.groups()[-3:])] if ok(x)]
    if c:
        return max(c)
    for m in re.finditer(r'繳款截止日.*\n((?:.*\n){1,3})', s):   # 表格：標題一行、日期在下面幾行
        c = [x for x, _ in _all(m.group(1)) if ok(x)]
        if c:
            return min(c)
    head = '\n'.join(s.splitlines()[:80])   # 版面沒標字：首頁摘要區裡、結帳後 10～28 天的日期（扣款日＝繳款日）
    c = [x for x, _ in _all(head) if ok(x)]
    return min(c) if c else None


def _amount(s):
    """本期應繳總金額（新臺幣）。依序：同一行明寫的 → 「自動扣繳 xx 元」那句 → 表格欄位。讀不到就回 None，不要猜"""
    try:
        from generic_parse import _NUM
    except Exception:
        return None
    L = [l for l in s.splitlines() if not re.search(r'積點|點數|紅利|哩程|里程|回饋點|最低|上限|為新台幣|為新臺幣|大於|小於|超過|以上|以下|不適用|代繳', l)]
    t = '\n'.join(L)
    cur = r'(?:TWD|NT\$|新臺幣|新台幣|\$)?[ \t]*'   # 不跨行

    def num(v):
        try:
            x = round(float(v.replace(',', '')))
        except ValueError:
            return None
        return x if -10_000_000 < x < 10_000_000 else None
    for k in _DUE_KEYS:   # 1) 同一行：「本期應繳總金額：  TWD 25,171」「本期應繳總額  0元」
        for m in re.finditer(r'(?<![上前])' + k + r'(?:\(註.\))?[：: \t]*' +r'[^\d\n-]{0,80}?' + cur + _NUM, t):
            v = num(m.group(1))
            if v is not None:
                return v
    m = re.search(r'(?:扣款|扣繳|自動扣繳)[^\d\n]{0,8}' + cur + r'(\d{1,3}(?:,\d{3})+|\d+)\s*元', t)   # 2) 「將自動扣繳 25,163 元」
    if m:
        return num(m.group(1))
    for k in _DUE_KEYS:   # 3) 表格：標題一行、金額在下一列同一欄
        for i, l in enumerate(L):
            j = l.find(k)
            if j < 0 or re.search(r'\d', l[j:j + len(k) + 6]):
                continue
            cx = j + len(k) / 2
            for r in L[i + 1:i + 3]:
                if re.match(r'\s*(日圓|美元|歐元|JPY|USD|EUR)', r):
                    continue
                toks = [(mm.start(), mm.end(), mm.group(0)) for mm in re.finditer(r'-?\d{1,3}(?:,\d{3})+|-?\d+', r)]
                toks = [x for x in toks if abs((x[0] + x[1]) / 2 - cx) <= max(12, len(k) * 2)]   # 一定要在同一欄附近
                if toks:
                    return num(min(toks, key=lambda x: abs((x[0] + x[1]) / 2 - cx))[2])
    return None


def _nopay(s):
    return bool(re.search(r'無需繳款|無須繳款|不用繳款|免繳款', '\n'.join(s.splitlines()[:60])))   # 只看首頁摘要，不看條款說明


def _add_month(y, m, k=1):
    m += k
    return y + (m - 1) // 12, (m - 1) % 12 + 1


def scan(txt_dir='txt', today=None):
    today = today or D.date.today()
    per = collections.defaultdict(list)
    bill = {}   # 每家銀行最新一期：(結帳日, 繳款截止日, 本期應繳)
    for f in sorted(glob.glob(os.path.join(txt_dir, '*.txt'))):
        b = os.path.basename(f)
        mm = re.match(r'(.+?)__(\d{4}-\d{2}-\d{2})', b)
        if not mm:
            continue
        bank, sent = mm.group(1), D.date.fromisoformat(mm.group(2))
        try:
            s = open(f, encoding='utf-8', errors='ignore').read()
        except OSError:
            continue
        x = _close(bank, s, sent)
        if x:
            per[bank].append(x)
            if bank not in bill or x >= bill[bank][0]:
                bill[bank] = (x, _due(s, x), _amount(s), _nopay(s))
    out = {}
    for bank, L in per.items():
        L = sorted(set(L))
        recent = L[-8:]
        day = collections.Counter(x.day for x in recent).most_common(1)[0][0]
        last = L[-1]
        # 下一次結帳日：從最後一期往後推到今天以後；遇假日銀行可能提前或順延，所以標「約」
        y, m = last.year, last.month
        while True:
            y, m = _add_month(y, m)
            dd = min(day, (D.date(*_add_month(y, m), 1) - D.timedelta(days=1)).day)
            nxt = D.date(y, m, dd)
            if nxt >= today:
                break
        out[bank] = {'day': day, 'last': last.isoformat(), 'next': nxt.isoformat(),
                     'hist': [x.isoformat() for x in recent],
                     'vary': sorted({x.day for x in recent})}
        b = bill.get(bank)
        if b and b[0] == last:
            if b[1]:
                out[bank]['due'] = b[1].isoformat()   # 最新一期的繳款截止日
            if b[2] is not None and (b[1] or b[3]):
                out[bank]['amt'] = b[2]               # 最新一期的本期應繳（0 或負數＝不用繳）
            if b[3] or (b[2] is not None and b[2] <= 0):
                out[bank]['nopay'] = True             # 帳單寫「無需繳款」或應繳 ≤ 0
    return out


def by_bank(txt_dir=None):
    try:
        return scan(txt_dir or os.path.join(os.path.dirname(os.path.abspath(__file__)), 'txt'))
    except Exception:
        return {}


if __name__ == '__main__':
    for k, v in scan().items():
        print(k, v['day'], '日｜上次', v['last'], '｜下次約', v['next'], '｜近幾期', v['vary'], '｜繳款截止', v.get('due', '—'), '｜應繳', v.get('amt', '—'))
