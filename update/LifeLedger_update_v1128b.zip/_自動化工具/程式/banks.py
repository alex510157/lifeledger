# 銀行清單：有幾家銀行的帳單就顯示幾家（原本 7 家排前面，其他銀行依第一次出現的順序接在後面）
# 另外提供「這筆算不算我的消費」：家人刷的附卡、勾了代付的交易，另外列，不算進我的消費
import json, os, re

KNOWN = ['台新', '永豐', '玉山', '聯邦', '中信', '星展', '國泰']
FULL = {'台新': '台新銀行', '永豐': '永豐銀行', '玉山': '玉山銀行', '聯邦': '聯邦銀行', '中信': '中國信託', '星展': '星展銀行',
        '國泰': '國泰世華', '遠東': '遠東商銀', '富邦': '台北富邦', '渣打': '渣打銀行', '第一': '第一銀行', '華南': '華南銀行',
        '彰銀': '彰化銀行', '兆豐': '兆豐銀行', '合庫': '合作金庫', '土銀': '土地銀行', '臺銀': '臺灣銀行', '上海': '上海商銀',
        '新光': '新光銀行', '凱基': '凱基銀行', '元大': '元大銀行', '王道': '王道銀行', '樂天': '樂天銀行', '匯豐': '匯豐銀行',
        '美國運通': '美國運通', '將來': '將來銀行', 'LINE Bank': 'LINE Bank', '企銀': '臺灣企銀', '陽信': '陽信銀行'}
# 前 7 色沿用原本的銀行色，後面給新增的銀行（皆可在淺色、深色背景辨識）
PALETTE = ['#2a78d6', '#eb6834', '#1baf7a', '#c98a00', '#d9608e', '#008300', '#4a3aa7',
           '#0f8fa6', '#a8551f', '#6b7f00', '#b23b8f', '#3f6fb5', '#8a6d3b', '#c0392b', '#5d6d7e']
FOLDER = {'遠東商銀': '遠東', '台北富邦': '富邦', '富邦銀行': '富邦', '渣打銀行': '渣打', '第一銀行': '第一', '國泰世華': '國泰',
          '中國信託': '中信', '中信銀行': '中信', '玉山銀行': '玉山', '台新銀行': '台新', '永豐銀行': '永豐', '聯邦銀行': '聯邦', '星展銀行': '星展'}


def short(folder):
    """銀行資料夾名 → 簡稱（遠東商銀 → 遠東）"""
    return FOLDER.get(folder, folder)


def full(b):
    return FULL.get(b, b if b.endswith('銀行') or 'Bank' in b else b + '銀行')


def order(rows):
    seen = {r['bank'] for r in rows}
    extra = []
    for r in sorted(rows, key=lambda r: r['date']):
        if r['bank'] not in KNOWN and r['bank'] not in extra:
            extra.append(r['bank'])
    return [b for b in KNOWN if b in seen] + extra


def color(i):
    return PALETTE[i % len(PALETTE)]


def mine(r):
    """算進「我的消費」：不是家人刷的附卡、也沒勾代付"""
    return r.get('owner', '我') == '我' and not r.get('paid')


def load_rows(all_rows=False):
    R = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rows.json'), encoding='utf8'))
    return R if all_rows else [r for r in R if mine(r)]


def txkey(r, l4=None):
    """一筆交易的識別碼（代付勾選要跨月保留）"""
    return '|'.join([r['bank'], l4 if l4 is not None else (r.get('card') or '—'), r['txn_date'], str(round(r['amount'])), r['merchant']])


_LONG = re.compile(r'(?<![\d.])\d{12,19}(?![\d.])')


def web_safe(rows):
    """要放上網頁／月報的交易：帳單說明裡 12 位以上的長數字（繳費帳號、可能像卡號）只留末四碼"""
    for r in rows:
        for k in ('desc', 'merchant'):
            if isinstance(r.get(k), str):
                r[k] = _LONG.sub(lambda m: '…' + m.group()[-4:], r[k])
    return rows


INC_CATS = ['薪資', '房租', '投資・配息', '利息', '其他收入']
INC_COL = {'薪資': '#1f8a5b', '房租': '#2f9e8f', '投資・配息': '#c9a45c', '利息': '#5aa9cf', '其他收入': '#9aa3b0'}


def inc_cat(src):
    """收入分類：薪資／房租／投資・配息／利息／其他收入"""
    s = src or ''
    if '薪資' in s: return '薪資'
    if '房租' in s: return '房租'
    if re.search(r'配息|投資|股票|股利|股息', s): return '投資・配息'
    if '利息' in s: return '利息'
    return '其他收入'


def prov_rows(rows=None):
    """隨手記記的刷卡、帳單還沒到的：先當作「暫列」消費放進月報和生活帳本；帳單到了對上就換成帳單那筆，
    帳單到了還對不上（帳單找不到）就不列。"""
    p = 'ledger_recon.json'
    if not os.path.exists(p):
        return []
    try:
        from cards import owner
    except Exception:
        owner = lambda b, l4: '我'
    rows = rows if rows is not None else (json.load(open('rows.json', encoding='utf8')) if os.path.exists('rows.json') else [])
    names = {}
    for r in rows:
        names.setdefault((r['bank'], r.get('card') or ''), r['cardname'])
    fix = {'醫療教育': '醫療', '稅款': '稅費'}
    out = []
    for x in json.load(open(p, encoding='utf8')).get('records', []):
        if x.get('status') != '帳單還沒到' or x.get('cash'):
            continue
        l4 = x.get('last4') or ''
        if owner(x['bank'], l4) != '我':
            continue
        note = x.get('note') or x.get('category') or '隨手記'
        out.append(dict(inst_n=None, inst_N=None, country='', bank=x['bank'], date=x['date'], txn_date=x['date'], stmt='',
                        desc='隨手記・帳單還沒到', merchant=note, amount=float(x['amount']), kind='spend',
                        category=fix.get(x.get('category'), x.get('category') or '其他'), installment=False, card=l4,
                        cardname=names.get((x['bank'], l4)) or x.get('card') or x['bank'], foreign=bool(x.get('foreign')),
                        currency='TWD', owner='我', key='prov|' + x['bank'] + '|' + l4 + '|' + x['date'] + '|' + str(round(x['amount'])) + '|' + note,
                        paid=False, hint='', prov=True, rid=x.get('rid') or '', memo=x.get('note') or ''))
    # 暫列上勾的代墊／代刷（或記帳時勾「幫別人代墊」）：先照勾的比例算，帳單到了會轉到帳單那筆
    try:
        from paths import setp as _sp
        _pf = _sp('代付標記.json')
        PV = (json.load(open(_pf, encoding='utf8')).get('prov', {}) if os.path.exists(_pf) else {})
    except Exception:
        PV = {}
    _sp_ = []
    for r in out:
        p = float((PV.get(r['rid']) or [0])[0]) if r['rid'] else 0
        if p >= 0.999:
            r['paid'] = True; r['paid_ratio'] = 0
        elif p > 0.001:
            q = dict(r); a0 = r['amount']
            q['amount'] = round(a0 * p, 2); r['amount'] = round(a0 - q['amount'], 2)
            r['paid_ratio'] = q['paid_ratio'] = p; q['paid'] = True; q['key'] = r['key'] + '#代付'
            _sp_.append(q)
    out += _sp_
    try:   # 子分類（交通、旅遊依說明判斷；網購沒有發票明細）
        import subcat as _sc
        for r in out:
            c = r.get('category'); d = (r.get('desc') or '') + ' ' + (r.get('merchant') or '')
            if c in _sc.SUB_RULES:
                r['sub'] = next((n for n, rx in _sc.SUB_RULES[c] if __import__('re').search(rx, d)), _sc.SUB_DEFAULT.get(c, '其他'))
            elif c == '網購':
                r['sub'] = next((n for n, rx in _sc.MERCHANT_SUB if __import__('re').search(rx, d)), None) or _sc.note_class(r.get('memo')) or _sc.NO_INVOICE
    except Exception:
        pass
    return out
