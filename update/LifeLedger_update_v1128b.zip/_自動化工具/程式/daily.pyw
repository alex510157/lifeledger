# 每日排程用（pythonw 執行，不會跳出黑色視窗）：更新月報 → 檢查程式新版（有就自動裝，下次排程生效）
# 執行紀錄照舊寫在 紀錄\daily_log.txt
import os, sys, subprocess, datetime

PROG = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(os.path.dirname(PROG), '紀錄')
os.makedirs(LOG, exist_ok=True)
# pythonw 旁邊的 python.exe：用「隱藏的主控台」執行，pdftotext、tesseract 等工具就不會一個個跳出視窗
exe = sys.executable
cand = os.path.join(os.path.dirname(exe), 'python.exe')
PY = cand if os.path.basename(exe).lower() == 'pythonw.exe' and os.path.exists(cand) else exe
NOWIN = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
args = sys.argv[1:] or ['--daily']
with open(os.path.join(LOG, 'daily_log.txt'), 'a', encoding='utf8') as log:
    log.write(f'==== {datetime.datetime.now():%Y/%m/%d %H:%M:%S} ====\n'); log.flush()
    subprocess.run([PY, os.path.join(PROG, 'run_local.py')] + args, cwd=PROG, stdout=log, stderr=subprocess.STDOUT, env=env, creationflags=NOWIN)
    log.write('---- 檢查程式更新 ----\n'); log.flush()
    subprocess.run([PY, os.path.join(PROG, 'updater.py')], cwd=PROG, stdout=log, stderr=subprocess.STDOUT, env=env, creationflags=NOWIN)
