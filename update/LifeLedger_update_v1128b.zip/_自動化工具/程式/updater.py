# LifeLedger 自動更新：從 GitHub 網頁抓最新版的程式，只換程式和說明，不碰設定、帳單、紀錄、月報
# 用法：python updater.py            檢查並更新（有新版就裝）
#       python updater.py --check    只檢查，不裝
# 每天排程（daily.pyw）跑完月報後會自動執行一次；桌面「LifeLedger 生活總帳」視窗也可以手動按
import os, sys, io, json, time, hashlib, zipfile, shutil, datetime, urllib.request, urllib.parse

PROG = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(PROG)                              # _自動化工具
MANIFEST = os.environ.get('LIFELEDGER_UPDATE_URL') or 'https://alex510157.github.io/lifeledger/update/version.json'   # 環境變數只給測試用
PREFIX = '_自動化工具/'
KEEP_OUT = ('設定/', '紀錄/', '_更新備份/')               # 這些資料夾是使用者自己的，更新永遠不碰
BACKUP = os.path.join(TOOLS, '_更新備份')
UA = {'User-Agent': 'LifeLedger-updater', 'Cache-Control': 'no-cache'}


def local_version():
    """這台電腦目前的版本：{version, build}；舊版沒有 version.json 的，build 當 0（一定會更新）"""
    try:
        v = json.load(open(os.path.join(PROG, 'version.json'), encoding='utf8'))
        return {'version': str(v.get('version', '?')), 'build': int(v.get('build', 0))}
    except (OSError, ValueError):
        pass
    try:
        return {'version': open(os.path.join(PROG, 'version.txt'), encoding='utf8').read().strip() or '?', 'build': 0}
    except OSError:
        return {'version': '?', 'build': 0}


def _get(url, timeout):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
        return r.read()


def remote_version(timeout=15):
    r = json.loads(_get(MANIFEST + '?t=' + str(int(time.time())), timeout))
    for k in ('version', 'build', 'file', 'sha256', 'size'):
        if k not in r:
            raise ValueError('更新資訊缺少 ' + k)
    r['build'] = int(r['build']); r['size'] = int(r['size'])
    return r


def _rel(name):
    """壓縮檔裡的路徑 → _自動化工具 底下的相對路徑；不安全或不該更新的回傳 None"""
    if not name.startswith(PREFIX) or name.endswith('/'):
        return None
    rel = name[len(PREFIX):]
    parts = rel.replace('\\', '/').split('/')
    if not rel or any(p in ('', '.', '..') for p in parts) or ':' in rel or rel.startswith(KEEP_OUT):
        return None
    return rel


def _prune(keep=3):
    try:
        ds = sorted(d for d in os.listdir(BACKUP) if os.path.isdir(os.path.join(BACKUP, d)))
        for d in ds[:-keep]:
            shutil.rmtree(os.path.join(BACKUP, d), ignore_errors=True)
    except OSError:
        pass


def _clean_old():
    """上次更新時正在執行、先改名成 .old 的檔案（例如 LifeLedger.exe）：現在應該可以刪了"""
    for root, _, fs in os.walk(TOOLS):
        if os.path.basename(root) in ('設定', '紀錄') or '_更新備份' in root:
            continue
        for f in fs:
            if f.endswith('.lifeledger-old'):
                try:
                    os.remove(os.path.join(root, f))
                except OSError:
                    pass


def _write(dst, data):
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    tmp = dst + '.lifeledger-new'
    with open(tmp, 'wb') as f:
        f.write(data)
    try:
        os.replace(tmp, dst)
    except PermissionError:   # 檔案正在執行（Windows 會鎖住 .exe）：舊的先改名，新的再放上去
        old = dst + '.lifeledger-old'
        if os.path.exists(old):
            os.remove(old)
        os.replace(dst, old)
        os.replace(tmp, dst)


def apply(r, log=print):
    """下載、檢查、套用；任何一步失敗就還原，回傳更新了幾個檔案"""
    data = _get(urllib.parse.urljoin(MANIFEST, r['file']), 180)
    if len(data) != r['size'] or hashlib.sha256(data).hexdigest() != r['sha256'].lower():
        raise ValueError('下載的檔案跟更新資訊對不上（可能沒下載完整），這次先不更新')
    z = zipfile.ZipFile(io.BytesIO(data))
    files = [(i.filename, _rel(i.filename)) for i in z.infolist()]
    files = [(n, rel) for n, rel in files if rel]
    vj = [n for n, rel in files if rel == '程式/version.json']
    if not vj or int(json.loads(z.read(vj[0])).get('build', -1)) != r['build']:
        raise ValueError('更新檔的版本資訊不一致，這次先不更新')
    files.sort(key=lambda x: x[1] == '程式/version.json')   # 版本檔最後寫：中途失敗不會顯示成新版
    lv = local_version()
    bdir = os.path.join(BACKUP, datetime.datetime.now().strftime('%Y%m%d_%H%M%S') + '_v' + lv['version'])
    done = []   # (相對路徑, 原本有沒有這個檔)
    try:
        for n, rel in files:
            dst = os.path.join(TOOLS, *rel.split('/'))
            new = z.read(n)
            existed = os.path.exists(dst)
            if existed:
                with open(dst, 'rb') as f:
                    if f.read() == new:
                        continue
                os.makedirs(os.path.dirname(os.path.join(bdir, rel)), exist_ok=True)
                shutil.copy2(dst, os.path.join(bdir, *rel.split('/')))
            _write(dst, new)
            done.append((rel, existed))
    except Exception:
        for rel, existed in reversed(done):   # 還原成更新前
            dst = os.path.join(TOOLS, *rel.split('/'))
            try:
                if existed:
                    shutil.copy2(os.path.join(bdir, *rel.split('/')), dst)
                else:
                    os.remove(dst)
            except OSError:
                pass
        raise
    _prune()
    log(f'已更新到 v{r["version"]}（{len(done)} 個檔案；舊檔備份在 _自動化工具\\_更新備份）')
    return len(done)


def check(install=True, log=print):
    """回傳 (狀態, 本機版本, 網路上的版本或 None)；狀態：latest / updated / available / error"""
    _clean_old()
    lv = local_version()
    if os.path.exists(os.path.join(PROG, 'make_share.py')):   # 產生分享版的那台電腦（原始程式）：分享版拿掉了個人設定，不能拿來蓋
        log('這台是產生分享版的電腦，不自動更新'); return 'latest', lv, None
    try:
        r = remote_version()
    except Exception as e:
        log(f'檢查更新失敗（{e}），沿用目前的 v{lv["version"]}')
        return 'error', lv, None
    if r['build'] <= lv['build']:
        log(f'已經是最新版 v{lv["version"]}')
        return 'latest', lv, r
    if not install:
        log(f'有新版 v{r["version"]}（目前 v{lv["version"]}）')
        return 'available', lv, r
    try:
        apply(r, log)
        try:   # 給桌面小視窗看：下次打開時顯示「已經自動更新到 vX」和這次改了什麼
            json.dump({'from': lv['version'], 'to': r['version'], 'notes': r.get('notes') or [], 'time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M')},
                      open(os.path.join(PROG, '.just_updated.json'), 'w', encoding='utf8'), ensure_ascii=False)
        except OSError:
            pass
        return 'updated', lv, r
    except Exception as e:
        log(f'更新失敗（{e}），已還原，沿用 v{lv["version"]}')
        return 'error', lv, r


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    st = check(install='--check' not in sys.argv)[0]
    sys.exit(1 if st == 'error' else 0)
