# LifeLedger 月報
#   email.html   ── 寄信存檔用（Outlook／Gmail 相容：純 table + inline style）：重點、回饋一覽、全部刷錯卡、全部明細
#   月報.html    ── 網頁版（Artifact）：每個月一份、可切換過去月份；分頁：總覽／本月回饋／刷錯卡／明細／卡片與分期
#   <OUT>/月報/LifeLedger月報.html ── 同一份網頁的離線版（不用 Claude，瀏覽器直接開）
import json, collections, os, re, html as H
BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)
OUT = os.environ.get('CARDFLOW_OUT', '/mnt/user-data/outputs')
CFG = json.load(open('config.json', encoding='utf8'))
CY, CM = CFG['cur_year'], CFG['cur_month']
import banks as _bk
from banks import web_safe as _bkws
RA = _bkws(json.load(open('rows.json', encoding='utf8')))      # 全部（含家人附卡、代付）
RA += _bkws(_bk.prov_rows(RA)) if hasattr(_bk, 'prov_rows') else []   # 隨手記記了、帳單還沒到：暫列
import subcat as _scf
for _r in RA:   # 報表用細分類：交通・停車、旅遊・住宿、網購・3C家電…
    _r['category'] = _scf.fine(_r)
RA = _scf.spread(RA)   # 自己分攤的大筆（機票、手機…）：分到各月
for _r in RA:   # 年費、海外手續費分開（年費減免那筆也算年費，淨額就是真的收的年費）
    if _r['category'] == '年費手續費': _r['category'] = '年費' if '年費' in _r['merchant'] + (_r.get('desc') or '') else '海外手續費'
FEES = ('年費', '海外手續費')
R = [r for r in RA if _bk.mine(r)]                      # 我的消費
PLANS = json.load(open('plans.json', encoding='utf8'))
RC = json.load(open('rewards_check.json', encoding='utf8')) if os.path.exists('rewards_check.json') else {}
_rd = lambda fn: open(fn, encoding='utf8').read().strip() if os.path.exists(fn) else ''
URL_LEDGER = _rd('ledger_url.txt')          # 線上生活帳本（沒有就不顯示連結）
URL_REPORT = _rd('report_url.txt')          # claude.ai 網頁月報（沒有就只用離線版）
URL_ONLINE = _rd('web_url.txt') or URL_REPORT   # 離線版的「切換到線上版」：有自架加密網址就用它，否則用 claude.ai
LEDGER_A = f'・<a href="{URL_LEDGER or "LifeLedger生活帳本.html"}" data-local="LifeLedger生活帳本.html" target="_blank" rel="noopener">生活帳本</a>'
BANKS = _bk.order(RA) + ['現金', '帳戶']   # 現金、帳戶扣款（房貸、無卡分期、轉帳）也當成一種「付款方式」，跟刷卡列在一起
BFULL = {b: {'現金': '現金', '帳戶': '帳戶扣款'}.get(b) or _bk.full(b) for b in BANKS}
_C7 = dict(zip(_bk.KNOWN, ['#2a78d6', '#eb6834', '#1baf7a', '#c98a00', '#d9608e', '#008300', '#4a3aa7']))
BCOL = {b: ({'現金': '#8a8f98', '帳戶': '#5d6f86'}.get(b) or (_C7.get(b) if i < 7 and BANKS[:i + 1] == _bk.KNOWN[:i + 1] else _bk.color(i))) for i, b in enumerate(BANKS)}
EXTRA_CSS = ':root{' + ''.join(f'--b{i}:{BCOL[b]};' for i, b in enumerate(BANKS) if i >= 7) + '}' if len(BANKS) > 7 else ''
REB = '回饋折抵'
INC = json.load(open('income.json', encoding='utf8')) if os.path.exists('income.json') else None
DEPJ = json.load(open('deposits.json', encoding='utf8')) if os.path.exists('deposits.json') else None
for _p in _scf.SPREAD_PLANS:   # 刷卡一次付清、自己分攤
    if _p.get('mine', '我') == '我':
        PLANS.append(dict(bank='', merchant=_p['name'], card=f'刷卡一次付清・自己分攤 {_p["n"]} 個月', N=_p['n'], start=_p['start'], end=_p['end'],
                          per=_p['per'], total=_p['total'], category=_p['category'], nocard=1, buy=_p['date']))
for _p in (INC or {}).get('inst', []):   # 無卡分期（每月自己轉帳繳）：跟信用卡分期一起列
    PLANS.append(dict(bank='', merchant=_p['name'], card='無卡分期・每月帳戶轉帳', N=_p['n'], start=_p.get('start') or _p['date'][:7],
                      end=_p.get('end') or _p['date'][:7], per=_p['per'], total=_p['total'], category=_p['category'], nocard=1, buy=_p['date']))


def dep_card(ym):
    """帳上存款：到這個月為止，各銀行最新一期存款／綜合對帳單的餘額"""
    if not DEPJ or not DEPJ.get('stmts'):
        return ''
    last = {}
    for s in sorted(DEPJ['stmts'], key=lambda s: s['month']):
        if s['month'] <= ym and s.get('balance') is not None:
            last[s['bank']] = s
    if not last:
        return ''
    tot = sum(s['balance'] for s in last.values()); loan = sum(s.get('loan', 0) for s in last.values())
    yi = sum(x['amount'] for x in DEPJ.get('interest', []) if x['date'][:4] == ym[:4] and x['date'][:7] <= ym)
    mi = sum(x['amount'] for x in DEPJ.get('interest', []) if x['date'][:7] == ym)
    mx = max(s['balance'] for s in last.values()) or 1
    stat = {x['bank']: x for x in DEPJ.get('status', [])}
    def badge(b):
        x = stat.get(b)
        if not x: return ''
        if x.get('manual'):
            mm = [m for m in x['missing'] if m <= ym]
            return ('<span class="stb bad">要回填 ' + '、'.join(m[2:].replace('-', '/') for m in mm) + '</span>') if mm else '<span class="stb man">手動回填・已是最新</span>'
        miss = [m for m in x['missing'] if m <= ym]
        if miss: return '<span class="stb bad">缺 ' + '、'.join(m[2:].replace('-', '/') for m in miss) + '</span>'
        return '<span class="stb ok">已到齊</span>' if x['regular'] else '<span class="stb man">不定期寄送</span>'
    rows = ''.join(f'<tr><td>{esc(_bk.full(b))}<small>{s["month"].replace("-", "/")} 對帳單' + ('（沿用上期）' if s['month'] != ym else '') + f'</small></td>'
                   f'<td class="n"><b>{f(s["balance"])}</b></td><td class="bar"><span class="meter"><span style="width:{s["balance"] / mx * 100:.0f}%;background:var(--bar)"></span></span></td><td>{badge(b)}</td></tr>'
                   for b, s in sorted(last.items(), key=lambda x: -x[1]['balance']))
    rows += ''.join(f'<tr><td>{esc(_bk.full(b))}<small>{x["last"].replace("-", "/")} 對帳單</small></td><td class="n muted">讀不到</td><td class="muted" style="font-size:12px">互動式對帳單，需手動補餘額</td><td>{badge(b)}</td></tr>'
                    for b, x in stat.items() if b not in last and x['received'])
    return (f'<div class="card"><h2>帳上存款</h2><p class="d">有對帳單的銀行都列出（沒錢也列）；餘額含外幣折台幣，利息已算進上面的收入；紅色＝該寄沒寄到的月份</p>'
            f'<div class="sum"><div><span class="l">存款合計</span><span class="v pos">NT$ {f(tot)}</span></div>'
            + (f'<div><span class="l">房貸餘額</span><span class="v">NT$ {f(loan)}</span></div>' if loan else '')
            + f'<div><span class="l">{int(ym[5:])} 月利息<small>{ym[:4]} 年累計 {f(yi)}</small></span><span class="v pos">NT$ {f(mi)}</span></div></div>'
            f'<div class="tbl"><table><tr><th>銀行</th><th class="n">餘額</th><th></th><th>對帳單</th></tr>{rows}</table></div></div>')
ACTS = json.load(open('activity.json', encoding='utf8')) if os.path.exists('activity.json') else []
LREC = json.load(open('ledger_recon.json', encoding='utf8')) if os.path.exists('ledger_recon.json') else dict(records=[], missing=[])
SAL = collections.defaultdict(float); CASH = collections.defaultdict(float)
for _x in (INC or {}).get('salary', []): SAL[_x['date'][:7]] += _x['amount']
for _x in (INC or {}).get('other', []): SAL[_x['date'][:7]] += _x['amount']   # 隨手記記的其他收入
for _x in (INC or {}).get('cash', []): CASH[_x['date'][:7]] += _x['amount']
OTHS = collections.defaultdict(float)   # (月份, 來源) → 金額
for _x in (INC or {}).get('other', []): OTHS[(_x['date'][:7], '房租' if '房租' in _x['source'] else '其他收入')] += _x['amount']
INCC = collections.defaultdict(float)   # (月份, 收入分類) → 金額
for _x in (INC or {}).get('salary', []): INCC[(_x['date'][:7], '薪資')] += _x['amount']
for _x in (INC or {}).get('other', []): INCC[(_x['date'][:7], _bk.inc_cat(_x['source']))] += _x['amount']
def inc_of(mm, cat=None): return sum(v for (m, k), v in INCC.items() if m in mm and (cat is None or k == cat))
from xrows import build as _xbuild, boutcat as _boutcat, card_buys as _cbuys
XR = _xbuild(INC) + _cbuys(R)   # + 刷卡分期的「分期購入」（0 元，看原始金額）   # 現金、帳戶扣款：做成跟刷卡一樣格式的明細（xrows.py）


def exp_cats(mm):
    """支出分類：刷卡（已扣代付、家人附卡）＋現金＋帳戶扣款，同名合併"""
    d = collections.defaultdict(lambda: [0.0, set()])
    for r in R:
        if r['date'][:7] in mm and r['category'] != REB: d[r['category']][0] += r['amount']; d[r['category']][1].add('刷卡')
    for x in XR:   # 現金、帳戶扣款（轉給配偶繳房貸的也算房貸）
        if x['date'][:7] in mm and x['amount']: d[x['category']][0] += x['amount']; d[x['category']][1].add('現金' if x['bank'] == '現金' else '帳戶扣款')
    return sorted(((k, v[0], '・'.join(sorted(v[1]))) for k, v in d.items() if round(v[0])), key=lambda x: -x[1])
INC_ITEMS = collections.defaultdict(list)   # 收入明細
for _x in (INC or {}).get('salary', []): INC_ITEMS[_x['date'][:7]].append((_x['date'], f"{_x['payer']} 薪資", '隨手記' if _x.get('src') == '隨手記' else '富邦帳戶入帳', _x['amount']))
for _x in (INC or {}).get('other', []): INC_ITEMS[_x['date'][:7]].append((_x['date'], _x['source'], _x.get('note') or '隨手記', _x['amount']))
CASH_ITEMS = collections.defaultdict(list)
for _x in (INC or {}).get('cash', []): CASH_ITEMS[_x['date'][:7]].append(_x)
BOUT_ITEMS = collections.defaultdict(list)
for _x in (INC or {}).get('bank_out', []): BOUT_ITEMS[_x['date'][:7]].append(_x)
BOUT = collections.defaultdict(float)
_bo = (INC or {}).get('bank_out', [])
_bom = len({x['date'][:7] for x in _bo}) or 1
_lc = collections.Counter(l for l, m in {(x['label'], x['date'][:7]) for x in _bo})
ONEOFF = {l for l, c in _lc.items() if c <= _bom * 0.5}   # 不是每個月都有的大額轉帳（例如偶爾一次匯一大筆給配偶繳房貸）→ 不定期大額
for _x in (INC or {}).get('bank_out', []): BOUT[_x['date'][:7]] += _x['amount']   # 房貸、固定轉帳
f = lambda n: f'{round(n):,}'
esc = H.escape


def mkey(y, m): return f'{y}-{m:02d}'
def prev(y, m): return (y - 1, 12) if m == 1 else (y, m - 1)
def pct(a, b): return (a / b - 1) * 100 if b else None
def mdiff(a, b): return (int(b[:4]) - int(a[:4])) * 12 + int(b[5:7]) - int(a[5:7])
def arrow(a, b): return f'{"▲" if a >= b else "▼"}{abs(pct(a, b) or 0):.0f}%' if b else '–'
def rate_txt(x): return '規則未建立' if x['rate'] is None else '%.1f%%' % x['rate']


def short_card(name):
    n = re.sub(r'（換發新卡號）|現金回饋卡|聯名卡', '', name)
    return re.sub(r'\s+', ' ', n).strip()


SP = [r for r in R if r['category'] != REB]
CHECKS = RC.get('checks', [])
MISSED_ALL = RC.get('missed_all', RC.get('missed', []))
MR_ALL = RC.get('month_rows_all', {})
MONTHS = []
_y, _m = int(CFG['start'][:4]), int(CFG['start'][5:])
LAST_DATA = max([mkey(CY, CM)] + [r['date'][:7] for r in R if r['date'][:7] <= CFG['data_through'][:7].replace('/', '-')])
while mkey(_y, _m) <= LAST_DATA:          # 網頁顯示到最新有資料的月份（帳單未到齊的會標示）
    MONTHS.append(mkey(_y, _m)); _m += 1
    if _m > 12: _y += 1; _m = 1


def agg(items):
    g = {}
    for x in items:
        k = (x['merchant'], x['cardname'])
        a = g.setdefault(k, dict(n=0, amount=0, gain=0, suggest=x['suggest'], reason=x['reason'], bank=x['bank'], dates=[]))
        a['n'] += 1; a['amount'] += x['amount']; a['gain'] += x['gain']; a['dates'].append(x['date'][5:].replace('-', '/'))
    return sorted(g.items(), key=lambda kv: -kv[1]['gain'])


def ctx(ym):
    """一個月份（依消費日）的所有數字"""
    y, m = int(ym[:4]), int(ym[5:]); py, pm = prev(y, m); pre = mkey(py, pm); ly = mkey(y - 1, m)
    tot = lambda k: sum(r['amount'] for r in SP if r['date'][:7] == k)
    c = dict(ym=ym, y=y, m=m, pm=pm, latest=(ym == mkey(CY, CM)), partial=(ym > mkey(CY, CM)))
    c['pv'] = [r for r in R if r.get('prov') and r['date'][:7] == ym]
    c['T'], c['TP'], c['TL'] = tot(ym), tot(pre), tot(ly)
    xs = [r for r in SP if r['date'][:7] == ym]
    xp = [r for r in SP if r['date'][:7] == pre]
    c['cnt'] = sum(1 for r in xs if r['amount'] > 0)
    bank = collections.defaultdict(float); bankp = collections.defaultdict(float)
    cat = collections.defaultdict(float); catp = collections.defaultdict(float)
    card = collections.defaultdict(lambda: [0.0, 0, ''])
    for r in xs:
        bank[r['bank']] += r['amount']; cat[r['category']] += r['amount']
        k = card[r['cardname']]; k[0] += r['amount']; k[1] += 1 if r['amount'] > 0 else 0; k[2] = r['bank']
    for r in xp:
        bankp[r['bank']] += r['amount']; catp[r['category']] += r['amount']
    xr = [r for r in XR if r['date'][:7] == ym]; xrp = [r for r in XR if r['date'][:7] == pre]
    for r in xr: bank[r['bank']] += r['amount']; cat[r['category']] += r['amount']
    for r in xrp: bankp[r['bank']] += r['amount']; catp[r['category']] += r['amount']
    _xt = lambda k: sum(r['amount'] for r in XR if r['date'][:7] == k)
    c['TA'], c['TAP'], c['TAL'] = c['T'] + _xt(ym), c['TP'] + _xt(pre), c['TL'] + _xt(ly)   # 全部支出＝刷卡＋現金＋帳戶扣款
    c['xr'] = xr
    c.update(bank=bank, bankp=bankp, cat=cat, catp=catp, card=card)
    c['rows'] = sorted([r for r in R if r['date'][:7] == ym] + xr, key=lambda r: (r['date'], r['bank']))
    other = [r for r in RA if r['date'][:7] == ym and not _bk.mine(r) and r['category'] != REB]
    c['fam'] = [r for r in other if r.get('owner') == '家人']
    c['paid'] = [r for r in other if r.get('owner') == '我' and r.get('paid')]
    c['hint'] = [r for r in RA if r['date'][:7] == ym and r.get('hint')]
    c['famT'] = sum(r['amount'] for r in c['fam']); c['paidT'] = sum(r['amount'] for r in c['paid'])
    c['sal'] = SAL.get(ym, 0); c['cash'] = CASH.get(ym, 0); c['bout'] = BOUT.get(ym, 0)
    c['lrec'] = [x for x in LREC['records'] if x['date'][:7] == ym]
    c['big'] = sorted([r for r in xs + xr if r['category'] not in FEES], key=lambda r: -r['amount'])[:5]
    c['refunds'] = sorted([r for r in xs if r['amount'] <= -10000], key=lambda r: r['amount'])
    fee = collections.defaultdict(float)
    for r in xs:
        if '年費' in r['merchant']:
            fee[(r['bank'], r['merchant'].replace('減免', ''))] += r['amount']
    c['fees'] = [dict(bank=b, merchant=mm, amount=v) for (b, mm), v in fee.items() if v > 0]
    c['fxfee'] = sum(r['amount'] for r in xs if r['category'] == '海外手續費')
    act = []                                  # 該月進行中的分期（依當時進度）
    for p in PLANS:
        if p.get('buy', '9')[:7] <= ym < p['start']:   # 無卡分期：買了、還沒開始繳
            act.append(dict(p, paid=0, remain=p['total'], new=(p['buy'][:7] == ym), wait=1))
        elif p['start'] <= ym <= p['end']:
            paid = min(mdiff(p['start'], ym) + 1, p['N'])
            act.append(dict(p, paid=paid, remain=(p['N'] - paid) * p['per'], new=(p['start'] == ym)))
    c['active'] = act; c['inst_month'] = sum(p['per'] for p in act if not p.get('wait'))
    MR = [x for x in MR_ALL.get(ym, []) if x['spend'] > 0]
    c['MR'] = MR
    c['est'] = sum(x['est'] or 0 for x in MR)
    base = sum(x['spend'] for x in MR if x['est'] is not None)
    c['est_rate'] = c['est'] / base * 100 if base else 0
    c['miss'] = [x for x in MISSED_ALL if x['date'][:7] == ym and x.get('act')]
    c['none'] = [x for x in MISSED_ALL if x['date'][:7] == ym and not x.get('act')]
    c['miss_g'] = agg(c['miss']); c['miss_gain'] = sum(x['gain'] for x in c['miss'])
    c['miss_keys'] = {(x['date'], x['merchant'], x['bank']) for x in c['miss']}
    c['none_keys'] = {(x['date'], x['merchant'], x['bank']) for x in c['none']}
    # 本月重點：最大三筆 → 花最多的分類 → 回饋 → 刷錯卡 → 其他
    T, TP = c['T'], c['TP']; hl = []
    if c['big']:
        hl.append(('info', f'最大三筆共 NT$ {f(sum(r["amount"] for r in c["big"][:3]))}', [
            f'{r["date"][5:].replace("-", "/")}　{r["merchant"]}　NT$ {f(r["amount"])}（{short_card(r["cardname"]).split(" ·")[0]}{"・分期" if r.get("installment") else ""}）'
            for r in c['big'][:3]]))
    cs = sorted(cat.items(), key=lambda x: -x[1]); _TA = c['TA']
    if cs:   # 原因交給下面的 key drivers
        hl.append(('info', f'花最多：{cs[0][0]} NT$ {f(cs[0][1])}（佔全部支出 {cs[0][1] / _TA * 100 if _TA else 0:.0f}%）',
                   ('其次是' + '、'.join(f'{k} {f(v)}' for k, v in cs[1:3]) + '。' if len(cs) > 1 else '')))
    hl += drivers(ym, pre)
    if c['latest']:
        bad = [k for k in CHECKS if k['status'].startswith('⚠️')]
        pend = [k for k in CHECKS if k['actual'] is None]
        okn = sum(1 for k in CHECKS if k['status'].startswith('✅'))
        if bad:
            hl.append(('bad', f'有 {len(bad)} 期回饋比應得少', '、'.join(f"{BFULL[k['bank']]} {k['stmt'][5:].replace('-', '/')} 帳單少 {f(k['expected'] - k['actual'])}" for k in bad) + '，建議打電話問銀行。'))
        else:
            hl.append(('ok', f'預估回饋 NT$ {f(c["est"])}（{c["est_rate"]:.1f}%），入帳都正常', f'近 6 個月 {okn} 期帳單都照規則入帳；還有 {len(pend)} 筆加碼等之後入帳。'))
    elif c['est']:
        hl.append(('ok', f'預估回饋 NT$ {f(c["est"])}（{c["est_rate"]:.1f}%）', '依各卡現行權益規則估算。'))
    if c['miss_g']:
        k0, a0 = c['miss_g'][0]
        hl.append(('warn', f'{len(c["miss"])} 筆刷錯卡，少拿約 NT$ {f(c["miss_gain"])}', f'最多的是 {k0[0]}（{short_card(k0[1])}）：{a0["suggest"]}。'))
    extra = [f'分期購入：{p["merchant"]} NT$ {f(p["total"])}，{p["N"]} 期（每期約 NT$ {f(p["total"] / p["N"])}），{int(p["start"][5:])} 月起每月算進「帳戶扣款」，這個月不一次算整筆'
             for p in act if p.get('nocard') and p['buy'][:7] == ym]
    extra += [f'新分期：{p["merchant"]} {p["N"]} 期，每期 NT$ {f(p["per"])}' for p in act if p['new'] and not (p.get('nocard') and p['buy'][:7] == ym)]
    extra += [f'{BFULL[r["bank"]]}退款 NT$ {f(-r["amount"])}（{r["merchant"]}），已從本月金額扣掉' for r in c['refunds'][:1]]
    if extra:
        hl.append(('info', '其他提醒', extra))
    c['hl'] = hl
    return c


def _top_item(ym, cat):
    """這個分類這個月最大的一筆（說明原因用）"""
    its = [(r['amount'], r['merchant']) for r in R if r['date'][:7] == ym and r['category'] == cat]
    its += [(x['amount'], x.get('note') or '現金') for x in CASH_ITEMS.get(ym, []) if x['category'] == cat]
    its += [(x['amount'], x.get('summary') or x['label']) for x in BOUT_ITEMS.get(ym, []) if re.sub(r'（.*?）', '', x['label']).strip() == cat or (cat == '房貸' and '房貸' in x['label'])]
    return max(its) if its else None


def drivers(ym, pre):
    """關鍵原因（key drivers）：總支出（刷卡＋現金＋帳戶扣款）、收入跟上個月、近 6 個月平均比，哪幾個分類貢獻最多"""
    i = MONTHS.index(ym) if ym in MONTHS else -1
    past = [m for m in MONTHS[max(0, i - 6):i]] if i > 0 else []
    if not past:
        return []
    cur = {k: v for k, v, _ in exp_cats([ym])}; prv = {k: v for k, v, _ in exp_cats([pre])}
    avg = collections.defaultdict(float)
    for m in past:
        for k, v, _ in exp_cats([m]): avg[k] += v / len(past)
    # 不定期大額（例如偶爾一次匯一大筆給配偶繳房貸）：另外列，比較時先扣掉，才看得出平常花費有沒有變
    def _one(m):
        return [x for x in BOUT_ITEMS.get(m, []) if x['amount'] >= 100000 and x['label'] in ONEOFF]
    def _cat(x): return '房貸' if '房貸' in x['label'] else re.sub(r'（.*?）', '', x['label']).strip()
    oc, op = _one(ym), _one(pre)
    for x in oc: cur[_cat(x)] = cur.get(_cat(x), 0) - x['amount']
    for x in op: prv[_cat(x)] = prv.get(_cat(x), 0) - x['amount']
    for m in past:
        for x in _one(m): avg[_cat(x)] -= x['amount'] / len(past)
    T, TP, TA = sum(cur.values()), sum(prv.values()), sum(avg.values())
    OT = sum(x['amount'] for x in oc)
    out = []
    def lines_(base):
        ds = sorted(((k, cur.get(k, 0) - base.get(k, 0)) for k in set(cur) | set(base)), key=lambda x: -abs(x[1]))
        res = []
        for k, dv in ds[:4]:
            if abs(dv) < 1000: break
            t = _top_item(ym, k) if dv > 0 else None
            res.append(f'{"▲" if dv > 0 else "▼"} {k} {"+" if dv > 0 else "−"}{f(abs(dv))}' + (f'（最大一筆：{t[1][:18]} {f(t[0])}）' if t and t[0] >= 0.3 * dv else ''))
        return res
    if TP:
        out.append(('info', (f'總支出 NT$ {f(T + OT)}（含不定期大額 {f(OT)}）・平常花費 NT$ {f(T)}，' if OT else f'總支出 NT$ {f(T)}，') + f'比 {int(pre[5:])} 月{"多" if T >= TP else "少"} {f(abs(T - TP))}（{pct(T, TP):+.0f}%）'
                    + (f'；比近 {len(past)} 個月平均{"高" if T >= TA else "低"} {abs(pct(T, TA) or 0):.0f}%' if TA else ''),
                    [f'不定期大額：{x["label"]} {f(x["amount"])}（{int(x["date"][5:7])}/{int(x["date"][8:])}），不列入比較' for x in oc] +
                    (lines_(prv) or ['各分類變化都不大']) + ['含刷卡、現金、帳戶扣款（房貸、分期、轉帳）']))
    ic = {k: v for (m, k), v in INCC.items() if m == ym}; ip = {k: v for (m, k), v in INCC.items() if m == pre}
    I, IP = sum(ic.values()), sum(ip.values())
    if I or IP:
        ds = sorted(((k, ic.get(k, 0) - ip.get(k, 0)) for k in set(ic) | set(ip)), key=lambda x: -abs(x[1]))
        why = [f'{"▲" if dv > 0 else "▼"} {k} {"+" if dv > 0 else "−"}{f(abs(dv))}' for k, dv in ds[:3] if abs(dv) >= 1000]
        out.append(('info', f'收入 NT$ {f(I)}，比 {int(pre[5:])} 月{"多" if I >= IP else "少"} {f(abs(I - IP))}・結餘 NT$ {f(I - T - OT)}' + (f'（不算不定期大額是 {f(I - T)}）' if OT else ''),
                    why or ['收入跟上個月差不多']))
    return out


lines = lambda x: x if isinstance(x, list) else [x]
C = {ym: ctx(ym) for ym in MONTHS}
NEWEST = max([ym for ym in MONTHS if C[ym]['rows']] or [''])
try:   # 各銀行每月結帳日（從帳單讀出的實際結帳日；太久沒帳單的銀行＝停卡或沒在刷，不列）
    import cycles as _cycles, datetime as _cdt
    CYC = {b: v for b, v in _cycles.by_bank().items()
           if b in BANKS and (_cdt.date.today() - _cdt.date.fromisoformat(v['last'])).days <= 75}
except Exception:
    CYC = {}


def cyc_card():
    if not CYC:
        return ''
    rows = ''.join(f'<tr class="cycrow" data-day="{v["day"]}"><td>{bdot(b)}{BFULL[b]}</td><td class="n"><b>每月 {v["day"]} 日</b></td><td class="n cnx"></td><td class="cst"></td>'
                   f'<td class="n mut">{(str(v["vary"][0]) + "–" + str(v["vary"][-1])) if len(v["vary"]) > 1 else v["vary"][0]} 日</td></tr>'
                   for b, v in sorted(CYC.items(), key=lambda kv: kv[1]['day']))
    return (f'<div class="card"><h2>每月結帳日</h2><p class="d">從各銀行帳單讀出的實際結帳日。結帳前 3 天內刷＝馬上進這期帳單；剛結帳後刷＝要到下一期才繳。遇假日銀行可能提前或順延 1–2 天</p>'
            f'<div class="tbl"><table class="cyct"><thead><tr><th>銀行</th><th class="n">結帳日</th><th class="n">下次結帳（約）</th><th>現在刷</th><th class="n">近幾期實際</th></tr></thead><tbody>{rows}</tbody></table></div></div>')


cur = C[mkey(CY, CM)]

# ======================= Email（存檔用：一封信就完整） =======================
FONT = "font-family:'Microsoft JhengHei','PingFang TC',Arial,sans-serif"
NUM = "font-family:'IBM Plex Mono',Consolas,'Courier New',monospace"
SERIF = "font-family:'Noto Serif TC','PMingLiU','Songti TC',serif"
NAVY, INK, INK2, MUTED, LINE = '#0e2035', '#121821', '#465061', '#7b8494', '#e3e8ee'
UP, DOWN = '#b3372b', '#17784b'
TONE = {'ok': ('#e8f5ee', '#17784b'), 'warn': ('#fff4e0', '#a86a00'), 'bad': ('#fdecea', '#b3372b'), 'info': ('#eef3f9', '#1d5c8f')}


def dot(b): return f'<span style="display:inline-block;width:8px;height:8px;border-radius:4px;background-color:{BCOL[b]};margin-right:6px"></span>'
def th(t, al='left'): return f'<td align="{al}" style="{FONT};font-size:12px;color:{MUTED};padding:6px 8px;border-bottom:1px solid #c9d1db">{t}</td>'
def td(c, al='left', ex=''): return f'<td align="{al}" valign="top" style="{FONT};font-size:14px;color:{INK};padding:9px 8px;border-bottom:1px solid {LINE};{ex}">{c}</td>'
def sub(t): return f'<div style="font-size:12px;color:{MUTED};margin-top:2px;font-weight:normal">{t}</div>'
def inner(rows): return f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse">{rows}</table>'


def kpi(lab, val, note, col='#f3f6fa'):
    return (f'<td width="33%" valign="top" bgcolor="#16304d" style="background-color:#16304d;padding:12px 14px;border-radius:10px;{FONT}">'
            f'<div style="font-size:12px;color:#a9b8cb">{lab}</div><div style="{NUM};font-size:19px;color:{col};margin:3px 0 2px;white-space:nowrap">{val}</div>'
            f'<div style="font-size:12px;color:#a9b8cb">{note}</div></td>')


def card_open(title, subt=''):
    return (f'<tr><td style="padding:0 0 14px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" '
            f'style="background-color:#ffffff;border:1px solid #e3e8ee;border-radius:14px;border-collapse:separate"><tr><td style="padding:18px 18px 8px">'
            f'<div style="{SERIF};font-size:18px;font-weight:900;color:{INK};letter-spacing:1px">{title}</div>'
            + (f'<div style="{FONT};font-size:12px;color:{MUTED};margin:2px 0 10px">{subt}</div>' if subt else '<div style="height:10px"></div>'))


CARD_CLOSE = '</td></tr></table></td></tr>'
c = cur
hl_rows = ''
for tone, t, s in c['hl']:
    bg, col = TONE[tone]
    hl_rows += (f'<tr><td style="padding:0 0 8px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse"><tr>'
                f'<td width="4" bgcolor="{col}" style="background-color:{col};font-size:0">&nbsp;</td><td bgcolor="{bg}" style="background-color:{bg};padding:10px 14px;{FONT}">'
                f'<div style="font-size:14px;font-weight:bold;color:{col}">{esc(t)}</div>'
                f'<div style="font-size:13px;color:{INK2};margin-top:2px;line-height:1.7">{"<br>".join(esc(x) for x in lines(s))}</div></td></tr></table></td></tr>')
rw_rows = f'<tr>{th("卡片")}{th("刷卡", "right")}{th("預估回饋", "right")}</tr>'
for x in c['MR']:
    rw_rows += (f'<tr>{td(dot(x["bank"]) + "<b>" + esc(short_card(x["card"])) + "</b>" + sub(esc(x["when"])), ex="font-size:13px")}'
                f'{td(f(x["spend"]), "right", f"color:{INK2};{NUM}")}'
                f'{td(("—" if x["est"] is None else f(x["est"])) + sub(rate_txt(x)), "right", f"font-weight:bold;{NUM}")}</tr>')
rw_rows += (f'<tr>{td("<b>合計</b>", ex="border-bottom:0")}{td("", ex="border-bottom:0")}'
            f'{td(f"<b style=\"color:{DOWN}\">{f(c['est'])}</b>" + sub(f"{c['est_rate']:.1f}%"), "right", f"border-bottom:0;{NUM}")}</tr>')
fix_rows = ''
for (mer, cn), a in c['miss_g']:
    fix_rows += (f'<tr>{td("<b>" + esc(mer) + "</b>" + sub(esc(short_card(cn)) + "・" + "、".join(sorted(a["dates"])) + f"・NT$ {f(a['amount'])}"))}'
                 f'{td("→ " + esc(a["suggest"]), ex=f"font-size:13px;color:{INK2}")}'
                 f'{td(f"<span style=\"color:{UP}\">−{f(a['gain'])}</span>", "right", f"white-space:nowrap;{NUM}")}</tr>')
oth_rows = ''                                  # 不算在我身上：家人附卡、代付、可能代付
_fc = collections.defaultdict(lambda: [0.0, 0, ''])
for r in c['fam']:
    k = _fc[r['cardname']]; k[0] += r['amount']; k[1] += 1; k[2] = r['bank']
for cn, (v, n, b) in sorted(_fc.items(), key=lambda x: -x[1][0]):
    oth_rows += f'<tr>{td(dot(b) + "<b>" + esc(short_card(cn)) + "</b>" + sub(f"家人附卡・{n} 筆"), ex="font-size:13px")}{td(f(v), "right", NUM)}</tr>'
for r in c['paid']:
    oth_rows += f'<tr>{td(dot(r["bank"]) + "<b>" + esc(r["merchant"]) + "</b>" + sub("代付・" + r["date"][5:].replace("-", "/")), ex="font-size:13px")}{td(f(r["amount"]), "right", NUM)}</tr>'
for r in c['hint']:
    oth_rows += (f'<tr>{td(dot(r["bank"]) + "<b>" + esc(r["merchant"]) + "</b>" + sub("可能是代付？" + r["hint"] + "（到 Excel 交易明細的「代付」欄勾 ✔）"), ex=f"font-size:13px;background-color:#fff4e0")}'
                 f'{td(f(r["amount"]), "right", NUM + ";background-color:#fff4e0")}</tr>')
det_rows = ''                                  # 全部明細：依卡片分組
bycard = collections.defaultdict(list)
for r in c['rows']:
    bycard[(BANKS.index(r['bank']), r['cardname'], r['bank'])].append(r)
for (_, cn, b), rs in sorted(bycard.items()):
    net = sum(r['amount'] for r in rs if r['category'] != REB)
    det_rows += (f'<tr><td colspan="3" bgcolor="#f3f6fa" style="background-color:#f3f6fa;{FONT};font-size:13px;font-weight:bold;color:{INK};padding:8px 8px">'
                 f'{dot(b)}{BFULL[b]}・{esc(short_card(cn))}<span style="float:right;{NUM};font-weight:normal">{len(rs)} 筆・NT$ {f(net)}</span></td></tr>')
    for r in rs:
        k = (r['date'], r['merchant'], r['bank'])
        tag = ''
        if r.get('installment'): tag += f' <span style="font-size:11px;color:#a86a00">分期 {r.get("inst_n")}/{r.get("inst_N")}</span>'
        if r.get('foreign'): tag += ' <span style="font-size:11px;color:#1d5c8f">海外</span>'
        if k in c['miss_keys']: tag += f' <span style="font-size:11px;color:{UP}">刷錯卡</span>'
        col = MUTED if r['category'] == REB else (DOWN if r['amount'] < 0 else INK)
        det_rows += (f'<tr>{td(r["date"][5:].replace("-", "/"), ex=f"font-size:12px;color:{MUTED};{NUM};white-space:nowrap")}'
                     f'{td(esc(r["merchant"]) + tag + sub(esc(r["category"]) + "・帳單 " + r["stmt"][5:].replace("-", "/")), ex="font-size:13px")}'
                     f'{td(f(r["amount"]), "right", f"color:{col};{NUM};white-space:nowrap")}</tr>')

BTN = f'''<tr><td align="center" style="padding:4px 0 18px"><table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>
<td bgcolor="{NAVY}" style="background-color:{NAVY};border-radius:999px;padding:12px 28px;{FONT}"><a href="{URL_REPORT}" style="color:#ffffff;text-decoration:none;font-size:14px;font-weight:bold">打開網頁版月報 →</a></td></tr></table></td></tr>''' if URL_REPORT else ''
email = f'''<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#eef1f4" style="background-color:#eef1f4;border-collapse:collapse"><tr><td align="center" style="padding:20px 10px">
<table role="presentation" width="640" cellpadding="0" cellspacing="0" border="0" style="width:640px;max-width:100%;border-collapse:collapse">
<tr><td style="padding:0 0 14px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="{NAVY}" style="background-color:{NAVY};background-image:linear-gradient(160deg,#0e2035,#16304d);border-radius:14px;border-collapse:separate">
<tr><td style="padding:24px 22px 8px;{FONT}">
<div style="{NUM};font-size:12px;letter-spacing:3px;color:#c9a45c">LIFELEDGER · {CY} 年 {CM} 月月報</div>
<div style="{NUM};font-size:38px;color:#f3f6fa;margin-top:10px;line-height:1.1">NT$ {f(c['T'])}</div>
<div style="font-size:14px;color:#a9b8cb;margin-top:8px">較 {c['pm']} 月 <b style="color:#f3f6fa;font-weight:normal">{arrow(c['T'], c['TP'])}</b>　較去年同月 <b style="color:#f3f6fa;font-weight:normal">{arrow(c['T'], c['TL'])}</b>　{c['cnt']} 筆</div>
</td></tr>
<tr><td style="padding:8px 14px 16px"><table role="presentation" width="100%" cellpadding="0" cellspacing="6" border="0"><tr>
{kpi("本月預估回饋", "NT$ " + f(c['est']), f"回饋率 {c['est_rate']:.1f}%", "#8fdcb3")}
{kpi("刷錯卡少拿", "NT$ " + f(c['miss_gain']), f"{len(c['miss'])} 筆可改善", "#ffb4aa" if c['miss_gain'] else "#f3f6fa")}
{kpi("分期每月", "NT$ " + f(c['inst_month']), f"{len(c['active'])} 筆進行中")}
</tr></table></td></tr></table></td></tr>
{card_open("本月重點")}{inner(hl_rows)}{CARD_CLOSE}
{card_open("本月回饋一覽", f"依 {CM} 月消費日預估，入帳時間各卡不同")}{inner(rw_rows)}{CARD_CLOSE}
{(card_open("刷錯卡（全部）", f"{CM} 月刷了卻沒拿到回饋的 {len(c['miss'])} 筆，依商家合併") + inner(fix_rows) + CARD_CLOSE) if fix_rows else ""}
{(card_open("不算在你身上的", f"家人附卡 NT$ {f(c['famT'])}・代付 NT$ {f(c['paidT'])}，上面的金額都已扣掉") + inner(oth_rows) + CARD_CLOSE) if oth_rows else ""}
{BTN}
{card_open("消費明細（全部）", f"{CM} 月所有帳單交易，依卡片分組；綠色為退款，灰色為回饋折抵")}{inner(det_rows)}{CARD_CLOSE}
<tr><td align="center" style="padding:8px 0 10px;{FONT};font-size:12px;color:{MUTED}">資料至 {CFG["data_through"]}・{f'<a href="{URL_LEDGER}" style="color:{MUTED}">生活帳本</a>・' if URL_LEDGER else ''}離線版：OneDrive › LifeLedger_生活總帳 › 月報</td></tr>
</table></td></tr></table>'''
open('email.html', 'w', encoding='utf8').write(email)
subj = f'LifeLedger｜{CM} 月刷卡 NT$ {f(c["T"])}（{"+" if c["T"] >= c["TP"] else "−"}{abs(pct(c["T"], c["TP"]) or 0):.0f}%）・回饋 {f(c["est"])}' + (f'・刷錯卡 {len(c["miss"])} 筆' if c['miss'] else '')
open('email_subject.txt', 'w', encoding='utf8').write(subj)


# ======================= 網頁（多月份、分頁） =======================
def ch(a, b):
    p = pct(a, b)
    if p is None: return '<span class="muted">–</span>'
    return f'<span class="chg {"up" if p >= 0 else "dn"}">{"▲" if p >= 0 else "▼"}{abs(p):.0f}%</span>'


def bdot(b): return f'<i class="dot" style="--c:var(--b{BANKS.index(b)})"></i>' if b in BANKS else '<i class="dot" style="--c:#8a8f98"></i>'
def meter(p, col='var(--bar)'): return f'<span class="meter"><span style="width:{max(1, min(100, p)):.0f}%;background:{col}"></span></span>'
def stc_of(s): return 'ok' if s.startswith('✅') else ('bad' if s.startswith('⚠️') else ('wait' if s.startswith('⏳') else 'na'))
def st_txt(s): return s.split(' ', 1)[1] if ' ' in s else s


def fix_cards(items, habit=False):
    out = ''
    for (mer, cn), a in items:
        when = f'半年 {a["n"]} 次' if habit else '、'.join(sorted(a['dates']))
        out += (f'<div class="fix"><div class="fx-top"><div><b>{esc(mer)}</b><small>{bdot(a["bank"])}{esc(short_card(cn))}・{when}</small></div>'
                f'<div class="n"><b>{f(a["amount"])}</b><small class="up">少拿 {f(a["gain"])}</small></div></div>'
                f'<div class="fx-do">→ {esc(a["suggest"])}</div><div class="fx-why">{esc(a["reason"])}</div></div>')
    return out



# ======================= 年度回顧（12 月的月報才有） =======================
PTS_ALL = json.load(open('points.json', encoding='utf8')) if os.path.exists('points.json') else []


def review_html(y):
    y = str(y); py = str(int(y) - 1)
    ms = [f'{y}-{k:02d}' for k in range(1, 13)]; pms = [f'{py}-{k:02d}' for k in range(1, 13)]
    have_prev = all(any(r['date'][:7] == m for r in R) for m in pms)
    def spend_of(mm): return sum(r['amount'] for r in R if r['date'][:7] in mm and r['category'] != REB) + sum(CASH.get(m, 0) + BOUT.get(m, 0) for m in mm)
    inc, exp = sum(SAL.get(m, 0) for m in ms), spend_of(ms)
    pinc, pexp = sum(SAL.get(m, 0) for m in pms), spend_of(pms)
    bal, pbal = inc - exp, pinc - pexp
    rate = bal / inc * 100 if inc else 0
    def yo(a, b, good_up=True):
        if not have_prev or not b: return '<span class="muted">去年資料不足</span>'
        p_ = (a / b - 1) * 100; up = p_ >= 0
        return f'<span class="{"pos" if up == good_up else "neg"}">{"▲" if up else "▼"}{abs(p_):.0f}%</span><small>去年 {f(b)}</small>'
    # 每月
    mx = max([SAL.get(m, 0) for m in ms] + [spend_of([m]) for m in ms] + [1]); W, H, gw = 640, 170, 640 / 12; bars = ''
    for i, m in enumerate(ms):
        si, so = SAL.get(m, 0), spend_of([m]); bw = gw * 0.32; hi, ho = si / mx * (H - 30), so / mx * (H - 30); x = i * gw
        bars += (f'<rect x="{x + gw * .16:.1f}" y="{H - 18 - hi:.1f}" width="{bw:.1f}" height="{hi:.1f}" rx="2" fill="#1baf7a"><title>{m} 收入 {f(si)}</title></rect>'
                 f'<rect x="{x + gw * .16 + bw + 2:.1f}" y="{H - 18 - ho:.1f}" width="{bw:.1f}" height="{ho:.1f}" rx="2" fill="{"#b3372b" if so > si else "#e07a6e"}"><title>{m} 支出 {f(so)}</title></rect>'
                 f'<text x="{x + gw / 2:.1f}" y="{H - 4}" text-anchor="middle" font-size="11" fill="currentColor" opacity=".6">{i + 1}月</text>')
    deficit = [m for m in ms if SAL.get(m, 0) and spend_of([m]) > SAL.get(m, 0)]
    # 分類
    cat = collections.defaultdict(float); pcat = collections.defaultdict(float)
    for r in R:
        if r['category'] == REB: continue
        if r['date'][:4] == y: cat[r['category']] += r['amount']
        elif r['date'][:4] == py: pcat[r['category']] += r['amount']
    for x in (INC or {}).get('cash', []):
        if x['date'][:4] == y: cat[x['category']] += x['amount']
        elif x['date'][:4] == py: pcat[x['category']] += x['amount']
    for x in (INC or {}).get('bank_out', []):
        if x['date'][:4] == y: cat[x['label']] += x['amount']
        elif x['date'][:4] == py: pcat[x['label']] += x['amount']
    cats = sorted(cat.items(), key=lambda kv: -kv[1])
    crow = ''.join(f'<tr><td>{esc(k)}</td><td class="n"><b>{f(v)}</b></td><td class="bar">{meter(v / exp * 100 if exp else 0)}</td><td class="n">{yo(v, pcat.get(k, 0), False) if have_prev else ""}</td></tr>' for k, v in cats[:10])
    # 大筆、商家
    ys = [r for r in R if r['date'][:4] == y and r['category'] != REB]
    big = sorted(ys, key=lambda r: -r['amount'])[:5]; bigsum = sum(r['amount'] for r in big)
    mer = collections.defaultdict(float)
    for r in ys: mer[r['merchant']] += r['amount']
    topm = sorted(mer.items(), key=lambda kv: -kv[1])[:5]
    # 回饋、費用
    reb = -sum(r['amount'] for r in R if r['date'][:4] == y and r['category'] == REB)
    pts = sum(p[2] or 0 for p in PTS_ALL if str(p[1])[:4] == y and p[2] and p[3] != '紅利點數')
    miss = [x for x in MISSED_ALL if x['date'][:4] == y and x.get('act')]
    missg = sum(x['gain'] for x in miss)
    fee_fx = sum(r['amount'] for r in ys if r['category'] == '海外手續費')
    fee_yr = sum(r['amount'] for r in ys if '年費' in r['merchant'])
    fxsp = sum(r['amount'] for r in ys if r.get('foreign') and r['category'] not in FEES)
    # 建議（都用實際數字）
    tips = []
    if inc:
        tone = 'ok' if rate >= 30 else ('warn' if rate >= 10 else 'bad')
        tips.append((tone, f'儲蓄率 {rate:.0f}%' + ('，收支健康' if rate >= 30 else ('，還有空間' if rate >= 10 else '，支出接近收入')),
                     f'一年存下 NT$ {f(bal)}，平均每月 NT$ {f(bal / 12)}。' + (f'比去年{"多" if bal >= pbal else "少"}存 NT$ {f(abs(bal - pbal))}。' if have_prev else '')))
    if deficit:
        why = []
        for m in deficit[:3]:
            cm = collections.defaultdict(float)
            for r in R:
                if r['date'][:7] == m and r['category'] != REB: cm[r['category']] += r['amount']
            k0 = max(cm, key=cm.get) if cm else '—'
            why.append(f'{int(m[5:])} 月（{k0} NT$ {f(cm.get(k0, 0))}）')
        tips.append(('warn', f'{len(deficit)} 個月支出超過收入', '、'.join(why) + '。大額支出可以提早分攤或改分期 0 利率。'))
    if have_prev:
        up = sorted(((k, v - pcat.get(k, 0)) for k, v in cat.items()), key=lambda kv: -kv[1])
        if up and up[0][1] > 0:
            k, d_ = up[0]; tips.append(('info', f'增加最多：{k} 多了 NT$ {f(d_)}', f'今年 NT$ {f(cat[k])}、去年 NT$ {f(pcat.get(k, 0))}。可以替這一類設個每月預算。'))
    if big:
        tips.append(('info', f'最大 5 筆佔全年支出 {bigsum / exp * 100 if exp else 0:.0f}%', '、'.join(f'{esc(r["merchant"])} {f(r["amount"])}' for r in big[:3]) + '。這類大額支出決定了一年的結餘。'))
    if missg >= 100:
        g = agg(miss)[:1]
        tips.append(('warn', f'刷錯卡少拿約 NT$ {f(missg)}', (f'最多的是 {g[0][0][0]}：{g[0][1]["suggest"]}。' if g else '') + '明年把固定扣款綁到對的卡，這筆就能拿回來。'))
    if fee_fx >= 300:
        tips.append(('info', f'海外手續費 NT$ {f(fee_fx)}', f'海外消費共 NT$ {f(fxsp)}。改用海外回饋高、可抵手續費的卡（例如 uniopen 海外實體店 3%＋加碼、永豐幣倍卡）。'))
    tips.append(('ok', f'{int(y) + 1} 年：現金也記進隨手記', '刷卡會自動進來；現金、其他收入記在隨手記，明年的回顧就是完整的家庭收支。'))
    # 收入組成：薪資 vs 業外（含房租、投資與配息、利息）
    sa, psa = inc_of(ms, '薪資'), inc_of(pms, '薪資')
    def yrow(lab, a_, b_, cls='', lc=''):
        if not have_prev:   # 去年資料不完整：只列今年，不做比較
            return f'<tr class="{cls}"><td class="{lc}">{lab}</td><td class="n"><b>{f(a_)}</b></td><td class="n muted">{a_ / inc * 100 if inc else 0:.0f}%</td></tr>'
        return f'<tr class="{cls}"><td class="{lc}">{lab}</td><td class="n">{f(b_)}</td><td class="n"><b>{f(a_)}</b></td><td class="n">{f(a_ - b_) if b_ else ""}</td><td class="n">{yo(a_, b_) if b_ else ""}</td></tr>'
    comp = yrow('薪資', sa, psa, 'sub') + yrow('業外收入', inc - sa, pinc - psa, 'sub') + ''.join(yrow(k, inc_of(ms, k), inc_of(pms, k), '', 'ind') for k in _bk.INC_CATS[1:]) + yrow('收入合計', inc, pinc, 'sub')
    inc_comp = (f'<div class="card"><h2>收入：薪資＋業外</h2><p class="d">{y} 年薪資 NT$ {f(sa)}＋業外 NT$ {f(inc - sa)}' + (f'（{py} 年：薪資 {f(psa)}＋業外 {f(pinc - psa)}）' if have_prev else '') + '；配息含保單配息、股利</p>'
                f'<div class="tbl"><table class="inct"><tr><th></th>' + (f'<th class="n">{py}</th><th class="n">{y}</th><th class="n">差額</th><th class="n">YoY</th>' if have_prev else f'<th class="n">{y}</th><th class="n">佔收入</th>') + f'</tr>{comp}</table></div></div>')
    tip_html = ''.join(f'<div class="hl {t}"><b>{a}</b><span>{b}</span></div>' for t, a, b in tips)
    big_html = ''.join(f'<tr><td class="muted n">{r["date"][5:].replace("-", "/")}</td><td>{esc(r["merchant"])}<small>{esc(r["category"])}・{esc(short_card(r["cardname"]))}</small></td><td class="n"><b>{f(r["amount"])}</b></td></tr>' for r in big)
    mer_html = ''.join(f'<tr><td>{esc(k)}</td><td class="n"><b>{f(v)}</b></td></tr>' for k, v in topm)
    return f"""
<section data-tab="review">
  <div class="card rv"><div class="rvhead"><span class="eyebrow">{y} 年度回顧</span><h2>{y} 年存下 NT$ {f(bal)}</h2>
    <p class="d">收入＝薪資入帳＋其他收入；支出＝你和配偶 的刷卡＋帳戶扣款（房貸、分期、轉帳）＋現金。{"" if have_prev else f"（{py} 年資料不完整，明年起才有逐項 YoY）"}</p></div>
    <div class="sum rvsum"><div><span class="l">全年收入</span><span class="v pos">NT$ {f(inc)}</span>{yo(inc, pinc)}</div>
      <div><span class="l">全年支出</span><span class="v">NT$ {f(exp)}</span>{yo(exp, pexp, False)}</div>
      <div><span class="l">結餘</span><span class="v {"pos" if bal >= 0 else "neg"}">NT$ {f(bal)}</span>{yo(bal, pbal)}</div>
      <div><span class="l">儲蓄率</span><span class="v">{rate:.0f}%</span>{f'<small>去年 {pbal / pinc * 100:.0f}%</small>' if have_prev and pinc else ''}</div></div>
    <div class="leg"><i style="background:#1baf7a"></i>收入<i style="background:#e07a6e"></i>支出<i style="background:#b3372b"></i>支出超過收入</div>
    <svg viewBox="0 0 {W} {H}" class="incsvg" role="img" aria-label="{y} 每月收支">{bars}</svg></div>
  {inc_comp}
  <div class="card"><h2>給明年的建議</h2><p class="d">都是從今年的實際帳單算出來的</p><div class="hls">{tip_html}</div></div>
  <div class="card"><h2>支出分類</h2><p class="d">全年，含現金{"；右欄為與去年比較" if have_prev else ""}</p><div class="tbl"><table><tr><th>分類</th><th class="n">金額</th><th></th><th class="n">{"YoY" if have_prev else ""}</th></tr>{crow}</table></div></div>
  <div class="grid2">
    <div class="card"><h2>最大 5 筆</h2><div class="tbl"><table>{big_html}</table></div></div>
    <div class="card"><h2>花最多的商家</h2><div class="tbl"><table>{mer_html}</table></div></div>
  </div>
  <div class="card"><h2>回饋與費用</h2><div class="sum"><div><span class="l">現金回饋入帳</span><span class="v pos">NT$ {f(reb)}</span></div>
    <div><span class="l">點數</span><span class="v">{f(pts)} 點</span></div><div><span class="l">刷錯卡少拿</span><span class="v neg">NT$ {f(missg)}</span></div>
    <div><span class="l">年費＋海外手續費</span><span class="v">NT$ {f(fee_yr + fee_fx)}</span></div></div></div>
</section>"""

def _src(r):
    """付款方式：哪張卡／現金／哪個帳戶"""
    if r['bank'] == '現金': return '現金' if r['cardname'] == '現金' else '隨手記・' + r['cardname']
    if r['bank'] == '帳戶': return r['cardname']
    return BFULL[r['bank']] + ' ' + short_card(r['cardname']).split(' ·')[0]


def cat_tree(rows, T):
    """大分類 → 細分類 → 付款方式（點開看）"""
    g = collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(float)))
    for r in rows:
        if r['category'] == REB or not r['amount']: continue
        g[r['category'].split('・')[0]][r['category']][(r['bank'], _src(r))] += r['amount']
    out = ''
    for top, subs in sorted(g.items(), key=lambda kv: -sum(sum(v.values()) for v in kv[1].values())):
        tt = sum(sum(v.values()) for v in subs.values())
        if round(tt) == 0: continue
        inner = ''
        for sc, srcs in sorted(subs.items(), key=lambda kv: -sum(kv[1].values())):
            st = sum(srcs.values())
            pays = ''.join(f'<li>{bdot(b)}<span>{esc(s)}</span><b class="n">{f(v)}</b></li>' for (b, s), v in sorted(srcs.items(), key=lambda kv: -kv[1]) if round(v))
            if len(subs) == 1 and '・' not in sc:   # 沒有細分類（例如房貸）：直接列付款方式
                inner += f'<ul class="pays">{pays}</ul>'; continue
            nm = sc.split('・', 1)[1] if '・' in sc else '（未細分）'
            inner += (f'<details class="ct2"><summary><span class="nm">{esc(nm)}</span><b class="n">{f(st)}</b><span class="n muted pc">{st / tt * 100 if tt else 0:.0f}%</span></summary><ul class="pays">{pays}</ul></details>')
        out += (f'<details class="ct"><summary><span class="nm">{esc(top)}</span>{meter(tt / T * 100 if T and tt > 0 else 0)}<b class="n">{f(tt)}</b>'
                f'<span class="n muted pc">{tt / T * 100 if T else 0:.0f}%</span></summary><div class="ctin">{inner}</div></details>')
    return f'<div class="ctree">{out}</div>'


def recon_card(ym):
    """對帳：帳上的結餘（收入−支出）跟存款帳戶實際多了／少了多少，差額列出來"""
    if not DEPJ: return ''
    bal = collections.defaultdict(dict); loan = collections.defaultdict(dict)
    for s in DEPJ.get('stmts', []):
        if s.get('balance') is not None: bal[s['month']][s['bank']] = s['balance']; loan[s['month']][s['bank']] = s.get('loan') or 0
    banks = sorted({b for m in bal.values() for b, v in m.items() if v})
    RNG = {b: (min(m for m in bal if b in bal[m]), max(m for m in bal if b in bal[m])) for b in banks}   # 每個帳戶有對帳單的期間
    hist = [m for m in MONTHS if m <= ym and m <= max(bal)][-12:]   # 還沒有任何對帳單的月份不列
    rows = ''
    for m in hist:
        y_, mo = int(m[:4]), int(m[5:]); py_, pm_ = prev(y_, mo); p = mkey(py_, pm_)
        inc = SAL.get(m, 0); out = (C[m]['TA'] if m in C else 0); res = inc - out
        miss = [b for b in banks if RNG[b][0] <= m <= RNG[b][1] and (b not in bal.get(m, {}) or (p >= RNG[b][0] and b not in bal.get(p, {})))]
        have = [b for b in banks if b not in miss and RNG[b][0] <= m <= RNG[b][1]]
        dd = sum(bal[m][b] - bal.get(p, {}).get(b, 0) for b in have)   # 新開的帳戶：上個月當 0
        dl = sum(loan[p].get(b, 0) - loan[m].get(b, 0) for b in have)   # 房貸本金少了多少（＝存下來的）
        gap = dd + dl - res
        note = []
        if miss: note.append('缺 ' + '、'.join(miss) + ' 對帳單')
        if abs(gap) >= 20000 and not miss: note.append('看下面說明')
        rows += (f'<tr><td><b>{int(m[5:])} 月</b><small>{m[:4]}</small></td><td class="n pos">{f(inc)}</td><td class="n">{f(out)}</td>'
                 f'<td class="n"><b class="{"pos" if res >= 0 else "neg"}">{f(res)}</b></td><td class="n">{f(dd)}</td><td class="n muted">{f(dl)}</td>'
                 f'<td class="n"><b>{f(gap)}</b>{f"<small>{esc(chr(12289).join(note))}</small>" if note else ""}</td></tr>')
    return (f'<div class="card"><h2>對帳：結餘 vs 存款實際變化</h2>'
            f'<p class="d">結餘＝你的收入 − 支出（我＋配偶：刷卡、現金、帳戶扣款，不含家人附卡、代付）。存款變化＝有對帳單的帳戶月底餘額變化；房貸本金減少也算存下來的。差額越接近 0，帳就越完整。</p>'
            f'<div class="tbl"><table><tr><th>月份</th><th class="n">收入</th><th class="n">支出</th><th class="n">結餘</th><th class="n">存款變化</th><th class="n">房貸本金↓</th><th class="n">差額</th></tr>{rows}</table></div>'
            f'<details class="more"><summary>差額通常是什麼？</summary><div class="d" style="padding:6px 2px;line-height:1.7">'
            f'① 信用卡是「刷卡月」算支出，但下個月才從帳戶扣款，所以月和月之間會一正一負互抵。<br>'
            f'② 沒有對帳單的帳戶（例如合庫、LINE Bank 缺的月份）進出看不到。<br>'
            f'③ 投資買賣、定存、轉帳固定轉帳 或家人、提領現金，不算收入支出，但會讓存款變少。<br>'
            f'④ 家人附卡、代墊的錢由你的帳戶繳卡費，但不算你的支出；收回來的錢也不算收入。</div></details></div>')


def page_month(c):
    ym, T, m = c['ym'], c['TA'], c['m']   # T：全部支出（刷卡＋現金＋帳戶扣款）
    hl_html = ''.join(f'<div class="hl {t}"><b>{esc(a)}</b>' + ''.join(f'<span>{esc(x)}</span>' for x in lines(b)) + '</div>' for t, a, b in c['hl'])
    bank_html = ''.join(f'<tr><td>{bdot(b)}{BFULL[b]}</td><td class="n">{f(v)}</td><td class="bar">{meter(v / T * 100 if T and v > 0 else 0, f"var(--b{BANKS.index(b)})")}</td><td class="n">{ch(v, c["bankp"].get(b, 0))}</td></tr>'
                        for b, v in sorted(c['bank'].items(), key=lambda x: -x[1]))
    cat_html = cat_tree(c['rows'], T)
    big_html = ''.join(f'<tr><td class="muted n">{r["date"][5:].replace("-", "/")}</td><td>{esc(r["merchant"])}{" <span class=tag>分期</span>" if r.get("installment") else ""}<small>{bdot(r["bank"])}{esc(short_card(r["cardname"]))}</small></td><td class="n"><b>{f(r["amount"])}</b></td></tr>' for r in c['big'])
    rw = ''
    for x in c['MR']:
        note = []
        if x['miss']: note.append(f'不給回饋的 {f(x["miss"])}')
        if x.get('refund'): note.append(f'退款 {f(x["refund"])} 未扣')
        rw += (f'<tr><td>{bdot(x["bank"])}<b>{esc(short_card(x["card"]))}</b><small>{esc(x["when"])}</small></td>'
               f'<td class="n">{f(x["spend"])}{"<small>" + "・".join(note) + "</small>" if note else ""}</td>'
               f'<td class="n"><b>{"—" if x["est"] is None else f(x["est"])}</b><small>{rate_txt(x)}</small></td>'
               f'<td><span class="st {stc_of(x["status"])}">{esc(st_txt(x["status"]))}</span></td></tr>')
    chk = ''
    if c['latest'] and CHECKS:
        byc = collections.defaultdict(list)
        for k in CHECKS: byc[(k['bank'], k['card'])].append(k)
        rows1 = ''
        for (b, cn), ks in sorted(byc.items()):
            ks.sort(key=lambda k: k['stmt']); done = [k for k in ks if k['actual'] is not None]
            nb = sum(1 for k in ks if k['status'].startswith('⚠️')); nw = len(ks) - len(done); last = done[-1] if done else None
            st = ('bad', f'少給 {nb} 期') if nb else ('ok', f'{len(done)} 期正常')
            rows1 += (f'<tr><td>{bdot(b)}<b>{esc(cn)}</b><small>{"最近 " + last["stmt"][5:].replace("-", "/") + " 帳單：應得 " + f(last["expected"]) + "、實得 " + f(last["actual"]) if last else ""}</small></td>'
                      f'<td><span class="st {st[0]}">{st[1]}</span>{f"<small>{nw} 筆待入帳</small>" if nw else ""}</td></tr>')
        rows2 = ''.join(f'<tr><td>{bdot(k["bank"])}{esc(k["card"])}<small>{k["stmt"].replace("-", "/")}・{esc(k["note"])}</small></td><td class="n">{f(k["expected"])}</td><td class="n">{"—" if k["actual"] is None else f(k["actual"])}</td><td><span class="st {stc_of(k["status"])}">{esc(st_txt(k["status"]))}</span></td></tr>'
                        for k in sorted(CHECKS, key=lambda k: (k['bank'], k['stmt']), reverse=True))
        chk = (f'<div class="card"><h2>帳單入帳核對</h2><p class="d">近 6 個月：應得（依規則估算）vs 帳單實際入帳</p><div class="tbl"><table><tr><th>卡片</th><th>結果</th></tr>{rows1}</table></div>'
               f'<details><summary>逐期明細（{len(CHECKS)} 筆）</summary><div class="tbl"><table><tr><th>卡片・帳單</th><th class="n">應得</th><th class="n">實得</th><th>狀態</th></tr>{rows2}</table></div></details></div>')
    none_note = (f'另有 {len(c["none"])} 筆分期、稅費或罰款共 NT$ {f(sum(x["amount"] for x in c["none"]))}，各卡本來就沒有回饋，不用換卡。' if c['none'] else '')
    fix_html = fix_cards(c['miss_g']) or '<p class="empty">這個月沒有刷錯卡</p>'
    habit = ''
    if c['latest']:
        recent = [x for x in MISSED_ALL if x.get('act') and 0 <= mdiff(x['date'][:7], ym) < 6]
        hb = [kv for kv in agg(recent) if kv[1]['n'] >= 2][:8]
        if hb:
            habit = f'<div class="card"><h2>固定會遇到的</h2><p class="d">近 6 個月重複 2 次以上，直接改掉付款方式或自動扣繳的卡</p><div class="fixes">{fix_cards(hb, True)}</div></div>'
    def txrow(r, chip=True):
        k = (r['date'], r['merchant'], r['bank'])
        tags = ''
        if r.get('installment'): tags += f'<span class="tag">分期 {r.get("inst_n")}/{r.get("inst_N")}</span>'
        if r.get('foreign'): tags += f'<span class="tag fx">海外{(" " + esc(r["currency"])) if r.get("currency") and r["currency"] != "TWD" else ""}</span>'
        if k in c['miss_keys']: tags += '<span class="tag bad">刷錯卡</span>'
        elif k in c['none_keys']: tags += '<span class="tag na">無回饋</span>'
        cls = 'reb' if r['category'] == REB else ('neg' if r['amount'] < 0 else '')
        desc = r['desc'] if r['desc'] and r['desc'] != r['merchant'] else ''
        bi = BANKS.index(r['bank'])
        chip_html = (f'<span class="cardchip" style="--c:var(--b{bi})"><b>{BFULL[r["bank"]]}</b>{esc(short_card(r["cardname"]))}</span>' if chip else '')
        if r.get('prov'): tags += '<span class="tag pv">暫列・隨手記</span>'
        if r.get('buy'): tags += '<span class="tag">分期購入</span>'
        pdb = ''
        _pid = ('r' + r['rid']) if r.get('prov') and r.get('rid') else ''
        if (_pid or not r.get('prov')) and r['category'] != REB and r.get('key'):
            if not _pid:
                _h = __import__('hashlib').sha1(str(r['key']).split('#')[0].encode('utf8')).hexdigest(); _pid = f'h{_h[:6]}k{_h[6:12]}'
            _pr = r.get('paid_ratio') or 0
            pdb = (f'<button type="button" class="pdb{" on" if _pr else ""}" data-pd="{_pid}" data-a="{round(r["amount"])}" data-pr="{_pr}">'
                   + (f'自付 {round((1 - _pr) * 100)}%' if _pr else '代墊？') + '</button>')
        return (f'<tr class="tx {cls}" data-d="{r["date"]}" data-b="{r["bank"]}" data-k="{esc(r["category"])}" data-c="{esc(r["cardname"])}" data-s="{esc((r["merchant"] + " " + desc + " " + r["category"] + " " + r["cardname"] + " " + (r.get("sub_items") or "") + " " + (r.get("sub") or "")).lower())}">'
                f'<td class="n muted">{r["date"][5:].replace("-", "/")}</td>'
                f'<td><div class="mer">{esc(r["merchant"])}{tags}</div>{chip_html}'
                f'<small>{esc(r["category"])}・{("帳單 " + r["stmt"][5:].replace("-", "/")) if r.get("stmt") else ({"cash": "隨手記・現金", "bank": "存款帳戶扣款"}.get(r.get("src")) or "帳單還沒到")}{("・" + esc(desc)) if desc and not r.get("prov") else ""}</small>'
                f'{('<small class="inv">🧾 ' + esc(r["sub_items"]) + "</small>") if r.get("sub_items") else ""}</td>'
                f'<td class="n amt">{f(r["amount"])}{pdb}</td></tr>')
    det = ''.join(txrow(r) for r in c['rows'])
    grp = collections.defaultdict(list)
    for r in c['rows']:
        grp[(BANKS.index(r['bank']), r['cardname'])].append(r)
    det_card = ''
    for (bi, cn), rs in sorted(grp.items()):
        net = sum(r['amount'] for r in rs if r['category'] != REB)
        det_card += (f'<tbody class="g"><tr class="gh" style="--c:var(--b{bi})"><td colspan="3"><span class="gname"><b>{BFULL[BANKS[bi]]}</b>{esc(short_card(cn))}</span>'
                     f'<span class="gsum n">{len(rs)} 筆・NT$ {f(net)}</span></td></tr>' + ''.join(txrow(r, False) for r in rs) + '</tbody>')
    gk = collections.defaultdict(list)
    for r in c['rows']:
        gk[r['category']].append(r)
    det_cat = ''

    def _subline(rs):   # 子分類小結：例如「加油 NT$ 2,400・停車 NT$ 350」（分類已拆細的就不用）
        if rs and '・' in rs[0]['category']:
            return ''
        sb = collections.defaultdict(float)
        for r in rs:
            if r.get('sub') and r['amount'] > 0:
                sb[r['sub']] += r['amount']
        if len(sb) < 2 and not any('未分類' in k for k in sb):
            return ''
        return ('<tr class="gh"><td colspan="3" style="font-size:12px;opacity:.8;padding-top:0">'
                + '・'.join(f'{esc(k)} NT$ {f(v)}' for k, v in sorted(sb.items(), key=lambda x: -x[1])) + '</td></tr>')
    for k_, rs in sorted(gk.items(), key=lambda kv: (kv[0] == REB, -sum(r['amount'] for r in kv[1]))):
        net = sum(r['amount'] for r in rs)
        share = net / T * 100 if T and k_ != REB and net > 0 else 0
        det_cat += (f'<tbody class="g"><tr class="gh kh"><td colspan="3"><span class="gname"><b>{esc(k_)}</b>{meter(share)}</span>'
                    f'<span class="gsum n">{len(rs)} 筆・NT$ {f(net)}{f"・{share:.0f}%" if share else ""}</span></td></tr>' + _subline(rs) + ''.join(txrow(r) for r in sorted(rs, key=lambda r: -r['amount'])) + '</tbody>')
    cats_opt = ''.join(f'<option value="{esc(k_)}">{esc(k_)}</option>' for k_ in sorted(gk, key=lambda k_: -sum(r['amount'] for r in gk[k_])))
    cards_opt = ''.join(f'<option value="{esc(cn)}">{esc(short_card(cn))}</option>' for cn in sorted({r['cardname'] for r in c['rows']}))
    banks_btn = ''.join(f'<button type="button" class="pill" data-b="{b}" aria-pressed="false">{bdot(b)}{b}</button>' for b in BANKS if any(r['bank'] == b for r in c['rows']))
    card_html = ''.join(f'<tr><td>{bdot(b)}{esc(short_card(nm))}</td><td class="n muted">{n}</td><td class="n"><b>{f(v)}</b></td><td class="bar">{meter(v / T * 100 if T else 0, f"var(--b{BANKS.index(b)})")}</td></tr>'
                        for nm, (v, n, b) in sorted(c['card'].items(), key=lambda x: -x[1][0]) if v > 0)
    inst_html = ''.join(f'<tr><td>{esc(p["merchant"])}{" <span class=tag>新</span>" if p["new"] else ""}<small>{(bdot(p["bank"]) + esc(short_card(p["card"]))) if not p.get("nocard") else esc(p["card"]) + ("・" + str(int(p["start"][5:])) + " 月開始算" if not p["paid"] else "")}</small></td>'
                        f'<td class="n">{p["paid"]}/{p["N"]}<span class="meter sm"><span style="width:{p["paid"] / p["N"] * 100:.0f}%;background:var(--b2)"></span></span></td>'
                        f'<td class="n">{f(p["per"])}</td><td class="n"><b>{f(p["remain"])}</b></td></tr>' for p in c['active'])
    fee_line = ('、'.join(f'{BFULL[x["bank"]]}{x["merchant"]} {f(x["amount"])} 元' for x in c['fees'])) if c['fees'] else '本月沒有實收年費'
    _xc = sum(r['amount'] for r in c['xr'] if r['bank'] == '現金'); _xb = sum(r['amount'] for r in c['xr'] if r['bank'] == '帳戶')
    _ot = sum(r['amount'] for r in c['xr'] if r['bank'] == '帳戶' and r['amount'] >= 100000 and r['merchant'] in ONEOFF)   # 不定期大額（例如偶爾一次匯一大筆給配偶繳房貸）
    hero = f'''<div class="big"><span class="v">NT$ {f(T)}</span>
    <span class="s">全部支出：刷卡 {f(c["T"])}{f"・現金 {f(_xc)}" if _xc else ""}{f"・帳戶扣款 {f(_xb)}" if _xb else ""}{f"<br>平常花費 <b>NT$ {f(T - _ot)}</b>（不含不定期大額 {f(_ot)}）" if _ot else ""}</span>
    <span class="s">較 {c["pm"]} 月 <b>{arrow(T, c["TAP"])}</b>　較去年同月 <b>{arrow(T, c["TAL"])}</b>　{c["cnt"]} 筆刷卡</span>
    {f'<span class="s ex">不含家人附卡 {f(c["famT"])}{f"、代付 {f(c['paidT'])}" if c["paidT"] else ""}{"・<b>" + str(len(c["hint"])) + " 筆可能代付</b>" if c["hint"] else ""}</span>' if (c["famT"] or c["paidT"] or c["hint"]) else ''}</div>
  <div class="kpis">
    <div class="kpi"><div class="l">預估回饋</div><div class="v g">NT$ {f(c["est"])}</div><div class="s">回饋率 {c["est_rate"]:.1f}%</div></div>
    <div class="kpi"><div class="l">刷錯卡少拿</div><div class="v{" r" if c["miss_gain"] else ""}">NT$ {f(c["miss_gain"])}</div><div class="s">{len(c["miss"])} 筆可改善</div></div>
    <div class="kpi"><div class="l">分期每月</div><div class="v">NT$ {f(c["inst_month"])}</div><div class="s">{len(c["active"])} 筆進行中</div></div>
  </div>'''
    _fc = collections.defaultdict(lambda: [0.0, 0, ''])
    for r in c['fam']:
        k = _fc[r['cardname']]; k[0] += r['amount']; k[1] += 1; k[2] = r['bank']
    oth = ''.join(f'<tr><td>{bdot(b)}<b>{esc(short_card(cn))}</b><small>家人附卡・{n} 筆</small></td><td class="n"><b>{f(v)}</b></td></tr>'
                  for cn, (v, n, b) in sorted(_fc.items(), key=lambda x: -x[1][0]))
    oth += ''.join(f'<tr><td>{bdot(r["bank"])}<b>{esc(r["merchant"])}</b><small>代付・{r["date"][5:].replace("-", "/")}・{esc(short_card(r["cardname"]))}</small></td><td class="n"><b>{f(r["amount"])}</b></td></tr>' for r in c['paid'])
    hint = ''.join(f'<tr class="hintrow"><td>{bdot(r["bank"])}<b>{esc(r["merchant"])}</b><small>{r["date"][5:].replace("-", "/")}・{esc(short_card(r["cardname"]))}・{esc(r["hint"])}</small></td><td class="n"><b>{f(r["amount"])}</b></td></tr>' for r in c['hint'])
    oth_card = ((f'<div class="card"><h2>不算在你身上的</h2><p class="d">家人刷的附卡、你勾了代付的交易，另外列；上面的金額都已扣掉</p>'
                 f'<div class="sum"><div><span class="l">家人附卡</span><span class="v">NT$ {f(c["famT"])}</span></div><div><span class="l">代付</span><span class="v">NT$ {f(c["paidT"])}</span></div></div>'
                 + (f'<div class="tbl"><table><tr><th>項目</th><th class="n">金額</th></tr>{oth}</table></div>' if oth else '')
                 + (f'<h3 class="h3">可能是代付？</h3><p class="d">是的話，到 Excel「交易明細」的「代付」欄選 ✔，下次更新就會移到這裡</p><div class="tbl"><table>{hint}</table></div>' if hint else '')
                 + '</div>') if (oth or hint) else '')
    inc_card = ''
    if INC:
        def spend_m(m): return (C[m]['T'] if m in C else 0) + CASH.get(m, 0) + BOUT.get(m, 0)
        out_ = T; bal = c['sal'] - out_
        hist = [m for m in MONTHS if m <= ym][-12:]
        mx = max([SAL.get(m, 0) for m in hist] + [spend_m(m) for m in hist] + [1])
        W, H, n = 640, 170, len(hist); gw = W / max(n, 1)
        bars = ''
        for i, mm_ in enumerate(hist):
            x = i * gw; si, so = SAL.get(mm_, 0), spend_m(mm_); bw = gw * 0.32
            hi, ho = si / mx * (H - 30), so / mx * (H - 30)
            bars += (f'<rect x="{x + gw * 0.16:.1f}" y="{H - 18 - hi:.1f}" width="{bw:.1f}" height="{hi:.1f}" rx="2" fill="var(--inc,#1baf7a)"><title>{mm_} 收入 {f(si)}</title></rect>'
                     f'<rect x="{x + gw * 0.16 + bw + 2:.1f}" y="{H - 18 - ho:.1f}" width="{bw:.1f}" height="{ho:.1f}" rx="2" fill="var(--exp,#e07a6e)"><title>{mm_} 支出 {f(so)}</title></rect>'
                     f'<text x="{x + gw / 2:.1f}" y="{H - 4}" text-anchor="middle" font-size="11" fill="currentColor" opacity=".6">{int(mm_[5:])}月</text>')
        svg = f'<svg viewBox="0 0 {W} {H}" class="incsvg" role="img" aria-label="近 12 個月薪資與支出">{bars}</svg>'
        yrs = sorted({m[:4] for m in MONTHS if m <= ym})
        def ysum(y, upto=12):
            ms_ = [f'{y}-{k:02d}' for k in range(1, upto + 1) if f'{y}-{k:02d}' <= ym]
            a_, b_ = sum(SAL.get(m, 0) for m in ms_), sum(spend_m(m) for m in ms_)
            return a_, b_, len(ms_)
        CL = _bk.INC_COL
        icats = [(k, INCC.get((ym, k), 0)) for k in _bk.INC_CATS]
        ecats = exp_cats([ym]); etot = sum(v for _, v, _ in ecats) or 1
        imx = max([v for _, v in icats] + [1]); emx = max([v for _, v, _ in ecats[:8]] + [1])
        def crow(name, v, tot, mx, col, sub=''):
            return (f'<tr><td>{esc(name)}{f"<small>{esc(sub)}</small>" if sub else ""}</td><td class="bar"><span class="meter"><span style="width:{max(0, v) / mx * 100:.0f}%;background:{col}"></span></span></td>'
                    f'<td class="n"><b>{f(v)}</b><small>{v / tot * 100 if tot else 0:.0f}%</small></td></tr>')
        in_rows = ''.join(crow(k, v, c['sal'], imx, CL[k]) for k, v in icats if v)
        top8, rest = ecats[:8], ecats[8:]
        out_rows = ''.join(crow(k, v, out_, emx, 'var(--exp,#e07a6e)', src) for k, v, src in top8) + \
            (crow(f'其他 {len(rest)} 類', sum(v for _, v, _ in rest), out_, emx, '#9aa3b0', '、'.join(k for k, _, _ in rest[:3])) if rest else '')
        top_ = max(c['sal'], out_, 1)
        def sbar(parts):
            segs = ''.join(f'<span style="width:{v / top_ * 100:.2f}%;background:{col}" title="{k} {f(v)}"></span>' for k, v, col in parts if v > 0)
            return f'<div class="sbar">{segs}</div>'
        bl = collections.defaultdict(float)
        for x in BOUT_ITEMS.get(ym, []): bl[x['label']] += x['amount']
        ip = [(k, v, CL[k]) for k, v in icats]
        ep = [('刷卡', c['T'], '#e07a6e'), ('帳戶扣款', c['bout'], '#b85c74'), ('現金', c['cash'], '#f0a58f')]
        iitems = ''.join(f'<tr><td class="n muted">{d_[5:].replace("-", "/")}</td><td><b>{esc(t_)}</b><small>{_bk.inc_cat(t_)}・{esc(n_)}</small></td><td class="n"><b class="pos">+{f(a_)}</b></td></tr>' for d_, t_, n_, a_ in sorted(INC_ITEMS.get(ym, []), reverse=True))
        nc = [(x['date'], x['label'], f"{x['summary']}" + (f"・{x['memo']}" if x.get('memo') else ''), x['amount']) for x in BOUT_ITEMS.get(ym, [])] + \
             [(x['date'], x.get('note') or x['category'], f"現金・{x['category']}（隨手記）", x['amount']) for x in CASH_ITEMS.get(ym, [])]
        bitems = ''.join(f'<tr><td class="n muted">{d_[5:].replace("-", "/")}</td><td><b>{esc(t_)}</b><small>{esc(n_)}</small></td><td class="n"><b>{f(a_)}</b></td></tr>' for d_, t_, n_, a_ in sorted(nc, reverse=True))
        # 全年：薪資 vs 業外
        yrows = ''
        for y in yrs:
            ms_ = [f'{y}-{k:02d}' for k in range(1, 13) if f'{y}-{k:02d}' <= ym]
            sa, ot, ex = inc_of(ms_, '薪資'), inc_of(ms_) - inc_of(ms_, '薪資'), sum(spend_m(m) for m in ms_)
            yrows += (f'<tr><td><b>{y}</b>{"<small>到 " + str(len(ms_)) + " 月</small>" if len(ms_) < 12 else ""}</td><td class="n">{f(sa)}</td><td class="n">{f(ot)}</td><td class="n"><b>{f(sa + ot)}</b></td><td class="n">{f(ex)}</td>'
                      f'<td class="n"><b class="{"pos" if sa + ot - ex >= 0 else "neg"}">{f(sa + ot - ex)}</b></td></tr>')
        if len(yrs) >= 2:
            mm = int(ym[5:]); m1 = [f'{yrs[-2]}-{k:02d}' for k in range(1, mm + 1)]; m2 = [f'{yrs[-1]}-{k:02d}' for k in range(1, mm + 1)]
            def gch(a, b, good_up=True):
                if not b: return '–'
                p_ = (a / b - 1) * 100; up = p_ >= 0
                return f'<span class="{"pos" if up == good_up else "neg"}">{"▲" if up else "▼"}{abs(p_):.0f}%</span>'
            s1, s2 = inc_of(m1, '薪資'), inc_of(m2, '薪資'); o1, o2 = inc_of(m1) - s1, inc_of(m2) - s2
            e1, e2 = sum(spend_m(m) for m in m1), sum(spend_m(m) for m in m2)
            yrows += (f'<tr class="same"><td>同期 1–{mm} 月</td><td class="n">{gch(s2, s1)}</td><td class="n">{gch(o2, o1)}</td><td class="n">{gch(s2 + o2, s1 + o1)}</td><td class="n">{gch(e2, e1, False)}</td><td class="n">{gch(s2 + o2 - e2, s1 + o1 - e1)}</td></tr>')
        inc_card = (f'<div class="card"><h2>收支</h2><p class="d">收入＝薪資＋業外（房租、投資與配息、利息、其他）；支出＝刷卡（已扣代付、家人附卡）＋帳戶扣款（房貸、分期、固定轉帳）＋現金</p>'
                    f'<div class="sum"><div><span class="l">{c["m"]} 月收入</span><span class="v pos">NT$ {f(c["sal"])}</span></div>'
                    f'<div><span class="l">支出</span><span class="v neg">NT$ {f(out_)}</span></div>'
                    f'<div><span class="l">結餘</span><span class="v {"pos" if bal >= 0 else "neg"}">NT$ {f(bal)}</span></div>'
                    f'<div><span class="l">儲蓄率</span><span class="v {"pos" if bal >= 0 else "neg"}">{bal / c["sal"] * 100 if c["sal"] else 0:.0f}%</span></div></div>'
                    + f'<div class="flow"><div class="fl"><span class="ft">收入</span>{sbar(ip)}</div><div class="fl"><span class="ft">支出</span>{sbar(ep)}</div></div>'
                    + f'<div class="grid2 iosplit"><div><h3 class="h3 hin">收入 <b>NT$ {f(c["sal"])}</b></h3><div class="tbl"><table>{in_rows or "<tr><td class=muted>這個月還沒有收入入帳</td></tr>"}</table></div></div>'
                    + f'<div><h3 class="h3 hout">支出 <b>NT$ {f(out_)}</b></h3><div class="tbl"><table>{out_rows}</table></div></div></div>'
                    + (f'<details class="more"><summary>收入明細（{len(INC_ITEMS.get(ym, []))} 筆）</summary><div class="tbl"><table>{iitems}</table></div></details>' if iitems else '')
                    + (f'<details class="more"><summary>帳戶扣款與現金明細（{len(nc)} 筆）</summary><div class="tbl"><table>{bitems}</table></div></details>' if bitems else '')
                    + f'<h3 class="h3">近 12 個月</h3><div class="leg"><i style="background:#1baf7a"></i>收入<i style="background:#e07a6e"></i>支出</div>{svg}'
                    + f'<h3 class="h3">全年：薪資＋業外收入</h3><div class="tbl"><table><tr><th>年度</th><th class="n">薪資</th><th class="n">業外</th><th class="n">收入</th><th class="n">支出</th><th class="n">結餘</th></tr>{yrows}</table></div></div>')
    act_card = ''
    rec_card = recon_card(ym) if INC else ''
    _acts = [a for a in ACTS if a.get('month') == ym]
    if _acts:
        stc = {'已入帳': 'ok', '等待入帳': 'wait'}
        arows = ''.join(f'<tr><td>{bdot(a["bank"]) if a["bank"] in BANKS else ""}<b>{esc(a["name"])}</b><small>{esc(a["card"])}・{esc(a["kind"])}{("・" + esc(a["note"])) if a["note"] else ""}</small></td>'
                        f'<td class="n"><b>{f(a["amount"])}</b></td><td><span class="st {stc.get(a["status"], "bad" if "超過" in a["status"] else "na")}">{esc(a["status"])}</span>'
                        f'{"<small>" + a["paid_date"][5:].replace("-", "/") + " 帳單</small>" if a.get("paid_date") else ""}</td></tr>' for a in _acts)
        act_card = (f'<div class="card"><h2>活動回饋</h2><p class="d">信用卡本身回饋以外、你在 Excel「活動回饋」登錄的活動；刷卡金會自動對帳單</p>'
                    f'<div class="sum"><div><span class="l">預計</span><span class="v pos">NT$ {f(sum(a["amount"] for a in _acts))}</span></div>'
                    f'<div><span class="l">已入帳</span><span class="v">NT$ {f(sum(a["amount"] for a in _acts if a["status"] == "已入帳"))}</span></div></div>'
                    f'<div class="tbl"><table><tr><th>活動</th><th class="n">金額</th><th>狀態</th></tr>{arows}</table></div></div>')
    lr_card = ''
    if c['lrec']:
        stc = {'對上': 'ok', '對上（補記）': 'ok', '帳單還沒到': 'wait', '帳單找不到': 'bad'}
        od = {'帳單找不到': 0, '帳單還沒到': 1, '對上（補記）': 2, '對上': 3}
        cnt = collections.Counter(x['status'] for x in c['lrec'])
        lrows = ''.join(f'<tr class="lr" data-d="{x["date"]}" data-c="{esc(x["card"])}" data-st="{x["status"]}"><td class="n muted">{x["date"][5:].replace("-", "/")}</td>'
                        f'<td>{bdot(x["bank"]) if x.get("bank") in BANKS else ""}<b>{esc(x["card"].split(" ·")[0])}</b><small>{esc(x.get("bank") or "")}{(" ·" + x["last4"]) if x.get("last4") else ""}</small></td>'
                        f'<td><b>{esc(x["note"] or x["category"])}</b><small class="cardm">{esc(x["card"].split(" ·")[0])}・{esc(x.get("bank") or "")}</small><small>{esc(x["category"])}{("　→ 帳單：" + esc(x["bill_merchant"]) + " " + f(x["bill_amount"])) if x.get("bill_merchant") else ""}</small></td>'
                        f'<td class="n">{f(x["amount"])}</td><td><span class="st {stc[x["status"]]}">{x["status"]}</span></td></tr>'
                        for x in sorted(c['lrec'], key=lambda x: x['date'], reverse=True))
        pills = ''.join(f'<button type="button" class="lrst" data-st="{k}" aria-pressed="false">{lab} {n_}</button>' for k, lab, n_ in
                        [('對上', '對上', cnt['對上'] + cnt['對上（補記）']), ('帳單還沒到', '帳單還沒到', cnt['帳單還沒到']), ('帳單找不到', '找不到', cnt['帳單找不到'])] if n_)
        lr_card = (f'<div class="card lrcard"><h2>隨手記對照</h2><p class="d">隨手記的 {len(c["lrec"])} 筆刷卡和帳單比對：對上 {cnt["對上"] + cnt["對上（補記）"]}、帳單還沒到 {cnt["帳單還沒到"]}、找不到 {cnt["帳單找不到"]}</p>'
                   f'<div class="lrbar"><div class="pills">{pills}</div><div class="seg2" role="group" aria-label="排列"><button type="button" data-lrg="date" aria-pressed="true">依日期</button><button type="button" data-lrg="card" aria-pressed="false">依卡片</button></div>'
                   f'<button type="button" class="lrsort">新 → 舊</button></div>'
                   f'<div class="tbl"><table class="lrt"><thead><tr><th>日期</th><th>卡片</th><th>隨手記</th><th class="n">金額</th><th>結果</th></tr></thead><tbody>{lrows}</tbody></table></div></div>')
    _o = T
    flow_mini = (f'<a class="fmini" href="#{ym}-flow"><span>收入 <b class="pos">NT$ {f(c["sal"])}</b></span><span>支出 <b class="neg">NT$ {f(_o)}</b></span>'
                 f'<span>結餘 <b class="{"pos" if c["sal"] - _o >= 0 else "neg"}">NT$ {f(c["sal"] - _o)}</b></span><span class="go">看收支 →</span></a>') if c.get('sal') else ''
    inst_card = (f'<div class="card"><h2>分期付款</h2><p class="d">{m} 月進行中，每月共 NT$ {f(c["inst_month"])}</p><div class="tbl"><table><tr><th>商家</th><th class="n">進度</th><th class="n">每期</th><th class="n">剩餘</th></tr>{inst_html}</table></div></div>'
                 if c['active'] else '')
    body = f'''
<section data-tab="overview">
  <div class="card"><h2>本月重點</h2><div class="hls">{hl_html}</div>{flow_mini}</div>
  {cyc_card() if c['ym'] == NEWEST else ''}
  <div class="grid2">
    <div class="card"><h2>付款方式</h2><p class="d">各銀行信用卡淨額（已扣退款），加上現金、帳戶扣款</p><div class="tbl"><table><tr><th>銀行</th><th class="n">金額</th><th></th><th class="n">較上月</th></tr>{bank_html}</table></div></div>
    <div class="card"><h2>支出分類</h2><p class="d">大分類 → 點開看細分類 → 再點開看用哪張卡／現金／帳戶付的</p>{cat_html}</div>
  </div>
  <div class="card"><h2>最大五筆</h2><div class="tbl"><table>{big_html}</table></div><p class="more"><a href="#{ym}-detail">看全部 {len(c["rows"])} 筆明細 →</a></p></div>
  {oth_card}
</section>
<section data-tab="rewards">
  <div class="card"><h2>本月回饋一覽</h2><p class="d">依 {m} 月消費日，按各卡權益規則預估（過去月份以現行規則估算）</p>
    <div class="sum"><div><span class="l">預估回饋</span><span class="v pos">NT$ {f(c["est"])}</span></div><div><span class="l">回饋率</span><span class="v">{c["est_rate"]:.1f}%</span></div><div><span class="l">刷錯卡少拿</span><span class="v neg">NT$ {f(c["miss_gain"])}</span></div></div>
    <div class="tbl"><table class="rw"><tr><th>卡片・入帳時間</th><th class="n">刷卡</th><th class="n">預估回饋</th><th>核對</th></tr>{rw}</table></div></div>
  {act_card}
  {chk}
</section>
<section data-tab="fix" data-n="{len(c['miss'])}">
  <div class="card"><h2>{m} 月刷錯卡（全部 {len(c["miss"])} 筆）</h2><p class="d">刷了卻沒拿到回饋，依商家合併；藍字是下次的付法。{esc(none_note)}</p><div class="fixes">{fix_html}</div></div>
  {habit}
</section>
<section data-tab="detail">
  <div class="card"><h2>{m} 月消費明細</h2><p class="d">所有帳單交易（右上可切換新→舊／舊→新）；標「暫列」的是隨手記記了、帳單還沒到的；綠色是退款，灰色是回饋折抵。每筆都標了帳單日，方便對帳單。</p>
    <div class="flt"><input type="search" class="q" placeholder="搜尋商家、分類…" aria-label="搜尋">
      <select class="cs" aria-label="卡片"><option value="">全部卡片</option>{cards_opt}</select>
      <select class="ks" aria-label="分類"><option value="">全部分類</option>{cats_opt}</select></div>
    <div class="pills">{banks_btn}</div>
    <div class="seg2" role="group" aria-label="排列方式"><button type="button" data-view="card" aria-pressed="true">依卡片</button><button type="button" data-view="cat" aria-pressed="false">依分類</button><button type="button" data-view="date" aria-pressed="false">依日期</button></div><button type="button" class="dsort">新 → 舊</button>
    <div class="tot"><span class="cntx">{len(c["rows"])} 筆</span><span class="sumx n">合計 NT$ {f(sum(r["amount"] for r in c["rows"] if r["category"] != REB))}</span></div>
    <div class="tbl"><table class="det" data-v="card">{det_card}</table><table class="det" data-v="cat" hidden>{det_cat}</table><table class="det" data-v="date" hidden>{det}</table></div></div>
</section>
<section data-tab="flow">
  {inc_card}
  {rec_card}
  {dep_card(ym)}
</section>
{('<section data-tab="ledger">' + lr_card + '</section>') if lr_card else ''}
<section data-tab="cards">
  <div class="card"><h2>各卡片</h2><p class="d">{m} 月刷卡金額</p><div class="tbl"><table><tr><th>卡片</th><th class="n">筆數</th><th class="n">金額</th><th></th></tr>{card_html}</table></div></div>
  {inst_card}
  <div class="card"><h2>年費與手續費</h2><p class="d" style="margin:0">年費：{esc(fee_line)}。海外手續費 NT$ {f(c["fxfee"])}。</p></div>
</section>'''
    if c['m'] == 12 and not c['partial']:
        body += review_html(c['y'])
    return f'<template id="t-{ym}" data-label="{c["y"]} 年 {m} 月{'（未到齊）' if c['partial'] else ''}"><div class="hero-m">{('<div class="partial">這個月還有帳單沒寄到，數字會再增加；完整月報到 ' + str(CM) + ' 月' + (f'。已先算進隨手記記的 {len(c["pv"])} 筆 NT$ {f(sum(r["amount"] for r in c["pv"]))}（帳單還沒到，標「暫列」）' if c.get('pv') else '') + '</div>') if c['partial'] else ''}{hero}</div><div class="body-m">{body}</div></template>\n'


CSS = open('report_style.css', encoding='utf8').read()
JS = open('report_app.js', encoding='utf8').read()
try:   # 不在隨手記網站（Claude、GitHub、本機檔）打開時，「代墊？」會帶你到線上版去勾
    _SITE = (json.load(open(__import__('paths').setp('local_settings.json'), encoding='utf8')).get('ledger') or {}).get('url', '').rstrip('/')
except Exception:
    _SITE = ''
JS = f'window.LL_SITE={json.dumps(_SITE)};\n' + JS
templates = ''.join(page_month(C[ym]) for ym in MONTHS if C[ym]['rows'])
page = f'''<title>LifeLedger 月報</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@900&family=Noto+Sans+TC:wght@400;500;700&family=IBM+Plex+Mono:wght@500&display=swap">
<style>{CSS}{EXTRA_CSS}
.rv .rvhead h2{{font-size:24px;margin:4px 0 2px}}.rv .eyebrow{{font-size:12px;letter-spacing:.15em;color:var(--gold,#c9a45c)}}
.rvsum>div small{{display:block;font-size:12px;opacity:.75;margin-top:2px}}.rvsum>div>span:not(.l):not(.v){{display:block;font-size:13px;margin-top:2px}}
nav.tabs a.rvtab{{color:var(--gold,#c9a45c)}}
.big .s.ex{{opacity:.85;font-size:12.5px;margin-top:4px}}.incsvg{{width:100%;height:auto;margin:4px 0 6px;color:var(--ink,#121821)}}
.leg{{display:flex;gap:6px;align-items:center;font-size:12px;opacity:.75;margin-top:6px}}.leg i{{width:10px;height:10px;border-radius:2px;display:inline-block;margin-left:8px}}.leg i:first-child{{margin-left:0}}
td b.pos,td span.pos{{color:#17784b}}td b.neg,td span.neg{{color:#b3372b}}@media (prefers-color-scheme:dark){{td b.pos,td span.pos{{color:#5fd39a}}td b.neg,td span.neg{{color:#f0897c}}}}
.flow{{margin:10px 0 4px;display:grid;gap:10px}}.fl{{display:grid;grid-template-columns:34px 1fr;gap:4px 8px;align-items:center}}.ft{{font-size:12px;opacity:.7;grid-row:span 2}}
.sbar{{display:flex;height:16px;border-radius:5px;overflow:hidden;background:rgba(127,127,127,.12)}}.sbar span{{display:block;height:100%}}
.sleg{{display:flex;flex-wrap:wrap;gap:2px 12px;font-size:12px;opacity:.85}}.sleg i{{display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:4px}}
.sum .l small{{display:block;font-size:11px;opacity:.7}}
tr.same td{{font-size:12.5px;opacity:.85;border-top:1px dashed rgba(127,127,127,.4)}}.big .s.ex b{{color:var(--gold,#c9a45c)}}
tr.hintrow td{{background:color-mix(in srgb,#f0a500 12%,transparent)}}.card .h3{{font-size:15px;margin:16px 0 2px}}
.iosplit{{margin-top:8px}}.iosplit .h3{{display:flex;justify-content:space-between;align-items:baseline;border-bottom:2px solid;padding-bottom:6px}}.h3.hin{{border-color:#1f8a5b}}.h3.hout{{border-color:#e07a6e}}
.h3.hin b{{color:#1f8a5b}}.h3.hout b{{color:#b3372b}}@media (prefers-color-scheme:dark){{.h3.hin b{{color:#5fd39a}}.h3.hout b{{color:#f0897c}}}}
.iosplit td small{{display:block;font-size:11.5px;opacity:.65}}.iosplit td.n small{{display:inline;margin-left:6px}}
details.more{{margin-top:10px;border:1px solid rgba(127,127,127,.25);border-radius:10px;padding:6px 12px}}details.more summary{{cursor:pointer;font-size:14px;font-weight:600;padding:4px 0}}
.inct td.ind{{padding-left:1.4em;font-size:13px;opacity:.85}}.inct tr.sub td{{font-weight:700}}
.fmini{{display:flex;flex-wrap:wrap;gap:6px 18px;align-items:baseline;margin-top:12px;padding:10px 14px;border-radius:10px;background:rgba(127,127,127,.08);text-decoration:none;color:inherit;font-size:14px}}.fmini b{{font-size:16px}}.fmini .go{{margin-left:auto;font-size:13px;opacity:.75}}
.lrbar{{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:8px 0}}.lrbar .pills{{margin:0}}.lrbar .lrsort{{margin-left:auto;font:inherit;font-size:13px;border:1px solid rgba(127,127,127,.35);background:none;color:inherit;border-radius:999px;padding:4px 12px;cursor:pointer}}
.lrst{{font:inherit;font-size:12.5px;border:1px solid rgba(127,127,127,.35);background:none;color:inherit;border-radius:999px;padding:3px 10px;cursor:pointer}}.lrst[aria-pressed="true"]{{background:var(--ink,#121821);color:var(--bg,#fff)}}
.dsort{{font:inherit;font-size:13px;border:1px solid rgba(127,127,127,.35);background:none;color:inherit;border-radius:999px;padding:4px 12px;cursor:pointer;margin-left:8px}}.tag.pv{{background:rgba(176,138,62,.16);color:inherit}}
.pdb{{display:block;margin:4px 0 0 auto;font:inherit;font-size:11.5px;border:1px solid rgba(127,127,127,.35);background:none;color:inherit;opacity:.75;border-radius:999px;padding:1px 9px;cursor:pointer;white-space:nowrap}}.pdb:hover{{opacity:1}}.pdb.on{{opacity:1;border-color:#b08a3e;background:rgba(176,138,62,.14);font-weight:600}}
#pdPop{{position:absolute;z-index:80;background:var(--card,#fff);color:inherit;border:1px solid rgba(127,127,127,.35);border-radius:12px;box-shadow:0 12px 30px rgba(0,0,0,.2);padding:10px;width:260px;font-size:13.5px}}#pdPop .t{{font-weight:700;margin-bottom:6px}}#pdPop .row{{display:flex;flex-wrap:wrap;gap:6px}}#pdPop button,#pdPop a.go{{font:inherit;font-size:13px;border:1px solid rgba(127,127,127,.35);background:none;color:inherit;border-radius:8px;padding:5px 10px;cursor:pointer;text-decoration:none}}#pdPop a.go{{display:inline-block;margin-top:8px;background:#b08a3e;color:#fff;border-color:#b08a3e}}#pdPop input{{width:64px;font:inherit;padding:3px 6px;border:1px solid rgba(127,127,127,.35);border-radius:6px;background:none;color:inherit}}#pdPop .cu{{margin-top:8px}}#pdPop p{{margin:0;font-size:12.5px;opacity:.8}}
table.lrt tr.grp td{{font-weight:700;background:rgba(127,127,127,.08);font-size:13px}}
body:not([data-tab="overview"]) .hero .kpis{{display:none}}body:not([data-tab="overview"]) .hero .partial{{font-size:12px;padding:4px 10px}}
.lrt td small.cardm{{display:none}}@media (max-width:640px){{table.lrt th:nth-child(2),table.lrt td:nth-child(2){{display:none}}.lrt td small.cardm{{display:block}}}}
.stb{{display:inline-block;font-size:11.5px;padding:1px 8px;border-radius:999px;white-space:nowrap}}.stb.ok{{background:rgba(23,120,75,.12);color:#17784b}}.stb.bad{{background:rgba(179,55,43,.12);color:#b3372b}}.stb.man{{background:rgba(127,127,127,.14)}}</style>
<header class="hero"><div class="wrap">
  <div class="top"><div class="eyebrow">LIFELEDGER · 生活總帳月報</div>
    <div class="tools"><button type="button" class="hbtn" id="reloadBtn" data-url="{URL_ONLINE}" title="線上版：重新整理拿到最新月報；離線版：打開線上版">↻ 重新整理</button>
    <button type="button" class="hbtn theme" id="themeBtn" aria-label="切換深淺色"><span class="ic"></span><span class="tx">自動</span></button></div></div>
  <div class="mnav"><button type="button" id="mprev" aria-label="上個月">‹</button><select id="msel" aria-label="選擇月份"></select><button type="button" id="mnext" aria-label="下個月">›</button><span class="latest" id="latestTag">最新</span></div>
  <div id="heroM"></div>
</div>
<nav class="tabs" aria-label="分頁"><div class="wrap">
  <a data-t="overview" href="#overview">總覽</a><a data-t="flow" href="#flow">收支</a><a data-t="rewards" href="#rewards">本月回饋</a><a data-t="fix" href="#fix">刷錯卡<span class="cnt" id="fixCnt" hidden></span></a><a data-t="detail" href="#detail">明細</a><a data-t="ledger" href="#ledger" class="lgtab" hidden>隨手記對照</a><a data-t="cards" href="#cards">卡片與分期</a><a data-t="review" href="#review" class="rvtab" hidden>年度回顧</a>
</div></nav></header>
<main><div class="wrap"><div id="app"></div>
<p class="foot">資料至 {CFG["data_through"]}{LEDGER_A}</p></div></main>
{templates}
<script>{JS}</script>'''
open('月報.html', 'w', encoding='utf8').write(page)
os.makedirs(f'{OUT}/月報', exist_ok=True)
open(f'{OUT}/月報/LifeLedger月報.html', 'w', encoding='utf8').write(
    '<!doctype html>\n<html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'
    + page.replace('<style>', '<style>\n:root{padding-top:env(safe-area-inset-top,0px)}', 1).replace('</style>', '</style></head><body>', 1) + '\n</body></html>')
print(subj, f'｜網頁 {len(page) // 1024} KB，{len(MONTHS)} 個月')
