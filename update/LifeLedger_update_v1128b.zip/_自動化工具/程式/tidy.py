# LifeLedger 自動整理（每次更新開頭跑；做過的不會重做）：把用不到、重複的檔案搬到帳本資料夾裡的「_待刪除」（不會真的刪）
import os, sys, json, shutil, datetime, glob
BASE = os.path.dirname(os.path.abspath(__file__))
from paths import setp, HOME
AUTO = os.path.dirname(BASE)
S = json.load(open(setp('local_settings.json'), encoding='utf8')) if os.path.exists(setp('local_settings.json')) else {}
OUT = os.environ.get('CARDFLOW_OUT') or S.get('out') or HOME
TRASH = os.path.join(OUT, '_待刪除', datetime.date.today().strftime('%Y%m%d'))
moved = []


def park(p, label):
    if not os.path.exists(p):
        return
    d = os.path.join(TRASH, label)
    os.makedirs(os.path.dirname(d), exist_ok=True)
    if os.path.exists(d):
        d += '_' + datetime.datetime.now().strftime('%H%M%S')
    try:
        shutil.move(p, d); moved.append(label)
    except Exception as e:
        print('  （整理時搬不動', p, '：', e, '）')


# 1. 隨手記網站只留一份：_自動化工具\隨手記網站（舊的 LifeLedger隨手記 資料夾裡的設定檔先搬過來）
site = os.path.join(AUTO, '隨手記網站'); old = os.path.join(OUT, 'LifeLedger隨手記')
if os.path.isdir(old):
    for rel in ('netlify.toml', 'package.json', os.path.join('public', 'catalog.json'), os.path.join('netlify', 'functions', 'catalog.mjs')):
        s_, d_ = os.path.join(old, rel), os.path.join(site, rel)
        if os.path.exists(s_) and not os.path.exists(d_):
            os.makedirs(os.path.dirname(d_), exist_ok=True); shutil.copy2(s_, d_)
    park(old, 'LifeLedger隨手記（已整合到 _自動化工具＼隨手記網站）')
park(os.path.join(site, 'index.html'), '隨手記網站外層多的index.html')
# 2. 重複的分享版資料夾（正式的是帳本資料夾旁邊的 LifeLedger_分享版）
outer = os.path.join(os.path.dirname(OUT), 'LifeLedger_分享版')
if os.path.isdir(outer):
    park(os.path.join(OUT, 'LifeLedger_分享版'), 'LifeLedger_分享版（重複的）')
    for f in os.listdir(outer):
        fp = os.path.join(outer, f)
        _cur = open(os.path.join(BASE, 'version.txt'), encoding='utf8').read().strip() if os.path.exists(os.path.join(BASE, 'version.txt')) else ''
        if f in ('LifeLedger_Setup.exe', 'LifeLedger_免安裝版.zip', 'LifeLedger_免安裝版') or \
           (_cur and f.startswith(('LifeLedger_Setup_v', 'LifeLedger_免安裝版_v')) and f'_v{_cur}.' not in f):
            park(fp, '分享版舊檔／' + f)   # 只留最新一版
# 3. 舊工具、暫存
for f in ('同步帳單到OneDrive.ps1', 'RUNBOOK.md', 'cardflow_daily.bat', 'migrate.ps1', 'web_preview', 'mail_tmp'):
    park(os.path.join(BASE, f), '程式／' + f)
# 4. Excel：開著檔案時另存的「新版」→ 留比較新的那份、用正式檔名
x1 = os.path.join(OUT, 'LifeLedger_生活總帳.xlsx'); x2 = os.path.join(OUT, 'LifeLedger_生活總帳（新版，請關閉舊檔後改名）.xlsx')
if os.path.exists(x2):
    try:
        if not os.path.exists(x1) or os.path.getmtime(x2) > os.path.getmtime(x1):
            park(x1, 'LifeLedger_生活總帳（舊的Excel）.xlsx'); shutil.move(x2, x1); moved.append('Excel 新版改回正式檔名')
        else:
            park(x2, 'LifeLedger_生活總帳（比較舊的那份）.xlsx')
    except Exception as e:
        print('  （Excel 正開著，下次再整理）', e)
if moved:
    print('整理資料夾：搬到 _待刪除 →', '、'.join(moved))
