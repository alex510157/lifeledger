# LifeLedger：從信箱直接收「信用卡帳單」和「銀行存款／綜合對帳單」PDF（任何一家銀行、任何信箱、可以設好幾個信箱）
#   支援：Gmail、Yahoo、HiNet、公司或其他 IMAP 信箱（要「應用程式密碼」或 IMAP 密碼）
#         Outlook 電腦版（傳統版 Outlook）：裡面加了幾個信箱（Outlook.com、Yahoo、HiNet…）就一起收，不用密碼
#   設定：跑「設定精靈」的【0c】，或在 設定\local_settings.json 的 "mailboxes" 自己加
#   存法跟 Google Apps Script 一樣（同名檔案不重複存）：
#     信用卡帳單 → <帳本資料夾>\<銀行>\<收信日>_<銀行>_<附件名>.pdf
#     存款對帳單 → <帳本資料夾>\帳單\存款對帳單\<銀行>存款\<收信日>_<銀行>存款_<附件名>.pdf（舊版面在 _收入）
#     只有通知、沒有 PDF 的對帳單（例如 LINE Bank）→ 記一個「這個月收到了」的小檔
#   只讀信、不改信（不會把信標成已讀、不刪信）；密碼只從本機設定讀，不會顯示
#   用法：python mail_fetch.py [--since 2025-01-01] [--test]   （--test：只測登入、列出找到幾封帳單，不存檔）
import os, sys, re, json, imaplib, email, datetime, hashlib, glob
from email.header import decode_header, make_header
from email.utils import parseaddr, parsedate_to_datetime

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)
from paths import setp, HOME, card_roots, INVOICE, CARD as CARD_DIR, DEPOSIT as DEPOSIT_DIR   # CARD、DEPOSIT 這兩個名字下面已經用在辨認信件的規則
from banks import FULL, short

S = json.load(open(setp('local_settings.json'), encoding='utf8'))
OUT = os.environ.get('CARDFLOW_OUT') or S.get('out') or HOME
TEST = '--test' in sys.argv
SINCE_ARG = sys.argv[sys.argv.index('--since') + 1] if '--since' in sys.argv else None
STATE_P = setp('mail_state.json')
STATE = json.load(open(STATE_P, encoding='utf8')) if os.path.exists(STATE_P) else {}
MY_NAME = S.get('my_name') or ''   # 存款對帳單只收信裡有這個名字的（同信箱也收到小孩帳戶的對帳單時用；可用 . 代表任一字）


def log(*a): print(*a, flush=True)


# ---------- 寄件網域 → 銀行（台灣所有發信用卡或寄電子對帳單的銀行；順序有意義：長的在前） ----------
DOMAINS = [
    ('永豐', r'banksinopac|sinopac'), ('台新', r'taishinbank|taishin'), ('星展', r'\bdbs\.com'), ('玉山', r'esunbank|esun\.com'),
    ('聯邦', r'ubot\.com'), ('中信', r'ctbcbank|ctbc'), ('國泰', r'cathaybk|cathaybank|cathay'), ('遠東', r'feib|feibank'),
    ('富邦', r'fubon'), ('渣打', r'standardchartered|\bsc\.com'), ('第一', r'firstbank|\bfirst\.com\.tw'), ('華南', r'hncb'),
    ('彰銀', r'\bchb\.com|bankchb'), ('兆豐', r'megabank|megaicbc'), ('合庫', r'tcb-bank|tcbbank\.com\.tw'), ('土銀', r'landbank'),
    ('臺銀', r'\bbot\.com\.tw'), ('上海', r'scsb'), ('新光', r'skbank'), ('凱基', r'kgibank|kgi\.com'), ('元大', r'yuantabank|yuanta'),
    ('王道', r'o-bank'), ('樂天', r'rakuten-bank|rakuten\.com\.tw'), ('匯豐', r'hsbc'), ('美國運通', r'americanexpress|aexp'),
    ('將來', r'nextbank'), ('LINE Bank', r'linebank'), ('企銀', r'\btbb\.com'), ('陽信', r'sunnybank'), ('安泰', r'entiebank'),
    ('台中銀', r'\btcbbank\.com'), ('京城', r'\bktb\.com'), ('華泰', r'hwataibank'), ('三信', r'cotabank'), ('瑞興', r'taipeistarbank'),
    ('板信', r'\bbop\.com\.tw'), ('花旗', r'\bciti'), ('日盛', r'jihsun'), ('澳盛', r'\banz\.com'),
]
NAME2 = {v: k for k, v in FULL.items()}
NAME2.update({'中國信託': '中信', '中信銀行': '中信', '台北富邦': '富邦', '富邦銀行': '富邦', '國泰世華': '國泰', '遠東商銀': '遠東',
              '遠東國際商業銀行': '遠東', '第一銀行': '第一', '華南銀行': '華南', '彰化銀行': '彰銀', '兆豐銀行': '兆豐', '合作金庫': '合庫',
              '土地銀行': '土銀', '臺灣銀行': '臺銀', '台灣銀行': '臺銀', '上海商銀': '上海', '上海商業儲蓄銀行': '上海', '新光銀行': '新光',
              '凱基銀行': '凱基', '元大銀行': '元大', '王道銀行': '王道', '樂天銀行': '樂天', '樂天國際商業銀行': '樂天', '匯豐銀行': '匯豐',
              '美國運通': '美國運通', '將來銀行': '將來', '臺灣企銀': '企銀', '台灣企銀': '企銀', '陽信銀行': '陽信', '安泰銀行': '安泰',
              '台中銀行': '台中銀', '京城銀行': '京城', '華泰銀行': '華泰', '三信銀行': '三信', '板信銀行': '板信', '花旗銀行': '花旗',
              '渣打銀行': '渣打', '星展銀行': '星展', '玉山銀行': '玉山', '台新銀行': '台新', '永豐銀行': '永豐', '聯邦銀行': '聯邦'})
NAME_RE = re.compile('|'.join(sorted(map(re.escape, NAME2), key=len, reverse=True)))

BILL = re.compile(r'帳單|對帳單|月結單|結單|帳戶明細|存款明細|交易明細表|statement|estatement|MTHLYSTMT|e-?bill', re.I)
DEPOSIT = re.compile(r'綜合對帳單|存款|銀行對帳單|帳戶對帳單|交易明細對帳單|月結單|綜合月報|帳戶明細|存款明細|交易明細表|MTHLYSTMT|存摺|account statement', re.I)
CARD = re.compile(r'信用卡|卡.{0,4}帳單|電子帳單|card', re.I)
NOT_BILL = re.compile(r'繳款成功|扣款成功|已收到.*繳款|繳費憑證|繳款提醒|繳款通知|消費通知|刷卡通知|交易通知|核卡|額度|優惠|活動|好禮|抽獎|'
                      r'電子報|驗證碼|OTP|登入通知|密碼|信託|基金|證券|投資|保險|貸款|房貸|行銷|廣告|newsletter|promotion', re.I)
JUNK_ATT = re.compile(r'PaymentSlip|繳款聯|繳款單|smime|設定繳款提醒|\.p7s$|\.ics$', re.I)
COMBINED_IN_CARD = {'永豐', '星展'}   # 這兩家的綜合對帳單跟信用卡帳單放同一個資料夾（原本就這樣存）


def dec(s):
    try:
        return str(make_header(decode_header(s or '')))
    except Exception:
        return s or ''


def which_bank(addr, name, subject):
    a = (addr or '').lower()
    dom = a.split('@')[-1]
    for b, rx in DOMAINS:
        if re.search(rx, dom):
            return b, True
    m = NAME_RE.search((name or '') + ' ' + (subject or ''))
    if m:
        return NAME2[m.group(0)], False
    m = re.search(r'([一-鿿]{2,4}?)(?:國際)?(?:商業)?銀行', (name or '') + ' ' + (subject or ''))
    if m and m.group(1) not in ('網路', '數位', '行動', '您的', '本行', '貴行'):
        return m.group(1), False
    return None, False


def kind(subject, att_names):
    s = subject + ' ' + ' '.join(att_names)
    if not BILL.search(s) or NOT_BILL.search(subject):
        return None
    if (DEPOSIT.search(s) or '對帳單' in subject) and not re.search(r'信用卡|卡友', subject):
        return 'deposit'
    if CARD.search(s) or BILL.search(subject):
        return 'card'
    return None


def safe(n):
    return re.sub(r'[\\/:*?"<>|\r\n\t]+', '_', n).strip(' ._') or 'statement.pdf'


def card_folder(bank):
    """用已經有的銀行資料夾（例如「遠東商銀」；帳單\信用卡 先找、再找舊版面），沒有才在 帳單\信用卡 新建簡稱資料夾"""
    for root in card_roots(OUT):
        for d in sorted(os.listdir(root)):
            if os.path.isdir(os.path.join(root, d)) and not d.startswith(('_', '帳單', '月報')) and short(d) == bank:
                return os.path.join(root, d)
    return os.path.join(OUT, CARD_DIR, bank)


def exists_anywhere(sub, fn):
    for r in dict.fromkeys([OUT] + list(S.get('bills', []))):
        if os.path.exists(os.path.join(r, sub, fn)):
            return True
    return False


def body_text(msg):
    out = []
    for p in msg.walk():
        if p.get_content_maintype() == 'text' and not p.get_filename():
            try:
                t = p.get_payload(decode=True).decode(p.get_content_charset() or 'utf8', 'replace')
            except Exception:
                continue
            out.append(re.sub(r'<[^>]+>', ' ', t) if p.get_content_subtype() == 'html' else t)
    return '\n'.join(out)


class Saver:
    def __init__(self, label):
        self.label, self.new, self.found, self.nopdf = label, 0, 0, []
        self.kinds = {'card': set(), 'deposit': set()}

    def handle(self, addr, name, subject, when, atts, get_body):
        """atts: [(檔名, 取資料的函式)]；get_body: 取信件內文的函式"""
        if (addr or '').lower().endswith('einvoice.nat.gov.tw'):   # 財政部雲端發票明細（網購子分類用）
            for n, g in atts:
                if n.lower().endswith('.csv'):
                    fn = safe(f'{when:%Y-%m-%d}_雲端發票_{n}')
                    if not exists_anywhere(INVOICE, fn) and not exists_anywhere('_電子發票', fn) and not TEST:
                        data = g()
                        if data:
                            os.makedirs(os.path.join(OUT, INVOICE), exist_ok=True)
                            open(os.path.join(OUT, INVOICE, fn), 'wb').write(data); self.new += 1
                            log(f'  + {INVOICE}\\{fn}')
            return
        bank, sure = which_bank(addr, name, subject)
        if not bank:
            return
        names = [n for n, _ in atts]
        k = kind(subject, names)
        if not k:
            return
        pdfs = [(n, f) for n, f in atts if n.lower().endswith('.pdf') and not JUNK_ATT.search(n)]
        d = when.strftime('%Y-%m-%d')
        if k == 'deposit' and MY_NAME and not re.search(MY_NAME, get_body() + subject):
            return   # 不是自己的帳戶（例如小孩的），不收
        self.found += 1
        self.kinds[k].add(bank)
        if k == 'deposit' and bank not in COMBINED_IN_CARD:
            sub = os.path.join(DEPOSIT_DIR, bank + '存款'); tag = bank + '存款'
        else:
            sub = os.path.relpath(card_folder(bank), OUT); tag = os.path.basename(sub)
        if not pdfs:
            ym = re.search(r'(20\d\d)\s*年\s*(\d{1,2})\s*月', subject)
            if k == 'deposit' and ym:
                fn = f'{d}_{tag}_{ym.group(1)}年{int(ym.group(2))}月_對帳單通知.txt'
                if not exists_anywhere(sub, fn) and not TEST:
                    os.makedirs(os.path.join(OUT, sub), exist_ok=True)
                    open(os.path.join(OUT, sub, fn), 'w', encoding='utf8').write(f'{subject}\n收到：{d}\n（互動式對帳單，餘額請自己開啟查看）')
                    self.new += 1
            else:
                self.nopdf.append(f'{bank} {d}「{subject[:30]}」')
            return
        for n, getter in pdfs:
            fn = safe(f'{d}_{tag}_{n}')
            if exists_anywhere(sub, fn):
                continue
            data = getter()
            if not data or len(data) < 5000:
                continue
            if TEST:
                self.new += 1; continue
            os.makedirs(os.path.join(OUT, sub), exist_ok=True)
            open(os.path.join(OUT, sub, fn), 'wb').write(data)
            self.new += 1
            log(f'  + {sub}\\{fn}' + ('' if sure else '（寄件網域不認得，只靠銀行名稱判斷，請確認是真的帳單）'))


# ---------- IMAP（Gmail／Yahoo／HiNet／其他） ----------
PRESET = {'gmail': ('imap.gmail.com', 993), 'yahoo': ('imap.mail.yahoo.com', 993), 'hinet': ('msa.hinet.net', 993),
          'outlook.com': ('outlook.office365.com', 993), 'icloud': ('imap.mail.me.com', 993)}


def guess_host(user):
    dom = user.split('@')[-1].lower()
    if dom in ('gmail.com', 'googlemail.com'): return PRESET['gmail']
    if 'yahoo' in dom: return PRESET['yahoo']
    if dom.endswith('hinet.net'): return PRESET['hinet']
    if dom in ('outlook.com', 'hotmail.com', 'live.com', 'msn.com'): return PRESET['outlook.com']
    if dom in ('icloud.com', 'me.com', 'mac.com'): return PRESET['icloud']
    return ('imap.' + dom, 993)


def imap_folders(M, mb):
    if mb.get('folders'):
        return mb['folders']
    typ, data = M.list()
    allbox = None
    for line in data or []:
        s = line.decode('utf8', 'replace') if isinstance(line, bytes) else str(line)
        if '\\All' in s:   # Gmail「所有郵件」：封存的信也收得到
            allbox = s.rsplit(' "/" ', 1)[-1].strip() if ' "/" ' in s else s.split()[-1]
    return [allbox] if allbox else ['INBOX']


def run_imap(mb, since):
    user = mb.get('login') or mb['user']; host, port = (mb.get('host') or guess_host(user)[0]), int(mb.get('port') or guess_host(user)[1])
    sv = Saver(mb.get('name') or user)
    # HiNet 等信箱的帳號格式不一（完整信箱或只有 @ 前面）、主機也可能是 msa.hinet.net 或 msXX.hinet.net：登入失敗就自動換組合再試
    tries = [(host, port, user)]
    dom = user.split('@')[-1].lower() if '@' in user else ''
    if not mb.get('host') and dom.endswith('hinet.net'):
        local = user.split('@')[0]
        for h in ('msa.hinet.net', dom, 'imap.hinet.net'):
            for u in (user, local):
                if (h, 993, u) not in tries:
                    tries.append((h, 993, u))
    M, err = None, None
    for h, pt, u in tries:
        try:
            M = imaplib.IMAP4_SSL(h, pt, timeout=60)
            M.login(u, mb['password'])
            if (h, u) != (host, user):
                log(f'  （用 {h}、帳號 {u} 登入成功，已記住）'); mb['host'], mb['port'], mb['login'] = h, pt, u
            break
        except Exception as e:
            M = None
            # 留下最有意義的錯誤：密碼錯 > 連線錯（備用主機連不到不代表密碼對）
            if err is None or isinstance(e, imaplib.IMAP4.error) or not isinstance(err, imaplib.IMAP4.error):
                err = e
    if M is None:
        tip = ('Gmail 要用 16 碼「應用程式密碼」（先開兩步驟驗證），不是平常的登入密碼' if 'gmail' in host else
               ('HiNet 連不到收信伺服器（網路或防火牆擋住，或這個信箱不支援 IMAP）；如果 Outlook 裡已經有這個 HiNet 信箱，用 Outlook 收就好，這個可以刪掉' if not isinstance(err, imaplib.IMAP4.error)
                else 'HiNet 密碼不對：要用「信箱密碼」（登入 HiNet 網頁信箱那組），不是上網撥接密碼') if 'hinet' in host else
               'Yahoo 要用「應用程式密碼」' if 'yahoo' in host else '確認帳號密碼，以及信箱有開 IMAP')
        raise RuntimeError(f'登入失敗：{tip}（{str(err)[:80]}）')
    for fo in imap_folders(M, mb):
        typ, _ = M.select(fo if fo.startswith('"') else f'"{fo}"', readonly=True)
        if typ != 'OK':
            log('  ⚠ 打不開資料夾', fo); continue
        typ, data = M.uid('search', None, 'SINCE', since.strftime('%d-%b-%Y'))
        uids = (data[0] or b'').split()
        for i in range(0, len(uids), 300):
            chunk = b','.join(uids[i:i + 300])
            typ, hd = M.uid('fetch', chunk, '(BODYSTRUCTURE BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])')
            cand = []
            for it in hd or []:
                if not isinstance(it, tuple):
                    continue
                meta = it[0].decode('utf8', 'replace')
                uid = re.search(r'UID (\d+)', meta)
                h = email.message_from_bytes(it[1])
                name, addr = parseaddr(dec(h.get('From')))
                subj = dec(h.get('Subject'))
                if uid and (addr.lower().endswith('einvoice.nat.gov.tw') or (which_bank(addr, name, subj)[0] and kind(subj, re.findall(r'"([^"]+\.pdf)"', meta, re.I)))):
                    cand.append(uid.group(1))
            for u in cand:
                typ, full = M.uid('fetch', u, '(BODY.PEEK[])')
                raw = next((x[1] for x in full or [] if isinstance(x, tuple)), None)
                if not raw:
                    continue
                msg = email.message_from_bytes(raw)
                name, addr = parseaddr(dec(msg.get('From')))
                try:
                    when = parsedate_to_datetime(msg.get('Date')).astimezone(datetime.timezone(datetime.timedelta(hours=8)))
                except Exception:
                    when = datetime.datetime.now()
                atts = [(dec(p.get_filename()), (lambda p=p: p.get_payload(decode=True))) for p in msg.walk() if p.get_filename()]
                sv.handle(addr, name, dec(msg.get('Subject')), when, atts, lambda m=msg: body_text(m))
    M.logout()
    return sv


# ---------- Outlook 電腦版（傳統版；新版 Outlook 不支援，請改用 IMAP 或轉寄） ----------
def run_outlook(mb, since):
    try:
        import win32com.client  # noqa
    except ImportError:
        import subprocess
        subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', 'pywin32'])
        import win32com.client  # noqa
    ns = win32com.client.Dispatch('Outlook.Application').GetNamespace('MAPI')
    want = (mb.get('account') or '').lower()
    sv = Saver(mb.get('name') or 'Outlook')
    tmp = os.path.join(BASE, 'mail_tmp'); os.makedirs(tmp, exist_ok=True)
    SKIPF = re.compile(r'刪除|Deleted|垃圾|Junk|Spam|寄件|Sent|草稿|Drafts|Outbox|寄件匣|RSS|行事曆|Calendar|連絡人|Contacts|工作|Tasks|記事|Notes|日記|Journal', re.I)

    def walk(f, depth=0):
        if depth > 3 or SKIPF.search(f.Name or ''):
            return
        try:
            items = f.Items; items.Sort('[ReceivedTime]', True)
        except Exception:
            items = None
        for it in (items or []):
            try:
                if it.Class != 43:   # 只看郵件
                    continue
                rt = it.ReceivedTime
                when = datetime.datetime(rt.year, rt.month, rt.day, rt.hour, rt.minute)
                if when.date() < since:
                    break
                subj = it.Subject or ''
                addr = it.SenderEmailAddress or ''
                if (it.SenderEmailType or '') == 'EX':
                    try: addr = it.Sender.GetExchangeUser().PrimarySmtpAddress
                    except Exception: pass
                name = it.SenderName or ''
                if not which_bank(addr, name, subj)[0] and not addr.lower().endswith('einvoice.nat.gov.tw'):
                    continue
                atts = []
                for a in it.Attachments:
                    def g(a=a):
                        p = os.path.join(tmp, 'a.bin')
                        a.SaveAsFile(p); b = open(p, 'rb').read(); os.remove(p); return b
                    atts.append((a.FileName or '', g))
                sv.handle(addr, name, subj, when, atts, lambda it=it: it.Body or '')
            except Exception:
                continue
        for sub in f.Folders:
            walk(sub, depth + 1)

    n = 0
    for st in ns.Stores:
        dn = (st.DisplayName or '').lower()
        if want and want not in dn:
            continue
        n += 1
        walk(st.GetRootFolder())
    if not n:
        raise RuntimeError(f'Outlook 裡找不到「{mb.get("account")}」這個信箱（account 填信箱地址的一部分就好）')
    return sv


def main():
    boxes = [b for b in S.get('mailboxes', []) if b.get('enabled', True)]
    if not boxes:
        log('收信：還沒設定信箱（用 Google Apps Script 或自己放 PDF 也可以；要設定請到 LifeLedger「⚙️ 設定 → 信箱收帳單」）'); return
    total = 0
    for mb in boxes:
        key = hashlib.sha1((mb.get('type', 'imap') + '|' + (mb.get('user') or mb.get('account') or '')).encode()).hexdigest()[:10]
        last = STATE.get(key)
        if SINCE_ARG:
            since = datetime.date.fromisoformat(SINCE_ARG)
        elif last:
            since = datetime.date.fromisoformat(last) - datetime.timedelta(days=10)   # 重疊 10 天，晚到的信也收得到
        else:
            since = datetime.date.fromisoformat(S.get('mail_since') or '2025-01-01')   # 第一次：補抓
        label = mb.get('name') or mb.get('user') or mb.get('account') or 'Outlook'
        try:
            sv = run_outlook(mb, since) if mb.get('type') == 'outlook' else run_imap(mb, since)
        except Exception as e:
            log(f'⚠ 收信 {label}：{str(e)[:160]}'); continue
        total += sv.new
        log(f'收信 {label}（{since:%Y/%m/%d} 起）：找到帳單 {sv.found} 封，新存 {sv.new} 份' + ('（測試，沒存檔）' if TEST else ''))
        log('  信用卡帳單：' + ('、'.join(sorted(sv.kinds['card'])) or '沒有'))
        log('  銀行存款／綜合對帳單：' + ('、'.join(sorted(sv.kinds['deposit'])) or '沒有（這個信箱沒收到銀行寄的存款對帳單；有些銀行要先在網銀申請「電子對帳單」，或用隨手記 設定 › 存款回填 手動填）'))
        for x in sv.nopdf[:5]:
            log('  · 這封沒有 PDF 附件（只有網頁連結），要自己到銀行網站下載 PDF：', x)
        if not TEST:
            STATE[key] = datetime.date.today().isoformat()
    if not TEST:
        json.dump(STATE, open(STATE_P, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
    if any(b.get('login') for b in boxes):   # 記住試出來可以登入的主機和帳號格式
        try:
            S2 = json.load(open(setp('local_settings.json'), encoding='utf8'))
            for b in S2.get('mailboxes', []):
                for x in boxes:
                    if x.get('login') and x.get('user') == b.get('user') and x.get('type', 'imap') == b.get('type', 'imap'):
                        b['host'], b['port'], b['login'] = x['host'], x['port'], x['login']
            json.dump(S2, open(setp('local_settings.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=1)
        except Exception:
            pass


if __name__ == '__main__':
    main()
