(function(){
  var TABS=['overview','flow','rewards','fix','detail','ledger','cards','review'];
  var months=[].map.call(document.querySelectorAll('template[id^="t-"]'),function(t){return t.id.slice(2);});
  var LATEST=months[months.length-1], curM=null;
  var sel=document.getElementById('msel'), heroM=document.getElementById('heroM'), app=document.getElementById('app');
  months.slice().reverse().forEach(function(m){var o=document.createElement('option');o.value=m;
    o.textContent=document.getElementById('t-'+m).dataset.label;sel.appendChild(o);});
  // 網址：#2026-09-detail（月份-分頁），也接受 #detail（最新月份）
  function parse(){var h=(location.hash||'').slice(1), m=LATEST, t='overview';
    var g=/^(\d{4}-\d{2})(?:-([a-z]+))?$/.exec(h);
    if(g&&months.indexOf(g[1])>=0){m=g[1];if(g[2]&&TABS.indexOf(g[2])>=0)t=g[2];}
    else if(TABS.indexOf(h)>=0){t=h;}
    return {m:m,t:t};}
  function go(m,t){var h='#'+m+'-'+t; if(location.hash!==h) location.hash=h; else render();}
  function render(){
    var r=parse();
    if(r.m!==curM){
      var tp=document.getElementById('t-'+r.m).content;
      heroM.innerHTML=''; heroM.appendChild(tp.querySelector('.hero-m').cloneNode(true));
      app.innerHTML=''; app.appendChild(tp.querySelector('.body-m').cloneNode(true));
      curM=r.m; sel.value=r.m; bindDetail();
      var i=months.indexOf(r.m);
      document.getElementById('mprev').disabled=(i<=0); document.getElementById('mnext').disabled=(i>=months.length-1);
      document.getElementById('latestTag').hidden=(r.m!==LATEST);
      document.querySelectorAll('nav.tabs a').forEach(function(a){a.href='#'+r.m+'-'+a.dataset.t;});
      var rvt=document.querySelector('nav.tabs a.rvtab'); if(rvt) rvt.hidden=!app.querySelector('[data-tab="review"]');
      var lgt=document.querySelector('nav.tabs a.lgtab'); if(lgt) lgt.hidden=!app.querySelector('[data-tab="ledger"]');
      var flt=document.querySelector('nav.tabs a[data-t="flow"]'); if(flt) flt.hidden=!app.querySelector('[data-tab="flow"] .card');
      bindLR();
      bindDS();
      bindCyc();
      var fx=+(app.querySelector('[data-tab="fix"]').dataset.n||0), cnt=document.getElementById('fixCnt');
      cnt.textContent=fx; cnt.hidden=!fx;
    }
    if(!app.querySelector('section[data-tab="'+r.t+'"]')) r.t='overview';
    app.querySelectorAll('section[data-tab]').forEach(function(s){s.hidden=(s.dataset.tab!==r.t);});
    document.body.dataset.tab=r.t;   // 總覽以外的分頁把上方大區塊收小，少捲動
    document.querySelectorAll('nav.tabs a').forEach(function(a){
      if(a.dataset.t===r.t) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current');});
  }
  // 隨手記對照：依結果篩選、依日期／卡片排列、新舊排序
  function bindLR(){
    var sec=app.querySelector('.lrcard'); if(!sec) return;
    var tb=sec.querySelector('table.lrt tbody'), rows=[].slice.call(tb.querySelectorAll('tr.lr')), asc=false, grp='date';
    try{asc=localStorage.getItem('cf-lrsort')==='asc'; grp=localStorage.getItem('cf-lrgrp')||'date';}catch(e){}
    var st=sec.querySelectorAll('.lrst'), gb=sec.querySelectorAll('[data-lrg]'), sb=sec.querySelector('.lrsort');
    function apply(){
      var on=[]; st.forEach(function(b){if(b.getAttribute('aria-pressed')==='true') on.push(b.dataset.st);});
      gb.forEach(function(b){b.setAttribute('aria-pressed',b.dataset.lrg===grp?'true':'false');});
      sb.textContent=asc?'舊 → 新':'新 → 舊';
      var xs=rows.slice().sort(function(a,b){var c=(grp==='card')?a.dataset.c.localeCompare(b.dataset.c):0; return c||(asc?1:-1)*a.dataset.d.localeCompare(b.dataset.d);});
      tb.innerHTML=''; var last=null;
      xs.forEach(function(r){var ok=!on.length||on.some(function(k){return r.dataset.st.indexOf(k)===0;}); if(!ok) return;
        if(grp==='card'&&r.dataset.c!==last){last=r.dataset.c; var g=document.createElement('tr'); g.className='grp'; var n=xs.filter(function(x){return x.dataset.c===last&&(!on.length||on.some(function(k){return x.dataset.st.indexOf(k)===0;}));}).length;
          g.innerHTML='<td colspan="5"></td>'; g.firstChild.textContent=last+'（'+n+' 筆）'; tb.appendChild(g);}
        tb.appendChild(r);});
    }
    st.forEach(function(b){b.addEventListener('click',function(){b.setAttribute('aria-pressed',b.getAttribute('aria-pressed')==='true'?'false':'true');apply();});});
    gb.forEach(function(b){b.addEventListener('click',function(){grp=b.dataset.lrg;try{localStorage.setItem('cf-lrgrp',grp);}catch(e){}apply();});});
    sb.addEventListener('click',function(){asc=!asc;try{localStorage.setItem('cf-lrsort',asc?'asc':'desc');}catch(e){}apply();});
    apply();
  }
  // 明細：新→舊／舊→新（記住選擇）
  // 結帳日：依今天算下次結帳、還有幾天（快結帳＝先別刷；剛結帳＝現在刷最晚繳）
  function bindCyc(){
    var t=new Date(), t0=new Date(t.getFullYear(),t.getMonth(),t.getDate()), W='日一二三四五六';
    function dim(y,m){return new Date(y,m+1,0).getDate();}
    app.querySelectorAll('tr.cycrow').forEach(function(tr){
      var day=+tr.dataset.day, d=new Date(t0.getFullYear(),t0.getMonth(),Math.min(day,dim(t0.getFullYear(),t0.getMonth())));
      if(d<t0) d=new Date(t0.getFullYear(),t0.getMonth()+1,Math.min(day,dim(t0.getFullYear(),t0.getMonth()+1)));
      var n=Math.round((d-t0)/864e5), pm=new Date(d.getFullYear(),d.getMonth()-1,1), last=new Date(pm.getFullYear(),pm.getMonth(),Math.min(day,dim(pm.getFullYear(),pm.getMonth()))), ago=Math.round((t0-last)/864e5);
      tr.dataset.n=n;
      tr.querySelector('.cnx').textContent=(d.getMonth()+1)+'/'+d.getDate()+'（'+W[d.getDay()]+'）';
      var s=tr.querySelector('.cst'); s.className='cst '+(n<=3?'bad':ago<=5?'good':'');
      s.textContent=n===0?'⚠ 今天結帳，先別刷':n<=3?'⚠ '+n+' 天後結帳，先別刷':ago<=5?'✓ 剛結帳，現在刷最晚繳':'還有 '+n+' 天';
    });
    app.querySelectorAll('table.cyct tbody').forEach(function(tb){
      Array.prototype.slice.call(tb.querySelectorAll('tr.cycrow')).sort(function(a,b){return a.dataset.n-b.dataset.n;}).forEach(function(r){tb.appendChild(r);});
    });
  }
  function bindDS(){
    var b=app.querySelector('[data-tab="detail"] .dsort'); if(!b) return;
    var MODES=['desc','asc','big'], LAB={desc:'新 → 舊',asc:'舊 → 新',big:'金額 大 → 小'}, m='desc';
    try{m=localStorage.getItem('cf-dsort')||'desc';}catch(e){} if(MODES.indexOf(m)<0) m='desc';
    function amt(r){var a=r.querySelector('.amt');return a?parseFloat(a.textContent.replace(/[^\d.\-]/g,''))||0:0;}
    function apply(){ b.textContent='排序：'+LAB[m]+' ▾'; b.title='點一下切換：新→舊、舊→新、金額大→小';
      app.querySelectorAll('[data-tab="detail"] table.det').forEach(function(t){
        var groups=t.tBodies.length?[].slice.call(t.tBodies):[t];
        groups.forEach(function(g){ if(t.dataset.v==='cat'&&m!=='big') return;   // 依分類本來就照金額大到小
          var rs=[].slice.call(g.querySelectorAll('tr.tx'));
          rs.sort(function(x,y){ if(m==='big') return amt(y)-amt(x)||y.dataset.d.localeCompare(x.dataset.d);
            var c=x.dataset.d.localeCompare(y.dataset.d); return m==='asc'?c:-c; });
          rs.forEach(function(r){g.appendChild(r);}); });
      }); }
    b.addEventListener('click',function(){m=MODES[(MODES.indexOf(m)+1)%MODES.length];try{localStorage.setItem('cf-dsort',m);}catch(e){}apply();}); apply();
  }
  var VIEW='card'; try{VIEW=localStorage.getItem('cf-view')||'card';}catch(e){}
  function bindDetail(){
    var sec=app.querySelector('[data-tab="detail"]'); if(!sec) return;
    var q=sec.querySelector('.q'), cs=sec.querySelector('.cs'), ks=sec.querySelector('.ks'), pills=sec.querySelectorAll('.pill');
    var tables=sec.querySelectorAll('table.det'), views=sec.querySelectorAll('[data-view]');
    var cntx=sec.querySelector('.cntx'), sumx=sec.querySelector('.sumx');
    function apply(){
      var term=(q.value||'').trim().toLowerCase(), card=cs.value, kat=ks?ks.value:'', on=[];
      pills.forEach(function(p){if(p.getAttribute('aria-pressed')==='true') on.push(p.dataset.b);});
      views.forEach(function(v){v.setAttribute('aria-pressed',v.dataset.view===VIEW?'true':'false');});
      var n=0,s=0;
      tables.forEach(function(t){
        var act=(t.dataset.v===VIEW); t.hidden=!act;
        t.querySelectorAll('tr.tx').forEach(function(tr){
          var ok=(!term||tr.dataset.s.indexOf(term)>=0)&&(!card||tr.dataset.c===card)&&(!kat||tr.dataset.k===kat)&&(!on.length||on.indexOf(tr.dataset.b)>=0);
          tr.hidden=!ok; if(ok&&act){n++; if(!tr.classList.contains('reb')) s+=parseFloat(tr.querySelector('.amt').textContent.replace(/,/g,''))||0;}
        });
        t.querySelectorAll('tbody.g').forEach(function(g){g.hidden=!g.querySelector('tr.tx:not([hidden])');});
      });
      cntx.textContent=n+' 筆'; sumx.textContent='合計 NT$ '+Math.round(s).toLocaleString('en-US');
    }
    q.addEventListener('input',apply); cs.addEventListener('change',apply); if(ks) ks.addEventListener('change',apply);
    pills.forEach(function(p){p.addEventListener('click',function(){p.setAttribute('aria-pressed',p.getAttribute('aria-pressed')==='true'?'false':'true');apply();});});
    views.forEach(function(v){v.addEventListener('click',function(){VIEW=v.dataset.view;try{localStorage.setItem('cf-view',VIEW);}catch(e){}apply();});});
    apply();
  }
  document.querySelectorAll('nav.tabs a').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();go(curM,a.dataset.t);window.scrollTo({top:0});});});
  app.addEventListener('click',function(e){var a=e.target.closest('a[href^="#"]'); if(a){e.preventDefault(); location.hash=a.getAttribute('href'); window.scrollTo({top:0});}});
  sel.addEventListener('change',function(){go(sel.value,parse().t);});
  document.getElementById('mprev').addEventListener('click',function(){var i=months.indexOf(curM);if(i>0)go(months[i-1],parse().t);});
  document.getElementById('mnext').addEventListener('click',function(){var i=months.indexOf(curM);if(i<months.length-1)go(months[i+1],parse().t);});
  window.addEventListener('hashchange',render); render();
  // 更新：網頁版重新載入（拿到最新發布的版本）；離線檔則改開網頁版
  if(location.protocol==='file:') document.querySelectorAll('a[data-local]').forEach(function(a){a.href=a.dataset.local;});   // 離線版：連到同資料夾的離線檔
  var rb=document.getElementById('reloadBtn');
  if(location.protocol==='file:'){ if(rb.dataset.url){rb.textContent='🌐 切換到線上版'; rb.classList.add('online');} else {rb.hidden=true;} }
  rb.addEventListener('click',function(){ if(location.protocol==='file:'){window.open(rb.dataset.url,'_blank');} else {location.reload();} });
  // 深淺色：自動 → 淺色 → 深色
  var modes=['auto','light','dark'], label={auto:'自動',light:'淺色',dark:'深色'}, btn=document.getElementById('themeBtn');
  function applyTheme(m){ if(m==='auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme',m);
    btn.querySelector('.tx').textContent=label[m]; btn.dataset.mode=m; }
  var saved='auto'; try{saved=localStorage.getItem('cf-theme')||'auto';}catch(e){}
  applyTheme(modes.indexOf(saved)<0?'auto':saved);
  btn.addEventListener('click',function(){var m=modes[(modes.indexOf(btn.dataset.mode)+1)%3];applyTheme(m);try{localStorage.setItem('cf-theme',m);}catch(e){}});

  /* ===== 代墊：在月報明細直接勾（隨手記網站裡打開時）；其他地方打開會帶你到線上版 ===== */
  (function(){
    var ONLINE=!!window.LL_ONLINE, SITE=window.LL_SITE||'';
    // 密碼在 localStorage（隨手記勾「記住這台裝置」）或 sessionStorage（沒勾，關掉分頁就清掉）；規則同隨手記 app/sync.js credLoad
    function cred(){var g=function(s,k){try{return s.getItem(k)||'';}catch(e){return '';}};return [g(localStorage,'cf-user'),g(localStorage,'cf-pw')||g(sessionStorage,'cf-pw')];}
    /* 新版隨手記網站（view.html 會載入 sync.js）：用 LLSync.pageLedger 讀寫，送登入金鑰、帳本加密就在這裡加解密；
       舊版網站沒有 LLSync，照舊（帳本加密後舊寫法會被伺服器擋下，不會蓋掉帳本） */
    var PL=null;try{if(window.LLSync&&LLSync.pageLedger)PL=LLSync.pageLedger(function(u,o){return fetch(u,o);},(window.LL_ONLINE&&window.LL_ONLINE.api)||'',
      (function(){try{return localStorage;}catch(e){return null;}})(),(function(){try{return sessionStorage;}catch(e){return null;}})());}catch(e){}
    function api(method,body){if(PL)return PL(method,body);var c=cred();return fetch(((window.LL_ONLINE&&window.LL_ONLINE.api)||'')+'/api/ledger',{method:method,headers:{'x-cf-user':encodeURIComponent(c[0]),'x-cf-key':encodeURIComponent(c[1]),'content-type':'application/json'},body:body?JSON.stringify(body):undefined,cache:'no-store'})
      .then(function(r){return r.json().catch(function(){return {};}).then(function(j){return {status:r.status,j:j};});});}
    /* 版本號（rev）與帳本格式檢查：和隨手記 app/sync.js 同一套規則（rev ≥ 0 的整數；只有 rev 0 才可能沒有帳本；存檔成功的 rev 要比 base 新） */
    function ledgerOf(g){var j=g.j||{};if(!Number.isSafeInteger(j.rev)||j.rev<0)throw new Error('雲端回應缺少有效的版本號，這次沒有存到');
      if(j.data===undefined)throw new Error('雲端回應缺少帳本資料欄位，這次沒有存到');   // 欄位完全缺失：不論 rev 都不存
      if(j.data===null){if(j.rev===0)return {records:[],cards:[]};throw new Error('雲端沒有回傳帳本資料，這次沒有存到');}   // 只有 rev 0（還沒有帳本）才可以從空帳本開始
      var d=j.data;if(typeof d!=='object'||Array.isArray(d)||!Array.isArray(d.records)||!Array.isArray(d.cards))throw new Error('雲端回傳的帳本格式不對，這次沒有存到');return d;}
    function savedOk(p,base){if(!p.j||!Number.isSafeInteger(p.j.rev)||p.j.rev<=base)throw new Error('伺服器回應不完整，無法確認有沒有存到，請重新整理後再試');return true;}
    function save(id,r,n){n=n||0;return api('GET').then(function(g){
        if(g.status===401)throw new Error('登入過期，請回隨手記重新登入');if(g.status!==200)throw new Error('連不上（'+g.status+'）');
        var d=ledgerOf(g);d.paidMarks=(d.paidMarks||[]).filter(function(m){return m.k!==id;});d.paidMarks.push({k:id,r:r,t:new Date().toISOString()});
        if(d.paidMarks.length>3000)d.paidMarks=d.paidMarks.slice(-3000);
        return api('PUT',{base:g.j.rev,data:d}).then(function(p){if(p.status===200&&savedOk(p,g.j.rev))return;if(p.status===409&&n<2)return save(id,r,n+1);throw new Error((p.j&&p.j.error)||'存檔失敗');});});}
    function toast(m){var t=document.getElementById('pdToast');if(!t){t=document.createElement('div');t.id='pdToast';t.setAttribute('role','status');t.style.cssText='position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:90;padding:10px 16px;border-radius:10px;font-size:14px;background:#0e2035;color:#fff;box-shadow:0 8px 24px rgba(0,0,0,.25);max-width:90vw';document.body.appendChild(t);}
      t.textContent=m;t.hidden=false;clearTimeout(t._t);t._t=setTimeout(function(){t.hidden=true;},4000);}
    function pop(btn){
      var el=document.getElementById('pdPop');if(!el){el=document.createElement('div');el.id='pdPop';document.body.appendChild(el);}
      var tr=btn.closest('tr'),mer=tr.querySelector('.mer'),name=mer&&mer.firstChild?(mer.firstChild.textContent||''):'',amt=+btn.dataset.a||0,pr=+btn.dataset.pr||0,tot=pr?Math.round(amt/(1-pr)):amt;
      if(!ONLINE){
        el.innerHTML='<div class="t">要標成代墊（幫別人付的）？</div><p>這份月報是唯讀的。到隨手記網站裡的月報或生活帳本就能直接勾，勾完下次更新會從你的消費扣掉。</p>'+
          (SITE?'<a class="go" target="_blank" rel="noopener" href="'+SITE+'/view.html?p=book">打開線上生活帳本 ↗</a>':'<p style="margin-top:6px">（也可以在 Excel 明細的「代付」欄打 ✔ 或 50%）</p>');
      }else{
        el.innerHTML='<div class="t"></div><div class="row"><button data-r="1">全部代墊</button><button data-r=".5">一半</button><button data-r="0">不是代墊</button></div>'+
          '<div class="cu">代墊 <input type="number" min="1" max="99" placeholder="%" aria-label="代墊比例"> % 或 <input type="number" min="1" placeholder="金額" aria-label="代墊金額"> <button data-r="c">好</button></div>';
        el.querySelector('.t').textContent=name.slice(0,24)+'・NT$ '+tot.toLocaleString();
        [].forEach.call(el.querySelectorAll('button'),function(b){b.onclick=function(ev){ev.stopPropagation();var r=b.dataset.r;
          if(r==='c'){var ins=el.querySelectorAll('input');r=ins[0].value?(+ins[0].value/100):ins[1].value?(+ins[1].value/tot):NaN;if(!(r>0&&r<=1))return;}
          r=+r;el.hidden=true;btn.disabled=true;btn.textContent='儲存中…';
          save(btn.dataset.pd,r).then(function(){btn.disabled=false;btn.dataset.pr=r>0&&r<.999?r:0;btn.classList.toggle('on',r>0);
              btn.textContent=r>=.999?'代墊 ✔':r>0?'自付 '+Math.round((1-r)*100)+'%':'代墊？';
              toast(r>0?'已標記代墊；電腦下次更新（或按「立即更新月報」）後總額會扣掉':'已取消代墊');})
            .catch(function(e){btn.disabled=false;btn.textContent='代墊？';toast('沒有存到：'+e.message);});};});
      }
      var rc=btn.getBoundingClientRect();el.style.top=(window.scrollY+rc.bottom+6)+'px';el.style.left=Math.max(8,Math.min(window.scrollX+rc.right-260,window.innerWidth-272))+'px';el.hidden=false;
    }
    document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('.pdb');if(b&&!b.disabled){e.preventDefault();e.stopPropagation();pop(b);return;}
      var p=document.getElementById('pdPop');if(p&&!p.hidden&&!e.target.closest('#pdPop'))p.hidden=true;},true);
  })();
})();
