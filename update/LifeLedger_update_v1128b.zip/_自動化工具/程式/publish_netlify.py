# LifeLedger：把月報與生活帳本「用隨手記密碼加密」後上傳到隨手記網站（同一個網址、同一組帳號就能看三樣）
#   網址：<隨手記網址>/view.html?p=report（月報）、?p=book（生活帳本）
#   由 run_local.py 每次更新後自動呼叫；內容沒變就不上傳
# 帳號密碼用 local_settings.json 的 "ledger"（跟抓隨手記同一組）。
# 加密：PBKDF2-SHA256（60 萬次）→ AES-256-GCM，先 gzip 壓縮。伺服器只存密文，網站管理者也看不到內容。
import os, sys, json, re, gzip, base64, hashlib, urllib.request, urllib.parse, urllib.error, subprocess

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)
from paths import setp, HOME
S = json.load(open(setp('local_settings.json'), encoding='utf8'))
L = S.get('ledger') or {}
OUT = os.environ.get('CARDFLOW_OUT') or S.get('out') or HOME
FORCE = '--force' in sys.argv
ITER = 600_000


def log(*a):
    print(*a, flush=True)
    try:   # 也記在 紀錄\線上狀態.txt，方便事後查
        from paths import LOG; import datetime as _d; os.makedirs(LOG, exist_ok=True)
        open(os.path.join(LOG, '線上狀態.txt'), 'a', encoding='utf8').write(f'{_d.datetime.now():%Y-%m-%d %H:%M} ' + ' '.join(map(str, a)) + '\n')
    except Exception:
        pass


if not (L.get('url') and L.get('user') and L.get('password')) or '填' in str(L.get('user')):
    log('線上版（隨手記網站）：local_settings.json 的 ledger 還沒填，略過'); sys.exit(0)
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
except ImportError:
    subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', 'cryptography'], check=True)
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes

rd = lambda p: open(p, encoding='utf8').read()
url_report = rd('report_url.txt').strip() if os.path.exists('report_url.txt') else ''
url_ledger = rd('ledger_url.txt').strip() if os.path.exists('ledger_url.txt') else ''


def localize(h):
    """claude.ai／GitHub 的連結改成隨手記網站裡的頁面（同一個分頁、不用再登入）"""
    if url_ledger:
        h = h.replace(f'href="{url_ledger}" target="_blank" rel="noopener"', 'href="view.html?p=book"').replace(url_ledger, 'view.html?p=book')
    if url_report:
        h = h.replace(f'href="{url_report}" target="_blank" rel="noopener"', 'href="view.html?p=report"').replace(url_report, 'view.html?p=report')
    return h


def full_doc(frag, title):
    if frag.lstrip().lower().startswith('<!doctype'):
        return frag
    return ('<!doctype html>\n<html lang="zh-Hant"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
            f'<title>{title}</title></head><body>\n' + frag + '\n</body></html>')


pages = {}
rep = os.path.join(OUT, '月報', 'LifeLedger月報.html')
if os.path.exists(rep):
    pages['report'] = localize(rd(rep))
if os.path.exists('刷卡帳本.html'):
    pages['book'] = localize(full_doc(rd('刷卡帳本.html'), 'LifeLedger 生活帳本'))
if not pages:
    log('線上版：還沒有月報／生活帳本可以上傳'); sys.exit(0)


def card_list():
    """隨手記「從我的帳單一鍵匯入」用：銀行、卡名、末四碼、近一年筆數（不含完整卡號；停卡的不列）"""
    try:
        R = json.load(open('rows.json', encoding='utf8'))
        try:
            from cards import STATUS
        except Exception:
            STATUS = {}
        import datetime as _dt
        since = (_dt.date.today() - _dt.timedelta(days=400)).isoformat()
        agg = {}
        for r in R:
            l4 = str(r.get('card') or '')[-4:]
            if (r.get('amount') or 0) <= 0:
                continue
            if not re.fullmatch(r'\d{4}', l4) or (r.get('bank'), l4) in STATUS or r.get('date', '') < since:
                continue
            k = (r['bank'], l4)
            a = agg.setdefault(k, {'bank': r['bank'], 'name': re.sub(r'\s*[·・.]\s*\d{4}\s*$|\d{6,}', '', str(r.get('cardname') or '')).strip() or '信用卡',
                                   'last4': l4, 'n': 0, 'last': '', 'mine': r.get('owner', '我') == '我'})
            a['n'] += 1; a['last'] = max(a['last'], r.get('date', ''))
        L = sorted(agg.values(), key=lambda x: (not x['mine'], -x['n']))
        try:   # 各銀行每月結帳日（從帳單讀出；隨手記用來提醒「快結帳先別刷」）
            from cycles import by_bank
            import datetime as _dt
            CY = {k: dict({'day': v['day'], 'vary': v['vary'], 'last': v['last']}, **{x: v[x] for x in ('due', 'amt', 'nopay') if x in v}) for k, v in by_bank().items()
                  if (_dt.date.today() - _dt.date.fromisoformat(v['last'])).days <= 75}   # 太久沒帳單＝停卡或沒在刷，不提醒；加上最新一期的繳款截止日、本期應繳
        except Exception:
            CY = {}
        for a in L:
            if a['bank'] in CY:
                a['cyc'] = CY[a['bank']]['day']
        return json.dumps({'v': 1, 'cards': L, 'cyc': CY}, ensure_ascii=False) if L else None
    except Exception as e:
        log('（卡片清單略過：', e, '）'); return None


_cl = card_list()
if _cl:
    pages['cards'] = _cl

strip_date = lambda h: re.sub(r'(資料至\s*)\d{4}/\d{2}/\d{2}', r'\1', h)
digest = hashlib.sha256((L['user'] + '\0' + L['password'] + '\0' + '\0'.join(strip_date(h) for h in pages.values())).encode()).hexdigest()
if not FORCE and os.path.exists('.netlify_hash') and rd('.netlify_hash').strip() == digest:
    log('線上版：內容沒有變化，不用上傳'); sys.exit(0)


def seal(html):
    salt, iv = os.urandom(16), os.urandom(12)
    key = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=ITER).derive(L['password'].encode('utf8'))
    ct = AESGCM(key).encrypt(iv, gzip.compress(html.encode('utf8'), 9), None)
    return {'v': 1, 'gz': 1, 'iter': ITER, 'salt': base64.b64encode(salt).decode(), 'iv': base64.b64encode(iv).decode(), 'ct': base64.b64encode(ct).decode()}


from ledger_client import Client   # 新版網站用登入金鑰登入（不送密碼原文）；頁面本身照舊用密碼加密
C = Client(L)
ok = 0
for name, html in pages.items():
    try:
        st, j = C.call('PUT', '/api/ledger?page=' + name, json.dumps({'blob': seal(html)}).encode(), timeout=90)
    except Exception as e:
        log('⚠ 線上版上傳失敗：', e); sys.exit(0)
    if st == 200:
        ok += 1; continue
    if st == 401:
        log('⚠ 線上版：隨手記帳號或密碼不對（在手機上改過或重設過密碼？）→ 打開 LifeLedger「⚙️ 設定 → 隨手記帳號」填新密碼'); sys.exit(0)
    if st == 400 and name == 'cards':
        continue   # 網站是前一版：卡片清單先不傳，其他照常
    if st == 400 and name == 'report':
        log('⚠ 線上版：隨手記網站還是舊版，請把新版 netlify/functions/ledger.mjs 上傳到 GitHub'); sys.exit(0)
    log(f'⚠ 線上版上傳 {name} 失敗（{st}）：{str(j.get("error") if isinstance(j, dict) else j)[:200]}'); sys.exit(0)
open('.netlify_hash', 'w').write(digest)
site = L['url'].rstrip('/')
log(f'線上版已更新（{ok} 頁，已加密）：{site}/view.html?p=report ・ {site}/view.html?p=book')
