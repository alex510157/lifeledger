﻿# LifeLedger：把整個帳本資料夾搬到 OneDrive（一鍵）。由「搬到OneDrive.bat」呼叫。
param([string]$Src)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
function Say($t) { Write-Host $t }
try {
  $Src = (Resolve-Path $Src).Path.TrimEnd('\')
  $od = $env:OneDrive
  if (-not $od -or -not (Test-Path $od)) { Say '這台電腦沒有登入 OneDrive：請先在右下角登入 OneDrive，再執行一次。'; exit 1 }
  $od = (Resolve-Path $od).Path.TrimEnd('\')
  if ($Src.ToLower().StartsWith($od.ToLower() + '\')) { Say "已經在 OneDrive 裡了：$Src"; exit 0 }
  $name = Split-Path $Src -Leaf
  $Dst = Join-Path $od $name
  if (Test-Path $Dst) { Say "OneDrive 裡已經有「$name」資料夾：$Dst`n請先確認裡面是什麼（可能是另一台電腦的帳本），改名或刪掉後再執行一次。"; exit 1 }
  Say "從：$Src"; Say "搬到：$Dst"; Say ''
  Say '1/4 暫停自動更新排程…'
  schtasks /Delete /TN "LifeLedger Daily" /F 2>$null | Out-Null
  schtasks /Delete /TN "LifeLedger 白天更新" /F 2>$null | Out-Null
  Say '2/4 搬移檔案（檔案多的話要幾分鐘）…'
  robocopy "$Src" "$Dst" /E /MOVE /R:2 /W:2 /NFL /NDL /NJH /NP | Out-Null
  if ($LASTEXITCODE -ge 8) { throw "搬移時有檔案搬不動（robocopy 代碼 $LASTEXITCODE）。請關掉 Excel、月報網頁後再執行一次；已搬過去的不會重複。" }
  if (Test-Path $Src) { Remove-Item $Src -Recurse -Force -ErrorAction SilentlyContinue }
  Say '3/4 更新設定和排程…'
  $ls = Join-Path $Dst '_自動化工具\設定\local_settings.json'
  if (Test-Path $ls) {
    $t = [IO.File]::ReadAllText($ls, [Text.Encoding]::UTF8)
    $t = $t.Replace($Src.Replace('\', '\\'), $Dst.Replace('\', '\\'))
    [IO.File]::WriteAllText($ls, $t, (New-Object Text.UTF8Encoding($false)))
  }
  $bat = Join-Path $Dst '_自動化工具\程式\lifeledger_daily.bat'
  schtasks /Create /TN "LifeLedger Daily" /SC DAILY /ST 07:30 /TR "`"$bat`"" /F | Out-Null
  schtasks /Create /TN "LifeLedger 白天更新" /SC DAILY /ST 12:30 /RI 240 /DU 09:00 /TR "`"$bat`"" /F | Out-Null
  Say '4/4 更新捷徑…'
  $sh = New-Object -ComObject WScript.Shell
  $sm = Join-Path ([Environment]::GetFolderPath('Programs')) 'LifeLedger 生活總帳'
  New-Item -ItemType Directory -Force -Path $sm | Out-Null
  $links = @{
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'LifeLedger 生活總帳.lnk') = $Dst;
    (Join-Path $sm '帳本資料夾.lnk') = $Dst;
    (Join-Path $sm '立即更新.lnk') = (Join-Path $Dst '_自動化工具\立即更新月報.bat');
    (Join-Path $sm '設定精靈.lnk') = (Join-Path $Dst '_自動化工具\設定精靈.bat');
    (Join-Path $sm '打開月報.lnk') = (Join-Path $Dst '月報\LifeLedger月報.html');
    (Join-Path $sm '打開生活帳本.lnk') = (Join-Path $Dst '月報\LifeLedger生活帳本.html');
    (Join-Path $sm '解除安裝.lnk') = (Join-Path $Dst '_自動化工具\解除安裝.exe')
  }
  foreach ($k in $links.Keys) { $l = $sh.CreateShortcut($k); $l.TargetPath = $links[$k]; $l.Save() }
  $rk = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\LifeLedger'
  if (Test-Path $rk) {
    Set-ItemProperty $rk InstallLocation $Dst
    Set-ItemProperty $rk UninstallString ('"' + (Join-Path $Dst '_自動化工具\解除安裝.exe') + '"')
  }
  Say ''; Say "✓ 搬好了！帳本現在在：$Dst"
  Say '  建議：在 OneDrive 裡對這個資料夾按右鍵 →「一律保留在此裝置上」。'
  Say '  以後換電腦：新電腦登入同一個 OneDrive，等同步完，雙擊 _自動化工具\安裝或換電腦.bat。'
  Start-Process explorer.exe $Dst
} catch { Say ''; Say ('⚠ ' + $_.Exception.Message) }
Read-Host "`n按 Enter 關閉" | Out-Null
