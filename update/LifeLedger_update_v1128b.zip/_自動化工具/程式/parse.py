import re, glob, os, json, unicodedata
from datetime import date

os.chdir(os.path.dirname(os.path.abspath(__file__)))
TXT = 'txt'
DATE = r'(?:\d{3,4}/)?\d{1,2}/\d{1,2}'
AMT = r'-?\d{1,3}(?:,\d{3})*(?:\.\d+)?'
ROW = re.compile(r'^\s*\+?\s*(' + DATE + r')\s+(?:(' + DATE + r')(?:\s+|$))?(.*)$')
AMT_RE = re.compile(r'(?<![\w/.:\-])(' + AMT + r')(?![\w/%])')

# amount position: 'first' = first amount token after description, 'last' = last token on line
AMTPOS = {'台新': 'first', '國泰': 'first', '永豐': 'first', '中信': 'first',
          '星展': 'last', '玉山': 'last', '聯邦': 'last'}

SKIP_DESC = re.compile(r'(上期|本期|小計|合計|總計|應繳|謝謝|已收到|繳款|自動轉帳|自動扣繳|扣繳|自扣|轉帳扣|銷帳|繳費)')
PAYMENT = re.compile(r'(餘額返回|溢付|溢繳|取消信用卡年費|感謝您|謝謝|已收到|自動轉帳|自動扣繳|扣繳|自扣|轉帳扣|繳款|繳納信用卡|上期)')
HEADER = re.compile(r'(卡號|末四碼|末4碼|正卡|附卡|新增消費小計|消費日|入帳|續下頁|頁)')


SECTION = {'臺幣': 'TWD', '日圓': 'JPY', '美元': 'USD', '歐元': 'EUR'}
RATE = {'JPY': 0.21, 'USD': 31.5, 'EUR': 35.0}


def norm(s):
    return unicodedata.normalize('NFKC', s)


def to_date(tok, stmt_date):
    parts = tok.split('/')
    if len(parts) == 3:
        y, m, d = map(int, parts)
        if y < 1911:
            y += 1911
    else:
        m, d = map(int, parts)
        y = stmt_date.year
        if m > stmt_date.month + 0 and (m - stmt_date.month) > 1:
            y -= 1
        elif m > stmt_date.month and stmt_date.month == 1:
            y -= 1
    try:
        return date(y, m, d)
    except ValueError:
        return None


def parse_file(path):
    fn = os.path.basename(path)
    bank = fn.split('__')[0]
    sd = re.search(r'(\d{4})-(\d{2})-(\d{2})', fn)
    stmt_date = date(*map(int, sd.groups()))
    lines0 = open(path, encoding='utf8', errors='ignore').read().split('\n')
    lines = []
    k = 0
    while k < len(lines0):
        l = lines0[k]
        mm = ROW.match(l)
        if mm and not mm.group(3).strip() and k + 1 < len(lines0) and not ROW.match(lines0[k + 1]) and lines0[k + 1].strip():
            lines.append(l.rstrip() + ' ' + lines0[k + 1].strip())
            lines.append('')
            k += 2
            continue
        lines.append(l)
        k += 1
    out = []
    card = ''
    sec_cur = 'TWD'
    for i, raw in enumerate(lines):
        line = raw.rstrip()
        if bank == '永豐' and line.strip() in SECTION:
            sec_cur = SECTION[line.strip()]
        mu = re.search(r'－[正附]卡\s*(\d{4})\s*$', line)
        if mu:
            card = mu.group(1)
        m4 = re.search(r'(?:末四碼|末4碼)[:：\s]*(\d{4})|卡號[:：]\s*\d{4}-X{4}-X{4}-(\d{4})', line)
        if m4:
            card = m4.group(1) or m4.group(2)
        m = ROW.match(line)
        if not m:
            continue
        d1, d2, rest = m.group(1), m.group(2), m.group(3)
        if re.search(r'\d\.\d+%', rest) and not d2:   # 有兩個日期的是交易列（如「權益類保費1.5%回饋」），不可跳過
            continue
        if not d2 and not PAYMENT.search(rest):
            continue
        dt = to_date(d1, stmt_date)
        if not dt or not (2023 <= dt.year <= 2027):
            continue
        # find amounts in rest
        amts = [(a.start(), a.group(1)) for a in AMT_RE.finditer(rest)]
        if not amts:
            continue
        # description = text before first amount token that is followed by big gap or end
        if bank == '永豐':
            rest2 = re.sub(r'^\s*(\d{4})\s+', '', rest)
            mc = re.match(r'^\s*(\d{4})\s+', rest)
            if mc:
                card = mc.group(1)
            rest = rest2
            amts = [(a.start(), a.group(1)) for a in AMT_RE.finditer(rest)]
            if not amts:
                continue
        # choose description end: first amount occurrence preceded by 2+ spaces
        desc_end = None
        for pos, a in amts:
            if not rest[:pos].strip():
                if not re.match(r'\s|$', rest[pos + len(a):]):
                    continue   # 說明開頭的數字（分期「6- 3 期」、「7-ELEVEN」、「７—８月保費」）不是金額
                desc_end = pos
                break
            if pos >= 2 and rest[pos - 2:pos] == '  ':
                desc_end = pos
                break
            if pos > 0 and rest[:pos].strip() and re.search(r'\s{2,}$', rest[:pos]):
                desc_end = pos
                break
        if desc_end is None:
            # amount directly at start (wrapped desc) or single-space
            desc_end = amts[0][0]
        desc = rest[:desc_end].strip()
        tail = rest[desc_end:]
        tamts = [a.group(1) for a in AMT_RE.finditer(tail)]
        if bank in ('國泰', '中信'):
            mc2 = re.match(r'\s*-?[\d,]+\s+(\d{4})\b', tail)
            if mc2:
                card = mc2.group(1)
        if not tamts:
            continue
        if AMTPOS[bank] == 'first':
            amt = tamts[0]
        else:
            amt = tamts[-1]
        # foreign currency info
        cur = re.search(r'\b(USD|JPY|EUR|MOP|HKD|KRW|THB|SGD|CNY|GBP|AUD|VND|MYR|CAD|NZD|TWD|CHF|PHP|IDR)\b', tail)
        country = re.search(r'\s([A-Z]{2})\s', tail + ' ')
        # wrapped description: look at neighbouring non-row lines
        if len(desc) < 2 or desc.endswith('第') or True:
            prev = lines[i - 1].strip() if i > 0 else ''
            nxt = lines[i + 1].strip() if i + 1 < len(lines) else ''
            add_prev = prev and not ROW.match(lines[i - 1]) and not HEADER.search(prev) and not AMT_RE.search(prev.replace(',', '')) and len(prev) < 40
            add_next = nxt and not ROW.match(lines[i + 1]) and not HEADER.search(nxt) and len(nxt) < 30 and not re.search(r'\d{2,}', nxt[:3])
            if len(desc) < 2:
                # 描述整段換行到上下行（如永豐 A- / HOTELCOM…）：下一行放寬到 60 字
                add_next2 = add_next or (nxt and not ROW.match(lines[i + 1]) and not HEADER.search(nxt) and len(nxt) < 60 and not AMT_RE.search(nxt.replace(',', '')))
                desc = (prev if add_prev else '') + ' ' + (nxt if add_next2 else '')
            else:
                # only join short continuation lines that look like wraps (台新 style)
                if bank == '台新' and add_next and len(nxt) <= 8 and (desc.endswith('第') or len(desc) >= 14):
                    desc = desc + nxt
        desc = norm(desc).strip()
        if len(re.sub(r'[\d\s,./-]', '', desc)) < 2:
            continue
        val = float(amt.replace(',', ''))
        orig = None
        if sec_cur != 'TWD':
            orig = val
            val = round(val * RATE[sec_cur])
        out.append(dict(bank=bank, stmt=stmt_date.isoformat(), date=dt.isoformat(), desc=desc,
                        amount=val, orig_amount=orig, bill_cur=sec_cur, card=card, currency=cur.group(1) if cur else 'TWD',
                        src=fn))
    return out


def parse_generic(path):
    """沒有專屬規則的銀行（遠東、富邦、渣打、第一…）：用通用解析器，格式轉成跟其他銀行一樣"""
    import generic_parse
    fn = os.path.basename(path)
    bank = fn.split('__')[0]
    sd = re.search(r'(\d{4})-(\d{2})-(\d{2})', fn)
    stmt_date = date(*map(int, sd.groups()))
    res = generic_parse.parse(open(path, encoding='utf8', errors='ignore').read(), stmt_date.isoformat(), bank)
    out = []
    for x in res['txns']:
        cur = re.search(r'\b(USD|JPY|EUR|MOP|HKD|KRW|THB|SGD|CNY|GBP|AUD|VND)\b', x['desc'])
        out.append(dict(bank=bank, stmt=stmt_date.isoformat(), date=str(x['date']),
                        desc=norm(x['desc']), amount=float(x['amount']), orig_amount=None, bill_cur='TWD', card=x['card'] or '',
                        currency=cur.group(1) if cur else 'TWD', src=fn, generic=True,
                        kind0='payment' if x['kind'] == 'payment' else None))
    return out, res


def parse_any(path):
    bank = os.path.basename(path).split('__')[0]
    if bank in AMTPOS:
        return parse_file(path)
    return parse_generic(path)[0]


def classify_kind(t):
    if t.get('kind0') == 'payment':
        return 'payment'
    d = t['desc']
    if re.search(r'(溢付|溢繳|取消信用卡年費|退還溢)', d):
        return 'adjust'
    if PAYMENT.search(d) and t['amount'] < 0:
        return 'payment'
    if re.search(r'(上期|本期|小計|合計|總計|應繳)', d):
        return 'summary'
    if t['amount'] < 0:
        return 'refund'
    return 'spend'


if __name__ == '__main__':
    allt = []; _seen = {}; _dup = []
    for f in sorted(glob.glob(TXT + '/*.txt')):
        if os.path.basename(f).startswith('中信'):   # Windows 路徑是反斜線，不能用 split('/')
            continue
        _rows = parse_any(f)
        # 同一期帳單收到兩份（銀行重寄、檔名不同、PDF 內容不完全一樣）：交易一模一樣就只算一次
        _k = (os.path.basename(f).split('__')[0], tuple(sorted((t['date'], round(t['amount']), t['desc']) for t in _rows)))
        if _rows and _k in _seen:
            print('· 同一期帳單有兩份，只算一次：', os.path.basename(f), '＝', _seen[_k]); _dup.append(os.path.basename(f)); continue
        _seen[_k] = os.path.basename(f)
        allt += _rows
    json.dump(_dup, open('dup_stmts.json', 'w', encoding='utf8'), ensure_ascii=False)
    for t in allt:
        t['kind'] = classify_kind(t)
    json.dump(allt, open('txns_raw.json', 'w'), ensure_ascii=False, indent=0)
    from collections import Counter
    print(len(allt), Counter((t['bank'], t['kind']) for t in allt))
