# 從帳單文字自動辨識「哪張卡」：卡名、正卡／附卡（分享版沒有卡片總表，就靠這個）
#   台新：卓富無限卡 (卡號末四碼:----)       玉山：卡號：5242-XXXX-XXXX-----（Unicard－正卡）
#   聯邦：微風悠遊鈦金卡 －正卡 ----          星展：以下為星展ECO永續卡 正卡（卡號末4碼 ----）
#   國泰、永豐：年費那一列（CUBE 卡年費優惠 … ----／0001 御璽卡年費…）
#   中信帳單是圖片、遠東／富邦帳單沒有逐卡標示 → 顯示「銀行卡 ·末四碼」＋最常刷的店，可在 Excel「卡片清單」改名
import re, os, glob

_N = r'(?P<name>[^\s()（）:：，。]{1,30}?(?: ?[^\s()（）:：，。]{0,20}?)?卡)'
PATS = [
    (r'以下為(?P<name>.{2,30}?)\s*(?P<role>正卡|附卡)\s*[（(]卡號末[四4]碼\s*(?P<l4>\d{4})[）)]', 3),
    (_N + r'\s*[（(]\s*(?:卡號)?末[四4]碼\s*[:：]?\s*(?P<l4>\d{4})\s*[)）]', 3),
    (r'卡號[:：]\s*\d{4}-[X\*\d]{4}-[X\*\d]{4}-(?P<l4>\d{4})\s*[（(](?P<name>[^－\-）)]+?)[－\-](?P<role>正卡|附卡)', 3),
    (r'^\s*' + _N + r'\s+[－\-]\s*(?P<role>正卡|附卡)\s+(?P<l4>\d{4})\s*$', 3),
    # 其他銀行常見寫法（第一、凱基、華南…）：卡名旁邊有遮蔽的卡號 1234-XXXX-XXXX-5678
    (_N + r'\s*(?:[（(]?(?P<role>正卡|附卡)[)）]?)?\s*(?:卡號)?[:：]?\s*\d{4}[-\s]?[X\*x＊]{4}[-\s]?[X\*x＊]{4}[-\s]?(?P<l4>\d{4})', 2),
    (r'(?:卡號)?[:：]?\s*\d{4}[-\s]?[X\*x＊]{4}[-\s]?[X\*x＊]{4}[-\s]?(?P<l4>\d{4})\s*[（(]?\s*' + _N + r'(?:\s*[－\-]?\s*(?P<role>正卡|附卡))?', 2),
    (r'\d{2}/\d{2}\s+\d{2}/\d{2}\s+(?:(?P<l4a>\d{4})\s+)?' + _N + r'年費\S*\s.*?(?:\s(?P<l4>\d{4}))?\s*$', 1),   # 年費列只知道卡等級
]
_STRIP = r'^(您的|感謝您對|台新|永豐|玉山|聯邦|中信|中國信託|星展|國泰世華|國泰|遠東|遠銀|富邦|台北富邦|第一|凱基|華南|兆豐|合庫|彰銀|上海|新光|元大|樂天|王道|滙豐|匯豐|渣打|臺銀|台銀|土銀|安泰|陽信|華泰|三信)(銀行)?'
_BAD = r'消費|小計|應繳|本期|信用卡$|^卡$|金融卡|簽帳'


def scan(txt_dir):
    """回傳 {(銀行, 末四碼): (卡名, 正卡/附卡/'', 可信度)}；同一張卡取可信度高、日期新的"""
    out = {}
    for f in sorted(glob.glob(os.path.join(txt_dir, '*.txt'))):
        b = os.path.basename(f).split('__')[0]
        seen = set(); first = {}   # 同一份帳單同名的卡：第一張是正卡，後面的是附卡（台新卓富這種）
        try:
            lines = open(f, encoding='utf8', errors='ignore').read().splitlines()
        except Exception:
            continue
        for line in lines:
            for p, conf in PATS:
                m = re.search(p, line)
                if not m:
                    continue
                g = m.groupdict(); l4 = g.get('l4') or g.get('l4a')
                if not l4 or (b, l4) in seen:
                    break
                nm = g['name'].strip()
                for _ in range(2): nm = re.sub(_STRIP, '', nm).strip('－-（( ')
                if len(nm) < 2 or re.search(_BAD, nm):
                    break
                role = g.get('role') or ''
                if not role and conf == 3:
                    role = '正卡' if first.setdefault(nm, l4) == l4 else '附卡'
                old = out.get((b, l4))
                if not old or conf >= old[2]:
                    out[(b, l4)] = (nm, role or (old[1] if old else ''), conf)
                seen.add((b, l4))
                break
    return out
