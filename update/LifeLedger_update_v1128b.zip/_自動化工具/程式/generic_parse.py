# 通用信用卡帳單解析器：給「沒有專屬解析規則」的銀行用（渣打、第一、華南、富邦…）。
# 適用文字型 PDF（pdftotext -layout 轉出的文字）；每份帳單都會拿帳單上印的「本期新增」總額核對，
# 核對不過就標成 needs_review，不會默默算錯。
import re, unicodedata

BANK_NAMES = [  # (帳單裡可能出現的字, 簡稱)；排越前面越優先
    ('渣打', '渣打'), ('Standard Chartered', '渣打'), ('第一銀行', '第一'), ('第一商業銀行', '第一'), ('華南', '華南'),
    ('彰化', '彰銀'), ('兆豐', '兆豐'), ('合作金庫', '合庫'), ('土地銀行', '土銀'), ('臺灣銀行', '臺銀'), ('台灣銀行', '臺銀'),
    ('上海商業儲蓄', '上海'), ('上海商銀', '上海'), ('富邦', '富邦'), ('新光銀行', '新光'), ('臺灣新光', '新光'), ('凱基', '凱基'),
    ('元大', '元大'), ('遠東', '遠東'), ('王道', '王道'), ('樂天', '樂天'), ('華泰', '華泰'), ('陽信', '陽信'), ('安泰', '安泰'),
    ('臺灣企銀', '企銀'), ('台灣中小企業', '企銀'), ('高雄銀行', '高銀'), ('美國運通', '美國運通'), ('American Express', '美國運通'),
    ('匯豐', '匯豐'), ('HSBC', '匯豐'), ('三信商業', '三信'), ('將來銀行', '將來'), ('連線商業銀行', 'LINE Bank'),
    ('國泰世華', '國泰'), ('台新', '台新'), ('玉山', '玉山'), ('永豐', '永豐'), ('聯邦', '聯邦'), ('中國信託', '中信'), ('星展', '星展'),
]
PAYMENT = re.compile(r'(餘額返回|繳款|自動扣繳|自動轉帳|轉帳繳|感謝您|謝謝|已收到您|溢繳|溢付|退還溢|帳款沖銷|上期帳單|上期應繳|上期金額|前期)')
NOT_TX = re.compile(r'(最低應繳|本期應繳|應繳總額|繳款截止|信用額度|循環信用利率|帳單結帳日|結帳日|可用額度|小計|合計|總計|^\s*總額)')
CUR = r'(?:TWD|NTD|NT\$|USD|JPY|EUR|GBP|HKD|CNY|RMB|KRW|THB|SGD|AUD|CAD|MYR|VND|PHP|CHF|NZD|IDR|MOP|TW|JP|US|KR|TH|SG|HK|GB|CN|元)'
DATE = r'(\d{2,4}/\d{1,2}/\d{1,2}|\d{1,2}/\d{1,2})'
TX = re.compile(r'^\s*[+＋]?\s*' + DATE + r'(?:\s+' + DATE + r')?\s+(.*\S)?\s*$')
AMT_TOK = re.compile(r'^-?[\d,]*\d(?:\.\d{1,2})?-?$')
CARD = re.compile(r'(?:末\s*四\s*碼|末\s*4\s*碼|卡\s*號|Card\s*No\.?)[^\d\n]{0,12}(?:[\dXx*＊]{4}[-\s]?){0,3}?(\d{4})(?!\d)')
TOTAL_KEYS = ['本期新增款項', '本期新增消費', '新增款項', '本期金額合計', '本期合計', '本期消費金額', '本期消費總額', '正卡本期消費', '本期消費', '本期新增']
_NUM = r'(-?\d{1,3}(?:,\d{3})+|-?\d+)(?:\.\d{1,2})?(?![\d,.%])'


def norm(s):
    return unicodedata.normalize('NFKC', s.replace('\r', ''))   # Windows 的 pdftotext 會多出 \r，會讓表格對不上


def detect_bank(text):
    """出現次數最多的銀行名（帳單裡常有其他銀行的廣告或轉帳說明，所以不能只看第一個）"""
    t = norm(text)
    skip = re.compile(PAYMENT.pattern[:-1] + r'|帳號|扣款|轉帳|自動|銀行\s*/\s*[\dXx]|代償)')   # 繳款銀行、扣款帳號不算發卡行
    keep = [l for l in t.splitlines() if not skip.search(l)]
    body = '\n'.join(keep); head = body[:800]
    cnt = {}
    for kw, short in BANK_NAMES:
        n = body.count(kw) + 5 * head.count(kw)   # 帳單開頭的銀行名權重最高
        if n:
            cnt[short] = cnt.get(short, 0) + n
    return max(cnt, key=cnt.get) if cnt else None


def table_value(text, key):
    """表頭一行、數值在下一行、欄位依序對應（富邦「前期應繳總額 - 繳(退)金額 - … + 本期新增 = 本期應繳總額」）。
    中文字在版面上佔兩格，所以不用欄位位置，改用「第幾個」對應。"""
    L = norm(text).splitlines()
    for i, l in enumerate(L):
        if key not in l or re.search(r'[，。,]', l):
            continue
        nxt = [x for x in L[i + 1:i + 8] if x.strip()][:1]   # 中間可能隔好幾行空白（富邦）
        if not nxt:
            continue
        vals = nxt[0].split()
        for pat in (r'\s+[-+=]\s+|\s{2,}', r'[\s+=]+|\s-\s'):
            heads = [h for h in re.split(pat, l.strip()) if h and h not in '-+=']
            idx = next((k for k, h in enumerate(heads) if key in h), None)
            if idx is not None and len(heads) >= 3 and len(heads) == len(vals):
                return vals[idx]
    return None


def stated_total(text, payments=0.0):
    """帳單上的「本期新增」金額。找不到明寫的，就用「本期應繳 − 上期 − 已繳」反推。"""
    lines = [l for l in text.splitlines() if not re.search(r'積點|點數|紅利|哩程|里程|回饋點|點\s*[，,。]', l)]
    t = '\n'.join(lines)
    tv = table_value(t, '本期新增')
    if tv and re.fullmatch(r'-?\d[\d,]*(\.\d+)?', tv):   # 至少要有一個數字（欄位只有「,」或「-」時改用下面的方法）
        return float(tv.replace(',', ''))
    sub = re.findall(r'新增消費小計[^\d\n-]{0,80}?' + _NUM, t)   # 每張卡各一個小計（星展）
    if sub:
        return sum(float(x.replace(',', '')) for x in sub)
    L = t.splitlines()
    for k in TOTAL_KEYS:
        ms = re.findall(k + r'[^\d\n-]{0,80}?(?:TWD|NT\$|新臺幣|新台幣)?\s*' + _NUM, t)
        if ms:
            return float(ms[0].replace(',', ''))
        # 表格式：關鍵字在表頭，金額在下一列同一欄（永豐新版「幣別｜上期｜已繳｜本期新增款項…」）
        for i, l in enumerate(L):
            j = l.find(k)
            if j < 0 or re.search(r'\d', l[j:j + len(k) + 6]):
                continue
            cx = j + len(k) / 2
            for r in L[i + 1:i + 4]:
                if re.match(r'\s*(日圓|美元|歐元|JPY|USD|EUR)', r):
                    continue
                toks = [(m.start(), m.end(), m.group(0)) for m in re.finditer(r'-?\d{1,3}(?:,\d{3})+|-?\d+', r)]
                if toks:
                    best = min(toks, key=lambda x: abs((x[0] + x[1]) / 2 - cx))
                    return float(best[2].replace(',', ''))
    def first(keys):
        for k in keys:
            m = re.search(r'(?<![上前])' + k + r'[^\d\n-]{0,80}?' + _NUM, t)
            if m:
                return float(m.group(1).replace(',', ''))
        return None
    due = first(['本期應繳總金額', '本期應\\S總金額', '本期應繳總額', '本期應繳金額', '應繳總額', '總計'])
    if due is None:
        return None
    owed = first(['上期結欠款項', '上期結欠', '上期未繳金額', '前期未繳'])   # 上期扣掉已繳後還欠的
    if owed is not None:
        return round(due - owed, 2)
    prev = first(['上期金額', '上期帳單總額', '上期應繳總金額', '上期應繳總額', '上期應繳金額', '前期餘額']) or 0.0
    paid_lines = re.findall(r'^(?!\s*[+]?\s*\d{1,4}/\d).*(?:付款金額|已繳金額|本期繳款|已收到)[^\d\n-]{0,80}?' + _NUM, t, re.M)
    paid = -sum(abs(float(x.replace(',', ''))) for x in paid_lines) if paid_lines else payments
    return round(due - prev - paid, 2)


def to_date(d, stmt_date):
    p = d.split('/')
    if len(p) == 3:
        y = int(p[0]); y = y + 1911 if y < 1000 else y
        m, dd = int(p[1]), int(p[2])
    else:
        m, dd = int(p[0]), int(p[1]); y = int(stmt_date[:4])
        if m > int(stmt_date[5:7]) + 1:   # 12 月的消費出現在 1 月帳單
            y -= 1
    if not (1 <= m <= 12 and 1 <= dd <= 31):
        return None
    return f'{y:04d}-{m:02d}-{dd:02d}'


def _amount_and_card(rest):
    """從一列的尾端取出新臺幣金額（最後一個數字欄），以及行尾的卡號末四碼（如果有）"""
    toks = rest.split()
    card = None
    # 去掉尾端的幣別／國家代碼
    while toks and re.fullmatch(CUR, toks[-1], re.I):
        toks.pop()
    # 國泰式：「金額  卡號末四碼」→ 最後一個是不帶逗號的 4 位數，前一個也是數字
    if len(toks) >= 2 and re.fullmatch(r'\d{4}', toks[-1]) and AMT_TOK.match(toks[-2]):
        card = toks.pop()
        while toks and re.fullmatch(CUR, toks[-1], re.I):
            toks.pop()
    if not toks or not AMT_TOK.match(toks[-1]):
        return None, card, rest
    a = toks[-1]
    neg = a.startswith('-') or a.endswith('-')
    val = float(a.strip('-').replace(',', ''))
    desc_toks = toks[:-1]
    # 描述尾端若殘留外幣金額與幣別（例如「JPY 3,000」），一起去掉
    while desc_toks and (AMT_TOK.match(desc_toks[-1]) or re.fullmatch(CUR, desc_toks[-1], re.I)):
        desc_toks.pop()
    return (-val if neg else val), card, ' '.join(desc_toks)


AMT_FIND = re.compile(r'(?<!\S)(-?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,3})?-?)(?=\s|$)')


def _amounts(line, start):
    """一列裡所有「獨立的」金額字串與其結束欄位（不含日期、期數這類）"""
    out = []
    for m in AMT_FIND.finditer(line, start):
        tok = m.group(1)
        if re.fullmatch(r'\d{4}', tok) or re.fullmatch(r'\d{1,2}/\d{1,2}', tok):
            continue   # 4 位數不帶逗號：卡號末四碼或日期（0120）
        out.append((m.end(), m.start(), tok))
    return out


def parse(text, stmt_date, bank=None):
    """回傳 dict(bank, txns=[...], stated=帳單本期新增或 None, parsed=交易合計, ok=是否對上)"""
    text = norm(text)
    bank = bank or detect_bank(text) or '其他銀行'
    raw = text.splitlines(); lines = []
    k = 0
    while k < len(raw):   # 日期單獨一行、說明和金額在下一行（台新部分帳單）→ 疊成一行，保留欄位位置
        ln = raw[k]
        mt = TX.match(ln)
        if mt and (not mt.group(3) or re.fullmatch(DATE, mt.group(3).strip())) and k + 1 < len(raw) and raw[k + 1].strip() and not TX.match(raw[k + 1]):
            nx = raw[k + 1]; ind = len(nx) - len(nx.lstrip())
            head = ln.rstrip()
            lines.append(head + ' ' + nx.lstrip() if len(head) >= ind else head.ljust(ind) + nx.lstrip())
            lines.append('')   # 佔位，維持行號
            k += 2; continue
        lines.append(ln); k += 1
    # 第 1 輪：找出交易列，統計「只有一個金額」的列，金額結束在哪一欄 → 新臺幣金額欄
    cands = []
    for i, line in enumerate(lines):
        if re.search(r'[\x00-\x08\x0b-\x1f\x7f-\x9f]', line):
            continue
        m = TX.match(line)
        if (m and m.group(3) and not NOT_TX.search(m.group(3)) and not re.search(r'\d\s*/\s*[\d,]{3,}', m.group(3))
                and not re.search(r'(?<!\S)\d+\.\d+%(?!\S)', m.group(3))):   # 有獨立利率欄的是分期資訊表，不是交易
            cands.append((i, m, _amounts(line, m.start(3))))
    ends = [a[0][0] for _, _, a in cands if len(a) == 1]
    col = max(set(ends), key=ends.count) if ends else None
    card = None; out = []; txi = {i for i, _, _ in cands}
    for i, line in enumerate(lines):
        if i not in txi:
            if re.search(r'卡\s*號|末\s*四\s*碼|末\s*4\s*碼|正卡|附卡|Card\s*No', line):
                d4 = re.findall(r'(?<![\d/])(\d{4})(?![\d/,])', line)
                if d4:
                    card = d4[-1]   # 「XXXX-XXXX-XXXX-1234」取最後一組
            continue
        _, m, ams = next(c for c in cands if c[0] == i)
        d1, d2 = m.group(1), m.group(2)
        if not ams and i + 1 < len(lines) and AMT_TOK.match(lines[i + 1].strip()):   # 星展式：金額換到下一行
            nxt = lines[i + 1]
            ams = [(len(nxt.rstrip()), len(nxt) - len(nxt.lstrip()), nxt.strip())]
            pick = ams[0]; desc_end = len(line)
        elif not ams:
            continue
        else:
            if len(ams) >= 2 and re.search(r'分\s*\d+\s*期|第\s*\d+\s*期|\d+\s*/\s*\d+\s*期', line):
                pick = min(ams, key=lambda a: abs(float(a[2].strip('-').replace(',', ''))))   # 分期：總額與本期金額取本期
            else:
                pick = min(ams, key=lambda a: abs(a[0] - col)) if col is not None and len(ams) > 1 else (ams[0] if len(ams) == 1 else ams[-1])
            desc_end = min(a[1] for a in ams)
        tok = pick[2]
        val = float(tok.strip('-').replace(',', ''))
        amt = -val if (tok.startswith('-') or tok.endswith('-')) else val
        desc = line[m.start(3):desc_end] if m.start(3) < desc_end else ''
        c2 = None
        cm = re.match(r'\s*(\d{4})\s+(.*)$', desc)                 # 永豐式：說明前面是卡號末四碼
        if cm:
            c2, desc = cm.group(1), cm.group(2)
        tail = line[pick[0]:].split()
        if tail and not c2 and re.fullmatch(r'\d{4}', tail[0]):      # 國泰式：金額後面一欄是卡號末四碼
            mm, dd = int(tail[0][:2]), int(tail[0][2:])
            if not (1 <= mm <= 12 and 1 <= dd <= 31):                 # 「0120」這種是外幣折算日，不是卡號
                c2 = tail[0]
        desc = re.sub(r'\s+(' + CUR + r')\s*$', '', desc.strip(), flags=re.I).strip()
        desc = re.sub(r'(\s+\d{2,4}/\d{1,2}/\d{1,2})+\s*$', '', desc).strip()   # 入帳日期欄（富邦）
        desc = re.sub(r'\s{2,}', ' ', desc)
        date = to_date(d1, stmt_date)
        if not date:
            continue
        if not re.search(r'[A-Za-z\u4e00-\u9fff]', desc):   # 說明換行到上下列（台新式）
            prev = lines[i - 1].strip() if i else ''
            nxt = lines[i + 1].strip() if i + 1 < len(lines) else ''
            parts = [x for x in (prev, nxt) if x and not TX.match(x) and not CARD.search(x) and not AMT_TOK.match(x)
                     and not re.search(r'[\^~`|\\{}<>]', x) and re.search(r'[\u4e00-\u9fff]{2}|[A-Za-z]{4}', x)]
            desc = (' '.join(parts) + ' ' + desc).strip()
            if not re.search(r'[A-Za-z\u4e00-\u9fff]', desc):
                continue
        kind = 'payment' if PAYMENT.search(desc) else ('refund' if amt < 0 else 'spend')
        out.append(dict(date=date, post=to_date(d2, stmt_date) if d2 else date, desc=desc, amount=round(amt, 2),
                        card=c2 or card, kind=kind, bank=bank))
    stated = stated_total(text, sum(t['amount'] for t in out if t['kind'] == 'payment'))
    parsed = round(sum(t['amount'] for t in out if t['kind'] in ('spend', 'refund')), 2)
    ok = stated is not None and abs(stated - parsed) <= 1
    return dict(bank=bank, txns=out, stated=stated, parsed=parsed, ok=ok, amount_col=col)



# ---------- OCR 帳單：日期、金額改用 PDF 文字層（渣打、凱基） ----------
# 這些帳單的中文是圖片或特殊字型，只能靠 OCR，但 OCR 常把金額認錯（99→39、1,483→1.483、690→ge、10/07→10007）。
# 其實 PDF 文字層裡的數字是對的：凱基是一般字元；渣打、部分凱基用自訂字型，0–9 存成 ð–ù、逗號 k、小數點 K、斜線 a、負號 `。
# 做法：交易列的日期、金額用文字層的，說明（中文）沿用 OCR；每張卡的「本期消費金額合計」也用文字層的。
LAYER_MARK = '# 日期、金額已用 PDF 文字層校正（v1）'
_SUBST = str.maketrans({**{chr(0xF0 + i): str(i) for i in range(10)}, 'k': ',', 'K': '.', 'a': '/', '`': '-', '[': '$'})
_LROW = re.compile(r'^\s*(\d{1,2}/\d{1,2})\s+(\d{1,2}/\d{1,2})\s+(?:.*?\s)?(-?\d{1,3}(?:,\d{3})*|-?\d+)(?:\.\d\d)?\s*$')
_LAMT = re.compile(r'^\s*(-?\d{1,3}(?:,\d{3})*|-?\d+)(?:\.\d\d)?\s*$')
_OROW = re.compile(r'^\s*(\d{1,2}/\d{1,2})\s+(\S+)\s+(.*)$')
_OSUB = re.compile(r'^\s*\S*合計\s+\S+\s*$')


def decode_layer(raw):
    """PDF 文字層：渣打的自訂字型數字還原成一般數字（看得出是這種字型才換，避免動到一般帳單）"""
    if sum(raw.count(chr(0xF0 + i)) for i in range(10)) >= 20:
        return raw.translate(_SUBST)
    return raw


def layer_rows(layer):
    """文字層的交易列 [(消費日, 入帳日, 金額字串)]，和每段交易之後的第一個單獨金額（該卡的本期消費合計）"""
    rows, subs, after, prev, bprev = [], [], False, None, None
    for l in layer.split('\n'):
        m = _LROW.match(l)
        if m:
            # 每張卡的交易列裡、金額剛好是「上期金額」（交易列上面那個單獨金額）的負數 → 繳款（OCR 常把「帳戶直接轉帳已收到」認成亂碼）
            if not after:
                bprev = prev   # 這張卡的上期金額
            pay = bprev is not None and m.group(3) == '-' + bprev
            rows.append((m.group(1), m.group(2), m.group(3), pay)); after = True; prev = None
            continue
        if not l.strip():
            continue
        ma = _LAMT.match(l)
        if after and ma:
            subs.append(ma.group(1))
        prev = ma.group(1) if ma and not after else None
        after = False
    return rows, subs


def _desc_of(rest):
    rest = re.sub(r'^[\s:：;“”"\'|.]+', '', rest)
    rest = re.sub(r'(\s+(?:TWD|NT\$?|[:：;|.,上]|-?[\d,.]+[:：;.]?|[A-Za-z]{1,2}))+\s*$', '', rest)   # 行尾的金額、幣別、雜訊
    rest = re.sub(r'(?<=\s)[\d,.]+(?=\s|$)', '', rest)   # 說明裡單獨的數字（OCR 雜訊，會被當成金額）
    rest = re.sub(r'\s{2,}', ' ', rest)
    rest = re.sub(r'(\s+\S)+\s*$', '', rest)   # 行尾一串單一字元（OCR 把表格線認成「- - ;」）
    return rest.strip(' :：;|“”"') or '（說明無法辨識）'


def merge_pdf_layer(ocr_text, layer_raw):
    """OCR 文字 + PDF 文字層 → 交易列的日期、金額換成文字層的。文字層沒有交易列（不適用）就回傳 None"""
    if ocr_text.startswith(LAYER_MARK):
        return None
    dec = decode_layer(layer_raw)
    rows, subs = layer_rows(dec)
    if not rows:
        return None
    if dec is layer_raw or '本期消費金額合計' not in ocr_text.replace(' ', '') and not re.search(r'消費金額合計|金[額祝]合計', ocr_text):
        subs = []   # 只有渣打那種「每張卡一個本期消費合計」的帳單才換合計
    L = ocr_text.split('\n')
    used = set(); start = 0; extra = []
    PAYD = '帳戶直接轉帳已收到,謝謝您'
    for d1, d2, amt, pay in rows:
        k = next((i for i in range(start, len(L)) if i not in used and _OROW.match(L[i]) and _OROW.match(L[i]).group(1) == d1), None)
        if k is None:
            extra.append(f'{d1}   {d2}   {PAYD if pay else "（說明無法辨識）"}   {amt}'); continue
        desc = _desc_of(_OROW.match(L[k]).group(3))
        if pay and not re.search(r'已收到|謝謝|繳款|扣繳|轉帳', desc):
            desc = PAYD
        L[k] = f'{d1}   {d2}   {desc}   {amt}'
        used.add(k); start = k + 1
    if subs:   # OCR 的合計列（常認錯）改成註記，正確的合計放到最後
        L = [('# OCR：' + l.strip()) if _OSUB.match(l) and re.search(r'消|費|金|額', l) else l for l in L]
    tail = (['', '[PDF 文字層校正]'] + extra + [f'您本期消費金額合計   {s}' for s in subs]) if (extra or subs) else []
    return LAYER_MARK + '\n' + '\n'.join(L + tail)

if __name__ == '__main__':
    import sys
    t = open(sys.argv[1], encoding='utf8').read()
    r = parse(t, sys.argv[2] if len(sys.argv) > 2 else '2026-10-01')
    print(r['bank'], 'stated', r['stated'], 'parsed', r['parsed'], 'OK' if r['ok'] else '需檢查', len(r['txns']), '筆')
    for x in r['txns'][:200]:
        print(' ', x['date'], x['card'], x['kind'], x['amount'], x['desc'][:40])
