# 回饋核對：(1) 依各卡規則估算每期應得回饋，和帳單上實際入帳比對
#          (2) 列出「刷了但沒拿到回饋」的消費，並建議改用哪張卡
# 規則依 2026 下半年權益；權益改版時改下面的 RULES / MISS 即可。→ rewards_check.json
import json, re, glob, os, unicodedata, collections
os.chdir(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open('config.json'))
from banks import web_safe as _bkws
R = _bkws(json.load(open('rows.json')))
# rows.json 已去掉永豐帳單的通路前綴（MA-、N-…），從原始解析結果補回來判斷
PFX = {}
for t in json.load(open('txns_raw.json')):
    if t['bank'] == '永豐':
        mm = re.match(r'(MA|N|MF|M|A)-\s*', unicodedata.normalize('NFKC', t['desc']))
        if mm:
            PFX[(t['stmt'], t['date'], round(t['amount']))] = mm.group(1) + '-'
MONTHS_BACK = 6

def nk(s):
    return unicodedata.normalize('NFKC', s or '')

def ago(ym, n):
    y, m = int(ym[:4]), int(ym[5:7]) - n
    while m <= 0:
        y -= 1; m += 12
    return f'{y}-{m:02d}'

CUT = ago(CFG['last_month'], MONTHS_BACK - 1)          # 近 6 個月帳單
TAISHIN_WEALTH = set()       # 台新卓富無限卡（正、附卡）
ESUN_WORLD = set()                           # 玉山世界卡
REB_ROW = re.compile(r'回饋|刷卡金|積點兌換|點數折抵|現金積點')
INS = re.compile(r'保險|人壽|產險|產物')
UTIL = re.compile(r'電信費|有線電視|長德|水費|自來水|電費|台電|瓦斯|代繳')
GOV = re.compile(r'罰鍰|規費|監理|稅|地方法院|戶政')
FAST = re.compile(r'麥當勞|MCDONALD|摩斯|MOS BURGER|肯德基|KFC|漢堡王|BURGER KING', re.I)

# 建議卡片與回饋率（用來估「可多拿多少」）
TW1 = ('台新卓富無限卡', 0.01)
DAWHO5 = ('永豐大戶卡（每期 2.5 萬內）', 0.05)
UBOT_INS = ('聯邦 M 卡', 0.012)
DBS_FAST = ('星展傳說對決（速食 10%）', 0.10)


def miss_reason(r):
    """回傳 (原因, 建議卡, 建議回饋率, 原卡回饋率) 或 None（表示有正常回饋）"""
    b, c, d = r['bank'], r['card'], nk(r['desc'] or r['merchant'])
    if b == '永豐' and 'stmt' in r and not re.match(r'(MA|N|MF|M|A)-', d):
        d = PFX.get((r['stmt'], r['date'], round(r['amount'])), '') + d
    if '自動加值' in d:
        return None                                   # 自動加值另有回饋（大戶 5%），不算漏
    if r.get('installment'):
        if INS.search(d) and b == '聯邦':
            return ('保費分期 0 利率：聯邦 M 卡分期就沒有 1.2% 回饋（二選一）', '不需要分期的話改一次付清，拿 1.2%', UBOT_INS[1], 0)
        return ('分期付款：各銀行都不給回饋', '想拿回饋就一次付清（估算以國內 1% 計）', TW1[1], 0)
    if INS.search(d) or r['category'] == '保險':
        if b == '聯邦' and c == '----':
            return None
        if b == '台新' and c in TAISHIN_WEALTH:
            return ('保費：卓富目前沒給回饋（官網列保費 1.5%，可能要登錄）', '改刷聯邦 M 卡（保費 1.2%）或請台新確認登錄', UBOT_INS[1], 0)
        return ('保費：這張卡不給回饋', '改刷聯邦 M 卡（保費 1.2%）', UBOT_INS[1], 0)
    if GOV.search(d):
        return ('罰款／規費／稅：多數卡都不回饋', '換卡也差不多，可忽略', 0, 0)
    if b == '永豐' and c == '3000':
        if UTIL.search(d):
            return ('大戶不回饋代繳（電信、有線電視、水電）', '代繳改綁台新卓富（國內 1%）；LINE Pay「繳費」通常不算一般消費，不建議', TW1[1], 0)
        if d.startswith('N-') or re.search(r'醫院|診所|醫療', d):
            return ('大戶不回饋醫療院所／公家機關（帳單標 N-）', '醫院收 LINE Pay 就用 LINE Pay 綁大戶卡付（帳單顯示「連支＊」可拿 5%，待下期驗證）；不收就刷台新卓富（1%）', DAWHO5[1], 0)
        if d.startswith('MA-'):
            if FAST.search(d):
                return ('大戶不回饋 MA- 小額支付平台', '星展傳說對決直接刷（當月加碼未滿 10%）；滿了就用 LINE Pay 綁大戶卡（5%）', DBS_FAST[1], 0)
            return ('大戶不回饋 MA- 小額支付平台', '改用 LINE Pay 綁大戶卡付（帳單顯示「連支＊」就有 5%）', DAWHO5[1], 0)
        if '全聯' in d:
            return ('大戶不回饋全聯（含 PX Pay、全支付）', '改用大戶卡「嗶悠遊卡」付，靠自動加值拿 5%', DAWHO5[1], 0)
    if b == '玉山' and c in ESUN_WORLD and not r.get('foreign'):
        return ('玉山世界卡國內消費只有約 0.2%', '改刷台新卓富（1%）或大戶卡（每期 2.5 萬內 5%）；若是為了世界卡的旅平險等權益刷機票可保留', TW1[1], 0.002)
    if b == '星展' and c == '----' and re.search(r'停車|自動加值|悠遊|一卡通|學費', d):
        return ('星展不回饋停車／加值／學費', '停車改刷大戶卡（5%）', DAWHO5[1], 0)
    return None


# ---------------- (2) 沒拿到回饋的消費 ----------------
missed = []
for r in R:
    if r['kind'] != 'spend' or r['amount'] <= 0:
        continue
    if r['category'] in ('回饋折抵', '年費手續費') or REB_ROW.search(nk(r['desc'])):
        continue
    m = miss_reason(r)
    if not m:
        continue
    reason, sug, rate_new, rate_old = m
    missed.append(dict(act=rate_new > rate_old and not reason.startswith(('分期', '保費分期', '罰款')), date=r['date'], stmt=r['stmt'], bank=r['bank'], card=r['card'], cardname=r['cardname'],
                       merchant=r['merchant'], amount=round(r['amount']), reason=reason, suggest=sug,
                       gain=round(r['amount'] * max(rate_new - rate_old, 0))))
missed.sort(key=lambda x: (x['date'], x['bank']), reverse=True)

# ---------------- (1) 每期回饋核對 ----------------
checks = []

def add(bank, card, stmt, base, exp, act, note):
    diff = act - exp
    tol = max(30, exp * 0.05)
    st = '✅ 正常' if diff >= -tol else ('⚠️ 少給' if exp > 0 else '—')
    checks.append(dict(bank=bank, card=card, stmt=stmt, base=round(base), expected=round(exp), actual=round(act),
                       diff=round(diff), status=st, note=note))

# 永豐大戶：回饋列在「下一期」帳單（大戶消費回饋入帳戶－國內/國外/任務/通路）
def sinopac(f):
    tx, reb, tier = [], collections.Counter(), ''
    for l in open(f, encoding='utf8'):
        m = re.match(r'\s*(\d\d/\d\d)\s+(\d\d/\d\d)\s+(\d{4})\s+(.*?)\s+(-?[\d,]+)\s*$', l)
        if not m:
            continue
        card, desc, a = m.group(3), nk(m.group(4)), int(m.group(5).replace(',', ''))
        g = re.search(r'大戶.*?回饋(入帳戶|調整)\s*[_－＿-]?\s*(任務|國內|國外|通路)\s*(\d+)?', desc)
        if g:
            v = int(g.group(3)) if g.group(3) else a
            reb[g.group(2)] += -a if g.group(1) == '調整' else v
            tier = 'Plus' if 'PL' in desc else (tier or '大戶')
            continue
        if card == '3000':
            tx.append((desc, a))
    return tx, reb, tier

sf = sorted(glob.glob('txt/永豐__*信用卡帳單.txt'))
for i in range(len(sf) - 1):
    stmt = os.path.basename(sf[i])[4:14]
    if stmt[:7] < CUT:
        continue
    tx, _, _ = sinopac(sf[i])
    _, reb, tier = sinopac(sf[i + 1])
    auto = sum(a for d, a in tx if '自動加值' in d)
    fake = {'bank': '永豐', 'card': '3000', 'category': '', 'installment': False, 'foreign': False}
    elig = sum(a for d, a in tx if '自動加值' not in d and not re.search(r'國外交易服務費|永豐自扣|已入帳', d)
               and not miss_reason(dict(fake, desc=d, merchant=d)))
    rate, cap, arate, acap = (0.04, 1000, 0.05, 500) if tier == 'Plus' else (0.025, 400, 0.03, 100)
    exp = elig * 0.01 + min(elig * rate, cap) + min(auto * arate, acap)
    act = sum(reb.values())
    add('永豐', '大戶 DAWHO ·3000', stmt, elig, exp, act,
        f"{tier or '—'}｜國內 {reb['國內']}・國外 {reb['國外']}・任務 {reb['任務']}・通路 {reb['通路']}（下期入帳）")
# 最新一期（回饋尚未出現在帳單上）：只給預估
if sf:
    stmt = os.path.basename(sf[-1])[4:14]
    tx, _, tier0 = sinopac(sf[-1])
    tier0 = sinopac(sf[-1])[2] or 'Plus'
    auto = sum(a for d, a in tx if '自動加值' in d)
    fake = {'bank': '永豐', 'card': '3000', 'category': '', 'installment': False, 'foreign': False}
    elig = sum(a for d, a in tx if '自動加值' not in d and not re.search(r'國外交易服務費|永豐自扣|已入帳', d)
               and not miss_reason(dict(fake, desc=d, merchant=d)))
    rate, cap, arate, acap = (0.04, 1000, 0.05, 500) if tier0 == 'Plus' else (0.025, 400, 0.03, 100)
    exp = elig * 0.01 + min(elig * rate, cap) + min(auto * arate, acap)
    checks.append(dict(bank='永豐', card='大戶 DAWHO ·3000', stmt=stmt, base=round(elig), expected=round(exp), actual=None,
                       diff=None, status='⏳ 待入帳', note='下個月第一個工作日存入 DAWHO 帳戶，下期帳單才會列出'))

# 台新卓富：當期帳單「權益類國內/國外消費 n% 回饋」；國內 1%、國外 3%
by = collections.defaultdict(lambda: collections.Counter())
for r in R:
    if r['bank'] != '台新' or r['card'] not in TAISHIN_WEALTH and not re.search(r'權益類', r['desc'] or ''):
        continue
    if r['stmt'][:7] < CUT:
        continue
    s = by[r['stmt']]
    d = nk(r['desc'])
    if re.search(r'權益類.*回饋', d):
        s['act'] += -r['amount']; continue
    if r['kind'] not in ('spend', 'refund') or r['category'] == '年費手續費' or miss_reason(r):
        continue
    s['fx' if r.get('foreign') else 'dom'] += r['amount']
for stmt, s in sorted(by.items()):
    add('台新', '卓富無限卡（正附卡）', stmt, s['dom'] + s['fx'], s['dom'] * 0.01 + s['fx'] * 0.03, s['act'],
        f"國內 {round(s['dom']):,}×1% ＋ 國外 {round(s['fx']):,}×3%（當期折抵）")

# 聯邦 M 卡保費 1.2%：下一期帳單「聯邦M保險加碼」
ub = collections.defaultdict(lambda: collections.Counter())
stmts = sorted({r['stmt'] for r in R if r['bank'] == '聯邦'})
for r in R:
    if r['bank'] != '聯邦':
        continue
    s = ub[r['stmt']]
    if '保險加碼' in (r['desc'] or ''):
        s['act'] += -r['amount']
    elif r['card'] == '----' and r['kind'] == 'spend' and INS.search(nk(r['desc'])) and not r.get('installment'):
        s['ins'] += r['amount']
for i, st in enumerate(stmts):
    if st[:7] < CUT or not ub[st]['ins']:
        continue
    if i + 1 < len(stmts):
        add('聯邦', 'M 卡 ·----', st, ub[st]['ins'], ub[st]['ins'] * 0.012, ub[stmts[i + 1]]['act'], '保費 1.2%（下期入帳）')
    else:
        checks.append(dict(bank='聯邦', card='M 卡 ·----', stmt=st, base=round(ub[st]['ins']), expected=round(ub[st]['ins'] * 0.012),
                           actual=None, diff=None, status='⏳ 待入帳', note='保費 1.2%，下期帳單入帳'))

# 玉山 U Bear：一般 1%（網購另加 2%），當期帳單
eb = collections.defaultdict(lambda: collections.Counter())
for r in R:
    if r['bank'] != '玉山' or r['stmt'][:7] < CUT:
        continue
    d = nk(r['desc'])
    if 'UBear' in d and '回饋' in d:
        eb[r['stmt']]['act'] += -r['amount']
    elif r['card'] == '----' and r['kind'] in ('spend', 'refund') and not miss_reason(r):
        eb[r['stmt']]['base'] += r['amount']
for st, s in sorted(eb.items()):
    if s['base'] or s['act']:
        add('玉山', 'U Bear ·----', st, s['base'], s['base'] * 0.01, s['act'], '一般 1%（網購另加 2%，所以實際可能較高）')

# 星展傳說對決 ·----：帳單只有總數 ——「本期新增」＝基本 0.2%（當期），「本期調整」＝加碼，
# 依「消費日的自然月」計算，次次月 1 日入帳（含 1 日的那期帳單）。
#   2026 上半年（2025 年申辦）：國內加碼 1.0%，精選通路（含 LINE Pay）加碼 8.8%，上限 1,000 點／月
#   2026 下半年：自動扣繳加碼 0.8%，精選通路（不含 LINE Pay）加碼 9%，上限 500 點／月（約 5,556 元）
DBS_CH = re.compile(r'蝦皮|SHOPEE|淘寶|TAOBAO|UBER ?EATS|FOODPANDA|熊貓|麥當勞|MCDONALD|摩斯|肯德基|KFC|漢堡王|NETFLIX|SPOTIFY|YOUTUBE|DISNEY|APPLE\.COM|ITUNES|GOOGLE ?PLAY|STEAM|NINTENDO|PLAYSTATION|KKBOX|KKTIX|拓元', re.I)
DBS_LP = re.compile(r'^連(加|支)|LINE ?PAY', re.I)
def dbs_rule(ym):
    return (0.010, 0.088, 1000, True) if ym < '2026-07' else (0.008, 0.09, 500, False)
dm = collections.defaultdict(list)
for r in R:
    if r['bank'] != '星展' or r['card'] not in ('----', '') or r['category'] == '回饋折抵' or r['kind'] not in ('spend', 'refund'):
        continue
    if miss_reason(r):
        continue
    dm[r['date'][:7]].append(r)
# 退款和原消費互相抵銷（同商家同金額），不算進精選通路順序
for ym, xs in list(dm.items()):
    neg = [x for x in xs if x['amount'] < 0]
    keep = list(xs)
    for n in neg:
        p = next((x for x in keep if x['amount'] == -n['amount'] and re.sub(r'\s', '', nk(x['desc'])) == re.sub(r'\s', '', nk(n['desc']))), None)
        if p:
            keep.remove(p); keep.remove(n)
    dm[ym] = keep
def dbs_bonus(ym, items):
    dr, cr, cap, lp = dbs_rule(ym)
    tot = sum(x['amount'] for x in items)
    ch_items = [x for x in items if DBS_CH.search(nk(x['desc'])) or (lp and DBS_LP.search(nk(x['desc'])))]
    ch = sum(x['amount'] for x in ch_items)
    return tot, ch, tot * dr + min(ch * cr, cap), ch_items, cr, cap
adj = {}
for f in sorted(glob.glob('txt/星展__*DAILYSTMT*.txt')):
    g = re.search(r'本期新增 ([\d,]+) 。 本期調整 (-?[\d,]+)', open(f, encoding='utf8').read())
    if not g:
        continue
    sd = os.path.basename(f).split('__')[1][:10]
    y, mo, dd = int(sd[:4]), int(sd[5:7]), int(sd[8:10])
    k = mo - (2 if dd >= 20 else 3)
    while k <= 0:
        k += 12; y -= 1
    adj[f'{y}-{k:02d}'] = (sd, int(g.group(2).replace(',', '')))
for ym in sorted(dm):
    tot, ch, exp, ch_items, cr, cap = dbs_bonus(ym, dm[ym])
    note = f"{ym.replace('-', '/')} 消費 {round(tot):,}，精選通路 {round(ch):,}（加碼上限 {cap} 點）"
    if ym < CUT:
        pass
    elif ym in adj:
        add('星展', '傳說對決 ·----（加碼）', adj[ym][0], tot, exp, adj[ym][1], note + '；帳單「本期調整」')
    else:
        _y, _m = int(ym[:4]), int(ym[5:]) + 2
        if _m > 12:
            _y += 1; _m -= 12
        checks.append(dict(bank='星展', card='傳說對決 ·----（加碼）', stmt=f'{_y}-{_m:02d}-01', base=round(tot), expected=round(exp), actual=None,
                           diff=None, status='⏳ 待入帳', note=note + '；次次月 1 日入帳'))
    # 精選通路加碼超過上限的部分：只剩 1%，列入「沒拿到回饋」
    used = 0.0
    for x in sorted(ch_items, key=lambda x: x['date']):
        room = max(cap - used, 0) / cr
        over = max(x['amount'] - room, 0)
        used += min(x['amount'], room) * cr
        if over >= 100:
            missed.append(dict(act=True, date=x['date'], stmt=x['stmt'], bank='星展', card=x['card'], cardname=x['cardname'], merchant=x['merchant'],
                               amount=round(over), reason=f'星展精選加碼當月已滿（{cap} 點），超過的只剩 1%',
                               suggest=f'當月精選通路超過約 {round(cap / cr):,} 元後改刷大戶卡（每期 2.5 萬內 5%）', gain=round(over * 0.04)))
missed.sort(key=lambda x: (x['date'], x['bank']), reverse=True)

checks.sort(key=lambda c: (c['bank'], c['stmt']))
missed_all = missed                                   # 全期（給網頁月報看過去月份）
missed = [m for m in missed_all if m['stmt'][:7] >= CUT]   # Excel／核對只看近 6 個月
summ = collections.defaultdict(lambda: [0, 0, 0])
for m in missed:
    k = m['reason']; summ[k][0] += 1; summ[k][1] += m['amount']; summ[k][2] += m['gain']
summary = sorted([dict(reason=k, n=v[0], amount=v[1], gain=v[2]) for k, v in summ.items()], key=lambda x: -x['gain'])
# ---------------- (3) 本月回饋一覽：報告月份（消費日）各卡預估回饋 ----------------
RM = f"{CFG['cur_year']}-{CFG['cur_month']:02d}"
def card_group(r):
    b, c = r['bank'], r['card']
    if b == '台新' and c in TAISHIN_WEALTH: return ('台新', '卓富無限卡（正附卡）')
    if b == '玉山' and c in ESUN_WORLD: return ('玉山', '世界卡（附卡）')
    return (b, r['cardname'].split(' ·')[0] + (f' ·{c}' if c else ''))
RULE = {}  # (銀行, 卡號末四碼): (預估方式, 入帳時間)；需要時請 Claude 依你的卡片權益加上
# uniopen（2026/9/1–12/31）：國內 1%；統一集團（7-ELEVEN、家樂福、康是美、星巴克…）加碼 2%（上限 500 點／月）；
# 海外一般 2%；海外實體店 3% ＋ 加碼 8%（上限 500 點／月）。icash Pay、跨品牌任務另計（請記在 Excel「活動回饋」）
UNI_GROUP = re.compile(r'統一超商|7-?ELEVEN|ICP|OPEN錢包|家樂福|CARREFOUR|康是美|星巴克|STARBUCKS|博客來|統一時代|夢時代|多拿滋|MISTER ?DONUT|速邁樂|黑貓|聖娜|21世紀|COLD ?STONE|DREAM ?PLAZA|uniopen', re.I)
def month_rows_for(RM):
    mon = collections.defaultdict(lambda: dict(spend=0, refund=0, elig=0, fx=0, auto=0, ins=0, miss=0, bank='', rule=None))
    for r in R:
        if r['date'][:7] != RM or r['kind'] not in ('spend', 'refund') or r['category'] in ('回饋折抵', '年費手續費'):
            continue
        if REB_ROW.search(nk(r['desc'])):
            continue
        k = card_group(r); g = mon[k]; g['bank'] = r['bank']
        if r['amount'] < 0:          # 退款另計，不拿來扣本月預估
            g['refund'] += -r['amount']; continue
        g['spend'] += r['amount']
        if r['bank'] == '台新' and r['card'] in TAISHIN_WEALTH:
            g['rule'] = ('tw', '當期帳單折抵')
        elif r['bank'] == '玉山' and r['card'] in ESUN_WORLD:
            g['rule'] = (0.002, 'e point，當期帳單')
        else:
            g['rule'] = g['rule'] or RULE.get((r['bank'], r['card']))
        d = nk(r['desc'])
        if '自動加值' in d:
            g['auto'] += r['amount']; continue
        mr = miss_reason(r)
        if mr and not (r['bank'] == '玉山' and r['card'] in ESUN_WORLD and mr[0].startswith('玉山世界卡')):
            g['miss'] += r['amount']; continue
        if r['bank'] == '聯邦' and INS.search(d):
            g['ins'] += r['amount']
        if r['bank'] == '中信' and r['card'] == '----':   # 中信 LINE Pay 卡（2026）：一般 1%；海外實體 2.8%；Hotels.com 專屬頁（帳單 HCOMCLP*）8%
            if re.search(r'HCOMCLP|HOTELS\.?COM', d, re.I) or re.search(r'HOTELS\.?COM', r['merchant'], re.I):
                g['lp_hotel'] = g.get('lp_hotel', 0) + r['amount']
            elif r.get('foreign') and not re.search(r'GOOGLE|APPLE|NETFLIX|AMAZON|AGODA|BOOKING|TRIP\.COM|KLOOK|AIRBNB|UBER', d, re.I):
                g['lp_fxp'] = g.get('lp_fxp', 0) + r['amount']
        if r['bank'] == '中信' and r['card'] == '----':
            if r.get('foreign'):
                g['uni_fx'] = g.get('uni_fx', 0) + r['amount']
                if not re.search(r'GOOGLE|APPLE|NETFLIX|AMAZON|AGODA|BOOKING|TRIP\.COM|KLOOK|HOTELS|AIRBNB', d, re.I):
                    g['uni_fxp'] = g.get('uni_fxp', 0) + r['amount']   # 海外實體店
            elif UNI_GROUP.search(d):
                g['uni_grp'] = g.get('uni_grp', 0) + r['amount']
        g['fx' if r.get('foreign') else 'elig'] += r['amount']
    month_rows = []
    for (b, name), g in mon.items():
        if g['spend'] <= 0: continue
        rule, when = g['rule'] or (None, '這張卡的權益規則尚未建立')
        e = g['elig'] + g['fx']
        if rule == 'dawho':
            est = e * 0.01 + min(e * 0.04, 1000) + min(g['auto'] * 0.05, 500)
        elif rule == 'dbs':
            est = e * 0.002 + dbs_bonus(RM, dm.get(RM, []))[2]
        elif rule == 'uniopen':
            est = g['elig'] * 0.01 + min(g.get('uni_grp', 0) * 0.02, 500) + g.get('uni_fx', 0) * 0.02 \
                  + g.get('uni_fxp', 0) * 0.01 + min(g.get('uni_fxp', 0) * 0.08, 500)
        elif rule == 'linepay':
            h, fp = g.get('lp_hotel', 0), g.get('lp_fxp', 0)
            est = (e - h - fp) * 0.01 + fp * 0.028 + h * 0.08   # Hotels.com 有輸入折扣碼 CTBCLP16 是 16%（每筆上限 1,800 點），沒輸入 8%：保守用 8%
        elif rule == 'tw':
            est = g['elig'] * 0.01 + g['fx'] * 0.03
        elif isinstance(rule, float):
            est = (e - g['ins']) * rule + g['ins'] * (0.012 if b == '聯邦' else 0)
        else:
            est = None
        bank_checks = [c for c in checks if c['bank'] == b and c['actual'] is not None]
        st = ('⚠️ 曾少給' if any(c['status'].startswith('⚠️') for c in bank_checks) else '✅ 核對正常') if bank_checks else ('— 點數回饋不在帳單上' if '看不到' in when else ('— 規則尚未建立' if est is None else '— 帳單沒列回饋明細'))
        month_rows.append(dict(bank=b, card=name, spend=round(g['spend']), elig=round(e + g['auto']), miss=round(g['miss']),
                               est=None if est is None else round(est), rate=None if est is None or g['spend'] <= 0 else round(est / g['spend'] * 100, 1),
                               when=when, status=st, refund=round(g['refund'])))
    month_rows.sort(key=lambda x: -(x['est'] or 0))
    return month_rows

_yms = sorted({r['date'][:7] for r in R if CFG['start'] <= r['date'][:7] <= CFG.get('data_through', '9999')[:7].replace('/', '-')})
month_rows_all = {ym: month_rows_for(ym) for ym in _yms}
month_rows = month_rows_all.get(RM, [])
json.dump(dict(cut=CUT, month=RM, month_rows=month_rows, month_rows_all=month_rows_all, checks=checks, missed=missed, missed_all=missed_all, summary=summary), open('rewards_check.json', 'w'), ensure_ascii=False, indent=1)
bad = [c for c in checks if c['status'].startswith('⚠️')]
print(f'回饋核對 {len(checks)} 期，少給 {len(bad)} 期；沒拿到回饋 {len(missed)} 筆 NT$ {sum(m["amount"] for m in missed):,}，換卡可多拿約 NT$ {sum(m["gain"] for m in missed):,}')
