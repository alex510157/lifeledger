# LifeLedger 健檢：檢查這台電腦的安裝、信箱、帳單、隨手記、排程，寫成一份報告（不會顯示任何密碼）
#   雙擊 _自動化工具\健檢.bat；報告在 _自動化工具\紀錄\健檢報告.txt，可以直接傳給幫你設定的人
import os, sys, json, glob, shutil, subprocess, datetime, re, urllib.request, urllib.parse, urllib.error

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)
sys.argv = [sys.argv[0], '--test']   # 收信只測試、不存檔
from paths import setp, HOME, LOG, ROOT, card_roots, deposit_roots

OUTL = []
OK, BAD, WARN = '✅', '❌', '⚠️'


def p(*a):
    t = ' '.join(str(x) for x in a)
    print(t, flush=True); OUTL.append(t)


def sec(t):
    p(''); p('■ ' + t)


def mask_user(u):
    u = str(u or '')
    if '@' in u:
        a, d = u.split('@', 1)
        return (a[:3] + '…' if len(a) > 3 else a) + '@' + d
    return u[:3] + '…' if len(u) > 3 else u


p(f'LifeLedger 健檢報告　{datetime.datetime.now():%Y-%m-%d %H:%M}')
_ver = open(os.path.join(BASE, 'version.txt'), encoding='utf8').read().strip() if os.path.exists(os.path.join(BASE, 'version.txt')) else '（沒有版號：舊版或你自己的主程式）'
p(f'程式版本：v{_ver}' if not _ver.startswith('（') else f'程式版本：{_ver}')
p(f'帳本資料夾：{HOME}')
od = os.environ.get('OneDrive') or ''
p('位置：' + (f'{OK} 在 OneDrive 裡（換電腦資料還在）' if od and os.path.abspath(HOME).lower().startswith(os.path.abspath(od).lower()) else f'{WARN} 不在 OneDrive（建議雙擊 _自動化工具\\搬到OneDrive.bat）'))

# ---------- 1. 工具 ----------
sec('1. 工具')
p(f'{OK} Python {sys.version.split()[0]}')
for mod in ('pikepdf', 'openpyxl', 'PIL', 'cryptography'):
    try:
        __import__(mod); p(f'{OK} 套件 {mod}')
    except Exception:
        p(f'{BAD} 套件 {mod} 沒裝好 → 重跑「安裝或換電腦.bat」')
try:
    _S0 = json.load(open(setp('local_settings.json'), encoding='utf8'))
except Exception:
    _S0 = {}
pt = shutil.which('pdftotext') or next((os.path.join(x, 'pdftotext.exe') for x in _S0.get('poppler_bin', []) + [r'C:\poppler\Library\bin', r'C:\Program Files\poppler\Library\bin']
                                       if os.path.isfile(os.path.join(x, 'pdftotext.exe'))), None) \
    or next(iter(glob.glob(os.path.join(os.environ.get('LOCALAPPDATA', ''), '**', 'pdftotext.exe'), recursive=True)), None)
p(f'{OK} PDF 轉文字工具' if pt else f'{BAD} 找不到 pdftotext（PDF 轉文字）→ 重跑「安裝或換電腦.bat」')
td = None
for d in [os.environ.get('TESSDATA_PREFIX', ''), os.path.join(os.environ.get('LOCALAPPDATA', ''), 'CardFlow', 'tessdata'),
          os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs', 'Tesseract-OCR', 'tessdata'), r'C:\Program Files\Tesseract-OCR\tessdata']:
    if d and os.path.isfile(os.path.join(d, 'chi_tra.traineddata')):
        td = d; break
tess = shutil.which('tesseract') or next((x for x in [os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs', 'Tesseract-OCR', 'tesseract.exe'), r'C:\Program Files\Tesseract-OCR\tesseract.exe'] if os.path.exists(x)), None)
p(f'{OK} 中文辨識（掃描版帳單用）' if (tess and td) else f'{WARN} 中文辨識沒裝好（只影響圖片版帳單，例如遠東）→ 重跑「安裝或換電腦.bat」')

# ---------- 2. 設定 ----------
sec('2. 設定（密碼只顯示有沒有填）')
try:
    S = json.load(open(setp('local_settings.json'), encoding='utf8'))
except Exception as e:
    S = {}; p(f'{BAD} 讀不到設定檔 local_settings.json：{e}')
try:
    PW = json.load(open(setp('passwords.json'), encoding='utf8'))
    n = len([k for k, v in PW.items() if k != '說明' and isinstance(v, str) and v])
    p(f'{OK} 帳單 PDF 密碼：已填 {n} 組' if n else f'{BAD} 帳單 PDF 密碼沒填 → LifeLedger「⚙️ 設定 → 帳單密碼」')
except Exception:
    p(f'{BAD} 帳單 PDF 密碼沒填 → LifeLedger「⚙️ 設定 → 帳單密碼」')
L = S.get('ledger') or {}
p(f'{OK} 隨手記：{L.get("url")}，帳號 {mask_user(L.get("user"))}，密碼{"已填" if L.get("password") else "沒填"}' if L.get('url') and L.get('user') else f'{WARN} 隨手記沒設定 → 設定精靈【0b】')
MB = S.get('mailboxes') or []
p(f'信箱：{len(MB)} 個' + ('' if MB else f'　{WARN} 沒設定 → LifeLedger「⚙️ 設定 → 信箱收帳單」'))
for b in MB:
    p(f'   · {b.get("type", "imap")}｜{mask_user(b.get("user") or b.get("account") or "Outlook")}｜密碼{"已填" if (b.get("password") or b.get("type") == "outlook") else "沒填"}'
      + (f'｜主機 {b["host"]}' if b.get('host') else ''))

# ---------- 3. 信箱實測 ----------
sec('3. 信箱實測（登入、找最近 13 個月的帳單；只看信、不存檔）')
if MB:
    try:
        import mail_fetch as MF
        since = datetime.date.today() - datetime.timedelta(days=400)
        for b in MB:
            lab = mask_user(b.get('user') or b.get('account') or 'Outlook')
            try:
                sv = MF.run_outlook(b, since) if b.get('type') == 'outlook' else MF.run_imap(b, since)
                p(f'{OK} {lab}：登入成功，找到帳單 {sv.found} 封')
                p('     信用卡帳單：' + ('、'.join(sorted(sv.kinds['card'])) or '沒有'))
                p('     存款／綜合對帳單：' + ('、'.join(sorted(sv.kinds['deposit'])) or '沒有'))
                for x in sv.nopdf[:5]:
                    p('     只有連結沒有 PDF：' + x)
                if b.get('login'):
                    p(f'     （自動找到可以登入的設定：{b.get("host")}，帳號 {mask_user(b.get("login"))}）')
            except Exception as e:
                p(f'{BAD} {lab}：{str(e)[:200]}')
    except Exception as e:
        p(f'{BAD} 收信程式出錯：{e}')
else:
    p('（沒有設定信箱，略過）')

# ---------- 4. 帳單資料夾 ----------
sec('4. 帳單資料夾（PDF 數量、最新一份）')
roots = list(dict.fromkeys([HOME] + list(S.get('bills', []))))
tot = 0
for r in roots:
    if not os.path.isdir(r):
        p(f'{WARN} 找不到資料夾：{r}'); continue
    for c in card_roots(r):
     for d in sorted(os.listdir(c)):
        fp = os.path.join(c, d)
        if not os.path.isdir(fp) or d.startswith('_') or d in ('月報', '帳單') or d.startswith('LifeLedger'):
            continue
        pdfs = glob.glob(os.path.join(fp, '*.pdf'))
        tot += len(pdfs)
        last = max((os.path.basename(x)[:10] for x in pdfs), default='')
        p(f'   {d}：{len(pdfs)} 份' + (f'，最新 {last}' if last else ''))
    for c in deposit_roots(r):
        for d in sorted(os.listdir(c)):
            fs = glob.glob(os.path.join(c, d, '*'))
            if fs:
                p(f'   {os.path.relpath(c, r)}\\{d}：{len(fs)} 份，最新 {max(os.path.basename(x)[:10] for x in fs)}')
p(f'{OK} 信用卡帳單 PDF 共 {tot} 份' if tot else f'{BAD} 還沒有任何信用卡帳單 PDF（信箱設好後按 LifeLedger 首頁的「立即更新全部帳目」，或自己放進銀行資料夾）')
dec_n = len(glob.glob(os.path.join(BASE, 'dec', '*.pdf'))); txt_n = len(glob.glob(os.path.join(BASE, 'txt', '*.txt')))
p(f'   已解密 {dec_n} 份、已轉文字 {txt_n} 份' + (f'　{WARN} 有 PDF 但都沒解開 → 帳單密碼可能不對（LifeLedger「⚙️ 設定 → 帳單密碼」）' if tot and not dec_n else ''))
# 哪幾份還沒解開（排除繳款聯等非帳單、內容重複的檔）
try:
    import hashlib
    from banks import short
    _SKIP = re.compile(r'PaymentSlip|繳款聯|綜合對帳單|MTHLYSTMT|smime|設定繳款提醒|銀行對帳單|存款對帳單', re.I)
    seen_h, notdec = set(), []
    for r in roots:
        for f in sorted(x for c in card_roots(r) for x in glob.glob(os.path.join(c, '*', '*.pdf'))):
            folder = os.path.basename(os.path.dirname(f)); fn = os.path.basename(f)
            if folder.startswith(('_', '月報', 'Claude', 'LifeLedger')) or _SKIP.search(fn):
                continue
            try:
                h = hashlib.md5(open(f, 'rb').read()).hexdigest()
            except OSError:
                continue
            if h in seen_h:
                continue
            seen_h.add(h)
            if not os.path.exists(os.path.join(BASE, 'dec', f'{short(folder)}__{fn}')):
                notdec.append(f'{folder}\\{fn}')
    if notdec:
        p(f'{WARN} 還沒解開的帳單 {len(notdec)} 份（密碼不對、或不是信用卡帳單）：')
        for x in notdec[:12]:
            p('     · ' + re.sub(r'(?<![\d.])\d{12,19}(?![\d.])', lambda m: '…' + m.group(0)[-4:], x))
    elif tot:
        p(f'{OK} 帳單都解開了')
except Exception as e:
    p(f'（列出未解開帳單時出錯：{e}）')
small = [os.path.basename(x) for x in glob.glob(os.path.join(BASE, 'txt', '*.txt')) if os.path.getsize(x) < 200]
if small:
    p(f'{WARN} 這幾份轉出來幾乎是空的（圖片版帳單，要中文辨識）：' + '、'.join(small[:5]))

# ---------- 5. 產出 ----------
sec('5. 產出')
for f, n in [(os.path.join(HOME, 'LifeLedger_生活總帳.xlsx'), 'Excel 總表'), (os.path.join(HOME, '月報', 'LifeLedger月報.html'), '月報'),
             (os.path.join(HOME, '月報', 'LifeLedger生活帳本.html'), '生活帳本')]:
    p(f'{OK} {n}：{datetime.datetime.fromtimestamp(os.path.getmtime(f)):%Y-%m-%d %H:%M} 更新' if os.path.exists(f) else f'{BAD} 還沒有{n}（要先有帳單）')
try:
    c = json.load(open(os.path.join(BASE, 'config.json'), encoding='utf8'))
    p(f'   資料至 {c.get("data_through")}')
except Exception:
    pass

# ---------- 6. 隨手記網站 ----------
sec('6. 隨手記網站')
if L.get('url') and L.get('user') and L.get('password'):
    try:
        from ledger_client import Client
        C = Client(L, ua='LifeLedger-health')
        _rev, d, enc = C.get_ledger(); d = d or {}
        p(f'{OK} 登入成功（用{C.login_method}）：記帳 {len(d.get("records", []))} 筆、卡片 {len(d.get("cards", []))} 張、收入 {len(d.get("incomes", []))} 筆')
        p(f'   {OK} 雲端帳本：' + ('已加密（在這台電腦解開）' if enc else '還沒加密') + ('' if C.v2 else '・網站是舊版（不支援登入金鑰和加密）'))
        for pg, nm in (('report', '月報'), ('book', '生活帳本'), ('cards', '卡片清單')):
            st, jj = C.call('GET', '/api/ledger?page=' + pg)
            if st == 200 and isinstance(jj, dict):
                p(f'   {OK if jj.get("blob") else WARN} 線上{nm}：' + (f'已上傳（{str(jj.get("savedAt", ""))[:16]}）' if jj.get('blob') else '還沒上傳（電腦有帳單、跑完更新後才會有）'))
            else:
                p(f'   {WARN} 線上{nm}：網站是舊版（{st}）')
    except Exception as e:
        st = getattr(e, 'status', None)
        if st:
            p(f'{BAD} 隨手記登入失敗（{st}）：' + ('帳號或密碼跟網站上的不一樣 → LifeLedger「⚙️ 設定 → 隨手記帳號」重新輸入' if st == 401 else '密碼錯太多次，15 分鐘後再試' if st == 429 else str(e)[:120]))
        elif getattr(e, 'code', None):
            p(f'{BAD} 隨手記：{e}')
        else:
            p(f'{BAD} 連不上隨手記網站：{e}')
else:
    p('（沒有設定，略過）')

# ---------- 7. 自動更新排程 ----------
sec('7. 自動更新排程')
if os.name == 'nt':
    for tn in ('LifeLedger Daily', 'LifeLedger 白天更新'):
        q = subprocess.run(['schtasks', '/Query', '/TN', tn, '/V', '/FO', 'LIST'], capture_output=True)
        try:
            out = q.stdout.decode('utf8')
        except UnicodeDecodeError:
            out = q.stdout.decode('cp950', 'ignore')
        if q.returncode:
            p(f'{WARN} 沒有排程「{tn}」' + ('（第一次更新後會自動建立）' if '白天' in tn else ' → 重跑「安裝或換電腦.bat」'))
        else:
            nxt = re.search(r'(下次執行時間|Next Run Time):\s*(.+)', out); last = re.search(r'(上次執行時間|Last Run Time):\s*(.+)', out)
            lr = last.group(2).strip() if last else '?'
            p(f'{OK} {tn}：下次 {nxt.group(2).strip() if nxt else "?"}；上次 ' + ('還沒跑過' if lr.startswith('1999') or 'N/A' in lr else lr))
else:
    p('（不是 Windows，略過）')

# ---------- 8. 最近的紀錄 ----------
sec('8. 最近的紀錄')
for f in ('線上狀態.txt', 'daily_log.txt', '試跑紀錄.txt'):
    fp = os.path.join(LOG, f)
    if os.path.exists(fp):
        lines = [x.rstrip() for x in open(fp, encoding='utf8', errors='replace').read().splitlines() if x.strip()]
        keep = [x for x in lines if re.search(r'⚠|✗|失敗|錯誤|Error|無法', x)][-6:] or lines[-3:]
        for i, x in enumerate(lines):   # 「金額跟帳單上印的不一樣」後面接著的明細也帶出來
            if '金額跟帳單上印的不一樣' in x:
                keep = keep + [y for y in lines[i + 1:i + 9] if y not in keep]
        p(f'   〔{f}〕最後更新 {datetime.datetime.fromtimestamp(os.path.getmtime(fp)):%Y-%m-%d %H:%M}')
        for x in keep:
            p('     ' + re.sub(r'(?<![\d.])\d{12,19}(?![\d.])', lambda m: '…' + m.group(0)[-4:], x)[:200])

p(''); p('（報告裡沒有任何密碼、完整卡號或帳號，可以放心傳給幫你設定的人）')
os.makedirs(LOG, exist_ok=True)
open(os.path.join(LOG, '健檢報告.txt'), 'w', encoding='utf8').write('\n'.join(OUTL) + '\n')
p(f'\n報告已存到：{os.path.join(LOG, "健檢報告.txt")}')
