# 現金（隨手記）、帳戶扣款（房貸、無卡分期、轉帳）→ 做成跟刷卡帳單一樣格式的明細列
#   月報（monthly_email.py）和生活帳本（compact.py）共用：主要分類、最大幾筆、明細都看得到，每筆標付款方式
#   bank 用兩個「虛擬銀行」：'現金'、'帳戶'；src = 'cash' / 'bank'
import re
import subcat as _scf

def _cashcat(c):
    """隨手記的分類 → 報表的細分類名稱（交通停車加油 → 交通・其他交通…）"""
    if c in _scf.FINE_PARENT:
        return _scf.fine_name(c, _scf.SUB_DEFAULT.get(c, '')) if _scf.SUB_DEFAULT.get(c) else c
    return c


def _boutcat(x):
    return '房貸' if '房貸' in x['label'] else re.sub(r'（.*?）', '', x['label']).strip()


def build(INC):
    XR = []
    INC = INC or {}
    for _x in INC.get('cash', []):
        _cn = _x.get('card') if _x.get('card') not in (None, '', '未指定', '現金') else '現金'
        XR.append(dict(date=_x['date'], amount=_x['amount'], category=_cashcat(_x['category']), merchant=_x.get('note') or _x['category'],
                       desc='隨手記', bank='現金', cardname=_cn, installment=False, foreign=False, src='cash', stmt='', kind='spend'))
    for _x in INC.get('bank_out', []):
        _nm = _x.get('summary') if _x.get('inst') else (_x['label'] if _x['label'] != '房貸' else '房貸・' + (_x.get('summary') or '放款繳款'))
        XR.append(dict(date=_x['date'], amount=_x['amount'], category=_boutcat(_x), merchant=_nm or _x['label'],
                       desc=('帳號末 ' + _x['memo']) if re.fullmatch(r'\d{3,}', str(_x.get('memo') or '')) else (_x.get('memo') or ''),
                       bank='帳戶', cardname=(_x.get('bank') or '富邦') + '帳戶', installment=False, foreign=False, src='bank', stmt='', kind='spend',
                       oneoff=0))
    for _p in INC.get('inst', []):   # 分期買的東西：買的那天列一筆 0 元的「分期購入」，之後每月一期
        XR.append(dict(date=_p['date'], amount=0.0, category=_p['category'], merchant=_p['name'],
                       desc=f'分期購入 總價 {_p["total"]:,.0f}，分 {_p["n"]} 期，{int(_p["start"][5:])} 月起每月 {_p["per"]:,.0f}（這筆不重複算）',
                       bank='帳戶', cardname='無卡分期', installment=False, foreign=False, src='bank', stmt='', kind='spend', buy=1))
    return XR


boutcat = _boutcat


def card_buys(R):
    """刷卡分期（銀行分期，帳單上每期一筆）：在買的那天加一筆 0 元的「分期購入」，看得到原始金額、幾期，支出照每期算、不重複"""
    import collections
    g = collections.defaultdict(list)
    for r in R:
        if r.get('installment') and r.get('inst_N') and r.get('txn_date'):
            g[(r['bank'], r['cardname'], r['txn_date'], r['merchant'])].append(r)
    out = []
    for (b, cn, d, m), rs in g.items():
        N = int(rs[0]['inst_N']); ns = {int(r.get('inst_n') or 0) for r in rs}
        if N < 2 or 1 not in ns or '保費分期' in cn:
            continue   # 沒看到第 1 期（帳單開始前就在繳）或保費每月自動分期：不列
        p1 = next(r['amount'] for r in rs if int(r.get('inst_n') or 0) == 1)
        later = [r['amount'] for r in rs if int(r.get('inst_n') or 0) > 1]
        per = later[0] if later else p1
        tot = sum(r['amount'] for r in rs) if len(ns) == N else round(p1 + per * (N - 1))   # 第 1 期常多幾塊（尾差）
        r0 = min(rs, key=lambda r: r['date'])
        out.append(dict(r0, date=d, amount=0.0, installment=False, inst_n=None, inst_N=None, key='', stmt=r0['stmt'], buy=1,
                        desc=f'分期購入 總價 {tot:,.0f}，分 {N} 期，每期約 {per:,.0f}，{int(r0["date"][5:7])} 月帳單起每期算一次（這筆不重複算）'))
    return out
