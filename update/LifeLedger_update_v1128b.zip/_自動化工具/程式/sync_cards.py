import os
# 從現有 Excel 讀回你改過的東西，下次重建時保留：
#   「卡片清單」卡名 → card_overrides.json；「歸屬」（我／家人）→ 設定/卡片歸屬.json
#   「交易明細」代付欄打 ✔ 的交易 → 設定/代付標記.json
import sys, json, re
xlsx = sys.argv[1] if len(sys.argv) > 1 else ""
from openpyxl import load_workbook
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from paths import setp
try:
    wb = load_workbook(sys.argv[1])
    ws = wb['卡片清單']
except Exception as e:
    print('沒有可讀的卡片清單：', e); sys.exit(0)


def col(sheet, row, name):
    for c in range(1, sheet.max_column + 1):
        if str(sheet.cell(row, c).value or '').strip() == name:
            return c
    return None


ov, own = {}, {}
oc = col(ws, 4, '歸屬')
for r in range(5, ws.max_row + 1):
    b, l4, nm, role, holder, src = (ws.cell(r, c).value for c in range(2, 8))
    if b and l4 and nm and str(ws.cell(r, 4).value or '') != '卡片名稱':
        ov[f'{b}|{l4}'] = [nm, role or '', holder or '', src or '']
        if oc and ws.cell(r, oc).value in ('我', '家人'):
            own[f'{b}|{l4}'] = ws.cell(r, oc).value
json.dump(ov, open('card_overrides.json', 'w', encoding='utf8'), ensure_ascii=False)
# 只記「跟預設不同」的歸屬（預設：附卡算家人、配偶 的附卡算自己），這樣預設規則改了也會套用
from cards import default_owner
own = {k: v for k, v in own.items() if v != default_owner(*k.split('|'))}
json.dump(own, open(setp('卡片歸屬.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=0)

# 代付勾選：Excel 是主要來源（✔＝全部代墊；50%＝代墊一半）；網頁上剛勾、Excel 還沒重做的保留
pf = setp('代付標記.json')
P = json.load(open(pf, encoding='utf8')) if os.path.exists(pf) else {'ticked': []}
tick, ratio = set(P.get('ticked', [])), dict(P.get('ratio', {}))
online = P.get('online', {})
import datetime as _dt
xmt = _dt.datetime.utcfromtimestamp(os.path.getmtime(xlsx)).strftime('%Y-%m-%dT%H:%M:%S') if xlsx and os.path.exists(xlsx) else ''
try:
    tx = wb['交易明細']
    sc, kc = col(tx, 1, '代付'), col(tx, 1, 'key')
    if sc and kc:
        for r in range(2, tx.max_row + 1):
            k = tx.cell(r, kc).value
            if not k or str(k).endswith('#代付'):
                continue
            if k in online and online[k][1] > xmt:   # 網頁上比這份 Excel 新的勾選
                continue
            v = str(tx.cell(r, sc).value or '').strip()
            m = re.fullmatch(r'(\d{1,3}(?:\.\d+)?)\s*[%％]', v)
            tick.discard(k); ratio.pop(k, None)
            if v in ('✔', '✓', 'v', 'V', 'y', 'Y', '1', '是', '代付', '代墊'):
                tick.add(k)
            elif m and 0 < float(m.group(1)) < 100:
                ratio[k] = round(float(m.group(1)) / 100, 4)
            elif m and float(m.group(1)) >= 100:
                tick.add(k)
except KeyError:
    pass
P.update({'說明': '代墊的交易：ticked＝全部代墊；ratio＝部分代墊比例（Excel 交易明細「代付」欄打 ✔ 或 50%，或在生活帳本網頁上勾）', 'ticked': sorted(tick), 'ratio': ratio})
json.dump(P, open(pf, 'w', encoding='utf8'), ensure_ascii=False, indent=0)
print('卡片', len(ov), '・家人卡', sum(1 for v in own.values() if v == '家人'), '・代付', len(tick))

# 活動回饋：Excel「活動回饋」頁你填的活動（登錄活動、加碼）→ 設定/活動回饋.json
try:
    ws = wb['活動回饋']
    acts = []
    for r in range(13, ws.max_row + 1):
        ym, bank, card, name, amt, kind, note, st = (ws.cell(r, c).value for c in range(2, 10))
        if not name or amt in (None, ''):
            continue
        ym = ym.strftime('%Y-%m') if hasattr(ym, 'strftime') else str(ym or '').strip().replace('/', '-')[:7]
        acts.append(dict(month=ym, bank=str(bank or ''), card=str(card or ''), name=str(name), amount=float(amt), kind=str(kind or '刷卡金'),
                         note=str(note or ''), manual=str(st or '') if str(st or '').startswith(('已入帳', '沒拿到')) else ''))
    json.dump(acts, open(setp('活動回饋.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=0)
    print('活動回饋', len(acts), '筆')
except KeyError:
    pass
