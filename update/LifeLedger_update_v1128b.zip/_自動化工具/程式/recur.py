import os
import json, re
os.chdir(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open('config.json')); CY, CM = CFG['cur_year'], CFG['cur_month']; PY = CY - 1
from banks import web_safe as _bkws
R = _bkws(json.load(open('rows.json')))
groups = [
 ('國泰人壽 保費', '多張保單，每月扣款', r'國泰人壽'), ('新光產險 保費', '分 12 期扣款', r'新光產險'), ('富邦產物 保費', '分期扣款', r'富邦產物'),
 ('其他產險／旅平險', '明台、國泰世紀、安達、新光人壽旅平險等', r'明台|國泰世紀|安達|新光人壽|臺灣產物|新安東京'),
 ('停車費', 'Autopass、嘟嘟房、iParking 等', r'Autopass|嘟嘟房|停車|iParking'), ('加油', '中油條碼、加油站、捷利卡儲值', r'中油|加油|COSMOOIL|捷利卡'),
 ('悠遊卡／eTag 自動加值', '', r'悠遊卡自動加值|eTag'), ('中華電信', '電信費', r'中華電信'), ('有線電視', '長德有線電視', r'有線電視'),
 ('電費／瓦斯', '台電、大台北瓦斯', r'台電|台灣電力|瓦斯'), ('職能治療', '幼思、安安優腦', r'職能治療'), ('Google One', '雲端空間訂閱', r'GOOGLE'),
]
out = []
for name, sub, pat in groups:
    xs = [r for r in R if re.search(pat, r['desc'] + ' ' + r['merchant']) and r['category'] != '回饋折抵']
    a = sum(r['amount'] for r in xs if r['date'][:4] == str(PY))
    b = sum(r['amount'] for r in xs if r['date'][:4] == str(CY) and int(r['date'][5:7]) <= CM)
    banks = '・'.join(sorted(set(r['bank'] for r in xs), key=lambda x: -sum(r['amount'] for r in xs if r['bank'] == x)))
    out.append([name, sub, banks, round(a), round(b)])
# 銀行帳戶直接扣的固定支出（房貸、固定轉帳），來自 income.py 讀的存款對帳單
if os.path.exists('income.json'):
    bo = json.load(open('income.json', encoding='utf8')).get('bank_out', [])
    for lab in sorted({x['label'] for x in bo}):
        xs = [x for x in bo if x['label'] == lab]
        a = sum(x['amount'] for x in xs if x['date'][:4] == str(PY))
        b = sum(x['amount'] for x in xs if x['date'][:4] == str(CY) and int(x['date'][5:7]) <= CM)
        sub = '每月月初自動扣款' if '房貸' == lab else f'{len([x for x in xs if x["date"][:4] in (str(PY), str(CY))])} 次轉帳'
        out.insert(0, [lab, sub + '（銀行帳戶）', '富邦帳戶', round(a), round(b)])
json.dump(out, open('recur.json', 'w'), ensure_ascii=False)
