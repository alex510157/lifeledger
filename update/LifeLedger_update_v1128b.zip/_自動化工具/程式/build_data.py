import os
import json, re, collections, datetime
from parse import parse_any, classify_kind
import glob

os.chdir(os.path.dirname(os.path.abspath(__file__)))
T = []
for f in sorted(glob.glob('txt/*.txt')):
    if os.path.basename(f).startswith('中信'):   # Windows 路徑是反斜線，不能用 split('/')
        continue
    for t in parse_any(f):
        t['kind'] = classify_kind(t)
        T.append(t)
T += json.load(open('ctbc_txns.json'))

ADJ = re.compile(r'專案:想分調整|溢付|溢繳|取消信用卡年費')
INST = re.compile(r'第\d{2}/\d{2}|分\d{2}期之第|\s\d{2}/\d{2}$|\d{2}/12\s*$|\d{2}/\d{2}\s+TW$')

CATS = [
    ('回饋折抵', r'回饋入帳戶|回饋調整|回饋|積點兌換|刷卡金|點數折抵|現金回饋|豐點'),
    ('年費手續費', r'年費|國外交易手續費|國外交易服務費|國外退貨手續費|手續費|服務費-|服務費$'),
    ('保險', r'產險|人壽|保險|旅平險|產物'),
    ('稅費', r'地方稅|稅款|牌照稅|燃料使用費|燃料費|房屋稅|地價稅|所得稅|綜所稅|綜合所得|財政部|國稅|稅捐|稅務|國庫|使用牌照|規費|罰鍰|交通違規|e政府|監理'),
    ('旅遊住宿', r'福朋|喜來|saily|Grab\*|CHITOSE AIRPORT|Hotels\.com|HOTEL|Hotel|易遊網|虎航|長榮航空|中華航空|KK ?day|KKday|客路|Klook|AGODA|TRIP\.COM|Hyatt|喜來登|酒店|酷遊天|INTERCONTINENT|E-VISA|RENT-A-CAR|機場接送|貴賓專接|機場貴賓|共樂遊|GUESTHOU|RAKUTENPAY GUES|PRINCE|飯店|旅行社|STUDIO CITY|MOBILITY RESORT|EVA AIR|航空|Flickket|旅遊|AsiaWiFi|eSIM|DJB'),
    ('汽車保養', r'車業|機車行|KYMCO|Kymco|光陽機車|三陽工業|Gogoro(?! ?Network)|睿能|摩特動力|宏佳騰|特斯拉|TESLA|裕隆|和泰汽車|8891汽車|監理所|賓士|保修|弘緯汽車|汽車股份|輪胎|帽帽龍|二輪部品'),
    ('交通停車加油', r'捷運|大眾捷運|UBER *TRIP|UBER.*TRIP|Uber Trip|計程車|台灣大車隊|LINE TAXI|yoxi|YOXI|Autopass|嘟嘟房|iParking|停車|中油|加油|eTag|悠遊卡自動加值|高鐵|捷利卡|台北捷|COSMOOIL|台灣中油|路邊停車|台鐵|臺鐵|台灣鐵路|客運|國光|統聯|巴士|遠通電收|YouBike|iRent|GoShare|WeMo|台塑石油|全國加油|速邁樂|PARKING|Parking'),
    ('生活繳費', r'中華電信|電信費|電話費|台電|台灣電力|瓦斯|有線電視|代收|GOOGLE\*GOOGLE|自來水|591房屋|管理費|台灣大哥大|遠傳|亞太電信|台灣之星|NETFLIX|Netflix|Spotify|SPOTIFY|YouTube|YOUTUBE|Disney\+|KKBOX|APPLE\.COM/BILL|天然氣|水費|電費'),
    ('教育', r'職能治療|學雜費|教育(?!館|用品)|補習|才藝|幼兒園|幼稚園|托嬰|托育|安親|課程|學費|美語|英語|音樂教室|鋼琴|舞蹈|樂高|KUMON|Kumon|何嘉仁|康軒|學校|兒童發展|感統|語言治療'),
    ('醫療', r'醫院|醫療|健康管理|藥行|診所|HERBALIFE|Dr\.Foot|藥局|藥妝|牙醫|眼科|復健|中醫|長庚|馬偕|榮總|台大醫|藥師|健保|皮膚科|小兒科|耳鼻喉'),
    ('網購', r'蝦皮|SHOPEE|PCHOME|momo|蘋果電腦|小米|Apple|綠界|藍新|露天|博客來|Yahoo|淘寶|eslite\.tw|樂購|AMAZON|Amazon|AliExpress|Coupang|酷澎|ZALORA|GOMAJI|91APP|Pinkoi|東森購物|ETMall'),
    ('超市便利商店', r'統一超商|7-ELEVEN|ICP|愛金卡|全家|FamiPay|FAMILYMART|家樂福|全聯|康達盛通|量販|COOP|MAXVALU|DONQUIJOTE|DAIKOKU|超市|OPEN錢包|OP錢包|萊爾富|LAWSON|美廉社|好市多|Costco|COSTCO|icashPay|全支付TWQR|TWQR|屈臣氏|Watsons|WATSONS|康是美|COSMED|大潤發|愛買|頂好|松青|小北百貨'),
    ('餐飲', r'路易莎|LOUISA|米粉|牛排|厚切|小吃|滷味|早餐|便當|茶飲|飲料|COMEBUY|可不可|五十嵐|清心|CAFE|Cafe|咖哩|丼|燒肉|火鍋|甜點|蛋糕|麵包|烘焙|麥當勞|SUKIYA|食堂|牛肉麵|壽司|餐|美食|鐵板燒|拉麵|豆花|咖啡|STARBUCKS|星巴克|水煮|廚房|鍋|烤|和牛|薩莉亞|花月嵐|勝博殿|饗|酸菜魚|定食|麵|腸粉|八方雲集|50嵐|蛋白盒子|布娜飛|新韓館|客美多|MisterDo|CHIFFON|五花馬|咖啡伴|滷轉乾坤|食焱|燒肉|PaMi|安永心食|義|CAFE|Cafe|MCDONALD|KITCHEN|RESTAURANT|YAKINIKU|DONUT|SUSHI|RAMEN|ROASTED|FOOD|東引快刀手|鮨|飯|小館|茶|乾杯|Great Fo|Lee饗|首爾富|IZAKAYA|AJJIDOKORO|SHOKUDO|BENEDICT|TENSHUKAKU|SUISAN|食|餃|羹|肉乾|鵝肉|臭豆腐|料理|Burger|COMEBUY|LOUISA|盒子|真芳|車輪|氣泡飲|味極|市場|明月堂|新東陽|Great Fo|Miss Ene|Miss Cro|Hello Fr|勝太郎|九初|涓邸|麻膳堂|爭鮮|潭酵|OLIMA|MR.ORANG|Thai|Ph|UBER \*EATS|Uber Eats|UBER EATS|foodpanda|FOODPANDA|星巴克|STARBUCKS|Starbucks|85度C|摩斯|肯德基|KFC|必勝客|達美樂|漢堡|拉麵|居酒屋|餐廳|RESTAURANT|Restaurant|吉野家|八方雲集|爭鮮|瓦城|鼎泰豐|王品|麻辣|奶茶|Mister Donut'),
    ('百貨購物', r'LaLaport|宏匯|百貨|微風|Global Mall|OUTLET|奧特萊斯|MITSUI|IKEA|特力屋|迪卡儂|DECATHLON|UNIQLO|誠品|昇恒昌|免稅|威士威|麗寶|美麗華|京站|CITYLINK|Dream ?Plaza|ABC-MART|A&F|Nespresso|遠東|Garden City|SOGO|新光三越|大遠百|NITORI|無印|HANDS|LOFT|晴空|商場|GIFT|DRUG|MART|SHOP|STORE|寶雅|POYA|三創|LOPIA|樂比亞|蜡藝|新光三越|遠百|太平洋SOGO|漢神|H&M|ZARA|全國電子|燦坤|順發'),
    ('運動休閒', r'頑皮世界|動物園|遊戲|KTV|錢櫃|好樂迪|運動中心|影城|威秀|足湯|百樂園|桌遊|健身|遊樂|樂園|疾風匣|ASPOR|博物館|門票|ticket|Ticket|可創活動|MARINEHOUSE|IRUKA|相信音樂|南仁湖|USPACE|健身工廠|World Gym|WORLD GYM|秀泰|國賓影城|Steam|STEAM|PlayStation|Nintendo|任天堂'),
]
CAT_RE = [(c, re.compile(p)) for c, p in CATS]


def categorize(d):
    for c, r in CAT_RE:
        if r.search(d):
            return c
    return '其他'


def clean_desc(d):
    d = re.sub(r'^(A-|MA-|MF-|N-|PY-)\s*', '', d)
    d = re.sub(r'\s*/\s*TW\s+\S.*$', '', d)
    d = re.sub(r'\s{2,}', ' ', d).strip()
    return d


def merchant(d):
    d = clean_desc(d)
    d = re.sub(r'^(連加\*|連支\*|街口電支-|全支付[—-]|LINEPAY\*)', '', d)
    d = re.sub(r'\s*(第\d{2}/\d{2}.*|分\d{2}期.*|\d{2}/\d{2}.*)$', '', d)
    d = re.sub(r'(TAIPEI|NEW TAIPEI.*|Taipei|TAINAN)$', '', d).strip()
    d = re.sub(r'\s*\d{8,}', '', d)
    d = re.sub(r'\s+(TWD|TW)$', '', d).strip()
    if d.startswith('樂購蝦皮') or d.startswith('SHOPEEPAY'):
        return '蝦皮購物'
    if 'Hotels.com' in d or d.startswith('HCOM') or d.startswith('HOTELCOM'):
        return 'Hotels.com'
    if d.startswith('易遊網'):
        return '易遊網'
    for k in ['Autopass', '國泰人壽', '新光產險', '新光人壽', '富邦產物', '台灣虎航', '長榮航空', 'KKday', 'KK day', '客路', 'AGODA', '統一超商', 'ICP-統一超商', '愛金卡-統一超商', '中油', 'eTag', '悠遊卡自動加值', 'PCHOME', '台灣麥當勞', '麥當勞', '嘟嘟房', 'LaLaport', '中華電信', '家樂福', '永固便利停車', '全鋒', 'SUKIYA', '高田食堂', 'Mr.布魯水煮健', '家味豆花', '幼思職能治療所', 'E-VISA', 'IKEA', '宏匯廣場', '統一時代百貨']:
        if k in d:
            return {'KK day': 'KKday', 'ICP-統一超商': '統一超商', '愛金卡-統一超商': '統一超商', '台灣麥當勞': '麥當勞'}.get(k, k)
    return d[:22]


REB_CARD = []   # (帳戶層級回饋的關鍵字, (銀行, 末四碼))
from cards import last4 as _last4, dispname as _disp
def cardname(b, c):
    return _disp(b, _last4({'card': c, 'bank': b, 'cardname': '想分' if (b == '聯邦' and not c) else ''}))

rows = []
for t in T:
    mr = re.search(r'回饋入帳戶\D*?(\d[\d,]*)\s*元', t['desc'])
    if mr and t['amount'] == 0:
        t['amount'] = -float(mr.group(1).replace(',', ''))
        t['kind'] = 'refund'
    if t['kind'] in ('payment', 'summary'):
        continue
    d = t['desc']
    kind = t['kind']
    if ADJ.search(d):
        kind = 'adjust'
    inst = bool(INST.search(d)) and kind == 'spend'
    eff = t['stmt'] if inst else t['date']
    # statements posted near cycle end: keep consumption date otherwise
    cat = categorize(d)
    fx = t.get('bill_cur', 'TWD') != 'TWD' or t['currency'] != 'TWD' or bool(re.search(r'\b(JP|MO|VN|ES|NL|KR|US|HK|TH|SG|GB|FR|DE|IT)\s*$|OKINAWA|TOKYO|SAPPORO|OSAKA|KYOTO|MACAU|MACAO|HO CHI|HA NOI|HANOI|London|GBR|HOI', d))
    if cat == '其他' and fx:
        cat = '旅遊住宿'
    if kind == 'adjust' and '想分調整' in d:
        cat = categorize(d.replace('專案:想分調整', ''))
    country = 'TW'
    m = re.search(r'\s([A-Z]{2})\s+[A-Z]{3}\b', d)
    foreign = t.get('bill_cur', 'TWD') != 'TWD' or t['currency'] not in ('TWD',)
    ctry = ''
    if fx or 'Hotels.com' in d or 'HCOM' in d:
        for k, pat in [('日本', r'\bJP\b|JPY|OKINAW|TOKYO|SAPPOR|OSAKA|KYOTO|ISHIGA|ISHIKA|HOKKAI|SHIGA|MITSUI|UESUTE|TENSHUKAKU|HAKONE|MOTEGI|CHITOSE|GIFU|KANAZAWA|FURANO|NEXCO|TOYA|TOUKIYOU'), ('澳門', r'MACAU|MACAO|\bMO\b|MOP'), ('越南', r'VIET|\bVN\b|VND|HO CHI|HA NOI|HANOI|HOI|Grab'), ('新加坡', r'SINGAP|Singap|SENTOSA'), ('荷蘭', r'Amster|\bNL\b'), ('英國', r'London|GBR|\bGB\b'), ('韓國', r'\bKR\b|KRW|SEOUL'), ('線上訂房／海外網站', r'Hotels\.com|HCOM|HOTELCOM|AGODA|TRIP\.COM|GOOGLE|HERBALIFE|\bES\b|\bUS\b|USD|\bSG\b|\bIE\b')]:
            if re.search(pat, d):
                ctry = k
                break
        if not ctry:
            ctry = '其他海外'
    n_ = N_ = None
    for pat, order in [(r'第(\d{1,2})/(\d{1,2})', 'nN'), (r'分(\d{1,2})期之第(\d{1,2})期', 'Nn'), (r'(\d{2})/(\d{2})\s*(?:期|TW|TWD)?\s*$', 'nN')]:
        mm_ = re.search(pat, d)
        if mm_ and inst:
            a_, b_ = int(mm_.group(1)), int(mm_.group(2))
            n_, N_ = (a_, b_) if order == 'nN' else (b_, a_)
            break
    if not t.get('card') and cat == '回饋折抵':   # 帳戶層級的回饋：從說明判斷是哪張卡給的
        for pat, (bb, l4_) in REB_CARD:
            if t['bank'] == bb and re.search(pat, d):
                t['card'] = l4_; break
    rows.append(dict(inst_n=n_, inst_N=N_, country=ctry, 
        bank=t['bank'], date=eff, txn_date=t['date'], stmt=t['stmt'], desc=clean_desc(d), merchant=merchant(d),
        amount=t['amount'], kind=kind, category=cat, installment=inst, card=t.get('card', ''), cardname=cardname(t['bank'], t.get('card', '')),
        foreign=fx, currency=t.get('bill_cur') if t.get('bill_cur', 'TWD') != 'TWD' else t['currency'],
    ))

# foreign flag from desc patterns too
for r in rows:
    if re.search(r'\b(JP|MO|VN|ES|NL|KR|US|HK|TH|SG)\b', r['desc']) and r['bank'] in ('台新', '永豐'):
        pass

_cfg = json.load(open('config.json', encoding='utf8'))
_end = _cfg.get('last_month', '2026-10') + '-31'
rows = [r for r in rows if (_cfg.get('start') or '2025-01') + '-01' <= r['date'] <= _end]

# ---------- 歸屬（我／家人附卡）與代付 ----------
from cards import owner as _owner, last4 as _l4
from banks import txkey
from paths import setp
_pf = setp('代付標記.json')
PAID = json.load(open(_pf, encoding='utf8')) if os.path.exists(_pf) else {'ticked': []}
TICK = set(PAID.get('ticked', []))
paid_merch = collections.Counter(k.split('|')[-1] for k in TICK)
for r in rows:
    l4 = _l4(r)
    r['owner'] = _owner(r['bank'], l4)
    r['key'] = txkey(r, l4)
    r['paid'] = r['key'] in TICK
# 帳單對上隨手記那筆：用你記帳時選的分類、寫的備註（例如「蝦皮・手機殼」「停車」）來歸類（income.py 產生 設定/隨手記帶入.json）
_cf = setp('隨手記帶入.json')
CARRY = (json.load(open(_cf, encoding='utf8')).get('rows', {}) if os.path.exists(_cf) else {})
_VC = {c for c, _ in CATS} - {'回饋折抵', '年費手續費'}
# 帳單本身看不出是什麼的（分到「其他」、或經過 LINE Pay／街口／全支付這類支付平台）才用隨手記的分類；
# 帳單商家已經很清楚的（例如嘟嘟房、Hotels.com）照帳單，避免記帳時沒改到預設分類（餐飲）反而分錯
_WEAK = re.compile(r'LINE ?PAY|LINEPAY|連加|街口|全支付|綠界|藍新|悠遊付|icash ?Pay|PX ?Pay|歐付寶|PAYPAL|PayPal|台灣Pay|TWQR|Pi 拍錢包', re.I)
_NOTE_EXTRA = [('旅遊住宿', re.compile(r'住宿|民宿|機票|門票|行程|旅館|旅店')), ('交通停車加油', re.compile(r'停車|加油|高鐵|計程車|捷運'))]


def _note_cat(note):
    c = categorize(note)
    if c in _VC:
        return c
    return next((c for c, rx in _NOTE_EXTRA if rx.search(note)), None)


_nc = 0
for r in rows:
    v = CARRY.get(r['key'])
    if not v or r['kind'] != 'spend' or r['category'] == '回饋折抵':
        continue
    note = (v.get('note') or '').strip()
    if r['category'] == '其他' or _WEAK.search(r['merchant']):
        _vc = {'購車／汽機車': '汽車保養', '汽機車': '汽車保養'}.get(v.get('cat'), v.get('cat'))
        lc = _vc if _vc in _VC else None
        c = (lc if lc and lc != '餐飲' else None) or (_note_cat(note) if note else None) or lc   # 餐飲是記帳的預設分類，有備註就先看備註
        if c and c != r['category']:
            r['category'] = c; _nc += 1
    if (v.get('inst') or 0) > 1 and not r.get('installment'):   # 隨手記勾了「分期／分攤」：帳單上一次刷，報表上分月算
        r['spread'] = [int(v['inst']), v.get('ist') or '']
    if note:
        r['memo'] = note
        if note not in (r.get('desc') or '') + r['merchant']:
            r['desc'] = (r.get('desc') or r['merchant']) + '・隨手記：' + note
if CARRY:
    print(f'隨手記帶入：對上 {len(CARRY)} 筆（備註帶進說明），其中 {_nc} 筆帳單看不出分類、改用隨手記的分類／備註')
# 部分代墊（例如團體消費只幫別人付一部分）：拆成「自己的部分」和「代墊的部分」兩筆，總額不變
RATIO = PAID.get('ratio', {})
_split = []
for r in rows:
    p = RATIO.get(r['key'])
    if p and 0 < p < 1 and not r['paid'] and r['owner'] == '我':
        q = dict(r); a0 = r['amount']
        q['amount'] = round(a0 * p, 2); r['amount'] = round(a0 - q['amount'], 2)
        r['paid_ratio'] = q['paid_ratio'] = p
        q['paid'] = True; q['key'] = r['key'] + '#代付'
        q['desc'] = (r.get('desc') or r['merchant']) + f'（代墊 {p * 100:.0f}%）'
        r['desc'] = (r.get('desc') or r['merchant']) + f'（自付 {100 - p * 100:.0f}%）'
        _split.append(q)
rows += _split
# 「可能是代付」提示：只看報告月份與之後（新帳單），讓使用者到 Excel 勾
_cm = f"{_cfg.get('cur_year')}-{int(_cfg.get('cur_month', 1)):02d}"
_recur = re.compile(r'國泰人壽|新光產險|富邦產物|中華電信|台電|瓦斯|Autopass|嘟嘟房|停車|中油|加油|eTag|悠遊卡|有線電視|GOOGLE')
_hist = collections.Counter(r['merchant'] for r in rows)
for r in rows:
    r['hint'] = ''
    if r['paid'] or r['owner'] != '我' or r['kind'] != 'spend' or r['date'][:7] < _cm or r['category'] == '回饋折抵':
        continue
    if paid_merch.get(r['merchant']):
        r['hint'] = '以前勾過代付的商家'
    elif r['amount'] >= 5000 and not r['installment'] and '結清' not in r['desc'] and not _recur.search(r['desc']) and _hist[r['merchant']] <= 2:
        r['hint'] = '金額較大、不是固定支出'
# drop adjust lines that are pure accounting (溢付/取消年費)
rows = [r for r in rows if not (r['kind'] == 'adjust' and '想分調整' not in r['desc'])]
# 子分類（交通→加油／停車…、旅遊→機票／住宿…、網購→用電子發票品名分 3C／食品／玩具…）
try:
    import subcat as _sc
    _ls = json.load(open(setp('local_settings.json'), encoding='utf8')) if os.path.exists(setp('local_settings.json')) else {}
    _roots = list(dict.fromkeys([os.environ.get('CARDFLOW_OUT') or _ls.get('out') or __import__('paths').HOME] + list(_ls.get('bills', []))))
    _h, _n = _sc.assign(rows, _roots)
    print(f'子分類：網購用電子發票配對到 {_h} 筆（發票明細 {_n} 張）')
    # 生活帳本裡自己改的名稱／分類（設定/明細修改.json，代號跟網頁一樣：交易代號雜湊）
    _rf = setp('商家分類.json')   # 「以後這家都用這個分類」
    _RULE = json.load(open(_rf, encoding='utf8')) if os.path.exists(_rf) else {}
    if _RULE:
        _nr = 0
        for r in rows:
            c = _RULE.get(r['merchant'])
            if c and r['kind'] == 'spend' and r['category'] != '回饋折抵':
                r['orig_fine'] = r.get('orig_fine') or _sc.fine(r)
                r['category'], r['sub'] = _sc.unfine(c); _nr += 1
        print(f'商家分類：套用你設定的 {len(_RULE)} 家，共 {_nr} 筆')
    _ef = setp('明細修改.json')
    _ED = json.load(open(_ef, encoding='utf8')) if os.path.exists(_ef) else {}
    if _ED:
        import hashlib as _hl
        _ne = 0
        for r in rows:
            _x = _hl.sha1(str(r.get('key', '')).split('#')[0].encode('utf8')).hexdigest()
            e = _ED.get('h' + _x[:6] + 'k' + _x[6:12])
            if not e:
                continue
            r['orig_merchant'], r['orig_fine'] = r['merchant'], r.get('orig_fine') or _sc.fine(r)
            if e.get('m'):
                r['merchant'] = e['m']
            if e.get('c'):
                r['category'], r['sub'] = _sc.unfine(e['c'])
            if e.get('n'):
                r['spread'] = [int(e['n']), e.get('s') or '']
            r['edited'] = 1; _ne += 1
        print(f'明細修改：套用你改過的 {_ne} 筆')
    # 發票有、帳上沒有（多半是現金）→ invoice_gap.json，生活帳本「發票對照」可以一鍵記成現金或忽略
    _lf = setp('隨手記.json'); _bf = setp('隨手記_完整備份.json')
    _recs = [(x[0], x[1]) for x in (json.load(open(_lf, encoding='utf8')).get('rec', []) if os.path.exists(_lf) else []) if len(x) > 1]
    _full = json.load(open(_bf, encoding='utf8')) if os.path.exists(_bf) else {}
    _ign = list(_full.get('invIgnore') or [])
    _today = datetime.date.today(); _cov = {}
    for r in rows:
        if r['kind'] == 'spend' and r.get('stmt') and (_today - datetime.date.fromisoformat(r['stmt'][:10])).days <= 75:
            _cov[r['bank']] = max(_cov.get(r['bank'], ''), r.get('txn_date') or r['date'])
    _cu = min(_cov.values()) if _cov else ''
    _APPC = {"餐飲","超市便利商店","網購","交通停車加油","旅遊住宿","生活繳費","百貨購物","醫療","教育","運動休閒","保險","汽車保養","稅款","房貸","其他"}
    _g, _mt = _sc.gaps(rows, _roots, _recs, _cu, json.load(open('config.json')).get('start', '') if os.path.exists('config.json') else '', _ign)
    for x in _g:
        c = categorize(x['seller'] + ' ' + x['items'])
        c = {'醫療教育': '醫療', '稅費': '稅款'}.get(c, c)
        if c not in _APPC or c == '其他':
            c = {'食品飲料': '餐飲', '3C家電': '百貨購物', '居家生活': '百貨購物', '服飾美妝': '百貨購物', '運動戶外': '運動休閒'}.get(x['cls'], '其他')
        x['cat'] = c
    json.dump({'cover_until': _cu, 'gaps': _g, 'matched': _mt}, open('invoice_gap.json', 'w', encoding='utf8'), ensure_ascii=False, indent=0)
    _k = collections.Counter(x['kind'] for x in _g)
    print(f'電子發票：已對上 {len(_mt)} 張；帳上沒有 {_k["cash"]} 張（多半是現金）、悠遊卡／禮券小額 {_k["ez"]} 張（不用記）、帳單可能還沒到 {_k["recent"]} 張')
except Exception as _e:
    print('子分類略過：', _e)
# 帳單沒寫卡名的卡（中信圖片帳單、遠東、富邦…）：名稱後面加「常刷：最常刷的店」，同一家銀行好幾張卡才分得出來
_fb = collections.defaultdict(collections.Counter)
for r in rows:
    if r['cardname'] == f"{r['bank']}卡 ·{r.get('card')}" and r['amount'] > 0 and r['category'] != '回饋折抵':
        _fb[r['cardname']][re.sub(r'\s*(股份有限公司|有限公司|－.*|-.*)$', '', r['merchant'])[:8]] += 1
for r in rows:
    if r['cardname'] in _fb:
        _top = [m for m, _ in _fb[r['cardname']].most_common(2)]
        r['cardname'] = r['cardname'].replace(' ·', f'（常刷：{"、".join(_top)}） ·')
json.dump(rows, open('rows.json', 'w'), ensure_ascii=False, indent=0)
c = collections.Counter(r['category'] for r in rows)
s = collections.defaultdict(float)
for r in rows:
    s[r['category']] += r['amount']
for k, v in sorted(s.items(), key=lambda x: -x[1]):
    print(f'{k:8} {v:>10.0f} {c[k]}')
print(len(rows))
oth = collections.defaultdict(float)
for r in rows:
    if r['category'] == '其他':
        oth[r['merchant']] += r['amount']
print(sorted(oth.items(), key=lambda x: -abs(x[1]))[:80])
