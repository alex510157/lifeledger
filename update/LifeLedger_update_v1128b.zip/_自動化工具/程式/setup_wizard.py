# LifeLedger 設定精靈：帳單密碼、隨手記、信箱收帳單、每月自動寄月報（Gmail）、加密線上版（GitHub Pages）
# 用法：雙擊 _自動化工具\設定精靈.bat；每一項都可以按 Enter 跳過，之後隨時再跑
# 密碼只寫進這台電腦的 設定\local_settings.json，不會上傳
import os, sys, json, getpass, subprocess, re
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from paths import setp

P = setp('local_settings.json')
S = json.load(open(P, encoding='utf8'))


def ask(q, default=''):
    a = input(f'{q}' + (f'［Enter＝{default}］' if default else '') + '：').strip()
    return a or default


def yes(q):
    return input(q + '（Y／N）：').strip().lower() in ('y', 'yes', '是', '好')


def blank(v):
    return not v or '填' in str(v) or '產生' in str(v)


def save():
    json.dump(S, open(P, 'w', encoding='utf8'), ensure_ascii=False, indent=1)


print('\n========== LifeLedger 生活總帳 設定精靈 ==========\n')

# ---------- 0. 帳單 PDF 密碼 ----------
PP = setp('passwords.json')
PW = json.load(open(PP, encoding='utf8')) if os.path.exists(PP) else {}
have = [('生日' if k == 'birthday' else k) for k, v in PW.items() if v and k != '說明']
print('【0】信用卡帳單 PDF 的開啟密碼', f'（目前已設定：{"、".join(have)}）' if have else '（目前：沒設定）')
if yes('要設定或修改嗎？'):
    print('  大部分銀行的帳單密碼是「身分證字號」（英文大寫），少數是生日或身分證後幾碼，請看銀行寄帳單的通知信。')
    print('  密碼只存在這台電腦的 設定\\passwords.json，畫面不會顯示。不改就直接 Enter。\n')
    d = getpass.getpass('  大部分銀行共用的密碼（通常是身分證字號）：').strip()
    if d:
        PW['default'] = d
    print('  有些銀行用生日當密碼（例如星展是 8 碼數字）。填生日的話，程式會自動試常見組合：生日 8 碼、民國生日、月日、身分證後 4 碼＋月日。')
    bd = getpass.getpass('  你的生日，西元 8 碼例如 19850406（不想填就 Enter；畫面不會顯示）：').strip()
    if re.fullmatch(r'\d{8}', bd):
        PW['birthday'] = bd; print('  ✓ 已記下（只存在這台電腦）')
    elif bd:
        print('  格式不對（要 8 碼數字），略過')
    print('  有哪家銀行的密碼跟上面不一樣？任何銀行都可以（例如 兆豐、第一、LINE Bank），一次輸入一家，打完直接 Enter 結束。')
    print('  （同一家不同帳單密碼不同也沒關係：程式會把你存的每一組密碼都試一遍）')
    while True:
        b = input('  銀行簡稱（Enter＝結束）：').strip()
        if not b:
            break
        v = getpass.getpass(f'  {b} 的帳單密碼（畫面不會顯示）：').strip()
        if v:
            PW[b] = v; print(f'  ✓ {b} 已記下')
    PW.setdefault('說明', '各銀行帳單 PDF 的開啟密碼；default 是共用的，銀行名稱的那一行會優先使用')
    json.dump(PW, open(PP, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
    print('  ✓ 已存好')

# ---------- 0b. 隨手記 ----------
L = S.setdefault('ledger', {'url': 'https://alexledger.netlify.app', 'user': '', 'password': ''})
print('\n【0b】手機隨手記（記現金、收入，跟帳單自動對照）', '（目前：已設定帳號 ' + L.get('user', '') + '）' if not blank(L.get('user')) and L.get('user') else '（目前：沒設定）')
if yes('要設定或修改嗎？'):
    print('  先用手機打開隨手記網址 → 建立帳號（需要邀請碼，跟分享給你的人拿），再把同一組帳號密碼填在這裡。')
    print('  設好之後：每天更新完，月報和生活帳本會用你的密碼加密放到隨手記網站，用同一組帳號就能看（別人、包括網站管理者都解不開）。')
    L['url'] = ask('  隨手記網址', L.get('url') or 'https://alexledger.netlify.app')
    L['user'] = ask('  隨手記帳號', '' if blank(L.get('user')) else L.get('user'))
    pw = getpass.getpass('  隨手記密碼（畫面不會顯示；不改就直接 Enter）：')
    if pw:
        L['password'] = pw
    save(); print('  ✓ 已存好，下次更新會自動抓隨手記')

# ---------- 0c. 信箱（直接從信箱收帳單：任何銀行、好幾個信箱都可以） ----------
MB = S.setdefault('mailboxes', [])
print('\n【0c】從信箱自動收帳單（任何銀行的信用卡帳單、存款／綜合對帳單）',
      '（目前：' + '、'.join(b.get('name') or b.get('user') or b.get('account') or 'Outlook' for b in MB) + '）' if MB else '（目前：沒設定）')
print('  已經用 Google Apps Script 存到雲端硬碟的 Gmail 不用再設；Yahoo、HiNet、第二個 Gmail、Outlook 收的信才需要。')
if yes('要新增或修改信箱嗎？'):
    while True:
        if MB:
            print('  目前的信箱：')
            for i, b in enumerate(MB, 1):
                print(f'   {i}. {b.get("name")}（{b.get("type")}）')
        print('  要做什麼？ 1) 新增 Gmail  2) 新增 Yahoo  3) 新增 HiNet  4) 新增其他信箱（IMAP）')
        print('            5) 用電腦上的 Outlook（傳統版）收信  6) 刪掉一個  Enter＝結束')
        c = input('  選：').strip()
        if not c:
            break
        if c == '6' and MB:
            i = input('  刪第幾個：').strip()
            if i.isdigit() and 1 <= int(i) <= len(MB):
                print('  已刪除', MB.pop(int(i) - 1).get('name'))
            continue
        if c == '5':
            print('  Outlook 要是「傳統版」（檔案 → 選項 那種）；新版 Outlook 不支援，請改選 1–4 或在 Outlook.com 設定轉寄到 Gmail。')
            acc = ask('  只收 Outlook 裡的某一個信箱？填信箱地址的一部分（Enter＝全部信箱都收）')
            mb = {'type': 'outlook', 'name': 'Outlook' + (f'（{acc}）' if acc else ''), 'account': acc}
        elif c in ('1', '2', '3', '4'):
            tip = {'1': '先到 https://myaccount.google.com/apppasswords 建一組「應用程式密碼」（要先開兩步驟驗證），貼 16 碼那組。',
                   '2': '到 Yahoo 帳號安全性（https://login.yahoo.com/myaccount/security）→「產生應用程式密碼」，貼那組密碼。',
                   '3': 'HiNet 信箱直接用信箱密碼（先到 HiNet 網頁信箱確認有開 IMAP／POP3 收信）。',
                   '4': '公司或其他信箱：要知道 IMAP 主機名稱（例如 imap.xxx.com），問 IT 或看信箱說明。'}[c]
            print('  ' + tip)
            user = ask('  信箱地址')
            if not user:
                continue
            mb = {'type': 'imap', 'name': user, 'user': user}
            if c == '3' and '@' not in user:
                mb['user'] = user + '@ms1.hinet.net'
            if c == '4':
                mb['host'] = ask('  IMAP 主機'); mb['port'] = int(ask('  連接埠', '993'))
            mb['password'] = getpass.getpass('  密碼（畫面不會顯示）：').strip().replace(' ', '') if c in ('1', '2') else getpass.getpass('  密碼（畫面不會顯示）：')
        else:
            continue
        MB[:] = [b for b in MB if not (b.get('type') == mb['type'] and (b.get('user') or b.get('account')) == (mb.get('user') or mb.get('account')))]
        MB.append(mb); save()
        print('  測試連線中（只看信、不存檔）…')
        r = subprocess.run([sys.executable, 'mail_fetch.py', '--test', '--since', (__import__('datetime').date.today() - __import__('datetime').timedelta(days=90)).isoformat()],
                           capture_output=True, text=True, encoding='utf8', errors='replace')
        print('  ' + (r.stdout + r.stderr).strip()[-800:].replace('\n', '\n  '))
    if MB and blank(S.get('my_name')):
        print('\n  同一個信箱也會收到家人（例如小孩）帳戶的存款對帳單嗎？填你在對帳單上的名字，就只收你的；不會就直接 Enter。')
        print('  （中間的字可以用 . 代替，例如 王.明 就會認得 王小明、王＊明）')
        nm = input('  你的名字：').strip()
        if nm:
            S['my_name'] = nm
    save(); print('  ✓ 已存好。每次更新會先收信；第一次會從 2025/01/01 補抓（要幾分鐘）')

# ---------- 1. 每月寄月報 ----------
M = S.setdefault('mail', {})
print('【1】每月自動寄月報到信箱', '（目前：已開啟）' if M.get('enabled') else '（目前：沒開）')
if yes('要設定或修改嗎？'):
    print('\n  需要一組 Gmail「應用程式密碼」（16 碼，不是你的 Gmail 密碼）。先在瀏覽器準備好，再回來這裡：')
    print('  1) 先開「兩步驟驗證」：https://myaccount.google.com/signinoptions/twosv （已經開了就跳過）')
    print('  2) 打開 https://myaccount.google.com/apppasswords → 應用程式名稱打 LifeLedger → 建立')
    print('  3) 畫面跳出 4 組共 16 個英文字母，按複製（或抄下來），之後在這裡貼上')
    print('  ※ 網頁顯示「你要找的設定不適用於你的帳戶」＝兩步驟驗證還沒開好；拿不到密碼就先按 Enter 跳過，之後再跑一次精靈\n')
    M['from'] = ask('  寄件的 Gmail', '' if blank(M.get('from')) else M.get('from'))
    M['to'] = ask('  收月報的信箱', M.get('to') or M['from'])
    pw = getpass.getpass('  貼上 16 碼應用程式密碼（畫面不會顯示，貼上後按 Enter；不改就直接 Enter）：').replace(' ', '')
    if pw:
        M['app_password'] = pw
    day = ask('  每月幾號寄', str(M.get('mail_day', 12)))
    M['mail_day'] = int(day) if day.isdigit() else 12
    if blank(M.get('app_password')) or not M.get('from'):
        print('  ⚠ 寄件信箱或應用程式密碼沒填，先不開啟'); M['enabled'] = False
    else:
        try:
            import smtplib
            with smtplib.SMTP_SSL('smtp.gmail.com', 465, timeout=20) as s:
                s.login(M['from'], M['app_password'])
            M['enabled'] = True; print('  ✓ Gmail 登入測試成功，之後每月', M['mail_day'], '號後的第一次更新會寄出月報')
        except Exception as e:
            M['enabled'] = False; print('  ✗ Gmail 登入失敗（', str(e)[:120], '）→ 先不開啟，請確認應用程式密碼後再跑一次精靈')
    save()

# ---------- 2. 加密線上版 ----------
W = S.setdefault('web', {})
print('\n【2】加密線上版（手機也能看月報、生活帳本；網址公開但內容要密碼才能解開）', '（目前：已開啟）' if W.get('enabled') else '（目前：沒開）')
if yes('要設定或修改嗎？'):
    print('\n  需要一個 GitHub 帳號（免費）和一組權杖：')
    print('  1) 瀏覽器打開 https://github.com/settings/tokens/new （沒有帳號先註冊）')
    print('  2) Note 打 LifeLedger，Expiration 選 No expiration，勾選 public_repo → 最下面 Generate token')
    print('  3) 複製 ghp_ 開頭的那串\n')
    tk = getpass.getpass('  貼上 GitHub 權杖（畫面不會顯示；不改就直接 Enter）：').strip()
    if tk:
        W['token'] = tk
    while True:
        wp = getpass.getpass('  設定「看網頁用的密碼」（至少 8 個字；不改就直接 Enter）：')
        if not wp:
            break
        if len(wp) < 8:
            print('  密碼太短，至少 8 個字'); continue
        if getpass.getpass('  再輸入一次：') != wp:
            print('  兩次不一樣，重來'); continue
        W['password'] = wp; break
    W['repo'] = W.get('repo') if W.get('repo') not in (None, '', 'cardflow') else 'lifeledger'
    if blank(W.get('token')) or blank(W.get('password')) or len(str(W.get('password'))) < 8:
        print('  ⚠ 權杖或網頁密碼沒填好，先不開啟'); W['enabled'] = False
    else:
        try:
            import cryptography  # noqa
        except ImportError:
            print('  安裝加密套件…'); subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', 'cryptography'])
        W['enabled'] = True; save()
        print('  上傳中（第一次會建立網站，約 1 分鐘）…')
        r = subprocess.run([sys.executable, 'publish_web.py', '--force'], capture_output=True, text=True, encoding='utf8', errors='replace')
        print('  ' + (r.stdout + r.stderr).strip()[-600:].replace('\n', '\n  '))
        if r.returncode == 0 and os.path.exists('web_url.txt'):
            print('  ✓ 線上版網址：', open('web_url.txt', encoding='utf8').read().strip(), '（GitHub 第一次開站要等 1–3 分鐘才打得開）')
        else:
            W['enabled'] = False; print('  ✗ 上傳沒成功，先不開啟；看上面的訊息，修正後再跑一次精靈')
    save()

print('\n設定完成。之後每天 07:30 的自動更新會照這些設定執行。')
