import os
# 分期付款計畫彙整 → plans.json（依 銀行／商家／卡／期數／每期金額，串接連續期數）
import json
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from banks import web_safe as _bkws
R = _bkws(json.load(open('rows.json')))
def addm(ym, k):
    y, m = int(ym[:4]), int(ym[5:7]); t = y * 12 + (m - 1) + k
    return f'{t // 12}-{t % 12 + 1:02d}'
xs = sorted([r for r in R if r['installment'] and r['inst_N']], key=lambda r: (r['stmt'], r['inst_n']))
open_plans = []
for r in xs:
    cand = [p for p in open_plans if p['bank'] == r['bank'] and p['merchant'] == r['merchant'] and p['N'] == r['inst_N']
            and p['card'] == r['cardname'] and p['last_n'] == r['inst_n'] - 1 and abs(p['per'] - r['amount']) <= max(5, 0.02 * r['amount']) and p['last_stmt'] < r['stmt']]
    if cand:
        p = cand[0]
    else:
        p = dict(bank=r['bank'], merchant=r['merchant'], card=r['cardname'], N=r['inst_N'], per=r['amount'], rows=[],
                 start=addm(r['stmt'][:7], -(r['inst_n'] - 1)), category=r['category'], last_n=0, last_stmt='')
        open_plans.append(p)
    p['rows'].append(r); p['last_n'] = r['inst_n']; p['last_stmt'] = r['stmt']; p['per'] = r['amount']
LAST = max(r['stmt'][:7] for r in R)
plans = []
for p in open_plans:
    amt = [r['amount'] for r in p['rows']]; per = round(sum(amt) / len(amt))
    left = max(0, p['N'] - p['last_n'])
    if addm(p['start'], p['N'] - 1) < LAST:
        left = 0
    plans.append(dict(bank=p['bank'], merchant=p['merchant'], card=p['card'], N=p['N'], start=p['start'], end=addm(p['start'], p['N'] - 1),
                      paid=p['N'] - left if left == 0 else p['last_n'], left=left, per=per, total=per * p['N'],
                      remain=left * per, category=p['category'], last_stmt=p['last_stmt']))
plans.sort(key=lambda p: (p['left'] == 0, p['end']))
json.dump(plans, open('plans.json', 'w'), ensure_ascii=False)
act = [p for p in plans if p['left'] > 0]
print(len(plans), 'active', len(act), 'remaining', sum(p['remain'] for p in act))
for p in act: print(p['bank'], p['merchant'], p['N'], p['paid'], p['per'], p['remain'], p['start'], p['end'], p['last_stmt'])
