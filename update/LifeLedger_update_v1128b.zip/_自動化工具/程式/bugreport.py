# 回報問題：把「紀錄」資料夾等打包成 zip，用管理者公鑰加密後上傳到隨手記網站；只有管理者的私鑰解得開
#   打包內容：紀錄\*.txt（每個檔只留最後一段）、健檢報告、版本、設定摘要（不含任何密碼、權杖、帳號）、你寫的說明
#   加密：隨機 AES-256-GCM 金鑰加密 zip（AAD="cf-bugreport:v1"），AES 金鑰再用管理者公鑰 RSA-OAEP-SHA256 包起來
#   沒有隨手記帳號、網站沒設管理者公鑰、或沒網路：改成存在 紀錄\問題回報_<時間>.zip，自己傳給管理者
import io, json, os, re, sys, zipfile, datetime, platform, glob

PROG = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(PROG)
sys.path.insert(0, PROG)
from paths import setp
import ledger_client as LC

AAD = b'cf-bugreport:v1'
PER_FILE = 400 * 1024        # 每個紀錄檔只留最後 400 KB
TOTAL = 3 * 1024 * 1024      # zip 最大約 3 MB（base64 後 4 MB，伺服器上限 4.4 MB）


def _load(p, d):
    try:
        return json.load(open(p, encoding='utf8'))
    except Exception:
        return d


def settings_summary():
    """設定摘要：只有「有沒有設定」和數量，不含任何密碼、權杖、帳號、信箱地址"""
    S = _load(setp('local_settings.json'), {}); PW = _load(setp('passwords.json'), {})
    M = S.get('mail') or {}; W = S.get('web') or {}; L = S.get('ledger') or {}
    return {
        'ledger': {'url': L.get('url'), 'has_user': bool(L.get('user')) and '填' not in str(L.get('user')), 'has_password': bool(L.get('password'))},
        'bill_passwords': {'default': bool(PW.get('default')), 'birthday': bool(PW.get('birthday')),
                           'banks': sorted(k for k, v in PW.items() if k not in ('default', 'birthday', '說明') and v)},
        'mailboxes': [{'type': b.get('type'), 'domain': (b.get('user') or '').split('@')[-1] if b.get('user') else '', 'host': b.get('host', ''),
                       'has_password': bool(b.get('password'))} for b in S.get('mailboxes', [])],
        'mail': {'enabled': bool(M.get('enabled')), 'mail_day': M.get('mail_day')},
        'web': {'enabled': bool(W.get('enabled')), 'repo': W.get('repo')},
        'report_start': S.get('report_start'), 'bills_folders': len(S.get('bills', [])), 'out_set': bool(S.get('out')),
        'spouse_names': len(S.get('spouse_names', [])), 'poppler_bin': S.get('poppler_bin'),
    }


def _tail(p, n):
    with open(p, 'rb') as f:
        f.seek(0, 2); size = f.tell(); f.seek(max(0, size - n)); data = f.read()
    return ('...(前面省略)\n'.encode('utf8') if size > n else b'') + data


def build_zip(note=''):
    """回傳 (zip bytes, 內容清單)"""
    S = _load(setp('local_settings.json'), {})
    home = S.get('out') or os.path.dirname(TOOLS)
    meta = {'time': datetime.datetime.now().isoformat(timespec='seconds'), 'note': note[:4000],
            'user': ((S.get('ledger') or {}).get('user') or ''), 'version': _load(os.path.join(PROG, 'version.json'), {}),
            'windows': platform.platform(), 'python': sys.version.split()[0]}
    buf = io.BytesIO(); names = []
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('說明.json', json.dumps(meta, ensure_ascii=False, indent=1)); names.append('說明.json')
        z.writestr('設定摘要.json', json.dumps(settings_summary(), ensure_ascii=False, indent=1)); names.append('設定摘要.json')
        logs = sorted(glob.glob(os.path.join(TOOLS, '紀錄', '*.txt')), key=os.path.getmtime, reverse=True)   # 新的先放
        for p in logs:
            if buf.tell() > TOTAL - PER_FILE:
                break
            n = '紀錄/' + os.path.basename(p); z.writestr(n, _tail(p, PER_FILE)); names.append(n)
        # 帳本資料夾裡有哪些資料夾、各幾份 PDF（只有數量，不含檔名內容）
        tree = {}
        for d in sorted(os.listdir(home)) if os.path.isdir(home) else []:
            dp = os.path.join(home, d)
            if os.path.isdir(dp) and not d.startswith('_自動化工具'):
                tree[d] = len(glob.glob(os.path.join(dp, '**', '*.[Pp][Dd][Ff]'), recursive=True))
        z.writestr('資料夾.json', json.dumps(tree, ensure_ascii=False, indent=1)); names.append('資料夾.json')
        for f in ('config.json',):
            p = os.path.join(PROG, f)
            if os.path.exists(p):
                z.writestr('程式/' + f, open(p, 'rb').read()); names.append('程式/' + f)
    return buf.getvalue(), names


def _no_secret(summary):
    """單元測試用：確認摘要裡沒有任何密碼值"""
    S = _load(setp('local_settings.json'), {}); PW = _load(setp('passwords.json'), {})
    vals = [v for v in PW.values() if isinstance(v, str) and len(v) >= 3 and v != PW.get('說明')]
    L = S.get('ledger') or {}; M = S.get('mail') or {}; W = S.get('web') or {}
    vals += [x for x in (L.get('password'), M.get('app_password'), W.get('token'), W.get('password')) if x]
    vals += [b.get('password') for b in S.get('mailboxes', []) if b.get('password')]
    t = json.dumps(summary, ensure_ascii=False)
    return not any(v in t for v in vals)


def encrypt(data, pub_b64):
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding
    AESGCM = LC._aesgcm()
    pub = serialization.load_der_public_key(LC.b64d(pub_b64))
    key = os.urandom(32); iv = os.urandom(12)
    ct = AESGCM(key).encrypt(iv, data, AAD)
    ek = pub.encrypt(key, padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
    import hashlib
    return {'v': 1, 'alg': 'RSA-OAEP-256+A256GCM', 'kid': hashlib.sha256(pub_b64.encode('ascii')).hexdigest()[:16],
            'ek': LC.b64e(ek), 'iv': LC.b64e(iv), 'ct': LC.b64e(ct)}


def decrypt(rep, private_key):
    """管理者用：rep 是伺服器存的那份，private_key 是 cryptography 的私鑰物件 → zip bytes"""
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import padding
    AESGCM = LC._aesgcm()
    key = private_key.decrypt(LC.b64d(rep['ek']), padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
    return AESGCM(key).decrypt(LC.b64d(rep['iv']), LC.b64d(rep['ct']), AAD)


def save_local(data):
    p = os.path.join(TOOLS, '紀錄', f'問題回報_{datetime.datetime.now():%Y%m%d_%H%M%S}.zip')
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'wb').write(data)
    return p


def send(note=''):
    """打包、加密、上傳。回傳 {'ok': True, 'id': ...} 或 {'ok': False, 'reason': ..., 'saved': 本機 zip 路徑}"""
    data, names = build_zip(note)
    S = _load(setp('local_settings.json'), {}); L = S.get('ledger') or {}
    if not (L.get('url') and L.get('user') and L.get('password')) or '填' in str(L.get('user')):
        return {'ok': False, 'reason': 'no_account', 'saved': save_local(data), 'files': names}
    try:
        C = LC.Client(L, ua='LifeLedger-bugreport')
        st, j = C._http('GET', '/api/ledger?action=pubkey')
        if st != 200 or not (isinstance(j, dict) and j.get('pubkey')):
            return {'ok': False, 'reason': 'no_pubkey', 'saved': save_local(data), 'files': names}
        rep = encrypt(data, j['pubkey'])
        st, r = C.call('POST', '/api/ledger?action=bugreport', rep, timeout=120)
        if st == 200 and isinstance(r, dict) and r.get('ok'):
            return {'ok': True, 'id': r.get('id'), 'files': names, 'size': len(data)}
        return {'ok': False, 'reason': (r or {}).get('code') or (r or {}).get('error') or f'HTTP {st}', 'saved': save_local(data), 'files': names}
    except Exception as e:
        return {'ok': False, 'reason': str(e)[:200], 'saved': save_local(data), 'files': names}


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    print(json.dumps(send(' '.join(sys.argv[1:])), ensure_ascii=False))
