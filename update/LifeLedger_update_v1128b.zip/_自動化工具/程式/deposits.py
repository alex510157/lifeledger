# 存款與資產：從各銀行的「存款／綜合對帳單」抓
#   1. 每月帳上餘額（資產總計，含外幣折台幣）與貸款餘額
#   2. 利息收入（交易明細裡的 利息／活存息／結息 存入）
# 對帳單 PDF 來源：
#   - 信用卡資料夾裡的綜合對帳單（永豐「電子綜合對帳單」、星展「MTHLYSTMT」…，信用卡解析會跳過它們）
#   - _收入/<銀行>存款 資料夾（Gmail 自動抓帳單程式存的，例如 富邦存款）
# 輸出 deposits.json：{"stmts":[{bank, month, file, balance, loan, interest:[[date, amount, note]]}], "latest":{bank: {...}}}
import os, re, sys, json, glob, unicodedata, subprocess, datetime
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from paths import setp, HOME, card_roots, deposit_roots

nf = lambda s: unicodedata.normalize('NFKC', s)
DEP = re.compile(r'綜合對帳單|MTHLYSTMT|銀行對帳單|存款對帳單|存款', re.I)
NOT = re.compile(r'信用卡|card|Creditcard|DAILYSTMT|PaymentSlip|繳款', re.I)
BANKS = ['富邦', '永豐', '星展', '台新', '玉山', '中信', '國泰', '渣打', '合庫', '聯邦', '遠東', '第一', '華南', '彰化', '兆豐', '土銀', '郵局', 'LINE Bank', '將來', '樂天']


def bank_of(path):
    for b in BANKS:
        if b in path:
            return b
    return os.path.basename(os.path.dirname(path)).replace('存款', '')


def sources():
    S = json.load(open(setp('local_settings.json'), encoding='utf8'))
    roots = [p for p in dict.fromkeys(S.get('bills', []) + [S.get('out', ''), os.environ.get('CARDFLOW_OUT', ''), HOME]) if p and os.path.isdir(p)]
    seen, out = set(), []
    for r in roots:
        for f in [x for c in card_roots(r) + deposit_roots(r) for x in glob.glob(os.path.join(c, '*', '*.[Pp][Dd][Ff]'))]:   # 帳單\信用卡（永豐、星展的綜合對帳單）、帳單\存款對帳單；舊版面也讀
            fn = os.path.basename(f); folder = os.path.basename(os.path.dirname(f))
            if folder.startswith(('月報', '_備份', 'Claude')) or folder == '_收入' or '薪資' in folder:
                continue
            if not (DEP.search(fn) or folder.endswith('存款')) or NOT.search(fn) or fn in seen:
                continue
            seen.add(fn); out.append(f)
    return sorted(out)


def receipts():
    """只寄通知信、沒有 PDF 的銀行（LINE Bank 互動式對帳單）：Gmail 自動抓帳單程式會存一個「對帳單收到了」的 .txt"""
    S = json.load(open(setp('local_settings.json'), encoding='utf8'))
    roots = [p for p in dict.fromkeys(S.get('bills', []) + [S.get('out', ''), os.environ.get('CARDFLOW_OUT', ''), HOME]) if p and os.path.isdir(p)]
    out = {}
    for r in roots:
        for f in [x for c in deposit_roots(r) for x in glob.glob(os.path.join(c, '*存款', '*_對帳單通知.txt'))]:
            b = bank_of(f); fn = os.path.basename(f)
            m = re.search(r'(20\d\d)年(\d{1,2})月', fn)
            ym = f'{m.group(1)}-{int(m.group(2)):02d}' if m else month_of(f, '')
            if ym:
                out.setdefault(b, {})[ym] = fn[:10]
    return out


def to_text(files):
    PW = json.load(open(setp('passwords.json'), encoding='utf8')) if os.path.exists(setp('passwords.json')) else {}
    os.makedirs('dep_txt', exist_ok=True)
    res = []
    for f in files:
        out = os.path.join('dep_txt', bank_of(f) + '__' + os.path.splitext(os.path.basename(f))[0] + '.txt')
        if not os.path.exists(out):
            import pikepdf
            for pw in [v for v in PW.values() if isinstance(v, str) and v] + ['']:
                try:
                    pikepdf.open(f, password=pw).save('dep_tmp.pdf'); break
                except pikepdf.PasswordError:
                    pass
                except Exception:
                    break
            else:
                print('  存款對帳單打不開（密碼不對）：', os.path.basename(f)); continue
            if not os.path.exists('dep_tmp.pdf'):
                continue
            subprocess.run(['pdftotext', '-layout', 'dep_tmp.pdf', out]); os.remove('dep_tmp.pdf')
        res.append((bank_of(f), f, out))
    return res


NUM = r'-?[\d,]+(?:\.\d+)?'
num = lambda s: float(s.replace(',', ''))
INT = re.compile(r'利息|活存息|結息|存款息|息\s*存入|INT\d')
FX = re.compile(r'\((日圓|美元|歐元|港幣|人民幣|澳幣|英鎊|新加坡幣|加拿大幣|瑞士法郎|紐西蘭幣|泰銖|南非幣)\)|外幣活存|外幣存款明細|外幣帳戶')
TWD = re.compile(r'\(新臺幣\)|\(新台幣\)|台幣活存|臺幣活存|新臺幣活期|新台幣活期|台幣存款明細')


def month_of(path, text):
    fn = nf(os.path.basename(path))
    m = re.search(r'(20\d\d)\s*年\s*(\d{1,2})\s*月', fn) or re.search(r'(1\d\d)\s*年\s*(\d{1,2})\s*月', fn)
    if m:
        y = int(m.group(1)); y = y + 1911 if y < 1000 else y
        return f'{y}-{int(m.group(2)):02d}'
    m = re.search(r'(20\d\d)-(\d\d)-(\d\d)', fn)   # 存檔日期 → 對帳單是上個月的
    if m:
        d = datetime.date(int(m.group(1)), int(m.group(2)), 1) - datetime.timedelta(days=1)
        return d.strftime('%Y-%m')
    return ''


def parse(bank, path, txt):
    t = nf(open(txt, encoding='utf8', errors='ignore').read())
    bal = None
    if bank == '玉山':   # 玉山「總資產現值」含保險累積保費，只算存款：存款表的 TWD 餘額
        xs = re.findall(r'^\s*\S*(?:活存|活儲|定存|存款)\s+\S+\s+TWD\s+(' + NUM + r')\s*$', t, re.M)
        if xs:
            bal = sum(num(x) for x in xs)
    for pat in (r'資產總計\s+(' + NUM + ')', r'資產總額\s+(' + NUM + ')', r'^\s*合計\s+\$?(' + NUM + r')\s*$', r'合計\s+TWD\s*(' + NUM + ')',
                r'存款總計[^\d\n]*(' + NUM + ')', r'台幣存款總計\s+(' + NUM + ')'):
        if bal is not None:
            break
        m = re.search(pat, t, re.M)
        if m:
            bal = num(m.group(1)); break
    m = re.search(r'貸款(?:餘額)?總計\s+(' + NUM + ')', t)
    loan = num(m.group(1)) if m else 0.0
    ints, fx = [], False
    for l in t.splitlines():
        if FX.search(l):
            fx = True
        elif TWD.search(l):
            fx = False
        d = re.search(r'(?:^|\s)(\d{4}/\d{2}/\d{2})\s+(.*)$', l)
        if not d or not INT.search(d.group(2)) or fx:
            continue
        ns = re.findall(r'(?<![\w/])' + NUM + r'(?![\w/])', d.group(2))
        ns = [x for x in ns if re.search(r'\d', x) and not re.fullmatch(r'\d{6,}', x)]   # 去掉帳號那種沒有逗號的長數字
        if len(ns) >= 2:
            ints.append([d.group(1).replace('/', '-'), num(ns[-2]), bank])
    return dict(bank=bank, month=month_of(path, t), file=os.path.basename(path), balance=bal, loan=loan, interest=ints)


if __name__ == '__main__':
    files = sources()
    rows = [parse(b, p, t) for b, p, t in to_text(files)]
    rows = [r for r in rows if r['month']]
    # 還沒有電子對帳單的帳戶：設定/存款_手動.json（網銀截圖手動記）。同銀行同月份有對帳單就以對帳單為準
    _mp = setp('存款_手動.json')
    _man = json.load(open(_mp, encoding='utf8')) if os.path.exists(_mp) else {}
    _have = {(r['bank'], r['month']) for r in rows}
    _lp = setp('存款_隨手記.json')   # 隨手記 App「設定 → 存款回填」填的（較新，同月份蓋過手動檔）
    _app = json.load(open(_lp, encoding='utf8')).get('balances', []) if os.path.exists(_lp) else []
    _appk = {(x['bank'], x['month']) for x in _app}
    _man['balances'] = [x for x in _man.get('balances', []) if (x['bank'], x['month']) not in _appk] + \
        [dict(bank=x['bank'], month=x['month'], balance=x['balance'], loan=x.get('loan', 0), note='隨手記回填') for x in _app]
    for x in _man.get('balances', []):
        if (x['bank'], x['month']) not in _have:
            rows.append(dict(bank=x['bank'], month=x['month'], file='手動：' + x.get('note', ''), balance=float(x['balance']), loan=float(x.get('loan', 0)), interest=[]))
    _manint = [[x['date'], float(x['amount']), x['bank']] for x in _man.get('interest', [])]
    if _manint:
        rows.append(dict(bank='', month='', file='手動利息', balance=None, loan=0, interest=_manint))
    # 同一銀行同一月份有兩份（重寄）→ 留一份
    uniq = {}
    for r in sorted(rows, key=lambda r: r['file']):
        uniq[(r['bank'], r['month'])] = r
    rows = sorted(uniq.values(), key=lambda r: (r['month'], r['bank']))
    _extra_int = [i for r in rows if r['file'] == '手動利息' for i in r['interest']]
    rows = [r for r in rows if r['file'] != '手動利息']
    latest = {}
    for r in rows:
        if r['balance'] is not None:
            latest[r['bank']] = dict(month=r['month'], balance=r['balance'], loan=r['loan'])
    seen_int, ints = set(), []
    for r in rows + [dict(interest=_extra_int)]:
        for d, a, b in r['interest']:
            if (b, d, a) not in seen_int:
                seen_int.add((b, d, a)); ints.append(dict(date=d, amount=a, bank=b))
    # 每家銀行的對帳單收件狀況：有對帳單就列出（沒錢也列），該到沒到的月份提醒
    today = datetime.date.today()
    recv = {}   # bank → {month: 收到日}
    for r in rows:
        if not r['file'].startswith('手動'):
            d = re.match(r'(\d{4}-\d{2}-\d{2})_', r['file'])
            recv.setdefault(r['bank'], {})[r['month']] = d.group(1) if d else ''
    for b, ms in receipts().items():
        for ym, d in ms.items():
            recv.setdefault(b, {}).setdefault(ym, d)
    for x in _man.get('received', []):   # 手動補的收件紀錄（例如 Gmail 裡已經收到的 LINE Bank 通知信）
        for ym in x['months']:
            recv.setdefault(x['bank'], {}).setdefault(ym, '')
    def ym_add(ym, n):
        y, m = int(ym[:4]), int(ym[5:]) + n
        while m < 1: y -= 1; m += 12
        while m > 12: y += 1; m -= 12
        return f'{y}-{m:02d}'
    status = []
    for b, ms in recv.items():
        days = sorted(int(d[8:10]) for d in ms.values() if d)
        due_day = (days[int(len(days) * .9) - 1] if len(days) >= 3 else 15) + 3   # 這家銀行通常幾號前寄到（取九成的日子＋3 天緩衝）
        last_due = ym_add(today.strftime('%Y-%m'), -1 if today.day > due_day else -2)
        try:
            _start = json.load(open('config.json', encoding='utf8')).get('start', '2025-01')
        except Exception:
            _start = '2025-01'
        first = max(min(ms), _start)   # 帳本開始之前的月份不提醒
        span = []
        ym = first
        while ym <= last_due:
            span.append(ym); ym = ym_add(ym, 1)
        got = [m for m in span if m in ms]
        regular = len(span) <= 2 or len(got) / len(span) >= .6
        miss = [m for m in span if m not in ms] if regular else []
        bal = latest.get(b, {}).get('balance')
        status.append(dict(bank=b, received=sorted(ms), last=max(ms), balance=bal, bal_month=latest.get(b, {}).get('month', ''),
                           missing=[m for m in miss if m >= _start][-12:], regular=regular, due_day=due_day))
    _due = ym_add(today.strftime('%Y-%m'), -1 if today.day > 5 else -2)   # 手動回填：每月 5 號後要有上個月底的餘額
    for b in latest:
        if b not in recv:   # 只有手動回填的（網銀截圖、隨手記回填）
            miss, ym = [], ym_add(latest[b]['month'], 1)
            while ym <= _due:
                miss.append(ym); ym = ym_add(ym, 1)
            status.append(dict(bank=b, received=[], last=latest[b]['month'], balance=latest[b]['balance'], bal_month=latest[b]['month'], missing=miss[-6:], regular=True, manual=True))
    for x in status:   # 有收件紀錄但讀不到餘額（LINE Bank）：用回填的餘額
        if x['balance'] is None and x['bank'] in latest:
            x['balance'] = latest[x['bank']]['balance']; x['bal_month'] = latest[x['bank']]['month']
    status.sort(key=lambda x: -(x['balance'] or 0))
    json.dump(dict(stmts=rows, latest=latest, status=status, interest=sorted(ints, key=lambda x: x['date'])), open('deposits.json', 'w', encoding='utf8'), ensure_ascii=False, indent=0)
    tot = sum(v['balance'] for v in latest.values())
    for x in status:
        if x['missing']:
            print(f"  ⚠ {x['bank']} 對帳單沒收到：{'、'.join(m.replace('-', '/') for m in x['missing'])}")
        if x['balance'] is None:
            print(f"  · {x['bank']} 有對帳單但讀不到餘額（最新 {x['last']}），可在 設定/存款_手動.json 補")
    print(f'存款對帳單 {len(rows)} 份・銀行 {len(latest)} 家・目前帳上 NT$ {tot:,.0f}・利息 {len(ints)} 筆 NT$ {sum(x["amount"] for x in ints):,.0f}')
