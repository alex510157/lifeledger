# 資料夾位置：程式在「程式」、使用者會改的檔案在「設定」、執行紀錄在「紀錄」
import os
PROG = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(PROG)
SET = os.path.join(ROOT, '設定')
LOG = os.path.join(ROOT, '紀錄')
HOME = os.path.dirname(ROOT)   # 帳本資料夾（_自動化工具 的上一層）：沒設定 out 時的預設輸出位置


def setp(*name):
    return os.path.join(SET, *name)


# ---------- 帳本資料夾的版面：帳單都放在「帳單」底下（layout.py 會把舊版面搬過來） ----------
BILLS = '帳單'
CARD = os.path.join(BILLS, '信用卡')          # 帳單\信用卡\<銀行>\*.pdf
DEPOSIT = os.path.join(BILLS, '存款對帳單')     # 帳單\存款對帳單\<銀行>存款\*.pdf
INVOICE = os.path.join(BILLS, '電子發票')       # 帳單\電子發票\*.csv
SALARY = os.path.join(BILLS, '薪資單')          # 帳單\薪資單\*.pdf


def card_roots(root):
    """放信用卡帳單銀行資料夾的地方：新版面（帳單\信用卡）和舊版面（帳本資料夾本身）都讀"""
    return [p for p in (os.path.join(root, CARD), root) if os.path.isdir(p)]


def deposit_roots(root):
    """放存款對帳單的地方：帳單\存款對帳單（新）、_收入（舊）"""
    return [p for p in (os.path.join(root, DEPOSIT), os.path.join(root, '_收入')) if os.path.isdir(p)]


def invoice_dirs(root):
    """電子發票：帳單\電子發票（新）、_電子發票（舊）"""
    return [p for p in (os.path.join(root, INVOICE), os.path.join(root, '_電子發票')) if os.path.isdir(p)]
