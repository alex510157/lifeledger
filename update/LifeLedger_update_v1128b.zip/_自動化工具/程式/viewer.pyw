# LifeLedger 內建檢視器：另開一個視窗看月報、生活帳本、隨手記（設定成「另開視窗」時，或按「另開視窗」）
#   pythonw viewer.pyw <網址或本機檔案> <視窗標題>
#   用 Windows 內建的 Edge WebView2 顯示；隨手記的登入狀態記在 %LOCALAPPDATA%\LifeLedger\webview（只在這台電腦）
import os, sys, ctypes

PROG = os.path.dirname(os.path.abspath(__file__))
try:   # 跟主視窗同一個工作列圖示
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('LifeLedger.App')
except Exception:
    pass

import webview

target = sys.argv[1] if len(sys.argv) > 1 else 'https://alex510157.github.io/lifeledger/app/'
title = sys.argv[2] if len(sys.argv) > 2 else 'LifeLedger'
store = os.path.join(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~'), 'LifeLedger', 'webview')
os.makedirs(store, exist_ok=True)
win = webview.create_window(f'LifeLedger ・ {title}', target, width=1180, height=820, min_size=(640, 480), text_select=True)


def set_icon():
    """視窗和工作列的圖示換成 LifeLedger 的（不然會是 Python 的）"""
    try:
        import win32gui, win32process
        hs = []
        win32gui.EnumWindows(lambda h, a: a.append(h) if win32gui.IsWindowVisible(h) and win32process.GetWindowThreadProcessId(h)[1] == os.getpid() else None, hs)
        ico = os.path.join(PROG, 'LifeLedger.ico'); u32 = ctypes.windll.user32
        for h in hs:
            for size, which in ((32, 1), (16, 0)):
                hi = u32.LoadImageW(None, ico, 1, size, size, 0x10)
                if hi:
                    u32.SendMessageW(h, 0x80, which, hi)
    except Exception:
        pass


win.events.shown += set_icon
webview.start(private_mode=False, storage_path=store)
