# 讀「信用卡管理總表」（OneDrive\Expense\信用卡管理總表_v*.xlsx，取版本號最大的一份）
# 卡名、正附卡、持卡人、卡號、有效期限、安全碼以總表為準；只在本機讀取，只寫進本機的 LifeLedger Excel「卡片清單」，
# 不寫進 JSON、網頁、月報或任何會上傳的檔案。
import os, re, glob, json

BANK = {'台新銀行': '台新', '永豐銀行': '永豐', '玉山銀行': '玉山', '聯邦銀行': '聯邦', '中國信託銀行': '中信',
        '星展銀行 (DBS)': '星展', '星展銀行': '星展', '國泰世華銀行': '國泰', '遠東商銀': '遠東', '台北富邦銀行': '富邦', '台北富邦': '富邦', '富邦銀行': '富邦', '遠東國際商業銀行': '遠東'}
_BASE = os.path.dirname(os.path.abspath(__file__))


def _path():
    p = os.environ.get('CARD_MASTER')
    if p and os.path.exists(p):
        return p
    try:
        S = json.load(open(os.path.join(os.path.dirname(_BASE), '設定', 'local_settings.json'), encoding='utf8'))
        if S.get('card_master') and os.path.exists(S['card_master']):
            return S['card_master']
        out = S.get('out', '')
    except Exception:
        out = ''
    cands = []
    for d in {os.path.dirname(out.rstrip('\\/')), os.path.dirname(os.path.dirname(os.path.dirname(_BASE)))}:
        cands += glob.glob(os.path.join(d, '信用卡管理總表_v*.xlsx'))
    ver = lambda f: int(re.search(r'_v(\d+)', f).group(1)) if re.search(r'_v(\d+)', f) else 0
    cands = [f for f in cands if not os.path.basename(f).startswith('~$')]
    return max(cands, key=ver) if cands else None


def _mmyy(v):
    if v is None or v == '':
        return ''
    if hasattr(v, 'month'):
        return f'{v.month:02d}/{v.year % 100:02d}'
    s = str(v).strip()
    m = re.match(r'(\d{4})-(\d{2})', s)
    return f'{m.group(2)}/{m.group(1)[2:]}' if m else s


def _short(name):
    return re.sub(r'\s*[（(].*$', '', str(name or '')).strip()


def load():
    """回傳 {(銀行簡稱, 末四碼): dict(name, role, holder, holder_tag, number, expiry, cvv, org, source)}；找不到總表回傳 {}"""
    p = _path()
    if not p:
        return {}
    try:
        from openpyxl import load_workbook
        wb = load_workbook(p, data_only=True, read_only=True)
    except Exception as e:
        print('⚠ 讀不到信用卡管理總表：', e)
        return {}
    out = {}

    def add(bank, name, org, num, exp, cvv, holder, role, tag):
        digits = re.sub(r'\D', '', str(num or ''))
        if not bank or len(digits) < 4:
            return
        b = BANK.get(str(bank).strip(), str(bank).strip()[:2])
        h = str(holder or '')
        label = re.search(r'[（(]([^)）]+)[)）]', h)
        out[(b, digits[-4:])] = dict(
            name=_short(name), role='附卡' if '附' in str(role or '') else '正卡',
            holder_tag=label.group(1) if label else '',
            holder=str(tag).strip() if tag and re.fullmatch(r'[一-鿿]{2,4}', str(tag).strip()) else '',
            number=' '.join(digits[i:i + 4] for i in range(0, len(digits), 4)),
            expiry=_mmyy(exp), cvv=str(cvv or '').strip(), org=str(org or ''), source=os.path.basename(p))

    for ws in wb.worksheets:
        rows = list(ws.iter_rows(values_only=True))
        for i, r in enumerate(rows):
            r = [('' if v is None else v) for v in r]
            if '卡號' not in [str(v) for v in r] or '發卡銀行' not in [str(v) for v in r]:
                continue
            H = {str(v): j for j, v in enumerate(r) if v != ''}
            exp_col = next((j for k, j in H.items() if k.startswith('有效期限')), None)
            for rr in rows[i + 1:]:
                rr = [('' if v is None else v) for v in rr]
                g = lambda k: rr[H[k]] if k in H and H[k] < len(rr) else ''
                if not g('發卡銀行') and not g('卡號'):
                    continue
                add(g('發卡銀行'), g('卡片名稱'), g('組織'), g('卡號'), rr[exp_col] if exp_col is not None and exp_col < len(rr) else '',
                    g('安全碼'), g('持卡人'), g('主/附'), g('卡背標籤'))
    return out


if __name__ == '__main__':
    M = load()
    print('總表：', _path(), '共', len(M), '張')
    for k, v in sorted(M.items()):
        print(k, v['name'], v['role'], v['holder'] or v['holder_tag'], v['expiry'])
