@echo off
chcp 65001 >nul
title LifeLedger 搬到 OneDrive
echo 這會把整個帳本資料夾（帳單、Excel、月報、設定）搬到 OneDrive，換電腦或電腦壞掉資料都還在。
echo 搬之前請先關掉 Excel 和月報網頁。
echo.
choice /C YN /M "要開始搬嗎"
if errorlevel 2 exit /b
rem 先把搬移程式複製到暫存資料夾再執行（不然搬的時候會把自己搬走）
copy /y "%~dp0程式\move_onedrive.ps1" "%TEMP%\ll_move_onedrive.ps1" >nul
rem 這一行一定要是最後一行：執行完這個資料夾已經搬走了
powershell -NoProfile -ExecutionPolicy Bypass -File "%TEMP%\ll_move_onedrive.ps1" -Src "%~dp0.."
