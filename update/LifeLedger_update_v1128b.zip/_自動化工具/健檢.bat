@echo off
chcp 65001 >nul
title LifeLedger 健檢
set "PY="
for %%V in (Python313 Python312 Python311) do if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\%%V\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\%%V\python.exe"
for %%V in (Python313 Python312 Python311) do if not defined PY if exist "C:\Program Files\%%V\python.exe" set "PY=C:\Program Files\%%V\python.exe"
if not defined PY for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PY=%%P"
if not defined PY set "PY=python"
set PYTHONUTF8=1
echo 檢查中（信箱要幾分鐘）...
pushd "%~dp0程式"
"%PY%" health_check.py
popd
echo.
echo 報告在「紀錄\健檢報告.txt」，可以直接傳給幫你設定的人。
start "" notepad "%~dp0紀錄\健檢報告.txt"
pause
