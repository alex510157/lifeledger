@echo off
chcp 65001 >nul
title LifeLedger 補抓舊帳單
set "PY="
for %%V in (Python313 Python312 Python311) do if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\%%V\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\%%V\python.exe"
for %%V in (Python313 Python312 Python311) do if not defined PY if exist "C:\Program Files\%%V\python.exe" set "PY=C:\Program Files\%%V\python.exe"
if not defined PY for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PY=%%P"
if not defined PY set "PY=python"
set PYTHONUTF8=1
pushd "%~dp0程式"
"%PY%" backfill.py
popd
pause
