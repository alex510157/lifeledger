# LifeLedger 生活總帳：桌面小視窗（不會跳出黑色命令視窗）
#   顯示目前版本、檢查／安裝新版、立即更新月報、打開月報與帳本資料夾、帳單密碼與隨手記設定
import os, sys, json, re, threading, queue, subprocess, webbrowser
import tkinter as tk
from tkinter import ttk, messagebox

PROG = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(PROG)
os.chdir(PROG)
sys.path.insert(0, PROG)
import updater
from paths import setp

HOME = os.path.dirname(TOOLS)
exe = sys.executable
_c = os.path.join(os.path.dirname(exe), 'python.exe')
PY = _c if os.path.basename(exe).lower() == 'pythonw.exe' and os.path.exists(_c) else exe
NOWIN = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
ENV = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')


def out_dir():
    try:
        return json.load(open(setp('local_settings.json'), encoding='utf8')).get('out') or HOME
    except Exception:
        return HOME


def open_path(p):
    if os.path.exists(p):
        os.startfile(p)
    else:
        messagebox.showinfo('LifeLedger', '還沒有這個檔案，先按「立即更新月報」產生。\n\n' + p)


class App:
    def __init__(self, root):
        self.root = root; self.q = queue.Queue(); self.busy = False; self.remote = None
        root.title('LifeLedger 生活總帳'); root.geometry('620x520'); root.minsize(520, 420)
        try:
            root.iconbitmap(default=os.path.join(PROG, 'LifeLedger.ico'))   # default：設定視窗也用同一個圖示
        except Exception:
            pass
        st = ttk.Style()
        try:
            st.theme_use('vista')
        except tk.TclError:
            pass
        f = ttk.Frame(root, padding=16); f.pack(fill='both', expand=True)
        ttk.Label(f, text='LifeLedger 生活總帳', font=('Microsoft JhengHei UI', 16, 'bold')).pack(anchor='w')
        vrow = ttk.Frame(f); vrow.pack(fill='x', pady=(6, 10))
        self.ver = ttk.Label(vrow, text='', font=('Microsoft JhengHei UI', 10)); self.ver.pack(side='left')
        self.upd = ttk.Button(vrow, text='檢查更新', command=self.check_update); self.upd.pack(side='right')
        g = ttk.Frame(f); g.pack(fill='x')
        btn = lambda t, c, r, col: ttk.Button(g, text=t, command=c).grid(row=r, column=col, sticky='ew', padx=4, pady=4, ipady=4)
        self.run_btn = ttk.Button(g, text='立即更新月報', command=self.run_report)
        self.run_btn.grid(row=0, column=0, columnspan=3, sticky='ew', padx=4, pady=4, ipady=8)
        btn('打開月報', lambda: open_path(os.path.join(out_dir(), '月報', 'LifeLedger月報.html')), 1, 0)
        btn('打開生活帳本', lambda: open_path(os.path.join(out_dir(), '月報', 'LifeLedger生活帳本.html')), 1, 1)
        btn('打開 Excel', lambda: open_path(os.path.join(out_dir(), 'LifeLedger_生活總帳.xlsx')), 1, 2)
        btn('帳本資料夾', lambda: open_path(out_dir()), 2, 0)
        btn('帳單密碼、隨手記設定', self.settings, 2, 1)
        btn('使用說明', lambda: open_path(os.path.join(TOOLS, '使用說明.md')), 2, 2)
        for c in range(3):
            g.columnconfigure(c, weight=1)
        ttk.Label(f, text='執行過程', foreground='#666').pack(anchor='w', pady=(12, 2))
        lf = ttk.Frame(f); lf.pack(fill='both', expand=True)
        self.log = tk.Text(lf, height=10, wrap='word', font=('Consolas', 9), relief='flat', background='#f6f7f9', state='disabled')
        sb = ttk.Scrollbar(lf, command=self.log.yview); self.log['yscrollcommand'] = sb.set
        self.log.pack(side='left', fill='both', expand=True); sb.pack(side='right', fill='y')
        self.show_version()
        root.after(100, self.pump)
        root.after(300, lambda: self.check_update(quiet=True))
        if self.first_run():
            root.after(600, self.first_setup)

    # ---------- 共用 ----------
    def say(self, s):
        self.q.put(('log', s))

    def pump(self):
        try:
            while True:
                k, v = self.q.get_nowait()
                if k == 'log':
                    self.log['state'] = 'normal'; self.log.insert('end', v.rstrip() + '\n'); self.log.see('end'); self.log['state'] = 'disabled'
                elif k == 'call':
                    v()
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    def show_version(self):
        lv = updater.local_version()
        t = f'目前版本 v{lv["version"]}'
        if self.remote and self.remote['build'] > lv['build']:
            t += f'　　有新版 v{self.remote["version"]}'
            self.upd.config(text=f'更新到 v{self.remote["version"]}', command=self.install_update)
        elif self.remote:
            t += '　　（已是最新版）'
            self.upd.config(text='檢查更新', command=self.check_update)
        self.ver.config(text=t)

    # ---------- 更新程式 ----------
    def check_update(self, quiet=False):
        def work():
            try:
                self.remote = updater.remote_version()
            except Exception as e:
                if not quiet:
                    self.say(f'檢查更新失敗：{e}（可能沒網路，等一下再試）')
                return
            lv = updater.local_version()
            if not quiet:
                self.say(f'有新版 v{self.remote["version"]}' if self.remote['build'] > lv['build'] else f'已經是最新版 v{lv["version"]}')
            self.q.put(('call', self.show_version))
        threading.Thread(target=work, daemon=True).start()

    def install_update(self):
        if self.busy:
            return
        self.busy = True; self.upd.config(state='disabled'); self.say('下載新版中…')

        def work():
            st = updater.check(install=True, log=self.say)[0]

            def done():
                self.busy = False; self.upd.config(state='normal'); self.remote = None; self.show_version()
                if st == 'updated':
                    if messagebox.askyesno('LifeLedger', '更新好了。要重新開啟這個視窗，換成新版嗎？'):
                        subprocess.Popen([sys.executable, os.path.abspath(__file__)], cwd=PROG)
                        self.root.destroy()
                    else:
                        self.check_update(quiet=True)
            self.q.put(('call', done))
        threading.Thread(target=work, daemon=True).start()

    # ---------- 更新月報 ----------
    def run_report(self):
        if self.busy:
            return
        if os.path.exists(os.path.join(PROG, '.running')):
            if not messagebox.askyesno('LifeLedger', '看起來排程正在更新（或上次沒正常結束）。還是要現在更新嗎？'):
                return
        self.busy = True; self.run_btn.config(state='disabled', text='更新中…（約 1–5 分鐘，可以先做別的事）')
        self.log['state'] = 'normal'; self.log.delete('1.0', 'end'); self.log['state'] = 'disabled'

        def work():
            p = subprocess.Popen([PY, 'run_local.py', '--auto'], cwd=PROG, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 env=ENV, creationflags=NOWIN, text=True, encoding='utf8', errors='replace')
            for line in p.stdout:
                if line.strip():
                    self.say(line)
            rc = p.wait()

            def done():
                self.busy = False; self.run_btn.config(state='normal', text='立即更新月報')
                if rc == 0:
                    if messagebox.askyesno('LifeLedger', '月報更新好了，要打開嗎？'):
                        open_path(os.path.join(out_dir(), '月報', 'LifeLedger月報.html'))
                else:
                    messagebox.showwarning('LifeLedger', '更新沒有完成。請把「執行過程」裡的錯誤訊息（或 紀錄 資料夾裡的檔案）傳給管理者看。')
            self.q.put(('call', done))
        threading.Thread(target=work, daemon=True).start()

    # ---------- 設定 ----------
    def first_run(self):
        try:
            S = json.load(open(setp('local_settings.json'), encoding='utf8'))
            L = S.get('ledger') or {}
            has_pw = os.path.exists(setp('passwords.json')) and any(v for k, v in json.load(open(setp('passwords.json'), encoding='utf8')).items() if k != '說明')
            return not has_pw and not (L.get('user') and '填' not in str(L.get('user')))
        except Exception:
            return False

    def first_setup(self):
        messagebox.showinfo('LifeLedger', '歡迎！先填帳單 PDF 的密碼和隨手記帳號（不用的可以空白），之後按「立即更新月報」就好。')
        self.settings()

    def settings(self):
        Settings(self.root, self.say)


class Settings:
    def __init__(self, parent, say):
        self.say = say
        self.PP = setp('passwords.json'); self.SP = setp('local_settings.json')
        self.PW = json.load(open(self.PP, encoding='utf8')) if os.path.exists(self.PP) else {}
        self.S = json.load(open(self.SP, encoding='utf8'))
        w = self.w = tk.Toplevel(parent); w.title('帳單密碼、隨手記設定'); w.geometry('580x470'); w.transient(parent); w.grab_set()
        f = ttk.Frame(w, padding=16); f.pack(fill='both', expand=True)
        H = lambda t: ttk.Label(f, text=t, font=('Microsoft JhengHei UI', 11, 'bold')).pack(anchor='w', pady=(10, 2))
        N = lambda t: ttk.Label(f, text=t, foreground='#666', wraplength=510, justify='left').pack(anchor='w')

        H('信用卡帳單 PDF 的開啟密碼')
        N('大部分銀行是身分證字號（英文大寫）；有些銀行用生日，例如 19850406。密碼只存在這台電腦。已經設定過的不會顯示，空白＝不修改。')
        self.e_def = self.field(f, '大部分銀行共用的密碼', show='•', hint='已設定' if self.PW.get('default') else '')
        self.e_bd = self.field(f, '生日（西元 8 碼，可不填）', show='•', hint='已設定' if self.PW.get('birthday') else '')
        N('密碼跟上面不一樣的銀行：一行一家，「銀行簡稱 密碼」，例如「星展 19850406」。')
        others = [k for k in self.PW if k not in ('default', 'birthday', '說明') and self.PW[k]]
        if others:
            N('目前另外設定的銀行：' + '、'.join(others) + '（要改就再輸入一次）')
        self.t_banks = tk.Text(f, height=3, font=('Microsoft JhengHei UI', 10)); self.t_banks.pack(fill='x', pady=4)

        H('手機隨手記')
        N('用同一組帳號密碼，每天更新時會自動抓隨手記的紀錄，月報也會加密放到隨手記網站。')
        L = self.S.get('ledger') or {}
        blank = lambda v: not v or '填' in str(v)
        self.e_url = self.field(f, '隨手記網址', value=L.get('url') or 'https://alexledger.netlify.app')
        self.e_user = self.field(f, '帳號', value='' if blank(L.get('user')) else L.get('user', ''))
        self.e_lpw = self.field(f, '密碼（空白＝不修改）', show='•', hint='已設定' if not blank(L.get('password')) else '')

        bf = ttk.Frame(f); bf.pack(fill='x', pady=(16, 0))
        ttk.Button(bf, text='其他設定（信箱收帳單、寄月報、線上版）…', command=self.advanced).pack(side='left')
        ttk.Button(bf, text='儲存', command=self.save).pack(side='right')
        ttk.Button(bf, text='取消', command=w.destroy).pack(side='right', padx=6)

    def field(self, f, label, show='', value='', hint=''):
        r = ttk.Frame(f); r.pack(fill='x', pady=2)
        ttk.Label(r, text=label, width=24).pack(side='left')
        e = ttk.Entry(r, show=show); e.pack(side='left', fill='x', expand=True)
        if value:
            e.insert(0, value)
        if hint:
            ttk.Label(r, text=hint, foreground='#2e7d32').pack(side='left', padx=4)
        return e

    def save(self):
        d, bd = self.e_def.get().strip(), self.e_bd.get().strip()
        if bd and not re.fullmatch(r'\d{8}', bd):
            messagebox.showwarning('LifeLedger', '生日要 8 碼數字，例如 19850406', parent=self.w); return
        if d:
            self.PW['default'] = d
        if bd:
            self.PW['birthday'] = bd
        for line in self.t_banks.get('1.0', 'end').splitlines():
            parts = line.strip().split(None, 1)
            if len(parts) == 2:
                self.PW[parts[0]] = parts[1].strip()
            elif line.strip():
                messagebox.showwarning('LifeLedger', f'這行看不懂：「{line.strip()}」\n格式是「銀行簡稱 密碼」，中間空一格。', parent=self.w); return
        self.PW.setdefault('說明', '各銀行帳單 PDF 的開啟密碼；default 是共用的，銀行名稱的那一行會優先使用')
        L = self.S.setdefault('ledger', {})
        L['url'] = self.e_url.get().strip() or 'https://alexledger.netlify.app'
        if self.e_user.get().strip():
            L['user'] = self.e_user.get().strip()
        if self.e_lpw.get():
            L['password'] = self.e_lpw.get()
        json.dump(self.PW, open(self.PP, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
        json.dump(self.S, open(self.SP, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
        self.say('✓ 設定已存好（只存在這台電腦）')
        self.w.destroy()

    def advanced(self):
        # 進階設定項目多（多個信箱、Gmail 應用程式密碼、GitHub 權杖），沿用原本的問答式設定精靈
        subprocess.Popen([PY, 'setup_wizard.py'], cwd=PROG, env=ENV, creationflags=getattr(subprocess, 'CREATE_NEW_CONSOLE', 0))


if __name__ == '__main__':
    root = tk.Tk()
    App(root)
    root.mainloop()
